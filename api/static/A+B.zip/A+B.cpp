#include<cstdio>

int a, b;
int main(){
	scanf("%d%d", &a, &b);
	printf("%d\n", a+b);
}