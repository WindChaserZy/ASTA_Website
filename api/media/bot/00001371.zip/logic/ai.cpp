#include "ai.h"
#include <iostream>
using namespace std;
/*
要求：模仿YouHead的植物攻击模式
0列种豌豆，1列种向日葵，2列种冰豌豆，4列种坚果。
到达底线时，如果有多只僵尸放辣椒。如果有一只僵尸放倭瓜。放完之后补种向日葵。如果豌豆冷却不足，则放置一个倭瓜。
开局：
向日葵按照从上到下的顺序种植。如果前面一格有僵尸则暂时不种。
在有僵尸的行，如果此行没有豌豆则种植一个豌豆。
如果五行的豌豆都种植完毕，则在有僵尸的行种植坚果。
如果坚果种植完毕，则在有僵尸的行种植冰豌豆。

移除植物
升级豌豆(get)
放置辣椒(get)
开局策略
阳光较多策略
*/

enum PlantType {
	NOPLANT = 0,
	SUNFLOWER,
	WINTERPEASHOOTER,
	PEASHOOTER,
	SMALLNUT,
	PEPPER,
	SQUASH
};
enum ZombieType {
	NOZOMBIE = 0,
	NORMAL,
	BUCKET,
	POLEVAULT,
	SLED,
	GARGANTUAR
};
enum TryPlant {
	SUCCEED = 0,
	WAITCD,
	NOSPACE,
	INVALIDTYPE,
	NEEDSUN
};
const int PlantSun[6] = { 50, 100, 400, 125, 50, 50 };
const int ZombieSun[5] = { 50, 125, 125, 300, 300 };

const int LineSunFlower[] = {1,4};
const int LinePeaShooter[] = { 0 ,2, 3 };
const int LineSmallNut[] = { 5 };
const int LinePepper[] = { 9 };

void plant_ai(IPlayer *player);
void plant_ai2(IPlayer *player);

//bool plantSunFlower(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
//void plantDenfece(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
//void plantNut(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
//void plantLastLine(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);

void zombie_ai(IPlayer *player);
void zombie_ai2(IPlayer *player);

void player_ai(IPlayer *player) {
	int CampType = player->Camp->getCurrentType();
	if (CampType == 0) {	//植物代码
		//plant_ai(player);
		plant_ai2(player);
	}
	else if (CampType == 1) {
		zombie_ai(player);
	}
}
//放置向日葵
//向日葵按照从上到下的顺序种植。如果前面一格有僵尸则暂时不种。
bool plantSunFlower(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	int *line = player->Camp->getLeftLines();
	const int Rows = player->Camp->getRows();
	const int Cols = player->Camp->getColumns();
	int SunFlowerNum = 0;
	//判断阳光是否充足(大于100)，僵尸是否临近左边4格，如果临近，且向日葵大于2则停止放置向日葵.
	//判断是否临近
	int minCol = Cols;
	for (int i = 0; i < Rows; i++) {
		for (int j = 0; j < Cols; j++) {
			if (Zombies[i][j][0] != -1) {
				if (minCol > j) {
					minCol = j;
				}
			}
		}
	}
	//计算向日葵个数
	for (int i = 0; i < Rows; i++) {
		if (Plants[i][LineSunFlower[0] == SUNFLOWER]) {
			SunFlowerNum++;
		}
	}
	if (minCol < 4 && SunFlowerNum > 2) {	//如果临近，且向日葵大于2则停止放置向日葵.
		return true;
	}
	else {
		if (SunFlowerNum < 2 || player->Camp->getSun() > 100) {	//如果有放置的必要
			for (int m = 0; m < 1; m++) {
				for (int i = 0; i < player->Camp->getRows(); i++) {
					if (line[i] == 1) {
						if (Plants[i][LineSunFlower[m]] == NOPLANT && PlantsCD[SUNFLOWER - 1] == 0 && Zombies[i][LineSunFlower[m]][0] == -1 && Zombies[i][LineSunFlower[m] + 1][0] == -1) {
							player->PlacePlant(SUNFLOWER, i, LineSunFlower[m]);
							PlantsCD = player->Camp->getPlantCD();
							return true;
						}
					}
				}
			}
			for (int m = 1; m < 2; m++) {
				for (int i = 0; i < player->Camp->getRows(); i++) {
					if (line[i] == 1) {
						if (Plants[i][LineSunFlower[m]] == NOPLANT && Plants[i][LineSmallNut[0]] == SMALLNUT && PlantsCD[SUNFLOWER - 1] == 0 && Zombies[i][LineSunFlower[m]][0] == -1 && Zombies[i][LineSunFlower[m] + 1][0] == -1) {
							player->PlacePlant(SUNFLOWER, i, LineSunFlower[m]);
							PlantsCD = player->Camp->getPlantCD();
							return true;
						}
					}
				}
			}
		}
	}
}
bool isGiant(int row ,int col, int ***Zombies) {
	bool isGiant = false; //此格是否有巨人
	for (int k = 0; Zombies[row][col][k] != -1; k++) {
		isGiant = isGiant || (Zombies[row][col][k] == GARGANTUAR);
	}
	return isGiant;
}
bool isSled(int row, int col, int ***Zombies) {
	bool isSled = false;	//此格是否有雪橇车
	for (int k = 0; Zombies[row][col][k] != -1; k++) {
		isSled = isSled || (Zombies[row][col][k] == SLED);
	}
	return isSled;
}
//放置豌豆，坚果，冰豌豆
//在有僵尸的行，如果此行没有豌豆则种植一个豌豆。
//如果五行的豌豆都种植完毕，则在有僵尸的行种植坚果。在阳光充足时也可考虑种坚果。
//如果坚果种植完毕，则在有僵尸的行种植冰豌豆。在阳光充足时也可考虑种冰豌豆。

void plantDefence(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	const int Rows = player->Camp->getRows();
	const int Cols = player->Camp->getColumns();
	
	//判断当前状况
	bool ShooterFinished = false;
	bool NutFinished = false;
	bool WinterFinished[3] = { false, false, false };
	int ShooterNum = 0;
	int NutNum = 0;
	int WinterNum[3] = {0 ,0 ,0};
	int SunFlowerNum = 0;	//底线的sunflower个数
	int Leftline = player->getNotBrokenLines();

	bool putWinter = false;
	for (int i = 0; i < player->Camp->getRows(); i++) {
		if (Plants[i][LinePeaShooter[0]] == PEASHOOTER || Plants[i][LinePeaShooter[0]] == WINTERPEASHOOTER) {
			ShooterNum++;
		}
		if (Plants[i][LineSmallNut[0]] == SMALLNUT) {
			NutNum++;
		}
		if (Plants[i][LinePeaShooter[0]] == WINTERPEASHOOTER) {
			WinterNum[0]++;
		}
		if (Plants[i][LinePeaShooter[1]] == WINTERPEASHOOTER) {
			WinterNum[1]++;
		}
		if (Plants[i][LinePeaShooter[2]] == WINTERPEASHOOTER){
			WinterNum[2]++;
		}
		if (Plants[i][LineSunFlower[0]] == SUNFLOWER) {
			SunFlowerNum++;
		}
	}
	ShooterFinished = (ShooterNum == Leftline);
	NutFinished = (NutNum == Leftline);
	for (int i = 0; i < 3; i++) {
		WinterFinished[i] = (WinterNum[i] == Leftline);
	}
	//判断是否有僵尸
	//问题：阳光没有充分利用
	//如果此格有僵尸，依然会种植植物
	for (int i = 0; i < Rows; i++) {
		for (int j = 0; j < Cols; j++) {

			if (Zombies[i][j][0] != -1) {	//如果有僵尸
				if (!ShooterFinished) {
					if (Plants[i][LinePeaShooter[0]] == NOPLANT && !(isSled(i, LinePeaShooter[0], Zombies) || isGiant(i, LinePeaShooter[0], Zombies))) {
						if (player->Camp->getSun() > 550) {
							player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[0]);
						}
						else {
							player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
						}
					}
				}
				else if (!NutFinished) {
					if (Plants[i][LineSmallNut[0]] == NOPLANT && !(isSled(i, LineSmallNut[0], Zombies) || isGiant(i, LineSmallNut[0], Zombies))) {
						player->PlacePlant(SMALLNUT, i, LineSmallNut[0]);
					}
				}
				else if (!WinterFinished[1]) {
					//中间部分种植冰豌豆
					if (player->Camp->getSun() > 550 && !putWinter && Plants[i][LinePeaShooter[1]] == NOPLANT && !(isSled(i, LinePeaShooter[1], Zombies) || isGiant(i, LinePeaShooter[1], Zombies))) {
						player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[1]);
						putWinter = true;
					}
				}
				else if (!WinterFinished[0]) {
					//豌豆替换为冰豌豆
					if (player->Camp->getSun() > 550) {
						if (player->Camp->getSun() > 550 && !putWinter && !(isSled(i, LinePeaShooter[0], Zombies) || isGiant(i, LinePeaShooter[0], Zombies))) {
							if (Plants[i][LinePeaShooter[0]] == PEASHOOTER) {
								player->removePlant(i, LinePeaShooter[0]);
							}
							player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[0]);
							putWinter = true;
						}
					}
				}
				else if (!WinterFinished[2]) {
					//升级之后，在第三列种植冰豌豆
					if (player->Camp->getSun() > 550 && !putWinter && Plants[i][LinePeaShooter[2]] == NOPLANT && !(isSled(i, LinePeaShooter[2], Zombies) || isGiant(i, LinePeaShooter[2], Zombies))) {
						if (PlantsCD[WINTERPEASHOOTER - 1] == 0 && !putWinter) {
							player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[2]);
							putWinter = true;
						}
					}
				}
			}
		}
	}
	//阳光剩余时
	for (int i = 0; i < Rows; i++) {
		for (int j = 0; j < Cols; j++) {
			if (ShooterFinished && player->Camp->getSun() >= 250) {
				if (PlantsCD[SMALLNUT - 1] == 0 && Plants[i][LineSmallNut[0]] == NOPLANT) {
					player->PlacePlant(SMALLNUT, i, LineSmallNut[0]);
				}
			}
			if (Plants[i][LineSmallNut[0]] == SMALLNUT) {
				//中间部分种植冰豌豆
				if (!WinterFinished[1]) {
					if (player->Camp->getSun() > 550 && !putWinter && Plants[i][LinePeaShooter[1]] == NOPLANT && !(isSled(i, LinePeaShooter[1], Zombies) || isGiant(i, LinePeaShooter[1], Zombies))) {
						player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[1]);
						putWinter = true;
					}
				}
				else if (!WinterFinished[2]) {
					//升级之后，在第三列种植冰豌豆
					if (player->Camp->getSun() > 550 && !putWinter && Plants[i][LinePeaShooter[2]] == NOPLANT && !(isSled(i, LinePeaShooter[2], Zombies) || isGiant(i, LinePeaShooter[2], Zombies))) {
						player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[2]);
						putWinter = true;
					}
				}
			}
		}
	}
	
}
//放置辣椒，如果没有突破防线的僵尸，且一行的僵尸大于或等于3个则放置辣椒
//如果应该放置辣椒而没有放置，则返回的布尔值为false，等待阳光恢复后放置
//放置辣椒和倭瓜的策略还要斟酌
//当防线建立起来时，考虑在坚果被攻破时放置倭瓜。优先级在防线建设后面。
//当植物较多时，即使未到达底线也应该放置辣椒或者倭瓜。
bool plantPepper(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	for (int i = 0; i < player->Camp->getRows(); i++) {
		for (int j = 0; j < player->Camp->getColumns() - 6; j++) {
			if (Zombies[i][j][0] != -1) {
				return true;
			}
		}
	}
	for (int i = 0; i < player->Camp->getRows(); i++) {
		int CountZombie = 0;	//第i行僵尸的个数
		for (int j = 0; j < player->Camp->getColumns(); j++) {
			for (int k = 0; Zombies[i][j][k] != -1; k++) {
				CountZombie++;
			}
		}
		if (CountZombie > 2) {
			if (PlantsCD[PEPPER - 1] == 0) {
				player->PlacePlant(PEPPER, i, LinePepper[0]);
				return true;
			}
			else {
				return false;
			}
		}
	}
	return true;
}
//放置底线辣椒、倭瓜
//只在开局有效
//到达底线时，如果有多只僵尸放辣椒。如果僵尸在同一格放倭瓜。(放完之后补种向日葵。如果豌豆冷却不足，则放置一个倭瓜。)
void plantLastLine(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	for (int i = 0; i < player->Camp->getRows(); i++) {

		if (Zombies[i][0][0] != -1) {
			//僵尸已经到达底线
			////统计僵尸个数
			//int zCount = 0;
			////统计最后一格僵尸个数
			//int lastLineCount = 0;
			//for (int j = 0; j < player->Camp->getColumns(); j++) {
			//	for (int k = 0; Zombies[i][j][k] != -1; k++) {
			//		zCount++;
			//		if (j == 0) {
			//			lastLineCount++;
			//		}
			//	}
			//}
			if (PlantsCD[SQUASH - 1] == 0) {
					player->PlacePlant(SQUASH, i, 0);
			}else if (PlantsCD[PEPPER - 1] == 0) {
					player->PlacePlant(PEPPER, i, LinePepper[0]);
			}
		}

	}
}
//有计时功能，在僵尸进入前方一格的3回合内铲植物
void plantRemove(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	//for (int i = 0; i < player->Camp->getRows(); i++) {
	//	for (int j = 0; j < player->Camp->getColumns() - 1; j++) {
	//		if (Plants[i][j] == SUNFLOWER && Plants[i][j + 1] == NOPLANT && Zombies[i][j + 1][0] != -1) {
	//			player->removePlant(i, j);
	//		}
	//	}
	//}
}
void plant_ai(IPlayer *player) {
	int ***Zombies = player->Camp->getCurrentZombies();
	int **Plants = player->Camp->getCurrentPlants();
	int *PlantsCD = player->Camp->getPlantCD();

	plantRemove(player, Zombies, Plants, PlantsCD);
	plantLastLine(player, Zombies, Plants, PlantsCD);
	plantSunFlower(player, Zombies, Plants, PlantsCD);
	plantPepper(player, Zombies, Plants, PlantsCD);
	plantDefence(player, Zombies, Plants, PlantsCD);
}
const int WinterLine2[] = {0,1,2,3,4,6};
int TryPlacePlant(IPlayer *const player, int PlantType, int x, int y) {
	if (PlantType < 1) {
#ifdef DEBUG
		cout << "Invalid PlantType! " << endl;
#endif // DEBUG
		return INVALIDTYPE;
	}
	if (player->Camp->getPlantCD()[PlantType - 1] > 0) {
		return WAITCD;
	}
	if (player->Camp->getCurrentPlants()[x][y] != NOPLANT) {
		return NOSPACE;
	}
	else if (player->Camp->getSun() < PlantSun[PlantType - 1]) {
		return NEEDSUN;
	}
	else
	{
		player->PlacePlant(PlantType, x, y);
		return SUCCEED;
	}
}
void plantDefence2(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	// 新的策略：以冰豌豆为主
	// 初期大量种植向日葵，当阳光数充分多时铲除向日葵种植冰豌豆
	// 初期防御和之前一样
	// 除去1，3列，冰豌豆都是先铲除向日葵再种植
	// 开局先在底线种豌豆，第二线种向日葵
	// 第3列出冰豌豆，在有冰豌豆的列前方种植3向日葵
	// 当五行冰豌豆都种植完毕，则铲除底线豌豆种植冰豌豆
	// 当底线豌豆替换完毕，铲除向日葵种植冰豌豆
	// 铲除条件还有阳光数超过2000/2500/3000，顺序从左到右
	// 辣椒放在最右边一列
	//
	//囤倭瓜，在第8列
	//囤坚果，在第7列

	//
	const int Rows = player->Camp->getRows();
	const int Cols = player->Camp->getColumns();

	//判断当前状况
	bool ShooterFinished = false;
	bool WinterFinished[] = { false, false, false, false, false, false};
	int ShooterNum = 0;
	int WinterNum[] = { 0 ,0 ,0, 0, 0, 0 };
	int Leftline = player->getNotBrokenLines();

	bool putWinter = false;
	for (int i = 0; i < player->Camp->getRows(); i++) {
		if (Plants[i][LinePeaShooter[0]] == PEASHOOTER || Plants[i][LinePeaShooter[0]] == WINTERPEASHOOTER) {
			ShooterNum++;
		}
		for (int j = 0; j < 6; j++) {
			if (Plants[i][WinterLine2[j]] == WINTERPEASHOOTER) {
				WinterNum[j]++;
			}
		}
	}
	ShooterFinished = (ShooterNum == Leftline);
	for (int i = 0; i < 6; i++) {
		WinterFinished[i] = (WinterNum[i] == Leftline);
	}
	bool ZombieOnLawn = false; //场上是否有僵尸，如果无僵尸，阳光超过800时放置僵尸
	for (int i = 0; i < Rows; i++) {
		bool isZombie = false;
		for (int j = 0; j < Cols && !isZombie; j++) {
			if (Zombies[i][j][0] != -1) {
				isZombie = true;
			}
		}
		ZombieOnLawn = ZombieOnLawn || isZombie;
		if (isZombie || (!isZombie && player->Camp->getSun() > 1000)) { //此行有僵尸或者没有僵尸且阳光数大于1000
			if (Plants[i][0] == NOPLANT) {
				// 如果僵尸已经推进到最左侧或者有铁桶则放弃种植豌豆
				bool isBucket = false;
				int bucketCol = 9;
				int leftzombie = 9;
				for (int j = 0; j < Cols; j++) {
					for (int k = 0; Zombies[i][j][k] != -1; k++) {
						switch (Zombies[i][j][0])
						{
						case NORMAL:		//普僵
							if (Plants[i][LinePeaShooter[0]] == NOPLANT) {
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
							}
							if (j < 5) {
								if (TryPlacePlant(player, SMALLNUT, i, j) == WAITCD || TryPlacePlant(player, SMALLNUT, i, j) == NEEDSUN) {
									if (Plants[i][LinePeaShooter[0]] != PEASHOOTER && Plants[i][LinePeaShooter[0]] != WINTERPEASHOOTER) {
										player->removePlant(i, LinePeaShooter[0]);
									}
									player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
								}
							}
							break;
						case BUCKET:		//铁桶
							if (Plants[i][LinePeaShooter[1]] == NOPLANT) {
								if (TryPlacePlant(player, SQUASH, i, j) == WAITCD) {
									player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
								}
							}
							else if (Plants[i][LinePeaShooter[2]] == NOPLANT) {
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[2]);
							}
							else if (Plants[i][j] == NOPLANT) {
								player->PlacePlant(SMALLNUT, i, j);
							}

							break;
						case POLEVAULT:		//撑杆
							if (Plants[i][LinePeaShooter[1]] == NOPLANT) {
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
							}
							if (TryPlacePlant(player, SMALLNUT, i, j) == WAITCD || TryPlacePlant(player, SMALLNUT, i, j) == NEEDSUN) {
								if (Plants[i][LinePeaShooter[0]] != PEASHOOTER && Plants[i][LinePeaShooter[0]] != WINTERPEASHOOTER) {
									player->removePlant(i, LinePeaShooter[0]);
								}
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
							}

							break;
						case SLED:		//雪橇车
							if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED) {

							}
							else if (TryPlacePlant(player, PEPPER, i, j) == SUCCEED)
							{

							}
							else {
								TryPlacePlant(player, PEASHOOTER, i, LinePeaShooter[0]);
							}
							break;
						case GARGANTUAR:		//伽刚特尔
							if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED &&
								TryPlacePlant(player, PEPPER, i, j) == SUCCEED) {

							}
							else {
								TryPlacePlant(player, WINTERPEASHOOTER, i, LinePeaShooter[0]);
							}
							break;
						default:
							break;
						}
						//适时放置倭瓜
						if (PlantsCD[SQUASH] <= 0) {
							if (k > 3) {	//如果有3个以上的僵尸
								TryPlacePlant(player, SQUASH, i, j);
							}
						}
					}
				}
			}
			else if (ShooterFinished) { //如果射手完成
				if (!WinterFinished[2]) {
					if (!putWinter && Plants[i][2] == NOPLANT && player->Camp->getSun() > 450 && PlantsCD[WINTERPEASHOOTER - 1] == 0) {
						player->PlacePlant(WINTERPEASHOOTER, i, 2);
						putWinter = true;
					}
				}
				else if(!WinterFinished[0]){
					if (!putWinter && (Plants[i][0] == NOPLANT || Plants[i][0] == PEASHOOTER) && player->Camp->getSun() > 450 && PlantsCD[WINTERPEASHOOTER - 1] == 0) {
						player->removePlant(i, 0);
						player->PlacePlant(WINTERPEASHOOTER, i, 0);
						putWinter = true;
					}
				}
				else if (!WinterFinished[1]) {
					if (!putWinter && (Plants[i][1] == NOPLANT || Plants[i][1] == SUNFLOWER) && player->Camp->getSun() > 1000 && PlantsCD[WINTERPEASHOOTER - 1] == 0) {
						player->removePlant(i, 1);
						player->PlacePlant(WINTERPEASHOOTER, i, 1);
						putWinter = true;
					}
				}
				else {
					bool flag = true;
					for (int j = 3; j < 6; j++) {
						if (!WinterFinished[j]) {
							if (!putWinter && (Plants[i][WinterLine2[j]] == NOPLANT || Plants[i][WinterLine2[j]] == PEASHOOTER || Plants[i][WinterLine2[j]] == SUNFLOWER) && player->Camp->getSun() > 1500 && PlantsCD[WINTERPEASHOOTER - 1] == 0) {
								player->removePlant(i, WinterLine2[j]);
								player->PlacePlant(WINTERPEASHOOTER, i, WinterLine2[j]);
								putWinter = true;
							}
						}
					}
				}
			}
			//囤坚果
			if (Plants[i][7] == NOPLANT && player->Camp->getSun() > 400 && Zombies[i][7][0] == -1) {
				player->PlacePlant(SMALLNUT, i, 7);
			}
		}

	}
	//囤倭瓜
	if (!ZombieOnLawn && player->Camp->getSun() > 500) {
		bool flag = true;
		for (int i = 0; i < Rows; i++) {
			for (int j = 8; j < Cols; j++) {
				if (Plants[i][j] == NOPLANT) {
					player->PlacePlant(SQUASH, i, j);
				}
			}
		}
	}
}
//阳光数大于150时才放置向日葵
void plantSunFlower2(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	const int Row = player->Camp->getRows();
	const int Column = player->Camp->getColumns();
	int sunNum = 0;
	bool sunFinished;
	int winterNum = 0;
	bool winterFinished;
	int leftLine = player->getNotBrokenLines();
	if (player->Camp->getSun() > 150) {
		for (int i = 0; i < Row; i++) {
			if (Plants[i][1] == SUNFLOWER) {
				sunNum++;
			}
		}
		sunFinished = (sunNum == leftLine);
		for (int i = 0; i < Row; i++) {
			if (Plants[i][1] == WINTERPEASHOOTER) {
				winterNum++;
			}
		}
		//cout << "Leftline: " << leftLine << ", sunFinished: " << sunFinished << ", sunNum: " << sunNum << endl;
		sunFinished = (sunNum == leftLine);
		winterFinished = (winterNum == leftLine);
		if (!sunFinished) {

			int i = 0;
			while (i < 5 && Plants[i][1] != NOPLANT) {
				i++;

			}
			//cout << "sun not finished, i: " << i;
			if (i < 5) {
				//cout << ", plant sunflower, CD:	" << PlantsCD[SUNFLOWER - 1];
				player->PlacePlant(SUNFLOWER, i, 1);
			}
			//cout << endl;
		}
		if (sunFinished || winterFinished) {
			bool flag = true;
			for (int i = 0; i < Row && flag; i++) {

				if (Plants[i][2] == WINTERPEASHOOTER) {
					int j = 3;
					while (j < 6 && flag)
					{
						if (Plants[i][j] == NOPLANT) {
							player->PlacePlant(SUNFLOWER, i, j);
							flag = false;
						}
						j++;
					}
				}
			}
		}
	}
	
}
void plant_ai2(IPlayer *player) {
	int ***Zombies = player->Camp->getCurrentZombies();
	int **Plants = player->Camp->getCurrentPlants();
	int *PlantsCD = player->Camp->getPlantCD();

	//plantRemove(player, Zombies, Plants, PlantsCD);
	plantLastLine(player, Zombies, Plants, PlantsCD);
	plantSunFlower2(player, Zombies, Plants, PlantsCD);
	plantPepper(player, Zombies, Plants, PlantsCD);
	plantDefence2(player, Zombies, Plants, PlantsCD);
}
// 放置撑杆跳僵尸和铁桶僵尸。
// 优先挑选植物阳光总数少的行放
const int PlantCost[] = {0, 50, 400, 100, 50,125, 50 };
void zombie_ai2(IPlayer *player) {
	int ***Zombies = player->Camp->getCurrentZombies();
	int **Plants = player->Camp->getCurrentPlants();
	int *PlantsCD = player->Camp->getPlantCD();
	const int Rows = player->Camp->getRows();
	const int Cols = player->Camp->getColumns();
	int PlantSunSum[5] = { 0 };
	int minRow = 0;
	int t = player->getTime() % Rows;
	player->PlaceZombie(POLEVAULT, t);
	player->PlaceZombie(BUCKET, (t + 1) % Rows);
}
//enum PlantType
//{
//    NOPLANT = 0,                                  //血量           阳光           冷却
//    SUNFLOWER,                                  //300            50            10/20
//    WINTERPEASHOOTER,                           //300            400           30/3
//    PEASHOOTER,                                 //300            100           10/2
//    SMALLNUT,                                   //4000           50            40
//    PEPPER,                                     //300            125           60
//    SQUASH                                      //300            50            60
//};
//
//enum ZombieType
//{
//    NOZOMBIE = 0,                                  //血量           阳光           冷却           移速
//    NORMAL,                                      //270            50             15            0.2
//    BUCKET,                                      //820            125            20            0.2
//    POLEVAULT,                                   //200            125            20            1/2.5,1/4.5
//    SLED,                                        //1600           300            25            1/3,...,1/8
//    GARGANTUAR                                   //3000           300            25            0.2
//};

enum TryZombie
{
	VacantRow = 0,
	Succeed,
	WaitCD,
	NoSun,
	GiveUp
};

const int bloodZombie[6] = { 0,270,820,200,1600,3000 };

const int ZombieSun2[6] = { 0,50, 125, 125, 300, 300 };

int TryPlaceZombie(IPlayer *const player, int ZombieType, int x, int *Z, int *P)
{
	int *PlantCD = player->Camp->getPlantCD();

	if (player->Camp->getSun() < ZombieSun2[ZombieType])return NoSun;
	else
	{
		if (PlantCD[ZombieType - 1] > 0)return WaitCD;
		else if (player->Camp->getSun() < 1000 && (Z[x] > 60))return GiveUp;
		else if (player->Camp->getSun() >= 1000 && (Z[x] > 80))return GiveUp;
		else return Succeed;
	}

}



void swap(int &a, int &b)
{
	int n;
	n = a;
	a = b;
	b = n;
}

static int inta = 0;
static int intb = 0;
static int intc = 0;
static int intd = 0;
static int n = 0;

//选手代码在下方填入
void zombie_ai(IPlayer *player)
{
	int time = player->getTime();
	const int rows = player->Camp->getRows();
	const int columns = player->Camp->getColumns();
	int *PlantCD = player->Camp->getPlantCD();
	int **Plants = player->Camp->getCurrentPlants();
	int ***Zombies = player->Camp->getCurrentZombies();
	int *LeftLines = player->Camp->getLeftLines();
	int Sun = player->Camp->getSun();




	int i1, j1, k1;
	int i2, j2;
	int *bloodP = new int[rows];
	int *bloodZ = new int[rows];
	int *attackP = new int[rows];

	int *order = new int[rows];
	int *order2 = new int[rows];
	int *order3 = new int[rows];

	int *P_Rows = new int[rows];
	int *Z_Rows = new int[rows];
	int KindZombie[5][6] = { 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0 };




	for (i1 = 0; i1 < rows; i1++)
	{
		bloodZ[i1] = 0;
		for (j1 = 0; j1 < columns; j1++)
		{
			k1 = 0;
			while (Zombies[i1][j1][k1] != -1)
			{
				if (Zombies[i1][j1][k1] == NORMAL) { bloodZ[i1] += 270; KindZombie[i1][NORMAL] += 1; }
				else if (Zombies[i1][j1][k1] == POLEVAULT) { bloodZ[i1] += 200; KindZombie[i1][POLEVAULT] += 1; }
				else if (Zombies[i1][j1][k1] == BUCKET) { bloodZ[i1] += 820; KindZombie[i1][BUCKET] += 1; }
				else if (Zombies[i1][j1][k1] == SLED) { bloodZ[i1] += 1600; KindZombie[i1][SLED] += 1; }
				else if (Zombies[i1][j1][k1] == GARGANTUAR) { bloodZ[i1] += 3000; KindZombie[i1][GARGANTUAR] += 1; }
				k1++;
			}
		}
	}


	for (i2 = 0; i2 < rows; i2++)
	{
		bloodP[i2] = 0; attackP[i2] = 0; int judgewinter = 0;
		for (j2 = 0; j2 < columns; j2++)
		{
			if (Plants[i2][j2] == NOPLANT);
			else if (Plants[i2][j2] == SMALLNUT)bloodP[i2] += 4000;
			else
			{
				bloodP[i2] += 300;
				if (Plants[i2][j2] == PEASHOOTER)attackP[i2] += 10;
				else if (Plants[i2][j2] == WINTERPEASHOOTER) { attackP[i2] += 20; judgewinter = 1; }
				else;
			}
		}
		if (judgewinter == 1) { attackP[i2] = attackP[i2] * 2; }
	}




	for (i2 = 0; i2 < rows; i2++)
	{
		P_Rows[i2] = (((bloodP[i2] / 75) + 50) * attackP[i2]) / 50;
		Z_Rows[i2] = bloodZ[i2] / (P_Rows[i2] + 1);
	}

	for (i1 = 0; i1 < rows; i1++)
	{
		order[i1] = i1;
	}
	for (i1 = 0; i1 < rows - 1; i1++)
	{
		k1 = i1;
		for (i2 = i1 + 1; i2 < rows; i2++)
		{
			if (P_Rows[order[k1]] > P_Rows[order[i2]])k1 = i2;
		}
		swap(order[k1], order[i1]);
	}
	for (i1 = 0; i1 < rows; i1++)
	{
		order2[i1] = i1;
	}
	for (i1 = 0; i1 < rows - 1; i1++)
	{
		k1 = i1;
		for (i2 = i1 + 1; i2 < rows; i2++)
		{
			if (bloodP[order2[k1]] > bloodP[order2[i2]])k1 = i2;
		}
		swap(order2[k1], order2[i1]);
	}
	for (i1 = 0; i1 < rows; i1++)
	{
		order3[i1] = i1;
	}
	for (i1 = 0; i1 < rows - 1; i1++)
	{
		k1 = i1;
		for (i2 = i1 + 1; i2 < rows; i2++)
		{
			if (attackP[order3[k1]] > attackP[order3[i2]])k1 = i2;
		}
		swap(order3[k1], order3[i1]);
	}

	int n2;
	if (LeftLines[order[0]] == 0)n2 = rows - 1;
	else n2 = rows - 2;

	if (time <= 400)
	{


		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
					}
				}
			}

		}
	}
	else if (time > 400 && time <= 497)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[NORMAL]) > 400))
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[BUCKET]) > 400))
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[BUCKET]) > 400))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[NORMAL]) > 400))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[BUCKET]) > 400))
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[BUCKET]) > 400))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[NORMAL]) > 400))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[GARGANTUAR]) > 400))
							player->PlaceZombie(GARGANTUAR, order[i1]);
					}
				}
			}

		}

	}
	else if (time > 497 && time <= 502)
	{
		if (time == 498)
		{
			inta = order2[4];
			intb = order2[3];
			intc = order2[2];
			intd = order2[1];

		}
		if ((TryPlaceZombie(player, GARGANTUAR, inta, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[inta] == 1 && Z_Rows[inta] < 50 && attackP[inta] < 60)
		{
			if (bloodZ[inta] < 1600)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if (LeftLines[intb] == 0 && LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if ((TryPlaceZombie(player, GARGANTUAR, intb, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intb] == 1 && Z_Rows[intb] < 50 && attackP[intb] < 60)
			{
				if (bloodZ[intb] < 1600)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intc, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intc] == 1 && Z_Rows[intc] < 50 && attackP[intc] < 60)
				{

					player->PlaceZombie(GARGANTUAR, intc);
					n++;

				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intd, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intd] == 1 && Z_Rows[intd] < 50 && attackP[intd] < 60)
				{

					player->PlaceZombie(GARGANTUAR, intd);
					n++;

				}
			}

		}
		if (n == 0 || n == 1)
		{
			if ((TryPlaceZombie(player, GARGANTUAR, inta, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[inta] == 1)
			{
				if (bloodZ[inta] < 1600)
				{
					player->PlaceZombie(GARGANTUAR, inta);
					n++;
				}
				else if (LeftLines[intb] == 0 && LeftLines[intc] == 0 && LeftLines[intd] == 0)
				{
					player->PlaceZombie(GARGANTUAR, inta);
					n++;
				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intb, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intb] == 1)
				{
					if (bloodZ[intb] < 1600)
					{
						player->PlaceZombie(GARGANTUAR, intb);
						n++;
					}
					else if ((TryPlaceZombie(player, GARGANTUAR, intc, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intc] == 1)
					{

						player->PlaceZombie(GARGANTUAR, intc);
						n++;

					}
					else if ((TryPlaceZombie(player, GARGANTUAR, intd, Z_Rows, P_Rows) == Succeed) && (n == 0 || n == 1) && LeftLines[intd] == 1)
					{

						player->PlaceZombie(GARGANTUAR, intd);
						n++;

					}
				}

			}
		}



		if (time == 502)
		{
			inta = 0; intb = 0; intc = 0; intd = 0;  n = 0;
		}
	}
	else if (time > 502 && time <= 900)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 120)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
								player->PlaceZombie(SLED, order[i1]);
						}
					}
				}
				else if (P_Rows[order[i1]] <= 180)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);

					}
				}
			}

		}
	}
	else if (time > 900 && time <= 997)
	{



		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[NORMAL]) > 1000))
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[BUCKET]) > 1000))
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[NORMAL]) > 1000))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[NORMAL]) > 1000))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 120)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[SLED]) > 1000))
								player->PlaceZombie(SLED, order[i1]);
						}
					}
				}
				else if (P_Rows[order[i1]] <= 180)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);
					}
					else if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);

					}
				}
			}

		}
	}
	else if (time > 997 && time <= 1002)
	{

		for (i1 = 4; i1 >= 1; i1--)
		{
			if (LeftLines[order3[i1]] == 0)continue;
			else
			{

				if (P_Rows[order3[i1]] <= 120)
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
								player->PlaceZombie(SLED, order3[i1]);
						}
					}
				}
				else if (P_Rows[order3[i1]] <= 180)
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);
					}
					else if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						else if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);

					}
				}
			}

		}

		if (time == 1002)
		{
			inta = 0; intb = 0; intc = 0; intd = 0; n = 0;
		}
	}
	else if (time > 1002 && time <= 1400)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 120)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
								player->PlaceZombie(SLED, order[i1]);
						}
					}
				}
				else if (P_Rows[order[i1]] <= 180)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);

					}
				}
			}

		}
	}
	else if (time > 1400 && time <= 1497)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[NORMAL]) > 1000))
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[BUCKET]) > 1000))
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[NORMAL]) > 1000))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[BUCKET]) > 1000))
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[NORMAL]) > 1000))
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 120)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[SLED]) > 1000))
								player->PlaceZombie(SLED, order[i1]);
						}
					}
				}
				else if (P_Rows[order[i1]] <= 180)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);
					}
					else if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[GARGANTUAR]) > 1000))
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[SLED]) > 1000))
							player->PlaceZombie(SLED, order[i1]);

					}
				}
			}

		}
	}
	else if (time > 1497 && time <= 1502)
	{
		for (i1 = 4; i1 >= 1; i1--)
		{
			if (LeftLines[order3[i1]] == 0)continue;
			else
			{

				if (P_Rows[order3[i1]] <= 120)
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
								player->PlaceZombie(SLED, order3[i1]);
						}
					}
				}
				else if (P_Rows[order3[i1]] <= 180)
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);
					}
					else if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						else if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order3[i1]][GARGANTUAR] + KindZombie[order3[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order3[i1]);
						if (TryPlaceZombie(player, SLED, order3[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order3[i1]);

					}
				}
			}

		}


		if (time == 1502)
		{
			inta = 0; intb = 0; intc = 0; intd = 0;  n = 0;
		}
	}
	else if (time > 1502)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else
			{
				if (P_Rows[order[i1]] <= 6)
				{
					if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(NORMAL, order[i1]);
				}
				else if (P_Rows[order[i1]] <= 18)
				{
					if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
						player->PlaceZombie(BUCKET, order[i1]);
					else;
				}
				else if (P_Rows[order[i1]] <= 24)
				{
					if (KindZombie[order[i1]][BUCKET] < 1)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 1)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 36)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 48)
				{
					if (KindZombie[order[i1]][BUCKET] < 2)
					{
						if (TryPlaceZombie(player, BUCKET, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(BUCKET, order[i1]);
					}
					if (KindZombie[order[i1]][NORMAL] < 2)
					{
						if (TryPlaceZombie(player, NORMAL, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(NORMAL, order[i1]);
					}
				}
				else if (P_Rows[order[i1]] <= 120)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else
						{
							if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
								player->PlaceZombie(SLED, order[i1]);
						}
					}
				}
				else if (P_Rows[order[i1]] <= 180)
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 0)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] == 1)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						else if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);
					}
					else;
				}
				else
				{
					if (KindZombie[order[i1]][GARGANTUAR] + KindZombie[order[i1]][SLED] < 3)
					{
						if (TryPlaceZombie(player, GARGANTUAR, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(GARGANTUAR, order[i1]);
						if (TryPlaceZombie(player, SLED, order[i1], Z_Rows, P_Rows) == Succeed)
							player->PlaceZombie(SLED, order[i1]);

					}
				}
			}

		}
	}

}