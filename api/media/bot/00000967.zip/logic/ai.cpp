#include "ai.h"
#include"stdio.h"
#include <ctime>
#include <cstdlib>
#define ROW 5
#define COLUMN 10
#define SHOOTCD 3
#define SUNCD 21
//#define FILE stdout
#define _FILE p
#define INF 1000000
//坐标点类
static struct Point {
    int x;
    int y;
    Point() {
        x = -1;
        y = -1;
    }
    Point(int x, int y) {
        this->x = x;
        this->y = y;
    }
};
void printfString(char* p) {
    FILE* tp;
    //fopen_s(&tp, "string.txt", "a");
    //fprintf(tp, "%s", p);
    //fclose(tp);
}
void printfInt(int a) {
    FILE* tp;
    //fopen_s(&tp, "string.txt", "a");
    //fprintf(tp, "%d", a);
    //fclose(tp);
}
//遍历得到植物的个数(在原地图上获得信息)
int SearchForPlantSum(int type, int** plants) {
    int ans = 0;
    for(int i=0;i<ROW;i++)
        for (int j = 0; j < COLUMN; j++) {
            if (plants[i][j] == type) {
                ans++;
            }
        }
    return ans;
}
//植物/僵尸阳光常数组
const int PLANTSUN[] = {0,50,400,100,50,125,50};//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
const int ZOMBIESUN[] = { 0,50,125,125,300,300 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//CD常数组
const int PLANTSCD[] = { 0,10,30,10,40,60,60 };//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
const int ZOMBIESCD[] = { 0,15,20,20,25,25 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//僵尸速度数组
double ZOMBIESVELOCITYTRUE[] = { 0,0.2,0.2,1 / 2.5,1 / 3.0,0.2 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
double ZOMBIESVELOCITYFALSE[] = { 0,0.2,0.2,1 / 4.5,1 / 8.0,0.2 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//冰车速度数组(在不同的格子速度不同)
double SLEDVELOITYTRUE[] = { 0.33333,0.28126,0.22917,0.17708,0.125 };

//植物类
static struct Plant
{
    Point pos;
    int type;
    int blood;
    int shootCD;
    int attack;
    int winter;
    //构造函数
    Plant() {
        Point _pos;
        _pos.x = -1;
        _pos.y = -1;
        this->pos = _pos;
        this->type = 0;
        this->blood = 0;
    }
    //初始化
    void init(int type,int x,int y) {
        pos.x = x;
        pos.y = y;
        shootCD = 0;
        attack = 0;
        this->type = type;
        blood = 300;  
        winter = 0;
        //寒冰射手
        if (type == 2) {
            this->attack = 60;
            this->winter = 1;
        }//豌豆射手
        else if (type == 3) {
            this->attack = 20;
        }//坚果
        else if (type == 4) {
            this->blood = 4000;
        }//火爆辣椒
        else if (type == 5) {
            this->attack = 1800;
        }//倭瓜
        else if (type == 6) {
            this->attack = 1800;
        }//什么都没有
        else if (type == 0) {
            blood = 0;
            shootCD = 0;
        }
    }
    //检测是否有植物或者植物血量为0消失(如果有植物返回1否则返回0)
    int ifHavePlant() {
        if (this->type == 0 || this->blood <= 0)
            return 0;
        return 1;
    }
    //检测植物是否死亡(死亡返回1，未死亡返回0)
    int ifPlantDead() {
        return blood <= 0;
    }
}; 
//僵尸基础信息
//僵尸类
static struct Zombie
{
    /*僵尸具体信息*/
    Point pos;//位置
    float detailPos;//浮点位置
    int type;//僵尸种类
    int blood;//血量
    int flag;//用于撑杆跳等僵尸的判据(True代表没有跳,False代表跳过了)
    int winterstep;//僵尸的减速剩余回合
    double velocity;//僵尸速度
    int attack;//僵尸攻击
    int Step;//已经到第几阶段(冰车僵尸使用)
/*操作*/
    //构造函数
    Zombie() {
        Point _pos;
        _pos.x = -1;
        _pos.y = -1;
        this->pos = _pos;
        this->type = 0;
        this->blood = 0;
        this->attack = 0;
    }
    //初始化(僵尸刚出现)
    void init(int type, int row) {
        pos.x = row;
        pos.y = COLUMN - 1;
        this->detailPos = COLUMN;
        this->type = type;
        FILE* p;
        //fopen_s(&p, "init.txt", "a");
        //fprintf(p, "|x=%d,y=%d,detailPos=%f,Type=%d|\n", pos.x, pos.y, this->detailPos, this->type);
        //fclose(p);
        flag = 1;//未完成动作
        winterstep = 0;//未被减速
        Step = 0;//第0阶段
        if (type == 1)/* 普通僵尸 */ {
            velocity = 0.2;
            blood = 270;
            attack = 75;
        }//铁桶僵尸
        if (type == 2) {
            velocity = 0.2;
            blood = 550 + 270;
            attack = 75;
        }//撑杆跳僵尸
        if (type == 3) {
            velocity = 0.4;
            blood = 200;
            attack = 75;
        }//冰车僵尸
        if (type == 4) {
            velocity = 0.4;
            blood = 1600;
            attack = INF;
        }//巨人僵尸
        if (type == 5) {
            velocity = 0.2;
            blood = 3000;
            attack = INF;
        }
    }
    //检查是否有僵尸(有僵尸返回1 无僵尸返回0)
    int ifHaveZombie() {
        return type != 0;
    }
    //检查是否在对应格子内
    int checkIfInBox() {
        return detailPos >= pos.y;
    }

    //处理僵尸血量减少(仍然存活返回1否则返回0)
    int bloodDecrease(int deltablood) {
        blood -= deltablood;
        if (blood > 0)return 1;
        else return 0;
    }
    //处理撑杆跳僵尸的跳跃(跳跃返回1 未跳跃或者早跳跃完成返回0)
    //只处理僵尸的跳跃不处理攻击(也不处理寒冰状态CD)
    void polevaultJumpAndRun(Plant plant) {
        if (flag == 1)/* 没有跳过 */ {
            if (plant.ifHavePlant()) {
                detailPos -= 1;
                flag = 0;
            }
            else {
                if (winterstep == 0)
                    detailPos -= 1 / 2.5;
                else
                    detailPos -= 0.5 * 1 / 2.5;
            }
        }/* 已经完成跳跃 */else {
            if (winterstep == 0)
                detailPos -= 1 / 4.5;
            else
                detailPos -= 0.5 * 1 / 4.5;
        }
        }
    //返回冰车在每个STEP的速度
    double sledVelocity() {
        if (detailPos >= 10)
            return SLEDVELOITYTRUE[0];
        if (detailPos >= 9)
            return SLEDVELOITYTRUE[1];
        if (detailPos >= 8)
            return SLEDVELOITYTRUE[2];
        if (detailPos >= 7)
            return SLEDVELOITYTRUE[3];
        return SLEDVELOITYTRUE[4];
    }
    //处理冰车僵尸前4格的速度变化(不处理寒冰时长CD)
    //也不处理pos的变化
    void sledMoving() {
        if (winterstep == 0)
            detailPos -= sledVelocity();
        else
            detailPos -= 0.5 * sledVelocity();
    }
    //处理僵尸的正常&减速1STEP移动(包括跳跃)
    //不处理寒冰状态
    void zombieMoveStep(Plant plant) {
        if(!plant.ifHavePlant())
        //具体位置的移动
        {
            if (winterstep == 0) {
                if (type == 1 || type == 2 || type == 5)
                    detailPos -= velocity;
                if (type == 4)
                    sledMoving();
            }
            else/* 寒冰状态 */ {
                if (type == 1 || type == 2 || type == 5)
                    detailPos -= 0.5 * velocity;
                if (type == 4)
                    sledMoving();
            }
        }
        //撑杆跳作为特例(在有植物的时候也可能运动)
        if (type == 3)
            polevaultJumpAndRun(plant);
    }
    //处理僵尸攻击(注意寒冰射手的影响)
    //不处理僵尸的寒冰状态改变
    void zombieAttack(Plant& plant) {
        //如果没有植物
        if (!plant.ifHavePlant())
            return;
        //如果有植物
        else {
            //空僵尸
            if (type == 0)
                return;
            //非寒冰状态
            if (winterstep == 0) {
                plant.blood -= attack;
            }//寒冰状态
            else {
                plant.blood -= attack / 2;
            }
        }
    }
    int ifHaveAttack() {
        return detailPos < 0;
    }
};
//僵尸CD初始化

//植物统计库类(植物的库统计)
static struct Plants {
    int plants[ROW][COLUMN];//植物地图
    int sum;//该植物总数
    Plant plantsmap[ROW][COLUMN];//详细数据植物地图
    Plant** sunFlowers;//向日葵表
    int SumOfSunFlower;//向日葵数目
    Plant** winterPeaShooters;//寒冰射手表
    int SumOfWinterPeaShooters;//寒冰射手数目
    Plant** peaShooters;//豌豆射手表
    int SumOfPeaShooters;//豌豆射手数目
    Plant** smallNuts;//坚果表
    int SumOfSmallNuts;//坚果数目
    Plant** peppers;//火爆辣椒表
    int SumOfPeppers;//火爆辣椒数目
    Plant** squashs;//倭瓜表
    int SumOfSquashs;//倭瓜数目
    //CD维护数组
    int PlantsCD[7];//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
    //攻破维护数组
    int haveAttack[5];//0是未攻破，1是已攻破
    int plantSun;//植物的阳光
    //默认构造函数
    Plants() {
        plantSun = 400;
        sum = 0;
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++) {
                plants[i][j] = 0;
                plantsmap[i][j].pos.x = i;
                plantsmap[i][j].pos.y = j;
            }
        for (int i = 0; i < 7; i++)
            PlantsCD[i] = 0;
        for (int i = 0; i < ROW; i++)
            haveAttack[i] = 0;
        sunFlowers = new Plant*[50];
        SumOfSunFlower = 0;
        winterPeaShooters = new Plant*[50];
        SumOfWinterPeaShooters = 0;
        peaShooters = new Plant*[50];
        SumOfPeaShooters = 0;
        smallNuts = new Plant*[50];
        SumOfSmallNuts = 0;
        peppers = new Plant*[50];
        SumOfPeppers = 0;
        squashs = new Plant*[50];
        SumOfSquashs = 0;
    }
    //析构函数(释放各个指针分配的内存)
    ~Plants() {
        delete[]sunFlowers;
        delete[]winterPeaShooters;
        delete[]peaShooters;
        delete[]smallNuts;
        delete[]peppers;
        delete[]squashs;
    }
    //处理死亡植物
    void cleanKilledPlantsMap() {
        //植物死亡(血量小于等于0)
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++) {
                if (plantsmap[i][j].ifPlantDead())
                    plantsmap[i][j].init(0, i, j);
            }
    }
    //更新植物地图
    void RenewPlantMap(int** newplants) {
        //更新新植物(注意存在铲子)
        for(int i=0;i<ROW;i++)
            for (int j = 0; j < COLUMN; j++) {
                plants[i][j] = newplants[i][j];
                if (!plantsmap[i][j].ifHavePlant()) {
                    plantsmap[i][j].init(newplants[i][j], i, j);
                    PlantsCD[newplants[i][j]] = PLANTSCD[newplants[i][j]];
                }
                if (plantsmap[i][j].ifHavePlant() && plantsmap[i][j].type != newplants[i][j]) {
                    plantsmap[i][j].init(newplants[i][j], i, j);
                    PlantsCD[newplants[i][j]] = PLANTSCD[newplants[i][j]];
                }
                if (newplants[i][j] == 0)
                    plantsmap[i][j].init(newplants[i][j], i, j);
            }
    }
    //输出植物地图
    void PrintPlantMap(FILE*p) {
        fprintf(_FILE,"***********************\n");
        for (int i = 0; i < ROW; i++) {
            fprintf(_FILE,"* ");
            for (int j = 0; j < COLUMN; j++) {
                fprintf(_FILE, "%d ", plantsmap[i][j].type);
            }
            fprintf(_FILE,"*\n");
        }
        fprintf(_FILE, "***********************\n");
    }
    //输出植物血量地图
    void PrintPlantBloodMap(FILE*p) {
        fprintf(_FILE, "*****************************************************\n");
        for (int i = 0; i < ROW; i++) {
            fprintf(_FILE, "* ");
            for (int j = 0; j < COLUMN; j++) {
                fprintf(_FILE, "%4.d ", plantsmap[i][j].blood);
            }
            fprintf(_FILE,"*\n");
        }
        fprintf(_FILE, "*****************************************************\n");
    }
    //更新各植物表
    void renewPlantList() {
        SumOfSunFlower = 0;
        SumOfWinterPeaShooters = 0;
        SumOfPeaShooters = 0;
        SumOfSmallNuts = 0;
        SumOfPeppers = 0;
        SumOfSquashs = 0;
        for(int row=0;row<ROW;row++)
            for (int column = 0; column < COLUMN; column++) {
                if (plantsmap[row][column].type == 1) {
                    sunFlowers[SumOfSunFlower] = &plantsmap[row][column];
                    SumOfSunFlower++;
                }
                else if (plantsmap[row][column].type == 2) {
                    winterPeaShooters[SumOfWinterPeaShooters] = &plantsmap[row][column];
                    SumOfWinterPeaShooters++;
                }
                else if (plantsmap[row][column].type == 3) {
                    peaShooters[SumOfPeaShooters] = &plantsmap[row][column];
                    SumOfPeaShooters++;
                }
                else if (plantsmap[row][column].type == 4) {
                    smallNuts[SumOfSmallNuts] = &plantsmap[row][column];
                    SumOfSmallNuts++;
                }
                else if (plantsmap[row][column].type == 5) {
                    peppers[SumOfPeppers] = &plantsmap[row][column];
                    SumOfPeppers++;
                }
                else if (plantsmap[row][column].type == 6) {
                    squashs[SumOfSquashs] = &plantsmap[row][column];
                    SumOfSquashs++;
                }
            }
    }
};
//统计在int***地图中每行type僵尸的数目
int SumZombiesInRow(int*** Zombies,int row,int type) {
    int ans = 0;
    for (int j = 0; j < COLUMN; j++) {
        int k = 0;
        while (Zombies[row][j][k] != -1) {
            if (Zombies[row][j][k] == type)
                ans++;
            k++;
        }
    }
    return ans;
}

//僵尸统计库类(单一僵尸的库统计)
static struct Zombies {
/*数据*/
    int zombies[ROW][COLUMN][100];//僵尸地图
    int sum;//僵尸总数
    Zombie zombiesmap[ROW][COLUMN][100];//僵尸详细数据地图
    int sumzombiesmap[ROW][COLUMN];
    Zombie** normals;//普通僵尸
    int sumNormals;//普通僵尸的数量
    Zombie** buckets;//铁桶僵尸
    int sumBuckets;//铁桶僵尸的数量
    Zombie** polevaults;//撑杆跳僵尸
    int sumPolevaults;//撑杆跳僵尸的数量
    Zombie** sleds;//冰车僵尸
    int sumSleds;//冰车僵尸的数量
    Zombie** gargantuars;//巨人僵尸
    int sumGargantuars;//巨人僵尸的数量
    int ZombiesCD[6];//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
    //攻破维护数组
    int haveAttack[5];//0是未攻破，1是已攻破
    int zombiesSun;//僵尸月光
/*操作*/
    //构造函数(僵尸地图初始化，总数归零，详细地图初始化，给各个指针分配内存)
    Zombies() {
        zombiesSun = 300;
        //僵尸地图初始化
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++)
                for (int k = 0; k < 100; k++)
                    zombiesmap[i][j][k].init(0, i);
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++)
                sumzombiesmap[i][j] = 0;
        //总数归零
        for (int i = 0; i < 6; i++)
            ZombiesCD[i] = 0;
        for (int i = 0; i < ROW; i++)
            haveAttack[i] = 0;
        sum = 0;
        sumNormals = 0;
        sumBuckets = 0;
        sumPolevaults = 0;
        sumSleds = 0;
        sumGargantuars = 0;
        //分配内存
        normals = new Zombie*[200];
        buckets = new Zombie*[200];
        polevaults = new Zombie*[200];
        sleds = new Zombie*[200];
        gargantuars = new Zombie*[200];
    }
    //析构函数(释放各个指针分配的内存)
    ~Zombies() {
        delete[]normals;
        delete[]buckets;
        delete[]polevaults;
        delete[]sleds;
        delete[]gargantuars;
    }
    //注意更新相关的数量参数(包括总数和各自的参数)
    //在(x,y)处添加一个为Zombie的僵尸 
    void addZombie(Zombie zombie, int x, int y) {
        zombiesmap[x][y][sumzombiesmap[x][y]] = zombie;
        sumzombiesmap[x][y]++;
        sum++;
    }
    //删除某僵尸(x,y,k)
    void delZombie(int x, int y, int k) {
        for (int l = k + 1; l < sumzombiesmap[x][y]; l++)
            zombiesmap[x][y][l - 1] = zombiesmap[x][y][l];
        sumzombiesmap[x][y]--;
        zombiesmap[x][y][sumzombiesmap[x][y]].type = 0;
        sum--;
    }
    //僵尸地图(row,9)处加一个type的僵尸 
    Zombie* addZombieMap(int type,int row) {
        zombiesmap[row][COLUMN-1][sumzombiesmap[row][COLUMN-1]].init(type,row);
        sumzombiesmap[row][COLUMN-1]++;
        sum++;
        ZombiesCD[type] = ZOMBIESCD[type];
        return &zombiesmap[row][COLUMN - 1][sumzombiesmap[row][COLUMN-1] - 1];
    }
    //清除地图血量小于等于0的僵尸在地图(x,y)处
    void cleanKilledZombie(int x,int y) {
        int k = 0;
        while (k < sumzombiesmap[x][y]) {
            if (zombiesmap[x][y][k].blood <= 0) {
                for (int i = k + 1; i < sumzombiesmap[x][y]; i++)
                    zombiesmap[x][y][i] = zombiesmap[x][y][i + 1];
                sumzombiesmap[x][y]--;
            }
            else {
                k++;
            }
        }
    }
    //删除所有血量小于等于0的僵尸
    void cleanKilledZombieMap() {
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++)
                cleanKilledZombie(i, j);
    }
    //添加一个满血的普通僵尸(刚出现)
    void addNormal(int row) {
        normals[sumNormals] = addZombieMap(1,row);
        sumNormals++;
    }
    //添加一个满血的铁桶僵尸(刚出现)
    void addBucket(int row) {
        buckets[sumBuckets] = addZombieMap(2,row);
        sumBuckets++;
    }
    //添加一个满血的撑杆跳僵尸(刚出现)
    void addPolevault(int row) {
        polevaults[sumPolevaults] = addZombieMap(3,row);
        sumPolevaults++;
    }
    //添加一个满血的冰车僵尸(刚出现)
    void addSled(int row) {
        sleds[sumSleds] = addZombieMap(4,row);
        sumSleds++;
    }
    //添加一个满血的巨人僵尸(刚出现)
    void addGargantuar(int row) {
        gargantuars[sumGargantuars] = addZombieMap(5,row);
        sumGargantuars++;
    }
    //添加一个type的僵尸
    void addTypeZombie(int row, int type) {
        switch (type)
        {
        case 1:
            addNormal(row);
            break;
        case 2:
            addBucket(row);
            break;
        case 3:
            addPolevault(row);
            break;
        case 4:
            addSled(row);
            break;
        case 5:
            addGargantuar(row);
            break;
        default:
            break;
        }
    }
    //寻找某一行最前面的僵尸的坐标(i,j,k)
    int* findLastFirstZombie(int x,int row) {
        int j = x;
        //寻找第一个有僵尸的格子
        while (j < COLUMN) {
            if (sumzombiesmap[row][j] > 0)
                break;
            j++;
        }
        //如果没有格子有僵尸返回空指针
        if (j == COLUMN)
            return 0;
        //如果找到了格子(row,j)
        int k = 0;
        float detailpos = 10.1;
        int index = -1;
        while(k<sumzombiesmap[row][j])
            if (zombiesmap[row][j][k].detailPos < detailpos) {
                index = k;
                detailpos = zombiesmap[row][j][k].detailPos;
                k++;
            }
            else {
                k++;
            }
        int* ans = new int[3];
        ans[0] = row;
        ans[1] = j;
        ans[2] = index;
        return ans;
    }
    //输出每一格的僵尸数目
    void PrintSumZombiesMap(FILE* p) {
        fprintf(_FILE, "***********************\n");
        for (int i = 0; i < ROW; i++) {
            fprintf(_FILE, "* ");
            for (int j = 0; j < COLUMN; j++) {
                fprintf(_FILE, "%d ", sumzombiesmap[i][j]);
            }
            fprintf(_FILE, "*\n");
        }
        fprintf(_FILE, "***********************\n");
    }
       //输出每一格的第一个僵尸type
       void PrintTypeZombiesMap(FILE* p) {
           fprintf(_FILE, "***********************\n");
           for (int i = 0; i < ROW; i++) {
               fprintf(_FILE, "* ");
               for (int j = 0; j < COLUMN; j++) {
                   fprintf(_FILE, "%d ", zombiesmap[i][j][0].type);
               }
               fprintf(_FILE, "*\n");
           }
           fprintf(_FILE, "***********************\n");
       }
       //输出每一格的第一个僵尸detailpos
       void PrintDetailposZombiesMap(FILE* p) {
           fprintf(_FILE, "***********************\n");
           for (int i = 0; i < ROW; i++) {
               fprintf(_FILE, "* ");
               for (int j = 0; j < COLUMN; j++) {
                   fprintf(_FILE, "%f ", zombiesmap[i][j][0].detailPos);
               }
               fprintf(_FILE, "*\n");
           }
           fprintf(_FILE, "***********************\n");
       }
       //输出每一格的第一个僵尸blood
       void PrintBloodZombiesMap(FILE* p) {
           fprintf(_FILE, "***********************\n");
           for (int i = 0; i < ROW; i++) {
               fprintf(_FILE, "* ");
               for (int j = 0; j < COLUMN; j++) {
                   fprintf(_FILE, "%d ", zombiesmap[i][j][0].blood);
               }
               fprintf(_FILE, "*\n");
           }
           fprintf(_FILE, "***********************\n");
       }
    //统计某行每种僵尸的数目(在未更新的地图中)
    int SumZombiesMapInRow(int row,int type) {
        int ans = 0;
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < sumzombiesmap[row][j]; k++)
                if (zombiesmap[row][j][k].type == type)
                    ans++;
        return ans;
    }
    //在僵尸地图中更新僵尸
    void renewZombiesMap(int***Zombies) {
        //统计每行每种僵尸数目
        const int TYPE = 5;
        int sumArray1[TYPE + 1][ROW];//统计数组
        for (int i = 0; i < ROW; i++) {
            for (int type = 1; type <= TYPE; type++) {
                sumArray1[type][i] = SumZombiesInRow(Zombies, i, type);
                printfInt(sumArray1[type][i]);
            }
        }
        int sumArray0[TYPE + 1][ROW];//原本的统计数组
        for (int i = 0; i < ROW; i++) {
            for (int type = 1; type <= TYPE; type++) {
                sumArray0[type][i] = SumZombiesMapInRow(i, type);
            }
        }
        
        //比较差异考察是哪个有不同(添加僵尸)
        for (int i = 0; i < ROW; i++)
            for (int type = 1; type <= TYPE; type++) {
                if (sumArray0[type][i] < sumArray1[type][i]) {
                    addTypeZombie(i, type);
                }
            }
    }
    //根据僵尸地图更新僵尸List
    void renewZombiesList() {
        sumNormals = 0;
        sumBuckets = 0;
        sumPolevaults = 0;
        sumSleds = 0;
        sumGargantuars = 0;
        for(int i=0;i<ROW;i++)
            for(int j=0;j<COLUMN;j++)
                for(int k=0;k<sumzombiesmap[i][j];k++)
                    switch (zombiesmap[i][j][k].type)
                    {
                    case 1:
                        normals[sumNormals] = &zombiesmap[i][j][k];
                        sumNormals++;
                        break;
                    case 2:
                        buckets[sumBuckets] = &zombiesmap[i][j][k];
                        sumBuckets++;
                        break;
                    case 3:
                        polevaults[sumPolevaults] = &zombiesmap[i][j][k];
                        sumPolevaults++;
                        break;
                    case 4:
                        sleds[sumSleds] = &zombiesmap[i][j][k];
                        sumSleds++;
                        break;
                    case 5:
                        gargantuars[sumGargantuars] = &zombiesmap[i][j][k];
                        sumGargantuars++;
                        break;
                    default:
                        break;
                    }
    }
};
//火力处理装置
//处理植物攻击僵尸，僵尸干掉植物这两件事
//处理一个豌豆射手的攻击(成功处理返回1，处理失败返回0)
int firePeaShooter(Plants& classPlants, Zombies& classZombies,int row,int column) {
    //这格不是豌豆射手
    if (classPlants.plantsmap[row][column].type != 3)
        return 0;
    //是豌豆射手处理
    //考虑是否有僵尸
    int* p = classZombies.findLastFirstZombie(column, row);
    FILE* pt;
    Plant& peaShooter = classPlants.plantsmap[row][column];

    //这一行有僵尸
    if (p != 0) {
        Zombie& zombie = classZombies.zombiesmap[p[0]][p[1]][p[2]];
        delete[]p;
        //射击
        if (peaShooter.shootCD == 0) {
            peaShooter.shootCD = 2;
            zombie.bloodDecrease(peaShooter.attack);
        }
        else
            peaShooter.shootCD--;
        return 1;
    }//这一行没有僵尸
    else {
        peaShooter.shootCD = 0;
        return 1;
    }
    
}
//处理一个寒冰豌豆射手的攻击(成功处理返回1，处理失败返回0)
int fireWinterPeaShooter(Plants& classPlants, Zombies& classZombies, int row, int column) {
    //这格不是寒冰豌豆射手
    if (classPlants.plantsmap[row][column].type != 2)
        return 0;
    //是寒冰豌豆射手处理(包括处理寒冰效应)
    int* p = classZombies.findLastFirstZombie(column, row);
    Plant& winterPeaShooter = classPlants.plantsmap[row][column];
    if (p != 0) {
        //寒冰豌豆有溅射效应
        int x = p[0];
        int y = p[1];
        //射击
        if (winterPeaShooter.shootCD == 0) {
            winterPeaShooter.shootCD = 3;
            for (int k = 0; k < classZombies.sumzombiesmap[x][y]; k++){
                classZombies.zombiesmap[x][y][k].bloodDecrease(winterPeaShooter.attack);
                classZombies.zombiesmap[x][y][k].winterstep = 10;
            }
        }
        else
            winterPeaShooter.shootCD--;
        return 1;
    }
    else {
        winterPeaShooter.shootCD = 0;
        return 1;
    }
}
//处理一个倭瓜的攻击(成功处理返回1，处理失败返回0)
int fireSquash(Plants& classPlants, Zombies& classZombies, int row, int column) {
    //这格不是倭瓜
    if (classPlants.plantsmap[row][column].type != 6)
        return 0;
    //是倭瓜处理
    Plant& squash = classPlants.plantsmap[row][column];
    //倭瓜攻击
    if (classZombies.sumzombiesmap[row][column] > 0)
        if (squash.shootCD == 0) {
            for (int k = 0; k < classZombies.sumzombiesmap[row][column]; k++) {
                classZombies.zombiesmap[row][column][k].bloodDecrease(squash.attack);
            }
            squash.blood = -1;
        }
        else {
            squash.shootCD--;
        }
    return 1;
}
//处理一个火爆辣椒的攻击(成功处理返回1，处理失败返回0)
int firePepper(Plants& classPlants, Zombies& classZombies, int row, int column) {
    //如果不是火爆辣椒
    if (classPlants.plantsmap[row][column].type != 5)
        return 0;
    //如果是火爆辣椒
    Plant& pepper = classPlants.plantsmap[row][column];
    if (pepper.shootCD == 0) {
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < classZombies.sumzombiesmap[row][j]; k++)
                classZombies.zombiesmap[row][j][k].bloodDecrease(pepper.attack);
        pepper.blood = -1;
    }
    else {
        pepper.shootCD--;
    }
    return 1;
}
//每次植物更新后应该更新地图(还是攻击完一起更新)
void plantFireProcessing(Plants& classPlants, Zombies& classZombies) {
    //植物攻击
    //处理寒冰豌豆射手
    for (int i = 0; i < classPlants.SumOfWinterPeaShooters; i++)
        fireWinterPeaShooter(classPlants, classZombies, (*classPlants.winterPeaShooters[i]).pos.x, (*classPlants.winterPeaShooters[i]).pos.y);
    //处理豌豆射手
    for (int i = 0; i < classPlants.SumOfPeaShooters; i++) {
        firePeaShooter(classPlants, classZombies, (*classPlants.peaShooters[i]).pos.x, (*classPlants.peaShooters[i]).pos.y);
    }//处理火爆辣椒
    for (int i = 0; i < classPlants.SumOfPeppers; i++)
        firePepper(classPlants, classZombies, (*classPlants.peppers[i]).pos.x, (*classPlants.peppers[i]).pos.y);
    //处理倭瓜
    for (int i = 0; i < classPlants.SumOfSquashs; i++)
        fireSquash(classPlants, classZombies, (*classPlants.squashs[i]).pos.x, (*classPlants.squashs[i]).pos.y);
}
//僵尸攻击
void zombiesFireProcessing(Plants& classPlants, Zombies& classZombies) {
//每个僵尸依次攻击一次
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < classZombies.sumzombiesmap[i][j]; k++)
            {
                classZombies.zombiesmap[i][j][k].zombieAttack(classPlants.plantsmap[i][j]);
            }
}

//注意僵尸移动会导致从(x,y)到(x,y-1)
//某僵尸移动 僵尸位置为(x,y) 僵尸序号为k
void zombiesMoving(Plants& classplant, Zombies& classZombies,int x,int y,int k) {
    Plant currentPlant = classplant.plantsmap[x][y];
    Zombie& currentzombie = classZombies.zombiesmap[x][y][k];
    currentzombie.zombieMoveStep(currentPlant);
}
//全图存活僵尸移动
void zombiesMovingMap(Plants& classplant, Zombies& classZombies) {
    //移动
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < classZombies.sumzombiesmap[i][j]; k++)
                zombiesMoving(classplant, classZombies, i, j, k);
    //如果有僵尸到达底线
    for(int i=0;i<ROW;i++)
        for(int k=0;k<classZombies.sumzombiesmap[i][0];k++)
            if (classZombies.zombiesmap[i][0][k].ifHaveAttack()) {
                classZombies.haveAttack[i]=classplant.haveAttack[i] = 1;
                //清空此行所有植物和僵尸
                for (int j = 0; j < COLUMN; j++)
                    if (classplant.plantsmap[i][j].ifHavePlant())
                        classplant.plantsmap[i][j].blood -= INF;
                classplant.cleanKilledPlantsMap();
                for (int j = 0; j < COLUMN; j++)
                    for (int k = 0; k < classZombies.sumzombiesmap[i][j]; k++)
                        if (classZombies.zombiesmap[i][j][k].ifHaveZombie())
                            classZombies.zombiesmap[i][j][k].bloodDecrease(INF);
                classZombies.cleanKilledZombieMap();
                break;
            }
    //改变格子
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < classZombies.sumzombiesmap[i][j]; k++) {
                if (!classZombies.zombiesmap[i][j][k].checkIfInBox()) {
                    classZombies.addZombie(classZombies.zombiesmap[i][j][k], i, j - 1);
                    classZombies.zombiesmap[i][j - 1][classZombies.sumzombiesmap[i][j - 1] - 1].pos.y--;
                    classZombies.delZombie(i, j, k);
                    k--;
                }
            }
}

//更新地图存活植物和僵尸，并完成僵尸移动，完成寒冰回合的更新，攻击回合的更新等等
//注意更新顺序 场上植物攻击，场上僵尸攻击，场上僵尸移动，植物放置，僵尸放置
void renewMap(Plant& classplant, Zombies& classZombies) {
    //僵尸移动
    //在僵尸刚吃完植物的时候种可行吗
}

//植物统计数组(分别为向日葵，寒冰射手，豌豆射手，坚果墙，辣椒，倭瓜)

//植物查找
//某点是否有向日葵(x,y)
int ifPointSunFlower(int** plant, int x, int y) {
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    return plant[x][y] == 1;
}
//某行向日葵查找row
int ifRowSunFlower(int** plant, int row) {
    if (row<0 || row>ROW)
        return 0;
    for (int j = 0; j < COLUMN; j++)
        if (plant[row][j] == 1)
            return 1;
    return 0;
}
//某点僵尸查找(返回统计数量的数组)
int* SearchForPointZombies(int*** Zombies, int x, int y) {
    int* ans = new int[6];
    for (int i = 0; i < 6; i++)
        ans[i] = 0;
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++) {
            int k = 0;
            while (Zombies[i][j][k] != -1 && Zombies[i][j][k] != 0) {
                ans[Zombies[i][j][k]]++;
                k++;
            }
        }
    return ans;
}
//释放查找指针
void EndSearch(int* p) {
    delete[]p;
}
//检查此格是否有僵尸(返回0/1)
int ifPointZombies(int***Zombies,int x, int y) {
    int* p = SearchForPointZombies(Zombies, x, y);
    int ans = 0;
    for (int i = 1; i < 6; i++) {
        if (p[i] != 0) {
            ans = 1;
            break;
        }
    }
    EndSearch(p);
    return ans;
}
//检查此行是否有僵尸(返回0/1)
int ifRowZombles(int*** Zombies, int Row) {
    int ans = 0;
    for (int i = 0; i <COLUMN; i++) {
        if (ifPointZombies(Zombies, Row, i)) {
            ans = 1;
            break;
        }
    }
    return ans;
}
//寻找种向日葵的合适地点(返回坐标)
Point FindPlaceForSunFlower(int** Plants, int*** Zombies) {
    for (int i = 0; i < ROW; i++) {
        if (Plants[i][3] == 0 && !ifRowZombles(Zombies, i)) {
            return Point(i, 3);
        }
    }
    return Point(-1, -1);
}
//倭瓜防御一行(返回是否成功)
Point DefenseBySquash(int** Plants, int x, int y) {
    while (y >= 0) {
        if (Plants[x][y] == 0) {
            return Point(x, y);
        }
        y--;
    }
    return  Point(-1, -1);
}

//检查向日葵CD
int SunFlowerCD(int* CD) {
    return CD[0] < 1;
}
//检查寒冰射手CD
int WinterPeachShooterCD(int* CD) {
    return CD[1] < 1;
}
//检查豌豆射手CD
int PeachShooterCD(int* CD) {
    return CD[2] < 1;
}
//检查坚果墙CD
int SmallNutCD(int* CD) {
    return CD[3] < 1;
}
//检查火爆辣椒CD
int PepperCD(int* CD) {
    return CD[4] < 1;
}
//检查倭瓜CD
int SquashCD(int* CD) {
    return CD[5] < 1;
}

//种植部分已经检查CD，植物种植位置是否合法(溢出边界or有植物)
//种植倭瓜
int PlantSquash(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SquashCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(6, x, y);
    return 1;
}
//种植向日葵
int PlantSunFlower(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >=ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SunFlowerCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(1, x, y);
    return 1;
}
//种植寒冰射手
int PlantWinterPeachShooter(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!WinterPeachShooterCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(2, x, y);
    return 1;
}
//种植豌豆射手
int PlantPeachShooter(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!PeachShooterCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(3, x, y);
    return 1;
}
//种植坚果墙
int PlantSmallNut(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SmallNutCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(4, x, y);
    return 1;
}
//种植火爆辣椒
int PlantPepper(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!PepperCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(5, x, y);
    return 1;
}



//僵尸
//普通僵尸CD检查(CD为0返回1，否则为0)
int NormalCD(int* CD) {
    return CD[0] < 1;
}
//铁桶僵尸CD检查(CD为0返回1，否则为0)
int BucketCD(int* CD) {
    return CD[1] < 1;
}
//撑杆跳僵尸CD检查(CD为0返回1，否则为0)
int PolevaultCD(int* CD) {
    return CD[2] < 1;
}
//冰车僵尸CD检查(CD为0返回1，否则为0)
int SledCD(int* CD) {
    return CD[3] < 1;
}
//巨人僵尸CD检查(CD为0返回1，否则为0)
int GargantuarCD(int* CD) {
    return CD[4] < 1;
}

//放置普通僵尸
//放置部分已经检查CD，僵尸放置位置是否合法(溢出边界)
int SetNormal(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!NormalCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(1,Row);
    return 1;
}
//放置铁桶僵尸
int SetBucket(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!BucketCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(2, Row);
}
//放置撑杆跳僵尸
int SetPolevault(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!PolevaultCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(3, Row);
    return 1;
}
//放置冰车僵尸
int SetSled(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!SledCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(4, Row);
}
//放置巨人僵尸
int SetGargantuar(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!GargantuarCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(5, Row);
}

//检测
//检测各行向日葵数目
void CheckSunFlower(int**Plants, int* Ans) {
    for (int i = 0; i < ROW; i++) {
        Ans[i] = 0;
        for (int j = 0; j < COLUMN; j++) {
            if (Plants[i][j] == 1)
                Ans[i]++;
        }
    }
}
//检测各行倭瓜数目
void CheckSquash(int** Plants, int* Ans) {
    for (int i = 0; i < ROW; i++) {
        Ans[i] = 0;
        for (int j = 0; j < COLUMN; j++) {
            if (Plants[i][j] == 6)
                Ans[i]++;
        }
    }
}


//对于僵尸的防御1(一次性防御)(并标记)(返回需要的阳光)

//防御能耗的概念(我下一个僵尸他需要完成防御的最少能耗和CD)

//

//僵尸策略1(1<=STEP<=50)(小费速攻策略)
//策略基本数据记录 
int attackRow1[] = { 0,0,0,0,0 };
//仅仅使用普通僵尸和撑杆跳进行进攻
void lowCostAttack(IPlayer* player) {
    //僵尸方
    int Step = player->getTime();//回合数
    int Sun = player->Camp->getSun();//月光数
    int Row = player->Camp->getRows();//行数
    int Column = player->Camp->getColumns();//列数
    int** Plants = player->Camp->getCurrentPlants();//植物数组
    int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
    int* CD = player->Camp->getPlantCD();//僵尸CD
    
    //检测是否处于前期策略(1<=STEP<=50)
    if (Step <= 1 || Step>70)
        return;
    //STEP=2放置撑杆跳/普通僵尸
    //根据不重复行原则和撑杆跳进攻向日葵原则
    if (Step == 2) {
        int row = 0;
        //检测有向日葵的地方
        //可能需要完善向日葵很前不进攻的特殊情况
        while (row < ROW) {
            if (ifRowSunFlower(Plants, row))
                break;
            row++;
        }
        //如果有向日葵，在有向日葵的地方放撑杆跳不然随机放
        if (row == ROW) {
            srand(time(0));
            int setrow = rand() % ROW;
            SetPolevault(player, setrow);
            attackRow1[setrow] = 1;
            printf("STEP:%d\n", Step);
            printf("Polevault:Row:%d\n", setrow);
        }
        else {
            SetPolevault(player, row);
            attackRow1[row] = 1;
            printf("STEP:%d\n", Step);
            printf("Polevault:Row:%d\n", row);
        }
         //在无僵尸的行放一个普通僵尸
        for (int row = 0,basic=rand()%ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Normal:Row:%d\n", setrow);
                SetNormal(player, setrow);
                attackRow1[setrow] = 1;
                break;
            }
        }
        return;
    }
    /*测试*/
    /*测试*/
    //只要CD好就放普通僵尸
    if (NormalCD(CD)&&Sun>=50) {
        for (int row = 0,basic = rand() % ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Normal:Row:%d\n", setrow);
                printf("%d\n",SetNormal(player, setrow));
                attackRow1[setrow] = 1;
                Sun -= 50;
                break;
            }
        }
    }
    //只要CD好就放撑杆跳僵尸
    if (PolevaultCD(CD)&&Sun>=75) {
        for (int row = 0, basic = rand() % ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Polevault:Row:%d\n", setrow);
                printf("%d\n",SetPolevault(player, setrow));
                attackRow1[setrow] = 1;
                Sun -= 75;
                break;
            }
        }
    }
}
Plants PlantsGarden;
Zombies ZombiesGarden;

//需要一个功能演化某行是否能防守成功的函数
int DefenseSolution(Plants CopyPlants,Zombies CopyZombies,int row) {

}
//需要一个功能演化某行是否能防守损失的函数
int DefenseHaveCost(Plants CopyPlants, Zombies CopyZombies, int row) {

}
//判断某点的植物在目前攻击下能存活的时长
int PlantSurviveTime() {

}
//植物策略
//根本目的形成阵容(后期可以使用铲子)
//前期目的尽可能多种植向日葵，并对僵尸进行基础的防御(可以选择拖时间)
//中期在有相当的阳光积累的时候进行阵容的完善，并使用一次性植物进行防御
//后期进行阵容加强还有保留阳光和一次性植物进行防御(考虑拖到2000回合+也是可以考虑的)
// 植物策略是对僵尸的即时响应策略，其远见性在于形成阵容
//前期阵容(0<STEP<500)
const int BattleArray1[5][10] = {
    {3,1,2,3,1,1,1,1,4,0},
    {3,1,2,3,1,1,1,1,4,0},
    {3,1,2,3,1,1,1,1,4,0},
    {3,1,2,3,1,1,1,1,4,0},
    {3,1,2,3,1,1,1,1,4,0},
};
//中期阵容(500<STEP<1000)
const int BattleArray2[5][10] = {
    {2,3,2,3,1,1,1,1,4,0},
    {2,3,2,3,1,1,1,1,4,0},
    {2,3,2,3,1,1,1,1,4,0},
    {2,3,2,3,1,1,1,1,4,0},
    {2,3,2,3,1,1,1,1,4,0},
};
//后期阵容(1000<STEP<1500)
const int BattleArray3[5][10] = {
    {2,2,2,3,2,3,1,1,4,0},
    {2,2,2,3,2,3,1,1,4,0},
    {2,2,2,3,2,3,1,1,4,0},
    {2,2,2,3,2,3,1,1,4,0},
    {2,2,2,3,2,3,1,1,4,0},
};
//大后期阵容(1000<STEP<1500)
const int BattleArray4[5][10]{
    {2,2,2,2,2,3,4,1,4,0},
    {2,2,2,2,2,3,4,1,4,0},
    {2,2,2,2,2,3,4,1,4,0},
    {2,2,2,2,2,3,4,1,4,0},
    {2,2,2,2,2,3,4,1,4,0},
};
//前期(附加向日葵持续阳光)
//判断是否为前期
int ifstage1() {

}
//如果敌方月光在300+保留175+阳光
//如果月光在200+保留125+阳光
//如果月光在100+保留100+阳光
//找到目前地图上最适合种向日葵的地方
Point FindBestPlaceForSunFlower() {
    if (ifstage1()) {
        int score[5][10];//价值数组(种在每一点的价值量)
        //存活时长

        //产生的阳光数

        //对本行战斗力的影响

        //对本行的防守损失的影响(有无向日葵的战斗损失)

        //对阵容形成的影响(如果本来要种向日葵加分，本来要种别的植物减分)

        //对敌方的不同进攻形式的防御程度和损失

        //把这些分数叠加(加权求和)

        //在高于一定分数的里面取最大的位置

    }
}
//僵尸策略
//考虑连续性 并记录策略
//给出一个僵尸策略类
//策略(小类)(包含一次步骤该有的信息)
#define PLANTSTYPE 6
#define ZOMBIESTYPE 5
struct strategy {
    //总策略开始回合
    int step;
    //是僵尸策略还是植物策略
    int flag;//0为植物策略，1为僵尸策略
    //如果是僵尸策略
    //在这几个回合内的放置的僵尸数目
    //Type的僵尸是否放置和放置的Step和放置的row
    //如果是植物策略
    //在这几个回合内的放置的植物数目
    //Type的植物是否放置和放置的Step和放置的位置row,column
    int setStrategySum;
    int setStrategy[PLANTSTYPE + 1][4];
    strategy(int flag=-1) {
        step = 0;
        this->flag = flag;
        setStrategySum = 0;
        for (int i = 0; i < PLANTSTYPE + 1; i++)
            for (int j = 0; j < 4; j++)
                setStrategy[i][j] = 0;
    }
};
int generateStrategy(strategy* _stragtegy, int flag, int* data,int step) {
    
    //植物
    if (flag == 0) {

    }//僵尸
    else if (flag == 1) {
        int sum = 0;//有多少种僵尸要枚举
        //有效僵尸type数组
        int effecttype[6] = { 0,0,0,0,0,0 };
        for (int type = 1; type <= 5; type++)
            if (data[type]) {
                effecttype[sum] = type;
                sum++;
            }
        if (sum == 0) {//特殊情况
            _stragtegy->step = step;
            _stragtegy->flag = flag;
            _stragtegy->setStrategySum = 0;
            return 0;
        }//一般情况(5进制)
        else {
            _stragtegy->step = step;
            _stragtegy->flag = flag;
            _stragtegy->setStrategySum = sum;
            int INDEX = 1;
            for (int i = 0; i < sum; i++)
                INDEX *= 5;
            int index = 0;
            while (index < INDEX) {
                int copy = index;
                for (int i = 0; i < sum; i++) {
                    _stragtegy->setStrategy[effecttype[i]][0] = 1;
                    _stragtegy->setStrategy[effecttype[i]][1] = step;
                    _stragtegy->setStrategy[effecttype[i]][2] = copy % 5;
                    copy /= 5;
                }
                index++;
                _stragtegy++;
            }
            return INDEX;
        }
    }

}
//总策略(小策略的集合)
struct Strategies {
    //总策略开始回合
    int step;
    //是僵尸策略还是植物策略
    int flag;//0为植物策略，1为僵尸策略
    //策略数
    int sum;
    //策略集合
    strategy* _strategy;
    //构造函数
    Strategies(int flag=-1) {
        step = 0;
        this->flag = flag;
        sum = 0;
        _strategy = 0;
    }
    //析构函数
    ~Strategies() {
        delete[]_strategy;
    }
    //给出策略集合
    void GetStrategies(int step, Plants classPlants, Zombies classZombies) {
        //植物僵尸分别讨论
        //植物
        if (flag == 0) {
            
        }
        //僵尸
        else if (flag == 1) {
            //考虑不定不等式\sum{ZOMBIESUN[i]*JUDGE[i]}<=Sun}
            int Sun = classZombies.zombiesSun;//阳光
            int sum = 0;//总方法数
            int judge[32][6] = {};
            int Case[32] = {};
            //初始化
            for (int row = 0; row < 32; row++)
            {
                Case[row] = 0;
                for (int i = 0; i < 6; i++)
                    judge[row][i] = 0;
            }
            //时间测试
            clock_t begin = clock();
            for (int index = 0; index < 32; index++) {
                int type = 1;
                int CD = 0;
                int copy = index;
                while (copy != 0) {
                    judge[sum][type] = copy % 2;
                    if (judge[sum][type] && classZombies.ZombiesCD[type] != 0)
                        CD = 1;
                    copy = copy / 2;
                    type++;
                }
                if (CD)continue;//该僵尸在CD
                int judgesum = 0;
                for (int type = 1; type <= 5; type++)
                    judgesum += judge[sum][type] * ZOMBIESUN[type];
                if (judgesum <= Sun) {
                    Case[sum] = 1;
                    for (int type = 1; type <= 5; type++) {
                        if (judge[sum][type])
                            Case[sum] *= 5;
                    }
                    sum++;
                }
            }
            //上面没问题
            
            if (sum>0) {
                int scale = 0;
                for (int i = 0; i < sum; i++)
                    scale += Case[i];
                _strategy = new strategy[scale];
                printf("Sum:%dTime:%d\n", sum, clock() - begin);
                for (int i = 0; i < sum; i++) {
                    generateStrategy(_strategy, flag, judge[i], step);
                    _strategy += Case[i];
                }
                printf("Sum:%dTime:%d\n", scale, clock() - begin);
                sum = scale;
            }
            else {
                _strategy = 0;
            }
        }
    }
    //打印策略
    void printfStrategiesSum() {
        FILE* p;
        //fopen_s(&p, "strategyies.txt", "a");
        //fprintf(p, "%d\n", sum);
        //fclose(p);
        for (int i = 0; i < sum; i++) {
            FILE* p;
           // fopen_s(&p, "strategyies.txt", "a");
           // fprintf(p, "%d\n", _strategy[sum].setStrategySum);
            //fclose(p);
        }
    }
};
//僵尸策略要考虑多步效应(决定策略应该进行枚举)
//并根据具体对策做出调整
//如何枚举(搜索树)
//核心Max-Min Search
//做一些基础假设 减少搜索空间
//估值函数比较困难(需要一个好的估值函数)
//估值函数需要考虑场上植物，场上僵尸
//植物已经获得的分数，和僵尸已经获得的分数
//还有植物方的阳光和僵尸方的月光
//与回合数有关
double EvaluationFunction(Plants classPlants, Zombies classZombies, int Step) {
    //植物
    //植物有效的行数(未攻破的行数)重要

    //植物数目和质量(向日葵数目前期重要，寒冰射手数目后期重要)

    //植物每一行的防御火力系数(在0.2的速度下能干掉多少体力的僵尸)
    //注意控制倭瓜带来的影响

    //植物方剩余的阳光(在一定数目上即系数衰减)

    //僵尸
    //
}
//alpha-beta剪枝 
//简单策略
void basicstrategy(IPlayer* player) {

}
//打印僵尸状态
void printfZombies(int step,int*** Zombies) {
    FILE* p;
    //fopen_s(&p, "Zombies.txt", "a");
    //fprintf(p, "Step:%d\n", step);
    for(int i=0;i<ROW;i++)
        for (int j = 0; j < COLUMN; j++) {
            int k = 0;
            while (Zombies[i][j][k] != -1) {
                fprintf(p, "%d ", Zombies[i][j][k]);
                k++;
            }
            fprintf(p, "-1\n");
        }
    //fclose(p);
}
//对存活的僵尸减少1Step的寒冰状态
void zombieDecreaseWinter(Zombies& ZombiesGarden) {
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++)
            for (int k = 0; k < ZombiesGarden.sumzombiesmap[i][j]; k++)
                if (ZombiesGarden.zombiesmap[i][j][k].winterstep > 1)
                    ZombiesGarden.zombiesmap[i][j][k].winterstep--;
}
//植物方 更新植物和僵尸信息
void RenewMapInfo(IPlayer* player) {

    int Step = player->getTime();//回合数
    int Row = player->Camp->getRows();//行数
    int Column = player->Camp->getColumns();//列数
    int** _Plants = player->Camp->getCurrentPlants();//植物数组
    int*** _Zombies = player->Camp->getCurrentZombies();//僵尸数组
   
    //1. 场上植物攻击（寒冰状态改变）
    plantFireProcessing(PlantsGarden, ZombiesGarden);
    //2. 消除植物攻击的僵尸
    ZombiesGarden.cleanKilledZombieMap();
    //3. 场上僵尸攻击
    zombiesFireProcessing(PlantsGarden, ZombiesGarden);
    //4. 消除场上死亡的植物
    PlantsGarden.cleanKilledPlantsMap();
    //5. 僵尸移动
    zombiesMovingMap(PlantsGarden, ZombiesGarden);
    //6. 对场上现有僵尸去除一个Step的寒冰效果
    zombieDecreaseWinter(ZombiesGarden);
    //7. 更新植物地图和僵尸地图(和更新植物List)(最新种下的植物和僵尸)
    PlantsGarden.RenewPlantMap(_Plants);
    PlantsGarden.renewPlantList();
    ZombiesGarden.renewZombiesMap(_Zombies);
    //8. 更新CD统计数目
    //植物
    for (int i = 1; i <= 6; i++)
        if (PlantsGarden.PlantsCD[i] != 0)
            PlantsGarden.PlantsCD[i]--;
    //僵尸
    for (int i = 1; i <= 5; i++)
        if (ZombiesGarden.ZombiesCD[i] != 0)
            ZombiesGarden.ZombiesCD[i]--;
    //输出调试
    FILE* p;
    //fopen_s(&p, "zombiesType.txt", "a");
    //fprintf(p, "\nStep%d\n", Step);
    //printfZombies(Step, _Zombies);
    
    ZombiesGarden.renewZombiesList();
    ZombiesGarden.PrintSumZombiesMap(p);
    ZombiesGarden.PrintTypeZombiesMap(p);
    ZombiesGarden.PrintBloodZombiesMap(p);
    fclose(p);
}

//需要把装置完善对阳光的更新
//策略
//我们把5个回合或者10个回合当做一个整体
//可以简化为植物运行5Step,僵尸运行5Step
//考虑状态空间
//僵尸的状态空间比较简单10Step
//在1-5行放置or不放置普通僵尸、其他僵尸
//状态空间实际上比这个更少因为阳光的限制

//植物的状态空间
//在地图上种植豌豆向日葵等等
//但是考虑阳光的限制实际状态远远小于此
//可以考虑加一些限制比如不在没有僵尸的地方放火爆辣椒
//不在前3格种豌豆或者寒冰射手
//每回合给一个铲除植物的空间(简化)
//评估函数
//最重要的一点能否防御成功
//以及植物的发展情况如何
//剩余的阳光和月光
void PlantStrategy(IPlayer* player) {
    //基础数据
    int Step = player->getTime();//回合数
    int Sun = player->Camp->getSun();//阳光
    int Row = player->Camp->getRows();//行数
    int Column = player->Camp->getColumns();//列数
    int** _Plants = player->Camp->getCurrentPlants();//植物数组
    int*** _Zombies = player->Camp->getCurrentZombies();//僵尸数组
    int* CD = player->Camp->getPlantCD();//返回植物的CD
    //拷贝的局面
    Plants CopyPlants = PlantsGarden;
    Zombies CopyZombies = ZombiesGarden;

    //统计需要防御的行数

    //给出防御策略

    //对这些策略模拟防守(看看效果)
    //是否能够防御成功以及防御损失
    //以搭建阵容为核心


}
//

//打印植物CD
void printfPlantCD(FILE* p) {
    fprintf(p, "PLANTSCD:%d,%d,%d,%d,%d,%d\n", PlantsGarden.PlantsCD[1], PlantsGarden.PlantsCD[2], PlantsGarden.PlantsCD[3], PlantsGarden.PlantsCD[4], PlantsGarden.PlantsCD[5], PlantsGarden.PlantsCD[6]);
}
//打印僵尸CD
void printfZombiesCD(FILE* p) {
    fprintf(p, "ZOMBIESCD:%d,%d,%d,%d,%d\n", ZombiesGarden.ZombiesCD[1], ZombiesGarden.ZombiesCD[2], ZombiesGarden.ZombiesCD[3], ZombiesGarden.ZombiesCD[4], ZombiesGarden.ZombiesCD[5]);
}
//选手代码在下方填入
void player_ai(IPlayer* player) {

    int Type = player->Camp->getCurrentType();
    if (Type == 0) {
        //植物方
        FILE*p;
        //fopen_s(&p,"err.txt", "a");
        int Step = player->getTime();//回合数
        int Sun = player->Camp->getSun();//阳光
        int Row = player->Camp->getRows();//行数
        int Column = player->Camp->getColumns();//列数
        int** _Plants = player->Camp->getCurrentPlants();//植物数组
        int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
        int* CD = player->Camp->getPlantCD();//返回植物的CD
        //更新地图
        /*
        RenewMapInfo(player);
        //
        Strategies basic(1);
        if (Step == 1) {
            clock_t begin = clock();
            basic.GetStrategies(1, PlantsGarden, ZombiesGarden);
            printf("TIME:%d\n", clock() - begin);
            system("pause");
            basic.printfStrategiesSum();
            system("pause");
        }

      */
    }
    if (Type == 1) {
        //僵尸方
        int Sun = player->Camp->getSun();//月光数
        int Row = player->Camp->getRows();//行数
        int Column = player->Camp->getColumns();//列数
        int** Plants = player->Camp->getCurrentPlants();//植物数组
        int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
        int* CD = player->Camp->getPlantCD();//僵尸CD
        int Step = player->getTime();//回合数
     
    }
}