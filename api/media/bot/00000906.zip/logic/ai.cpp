#include "ai.h"
#include <random>
#include <iostream>
#include <time.h>
//#define DEBUG
//#define SETSEED
/*			普僵	(270)	铁桶(550+270)	撑杆跳(200)	雪橇车(1600)	伽刚特尔(3000)
向日葵(300)	-/3.6		-/3.6			-/3.6		-/1			-/1
豌豆(300)	28/3.6		82/3.6			20/3.6		160/1		300/1
冰豌豆(300)	15/3.6		41/3.6			10/3.6		80/1		150/1
辣椒	(300)	1/-			1/-				1/			1/1			2/1
倭瓜	(300)	1/-			1/-				1/			1/1			2/1
坚果墙(4000)	-/53.3		-/53.3			-/53.3		-/1			-/1

坚果摆在哪一列？4
向日葵种植数量？4
何时种植冰豌豆？

开局种4个

普僵：在左侧放置豌豆
铁桶：在第4格放坚果
撑杆：在撑杆所在的格子放置向日葵
雪橇车：如果有倭瓜在其前一格放倭瓜，如没有则放置辣椒
伽刚特尔：在其所在格放置倭瓜和辣椒（优先级高于雪橇车）


冷却时间主要按月光考虑，次要按CD计算

*/
enum PlantType {
	NOPLANT = 0,
	SUNFLOWER,
	WINTERPEASHOOTER,
	PEASHOOTER,
	SMALLNUT,
	PEPPER,
	SQUASH
};
enum ZombieType {
	NOZOMBIE = 0,
	NORMAL,
	BUCKET,
	POLEVAULT,
	SLED,
	GARGANTUAR
};
enum TryPlant {
	SUCCEED = 0,
	WAITCD,
	NOSPACE,
	INVALIDTYPE,
	NEEDSUN
};
using namespace std;
const int PlantSun[6] = { 50, 100, 400, 125, 50, 50 };
const int ZombieSun[5] = { 50, 125, 125, 300, 300 };

int TryPlacePlant(IPlayer *const player, int PlantType, int x, int y);
bool isSafeToPlant(int ***Zombies, int x, int y);

//选手代码在下方填入
void player_ai(IPlayer *player) {
//	//both
	int CampType = player->Camp->getCurrentType();
	static bool isInitalized = false;
	const int Rows = player->Camp->getRows();
	const int Columns = player->Camp->getColumns();
	if (CampType == 0) {
//		//Plants
//		/*
//		需要解决的问题：
//		根据重要程度决策。例如离底线较近的僵尸需要优先考虑，防御较少的行优先考虑。
// 		当僵尸接近底线时，考虑使用倭瓜和辣椒。
//		寒冰射手。大后期需要用来拖慢速度。
//		阳光冗余。阳光堆积太多，可以适当种一些豌豆、坚果和向日葵。
// 		   当阳光够多时，把后排的豌豆逐渐升级为冰豌豆，
//		向日葵被打后立即补种，结果又被吃掉(get)
//		僵尸累积起来之后，可以考虑放置一个倭瓜。
//		一行的僵尸如果数量够多，则考虑放置一个辣椒。
//		及时止损：当植物快被摧毁时，及时铲除。(铲除后避免再次放置)，后侧的植物都是如此。
// 		   如果在右侧有向日葵，受到僵尸攻击时，将其清除。
// 
//		植物被僵尸推掉之后会给僵尸大量阳光，重点是冰豌豆和坚果。
// 		  
//		
//
// 		
// 
//		阳光仍有盈余。考虑除去一些向日葵，改种射手。
// 		   可以考虑囤倭瓜？
//		后期僵尸增强，无法守住防线。
//		阳光较多时，除去向日葵，改种射手；阳光较少时，增种向日葵？
//		考虑舍弃一行？
//		*/
//
		int ***Zombies = player->Camp->getCurrentZombies();
		int **Plants = player->Camp->getCurrentPlants();
		int *PlantsCD = player->Camp->getPlantCD();
		bool isGiant = false;
		bool isSled = false;
		//根据僵尸做出决策
		for (int j = 0; j < Columns; j++)
			for (int i = 0; i < Rows; i++)
				//如果僵尸靠近底线，则使用倭瓜和辣椒
				for (int k = 0; k < 2 && Zombies[i][j][k] != -1; k++) {
					if (j == 0) {
						if (TryPlacePlant(player, SQUASH, i, 0) == SUCCEED) {

						}
						else if(TryPlacePlant(player, PEPPER, i, 0) == SUCCEED){
						
						}
						else {
							isGiant = false;
							isSled = false;
							for (int m = 0; m < k; m++) {
								if (Zombies[i][j][m] == GARGANTUAR) {
									isGiant = true;
								}
								else if (Zombies[i][j][m] == SLED) {
									isSled = true;
								}
							

							}
							if (isSled || isGiant) {
								player->removePlant(i, 0);
							}
							else {
								TryPlacePlant(player, SMALLNUT, i, 0);
							}
						}
					}
					switch (Zombies[i][j][0])
					{
					case NORMAL:		//普僵
						if (Plants[i][1] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, 1);
						}
						break;
					case BUCKET:		//铁桶
						if (Plants[i][1] == NOPLANT) {
							if (TryPlacePlant(player, SQUASH, i, j) == WAITCD) {
								player->PlacePlant(PEASHOOTER, i, 1);
							}
						}
						else if (Plants[i][2] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, 2);
						}
						else if (Plants[i][5] == NOPLANT) {
							player->PlacePlant(SMALLNUT, i, 5);
						}
						else if (Plants[i][0] == NOPLANT) {
							if(player->Camp->getSun() > 700)
							player->PlacePlant(WINTERPEASHOOTER, i, 0);
						}

						break;
					case POLEVAULT:		//撑杆
						if (Plants[i][1] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, 1);
						}
						if (TryPlacePlant(player, SUNFLOWER, i, j) == WAITCD) {
							if (TryPlacePlant(player, SMALLNUT, i, j) == WAITCD) {
								TryPlacePlant(player, PEASHOOTER, i, 2);
							}
						}
						break;
					case SLED:		//雪橇车
						if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED) {

						}
						else if(TryPlacePlant(player, PEPPER, i, j) == SUCCEED)
						{

						}
						else {
							TryPlacePlant(player, PEASHOOTER, i, 0);
						}
						break;
					case GARGANTUAR:		//伽刚特尔
						if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED &&
							TryPlacePlant(player, PEPPER, i, j) == SUCCEED) {
							
						}
						else {
							TryPlacePlant(player, WINTERPEASHOOTER, i, 0);
						}
						break;
					default:
						break;
					}
					//适时放置倭瓜
					if (PlantsCD[SQUASH] <= 0) {
						if (k > 3) {	//如果有3个以上的僵尸
							TryPlacePlant(player ,SQUASH, i, j);
						}

					}
					//如果同一格内有僵尸，则铲除除坚果，辣椒，倭瓜以外的植物
					if (Plants[i][j] == PEASHOOTER || Plants[i][j] == WINTERPEASHOOTER || Plants[i][j] == SUNFLOWER) {
						player->removePlant(i, j);
					}
					//如果有巨人或者雪橇车，则铲除其前方一格的植物
					if (j > 0) {	//如果不是底线，即其前方还有一格
						if (Zombies[i][j][k] == GARGANTUAR || Zombies[i][j][k] == SLED) {
							if (Plants[i][j - 1] != PEPPER && Plants[i][j - 1] != SQUASH) {
								player->removePlant(i, j - 1);
							}
						}
					}

				}
		//种植4个向日葵
		int i;
		for (i = 0; i < 4 && Plants[i][3] != NOPLANT; i++);
		if (Zombies[i][3][0] == -1 && isSafeToPlant(Zombies,i, 3)) {
			player->PlacePlant(SUNFLOWER, i, 3);
		}

		if (player->getTime() >= 250 && Plants[4][3] == NOPLANT) {
			if (Zombies[4][3][0] == -1 && isSafeToPlant(Zombies, 4, 3)) {
				player->PlacePlant(SUNFLOWER, 4, 3);
			}
		}
		//阳光较多时
		//种植坚果
		if (player->Camp->getSun() > 700) {
			for (i = 0; i < 5 && Plants[i][5] != NOPLANT; i++);
			if (i < 5 && isSafeToPlant(Zombies,i,5)) {
				player->PlacePlant(SMALLNUT, i, 5);
			}
		}
		//种植向日葵
		if (player->Camp->getSun() > 800) {
			for (i = 0; i < 5 && Plants[i][4] != NOPLANT; i++);
			if (i < 5 && isSafeToPlant(Zombies, i, 4)) {
				player->PlacePlant(SUNFLOWER, i, 4);
			}
		}
		//种植冰豌豆
		if (player->Camp->getSun() > 1000) {
			for (int j = 0; j < 3; j++) {
				for (i = 0; i < 5 && Plants[i][j] == WINTERPEASHOOTER; i++);
				if (i < 5 && isSafeToPlant(Zombies, i ,j)) {	//如果符合种植条件
					if (Plants[i][j] != NOPLANT) {
						player->removePlant(i, j);
					}
					player->PlacePlant(WINTERPEASHOOTER, i, j);
					j = 3;
				}
				else {		//如果不符合种植条件
					
				}
			}


		}
	}

	if (CampType == 1) {
		//Zombie
		static int *ZombieTypes;
		static int *lines;
		static int ZombieIndex = 0;
		static int LineIndex = 0;
		if (!isInitalized) {
			ZombieIndex = 0;
			LineIndex = 0;
			ZombieTypes = new int[2000];
			lines = new int[2000];
			time_t t;
			unsigned int seed = (unsigned)time(&t);
			srand(seed); //1650425929
			isInitalized = true;
#ifdef SETSEED
			cout << "Initialized! seed: " << seed << endl;
#endif // DEBUG

			for (int i = 0; i < 2000; i++) {
				ZombieTypes[i] = rand() % 5;
				lines[i] = rand() % 5;
			}
		}
		/*随机化策略：
			随机生成僵尸，用于训练和调试植物
			具体内容：随机抽取僵尸种类，若可以放置则放置，若不能放置，则等待放置条件成立后再放置
			如果找到符合条件的，则抽取行数，并放置僵尸。
		*/
		int *ZombieCD = player->Camp->getPlantCD();
		int ZombieType = 0;
		int line = 0;
			if (ZombieTypes != NULL) {
				ZombieType = ZombieTypes[ZombieIndex];
			}
			else {
#ifdef DEBUG

				cout << "ZombieTypes is NULL! " << endl;
#endif // DEBUG
			}

		if (lines != NULL) {
			line = lines[LineIndex];
		}
		else
		{
#ifdef DEBUG

			cout << "lines is NULL" << endl;
#endif // DEBUG
		}
#ifdef DEBUG
		cout << "index: " << LineIndex << endl;
		cout << "Zombie Type: " << ZombieType << endl;
		cout << "line: " << line << endl;
		cout << "Sun:" << player->Camp->getSun() << endl;
#endif // DEBUG
		if (player->Camp->getSun() > ZombieSun[ZombieType]) {
			int i;
			for (i = 0; i < 5 && ZombieCD[(ZombieType + i) % 5] > 0; i++);
			if (i<5) {
				if (player->Camp->getLeftLines()[line]) {
					player->PlaceZombie((ZombieType+ i)% 5  + 1, line);
					ZombieIndex++;
#ifdef DEBUG

					cout << "Place Zombie: " << (ZombieType + i) % 5 + 1 << endl;
#endif // DEBUG

				}
				else {
#ifdef DEBUG

					cout << "The line has been destroyed! line: " << line << endl;
#endif // DEBUG
				}
			}
			else {
#ifdef DEBUG

				cout << "The zombie is not cooled down! CD: " << ZombieCD[ZombieType] << endl;
#endif // DEBUG
				
			}
		}
		else {
#ifdef DEBUG

			cout << "Sun is not enough! Sun needed: " << ZombieSun[ZombieType] << endl;
#endif // DEBUG
		}
		LineIndex++;
		if (LineIndex == 2000) {
#ifdef DEBUG
			cout << "random is ended!" << endl;
#endif
			delete[] ZombieTypes;
			delete[] lines;
			ZombieTypes = NULL;
			lines = NULL;
			ZombieIndex = 0;
			LineIndex = 0;
			isInitalized = false;
		}
	}
}
//返回三种状态，
int TryPlacePlant(IPlayer *const player, int PlantType, int x, int y) {
	if (PlantType < 1) {
#ifdef DEBUG
		cout << "Invalid PlantType! " << endl;
#endif // DEBUG
		return INVALIDTYPE;
	}
	if (player->Camp->getPlantCD()[PlantType - 1] > 0) {
		return WAITCD;
	}
	if (player->Camp->getCurrentPlants()[x][y] != NOPLANT) {
		return NOSPACE;
	}
	else if (player->Camp->getSun() < PlantSun[PlantType - 1]) {
		return NEEDSUN;
	}
	{
		player->PlacePlant(PlantType, x, y);
		return SUCCEED;
	}
}
//如果植物前方没有僵尸，则返回true
bool isSafeToPlant(int*** Zombies,int x, int y) {
	for (int k = 0; Zombies[x][y][k] != -1; k++) {
		if (Zombies[x][y + 1][k] == GARGANTUAR || Zombies[x][y + 1][k] == SLED) {
				return false;
		}
	}
	return true;
}