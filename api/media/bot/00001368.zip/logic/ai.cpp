#include "ai.h"
#include <iostream>
#include <vector>
#include <ctime>
#include <map>
using namespace std;

static IPlayer* thePlayer;
//游戏回合，0-2000
static int gTime = 0;
//我方阳光/月光
static int sun = 0;

int linshi = -1;

bool zombie_linshi = false;
void CreatureUpdate();

void PlantAction(); void ZombieAction();
void SunFlower_Plant(); void IcePea_Plant(); void MegaBomb_Plant();  void Nut_plant(); void NormalPea_plant();
int* DoesThisLevelZombieShowUp(int level);
int GetLineZombieNums(int line = 0);
bool Place(int type, int pos, bool isPlant = true, bool replace = false);
bool DoesTheLineHaveZombie(int lineID, int columnID, int distance = 1, int kind = 0);
//场地为5*10
// 1向日葵 2冰豆3豌豆 4坚果 5辣椒 6倭瓜
map<int, vector<int>> plants;
// 5巨人 4雪橇 3撑杆 2铁桶 1普通
map<int, vector<int>> zombies;

//个位为行 十位为列

int nutNum[5] = { 0,0,0,0,0 };
//选手代码在下方填入

void player_ai(IPlayer* player)
{
	if (thePlayer == nullptr)thePlayer = player;
	gTime = thePlayer->getTime();
	sun = thePlayer->Camp->getSun();

	CreatureUpdate();
	for (int i = 0; i < 5; i++)
	{
		if (thePlayer->Camp->getLeftLines()[i] == 1)
		{
			break;
		}
		else if (i == 4)
		{
			return;
		}
	}

	srand((int)time(NULL) + thePlayer->getTime() + rand() % 100);
	switch (thePlayer->Camp->getCurrentType())
	{
	case 0:
		PlantAction();
		break;
	case 1:
		ZombieAction();
		break;
	}
}

void PlantAction()//植物行为
{
	MegaBomb_Plant();
	if (gTime <= 1000)	Nut_plant();
	IcePea_Plant();
	NormalPea_plant();
	SunFlower_Plant();
}
void ZombieAction()
{
	vector<int> sb{ -1,-1,-1,-1,-1 };
	int j = 0;
	for (int i = 0; j < 5; i++)
	{
		if (i == 5)i = 0;
		if (thePlayer->Camp->getLeftLines()[i] == 1)
		{
			sb[j] = i;
			j++;
		}
	}
	int first, second, third;
	if (thePlayer->Camp->getSun() >= 125 && thePlayer->getTime() <= 450)//撑杆和普通
	{
		first = rand() % 5;
		thePlayer->PlaceZombie(3, sb[first]);
		sb.erase(sb.begin() + first);
		second = rand() % 4;
		thePlayer->PlaceZombie(1, sb[second]);
		sb.erase(sb.begin() + second);
	}
	else if (thePlayer->getTime() >= 499 && thePlayer->getTime() % 10 == 0 && thePlayer->getTime() < 600)
	{
		if (plants.at(2).size() >= 8)return;
		first = rand() % 5;
		thePlayer->PlaceZombie(5, sb[first]);
		sb.erase(sb.begin() + first);
		second = rand() % 4;
		thePlayer->PlaceZombie(3, sb[second]);
		sb.erase(sb.begin() + second);
		third = rand() % 3;
		thePlayer->PlaceZombie(4, sb[third]);
		sb.erase(sb.begin() + third);
		int fourth = rand() % 2;
		thePlayer->PlaceZombie(2, sb[fourth]);
		sb.erase(sb.begin() + fourth);
	}
	else if (thePlayer->getTime() >= 1499)
	{
		if (!zombie_linshi && plants.at(6).size() >= 3)
		{
			second = rand() % 4;
			thePlayer->PlaceZombie(2, sb[second]);
			sb.erase(sb.begin() + second);
			third = rand() % 3;
			thePlayer->PlaceZombie(1, sb[third]);
			sb.erase(sb.begin() + third);

			zombie_linshi = true;
		}
		else if (!zombie_linshi && plants.at(6).size() >= 1)
		{
			Place(2, plants.at(6)[0] % 10, false);
			zombie_linshi = true;
		}
		else if (zombie_linshi || plants.at(6).size() <= 1)
		{
			first = rand() % 5;
			thePlayer->PlaceZombie(5, sb[first]);
			sb.erase(sb.begin() + first);
			second = rand() % 4;
			thePlayer->PlaceZombie(4, sb[second]);
			sb.erase(sb.begin() + second);
			zombie_linshi = false;
		}
	}
	sb.clear();
}
// 更新creature情况
void CreatureUpdate()
{
	plants = { {1,{}} , {2,{}} , {3,{}} , {4,{}} , {5,{}} , {6,{}} };
	zombies = { {1,{}} , {2,{}} , {3,{}} , {4,{}} , {5,{}} };
	for (int i = 0; i < 5; i++)//个位为 行 十位为 列
	{
		for (int j = 0; j < 10; j++)
		{
			if (thePlayer->Camp->getCurrentPlants()[i][j] > 0)
				plants.at(thePlayer->Camp->getCurrentPlants()[i][j]).push_back(i + 10 * j);
			int k = 0;
			while (thePlayer->Camp->getCurrentZombies()[i][j][k] > 0)
			{
				zombies.at(thePlayer->Camp->getCurrentZombies()[i][j][k]).push_back(i + 10 * j);
				k++;
			}
		}
	}
}
//==========================================================
void SunFlower_Plant()//种植太阳花
{
	if (gTime <= 200 && zombies.at(3).size() > 0 && zombies.at(3)[0] / 10 > 4)
		Place(1, zombies.at(3)[0] - 10, true);
	if (thePlayer->Camp->getSun() >= 1500)return;
	for (int i = 0; i < 5; i++)
		if (nutNum[i] > 3)
			for (int j = 3; j < nutNum[i]; j++)
				if (Place(1, i + 10 * j))
					break;
	vector<int> area = { 40,41,42,43,44 };
	if (gTime < 700)
	{
		area.push_back(30);
		area.push_back(31);
		area.push_back(32);
		area.push_back(33);
		area.push_back(34);
		area.push_back(50);
		area.push_back(51);
		area.push_back(52);
		area.push_back(53);
		area.push_back(54);
		area.push_back(60);
		area.push_back(61);
		area.push_back(62);
		area.push_back(63);
		area.push_back(64);
	}
	if (gTime > 650)
	{
		area.push_back(60);
		area.push_back(61);
		area.push_back(62);
		area.push_back(63);
		area.push_back(64);
	}
	while (area.size() > 0 && area[0] > 0)
	{
		int number = rand() % area.size();
		int num = area[number];
		if (thePlayer->Camp->getCurrentPlants()[num % 10][num / 10] == 0 && !DoesTheLineHaveZombie(num % 10, num / 10, 3))
		{
			thePlayer->PlacePlant(1, num % 10, num / 10);
			break;
		}
		area.erase(area.begin() + number);
	}
	area.clear();
}
void IcePea_Plant()
{
	if (linshi >= 0 && (Place(2, linshi, true) || thePlayer->Camp->getCurrentPlants()[linshi % 10][linshi / 10] > 0))
		linshi = -1;
	else
	{
		vector<int> area = { 0,1,2,3,4,10,11,12,13,14,20,21,22,23,24 };
		if (thePlayer->getTime() >= 550)
		{
			area.push_back(30);
			area.push_back(31);
			area.push_back(32);
			area.push_back(33);
			area.push_back(34);
		}
		if (thePlayer->getTime() >= 650)
		{
			area.push_back(40);
			area.push_back(41);
			area.push_back(42);
			area.push_back(43);
			area.push_back(44);
			area.push_back(50);
			area.push_back(51);
			area.push_back(52);
			area.push_back(53);
			area.push_back(54);
		}
		while (area.size() > 0)
		{
			int number = rand() % area.size();
			int num = area[number];
			if ((DoesTheLineHaveZombie(num % 10, num / 10, 10) || sun >= 500) && thePlayer->Camp->getPlantCD()[1] == 0)
			{
				if (thePlayer->Camp->getCurrentPlants()[num % 10][num / 10] != 2 && sun >= 500 && linshi < 0 && thePlayer->Camp->getLeftLines()[num % 10]>0)
				{
					thePlayer->removePlant(num % 10, num / 10);
					linshi = num;
					break;
				}
				if (Place(2, num, true))
					break;
			}
			area.erase(area.begin() + number);
		}
		area.clear();
	}

}
//只尝试种植少数豌豆射手,在第0列
void NormalPea_plant()
{
	if (gTime <= 80)
	{
		if (zombies.at(3).size() > 0
			&& thePlayer->Camp->getCurrentZombies()[zombies.at(3)[0] % 10][zombies.at(3)[0] / 10][1] == -1
			&& zombies.at(3)[0] / 10 >= 9)
			Place(3, zombies.at(3)[0] % 10, true);
		if (zombies.at(2).size() > 0)
			Place(3, zombies.at(2)[0] % 10, true);
		if (zombies.at(1).size() > 0)
			Place(3, zombies.at(1)[0] % 10, true);
	}
}
void Nut_plant()
{
	if (gTime == 999)
	{
		for (int i = 0; i < 5; i++)
		{
			if (nutNum[i] >= 0 && thePlayer->Camp->getCurrentPlants()[i][nutNum[i]] == 4)
			{
				thePlayer->removePlant(i, nutNum[i]);
			}
		}
	}

	for (int i = 0; i < 5; i++)if (thePlayer->Camp->getCurrentPlants()[i][nutNum[i]] != 4 || nutNum[i] <= 3)nutNum[i] = 0;

	int* p = DoesThisLevelZombieShowUp(2);
	if (p[1] > 1)
	{
		if (nutNum[p[0]] > 0)goto end1;
		thePlayer->PlacePlant(4, p[0], p[1] - 1);
		if (thePlayer->Camp->getCurrentPlants()[p[0]][p[1] - 1] == 4)
		{
			nutNum[p[0]] = p[1] - 1;
			thePlayer->PlacePlant(4, p[0], p[1] - 3);
			Place(3, p[0], true);
		}
	}
end1:delete[]p;
	p = DoesThisLevelZombieShowUp(1);
	if (p[1] > 1)
	{
		if (nutNum[p[0]] > 0)goto end2;
		thePlayer->PlacePlant(4, p[0], p[1] - 1);
		if (thePlayer->Camp->getCurrentPlants()[p[0]][p[1] - 1] == 4)
		{
			nutNum[p[0]] = p[1] - 1;
			Place(3, p[0], true);
		}
	}
end2: delete[]p;
}
void MegaBomb_Plant()
{
	bool placeMelon = false;
	//倭瓜·前期普通、铁桶、撑杆的压顺序
	if (zombies.at(4).size() > 0)
	{
		if (GetLineZombieNums(zombies.at(4)[0] % 10) < 2 && Place(6, zombies.at(4)[0] - 10)) placeMelon = true;
	}
	else if (zombies.at(5).size() > 0)
	{
		Place(6, zombies.at(5)[0] - 10);
	}
	else if (gTime <= 250 && zombies.at(2).size() * zombies.at(3).size() > 0)
	{
		Place(6, zombies.at(2)[0] - 10);
	}
	else if (gTime <= 250 && zombies.at(1).size() * zombies.at(3).size() > 0)
	{
		thePlayer->PlacePlant(6, zombies.at(3)[0] % 10, zombies.at(3)[0] / 10 - 1);
	}
	//遍历每一行,从数量最多的一行开始，写的比较烂
	int numRank[5][2] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		numRank[i][0] = GetLineZombieNums(i);
		numRank[i][1] = i;
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = i + 1; j < 5; j++)
		{
			if (numRank[i][0] < numRank[j][0])
			{
				int sb = numRank[i][0];
				numRank[i][0] = numRank[j][0];
				numRank[j][0] = sb;
				sb = numRank[i][1];
				numRank[i][1] = numRank[j][1];
				numRank[j][1] = sb;
			}
		}
	}
	for (int i = 0; i < 5; i++)
	{
		//有僵尸出现在第二列（列id为1）的情况
		if (thePlayer->Camp->getCurrentZombies()[numRank[i][1]][1][0] > 0)
		{
			if (GetLineZombieNums(numRank[i][1]) >= 2)
			{
				Place(5, 90 + numRank[i][1]);
			}
			else
			{
				if (!Place(6, numRank[i][1]))	Place(6, 10 + numRank[i][1]);
			}
		}
		//辣椒对于冰车、巨人
		if (DoesTheLineHaveZombie(i, 0, 10, 4))
		{
			if (placeMelon)
			{
				placeMelon = false;
			}
			else
			{
				Place(5, 90 + numRank[i][1]);
			}
		}
		if (DoesTheLineHaveZombie(i, 0, 10, 5))
		{
			if (gTime >= 1000 && GetLineZombieNums(numRank[i][1]) >= 2)
			{
				Place(5, 90 + numRank[i][1]);
			}
			else if (gTime < 1000)
			{
				Place(5, 90 + numRank[i][1]);
			}
		}
	}
	//中期在右边三列种植倭瓜
	if (gTime > 600 && gTime < 1600)
	{
		vector<int> area = { 80,81,82,83,84,90,91,92,93,94,70,71,72,73,74 };
		while (area.size() > 0 && area[0] > 0)
		{
			int number = rand() % area.size();
			int num = area[number];
			if (thePlayer->Camp->getCurrentPlants()[num % 10][num / 10] == 0)
			{
				thePlayer->PlacePlant(6, num % 10, num / 10);
				break;
			}
			area.erase(area.begin() + number);
		}
		area.clear();
	}
}
//==========================================================
bool DoesTheLineHaveZombie(int lineID, int columnID, int distance, int kind)//该行是否有僵尸,如果有，则判断相对位置
{
	for (int i = 0; i < 10; i++)
	{
		if (thePlayer->Camp->getCurrentZombies()[lineID][i][0] > 0)
		{
			if (kind > 0)
			{
				int j = 0;
				while (thePlayer->Camp->getCurrentZombies()[lineID][i][j] > 0)
				{
					if (kind == thePlayer->Camp->getCurrentZombies()[lineID][i][0])return 1;
					j++;
				}
			}
			else
			{
				if (columnID < i - distance)return 0;
				else return 1;
			}

		}
	}
	return 0;
}
/// <summary>
///  返回位置
/// </summary>
int* DoesThisLevelZombieShowUp(int level)
{
	int* pos = new int[2]{ -1,-1 };
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			int k = 0;
			while (thePlayer->Camp->getCurrentZombies()[i][j][k] > -1)
			{
				if ((thePlayer->Camp->getCurrentZombies()[i][j][k] == level))
				{
					pos[0] = i;
					pos[1] = j;
					goto end;
				}
				k++;
			}
		}
	}
end:return pos;
}

int GetLineZombieNums(int line)
{
	int num = 0;
	for (int j = 0; j < 10; j++)
	{
		int k = 0;
		while (thePlayer->Camp->getCurrentZombies()[line][j][k] > -1)k++;
		num += k;
	}
	return num;
}
//pos:个位数字 行 ；十位数字 列
bool Place(int type, int pos, bool isPlant, bool replace)
{
	bool success = false;
	if (isPlant)
	{
		if (!thePlayer->Camp->getLeftLines()[pos % 10]) return success;
		if (thePlayer->Camp->getCurrentPlants()[pos % 10][pos / 10] > 0)
			return success;
		thePlayer->PlacePlant(type, pos % 10, pos / 10);
		if (thePlayer->Camp->getCurrentPlants()[pos % 10][pos / 10] == type)success = true;
	}
	else
	{
		thePlayer->PlaceZombie(type, pos % 10);
		success = true;
	}
	return success;
}