#include <vector>
#include <queue>
#include "ai.h"

// code only for fun, happiness is the most important!!!

const int plantSun[7] = { 0, 50, 400, 100, 50, 125, 50 };
const int zombieSun[6] = { 0, 50, 125, 125, 300, 300 };
const int zombieBlood[6] = { 0, 270, 820, 200, 1600, 3000 };

struct Map
{
	int** Plant;    // (i, j) 's plant
	int*** Zombies; // (i, j) 's zombies
	std::vector<std::pair<int, int>> plantsPosition[7];  // position of the plants which are type i
	std::vector<std::pair<int, int>> zombiesPosition[6]; // position of the zombies which are type i

	int Sun;
	int Time;
	int* CD;
	int* LeftLines;

	Map(IPlayer* player) 
	{
		Sun = player->Camp->getSun();
		CD = player->Camp->getPlantCD();          // from 0
		LeftLines = player->Camp->getLeftLines(); // 1 exist, 0 don't exist
		Plant = player->Camp->getCurrentPlants();
		Zombies = player->Camp->getCurrentZombies();
		Time = player->getTime();
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (Zombies[i][j][k] != -1)
				{
					zombiesPosition[Zombies[i][j][k]].push_back(std::pair<int, int>(i, j));
					k++;
				}

				plantsPosition[Plant[i][j]].push_back(std::pair<int, int>(i, j));
			}
		}
	}

};


struct PlantAction
{
	int Type;
	int i, j;
	int priority;
	PlantAction(int Type, int i, int j, int priority) :Type(Type), i(i), j(j), priority(priority) {}

	bool operator<(const PlantAction& x) const
	{
		return priority < x.priority;
	}
};


struct ZombieAction
{
	int Type;
	int i;
	int priority;
	ZombieAction(int Type, int i, int priority) :Type(Type), i(i), priority(priority) {}

	bool operator<(const PlantAction& x) const
	{
		return priority < x.priority;
	}
};


struct RowBlood
{
	int row, blood;

	RowBlood(int row, int blood) :row(row), blood(blood) {}
	bool operator<(const RowBlood& x) const
	{
		return blood > x.blood;
	}
};


PlantAction sunFlower(Map map)
{
	int priority = 0;
	std::priority_queue<RowBlood> rowBlood;

	if (map.plantsPosition[1].size() < 2 && map.Sun <= 175)
		priority = 12;
	else if (map.plantsPosition[1].size() < 7 && map.Sun <= 300)
		priority = 5;
	else
		priority = 1;

	for (int i = 0; i < 5; i++)
	{
		if (!map.LeftLines[i]) continue;
		int bloods = 0;
		for (int k = 1; k < 6; k++)
		{
			int j = 0;
			while (j < map.zombiesPosition[k].size())
			{
				if (map.zombiesPosition[k][j].first == i)
					bloods += zombieBlood[k];
				j++;
			}
		}
		rowBlood.push(RowBlood(i, bloods));
	}
	
	int sum = int(rowBlood.size());
	for (int i = 0; i < sum; i++)
	{
		int row = rowBlood.top().row;
		for (int j = 2; j < 5; j++)
		{
			if (map.Plant[row][j] == 0 && !map.CD[0])
			{
				return PlantAction(1, row, j, priority);
			}
		}
		rowBlood.pop();
	}

	priority = 0;
	return PlantAction(1, 0, 0, priority);
}


PlantAction peaShooter(Map map)
{
	int priority = 0;
	int row = 0, column = 0;
	std::priority_queue<RowBlood> rowBlood;

	for (int i = 0; i < 5; i++)
	{
		if (!map.LeftLines[i]) continue;
		int bloods = 0;
		for (int k = 1; k < 6; k++)
		{
			int j = 0;
			while (j < map.zombiesPosition[k].size())
			{
				if (map.zombiesPosition[k][j].first == i)
					bloods += zombieBlood[k];
				j++;
			}
		}
		rowBlood.push(RowBlood(i, bloods));
	}

	int sum = int(rowBlood.size());
	for (int i = 0; i < sum; i++)
	{
		row = rowBlood.top().row;
		for (int j = 0; j < 2; j++)
		{
			if (map.Plant[row][j] == 0 && !map.CD[2] &&rowBlood.top().blood > 0 && rowBlood.top().blood <= 600)
			{
				priority = 7;
				return PlantAction(3, row, j, priority);
			}
		}
		rowBlood.pop();
	}


	for (int j = 0; j < 6; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!map.Plant[i][j] && map.LeftLines[i] && map.Sun >= 350)
			{
				priority = 4;
				return PlantAction(3, i, j, priority);
			}
		}
	}

	priority = 0;
	return PlantAction(3, 0, 0, priority);
}


PlantAction winterPeaShooter(Map map)
{
	int priority = 0;
	int row = 0, column = 4;
	if (map.Time >= 1500)
		column = 5;
	std::priority_queue<RowBlood> rowBlood;
	if (map.Sun >= 600)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!map.LeftLines[i]) continue;
			int bloods = 0;
			for (int k = 1; k < 6; k++)
			{
				int j = 0;
				while (j < map.zombiesPosition[k].size())
				{
					if (map.zombiesPosition[k][j].first == i)
						bloods += zombieBlood[k];
					j++;
				}
			}
			rowBlood.push(RowBlood(i, bloods));
		}

		std::priority_queue<RowBlood> rowBloodCopy(rowBlood);
		int sum = int(rowBlood.size());
		for (int i = 0; i < sum; i++)
		{
			row = rowBlood.top().row;
			for (int j = 0; j < column; j++)
			{
				if (map.Plant[row][j] == 0 && !map.CD[1])
				{
					priority = 10;
					return PlantAction(2, row, j, priority);
				}
			}
			rowBlood.pop();
		}

		sum = int(rowBloodCopy.size());
		for (int i = 0; i < sum; i++)
		{
			row = rowBloodCopy.top().row;
			for (int j = 0; j < column; j++)
			{
				if (map.Plant[row][j] != 2 && !map.CD[1])
				{
					priority = 10;
					return PlantAction(2, row, j, priority);
				}
			}
			rowBloodCopy.pop();
		}
	}

	priority = 0;
	return PlantAction(2, 0, 0, priority);
}


PlantAction smallNut(Map map)
{
	int priority = 0;
	int row = 0, column = 0;
	if (map.Time < 1500)
	{
		for (int i = 0; i < map.zombiesPosition[1].size(); i++)
		{
			int row = map.zombiesPosition[1][i].first;
			int bloods = 0;
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (map.Zombies[row][j][k] != -1)
				{
					bloods += zombieBlood[map.Zombies[row][j][k]];
					k++;
				}
			}

			if (bloods <= 900 && bloods > 0)
			{
				for (int j = 0; j < 10; j++)
				{
					if (map.Zombies[row][j][0] != -1 && !map.CD[3])
					{
						priority = 6;
						return PlantAction(4, row, j - 1, priority);
					}
				}
			}
		}

		for (int j = 8; j < 9; j++)
		{
			for (int i = 0; i < 5; i++)
			{
				if (!map.Plant[i][j] && map.LeftLines[i] && map.Sun >= 200 && !map.CD[3])
				{
					priority = 2;
					return PlantAction(4, i, j, priority);
				}
			}
		}
	}
	priority = 0;
	return PlantAction(4, 0, 0, priority);
}


PlantAction pepper(Map map)
{
	int priority = 0;
	int row = 0, column = 0;
	int gate = 3000;

	if (map.Time < 400)
		gate = 600;
	for (int i = 0; i < 5; i++)
	{
		int bloods = 0;
		for (int j = 0; j < 10; j++)
		{
			int k = 0;
			while (map.Zombies[i][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[i][j][k]];
				k++;
			}
		}

		if (bloods >= gate)
		{
			for (int j = 8; j >= 0; j--)
			{
				int k = 0;
				if (map.Plant[i][j] == 0 && !map.CD[4])
				{
					priority = 13;
					return PlantAction(5, i, j, priority);
				}
			}
		}
	}

	priority = 0;
	return PlantAction(5, 0, 0, priority);
}


PlantAction squash(Map map)
{
	int priority = 0;
	int row = 0, column = 0;

	for (int i = 0; i < 5; i++)
	{
		for (int j = 1; j < 10; j++)
		{
			int bloods = 0;
			int k = 0;
			while (map.Zombies[i][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[i][j][k]];
				k++;
			}

			if (bloods >= 250)
			{
				for (int k = 5; k > 0; k--)
				{
					for (int j = 0; j < map.zombiesPosition[k].size(); j++)
					{
						if (!map.CD[5] && map.zombiesPosition[k][j].second > 6)
						{
							priority = 11;
							return PlantAction(6, map.zombiesPosition[k][j].first, map.zombiesPosition[k][j].second - 1, priority);
						}
					}
				}
			}
		}
	}
	 
	for (int j = 9; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (map.Plant[i][j] == 0 && map.LeftLines[i] && map.Sun >= 250 && !map.CD[5])
			{
				priority = 3;
				return PlantAction(6, i, j, priority);
			}
		}
	}

	priority = 0;
	return PlantAction(6, 0, 0, priority);
}


void ZombieActionBegin(IPlayer* player)
{
	Map map(player);
	int Time = player->getTime();
	if (Time < 300 || (Time >= 499 && Time <=750))
	{
		std::priority_queue<RowBlood> rowBlood;
		for (int i = 0; i < 5; i++)
		{
			if (!map.LeftLines[i]) continue;
			int cnt = 0;
			for (int k = 2; k < 7; k++)
			{
				int j = 0;
				while (j < map.plantsPosition[k].size())
				{
					if (map.plantsPosition[k][j].first == i)
						cnt++;
					j++;
				}
			}
			rowBlood.push(RowBlood(i, cnt));
		}

		int sum = int(rowBlood.size());
		int j = 2;
		for (int i = 0; i < sum; i++)
		{
			int row = rowBlood.top().row;
			if (!map.CD[j - 1])
			{
				player->PlaceZombie(j, row);
				rowBlood.pop();
			}
			j = (j + 1) % 3 + 1;
		}
	}
	return;
}

void ZombieActionEnd(IPlayer* player)
{
	Map map(player);
	int Time = player->getTime();
	if ((Time >= 999 && Time <= 1300) || (Time >= 1499 && Time <= 1800))
	{
		std::priority_queue<RowBlood> rowBlood;
		for (int i = 0; i < 5; i++)
		{
			if (!map.LeftLines[i]) continue;
			int cnt = 0;
			for (int k = 2; k < 7; k++)
			{
				int j = 0;
				while (j < map.plantsPosition[k].size())
				{
					if (map.plantsPosition[k][j].first == i)
						cnt++;
					j++;
				}
			}
			rowBlood.push(RowBlood(i, cnt));
		}

		int sum = int(rowBlood.size());
		int j = 5;
		for (int i = 0; i < sum; i++)
		{
			int row = rowBlood.top().row;
			if (!map.CD[j - 1])
			{
				player->PlaceZombie(j, row);
				rowBlood.pop();
			}
			if (j == 5) j = 4;
			else j = 5;
		}
	}
	return;
}


void plantPlay(IPlayer* player)
{
	Map map(player);
	std::priority_queue<PlantAction> actions;

	actions.push(sunFlower(map));
	actions.push(peaShooter(map));
	actions.push(winterPeaShooter(map));
	actions.push(pepper(map));
	actions.push(smallNut(map));
	actions.push(squash(map));

	int sum = int(actions.size());

	if (actions.top().priority != 0 && !map.CD[actions.top().Type - 1])
	{
		if (actions.top().priority >= 10)
		{
			player->removePlant(actions.top().i, actions.top().j);
			player->PlacePlant(actions.top().Type, actions.top().i, actions.top().j);
		}
		else if (!map.Plant[actions.top().i][actions.top().j] && plantSun[actions.top().Type] <= map.Sun - 50)
		{
			player->PlacePlant(actions.top().Type, actions.top().i, actions.top().j);
		}
	}
	actions.pop();
	return;
}

void player_ai(IPlayer* player)
{
	auto type = player->Camp->getCurrentType();

	// 植物方
	if (type == 0)
	{
		plantPlay(player);
	}

	// 僵尸方
	if (type == 1)
	{
		ZombieActionBegin(player);
		ZombieActionEnd(player);
	}
}

