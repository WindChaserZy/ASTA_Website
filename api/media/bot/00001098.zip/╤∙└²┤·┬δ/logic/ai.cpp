#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}
int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
void player_ai(IPlayer * player)
{
    // player code here
    int Type = player->Camp->getCurrentType();
    if (Type == 0)
    {
        int Time = player->getTime();
        int ZombiesBlood[6] = { 0, 270 * 3, 820 * 3, 200 * 3, 1600 * 3, 3000 * 3 };//��ʬѪ������Ϊ�㶹�Ĺ�������20 / 3�������ҽ���ʬѪ�����㶹�Ĺ�����������3
        if (Time > 1000)
        {
            for (int i = 0; i < 6; i++)
            {
                ZombiesBlood[i] = (long)ZombiesBlood[i] * (long)Time / (long)1000;
            }
        }
        const int ZombiesSpeed[7] = { 0, 2, 2, 4, 2, 2, 2 };//��ʬ�ٶȣ�ZombiesSpeeed[6]Ϊ�Ÿ�����ʬ������ٶȣ��һ�û�����ѩ�����ľ�ȷ�ٶ�
        int Giant[5] = { 0 };//�����i���о��ˣ���ô����1
        int Sled[5] = { 0 };
        int* LeftLines = player->Camp->getLeftLines();
        int*** ZombiesNow = player->Camp->getCurrentZombies();//��ǰ�غϽ�ʬ��Ϣ
        int** PlantsNow = player->Camp->getCurrentPlants();//��ǰ�غ�ֲ����Ϣ
        int Nearest[5] = { -1, -1, -1, -1, -1 };//����Ľ�ʬ��ţ���ʼֵΪ-1
        int* PlantCD = player->Camp->getPlantCD();//ֲ��CD
        int Sun = player->Camp->getSun();//����
        Sun -= 75;
        //ͳ���㶹������
        int SunflowerNum[5] = { 0 };
        int PeashooterNum[5][2] = { 0 };//PeashootNum[i][0]Ϊ�㶹������[1]Ϊ���㶹����
        int HasWinterPeashooter[5] = { 0 };//���һ�����б��㶹����ôΪ1���ں��������У����Ϊ1��ô��ǰ����ʬ�ٶȼ���
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (PlantsNow[i][j] == 3)
                {
                    PeashooterNum[i][0]++;
                }
                if (PlantsNow[i][j] == 2)
                {
                    PeashooterNum[i][1]++;
                    HasWinterPeashooter[i] = 1;
                }
                if (PlantsNow[i][j] == 1)
                {
                    SunflowerNum[i]++;
                }
            }
        }
        //ͳ�ƽ�ʬ��Ѫ����λ�ú�����
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int k = 0; ZombiesNow[i][9][k] != -1; k++)
            {
                int HasSameZombie = 0;//�����һ�غ�����һ�غϵ����ҷ��ĸ���������ͬ���͵Ľ�ʬ��������������ͬһ����ʬ�������һ�غ��ж���һ�غ�û�У���ô������ʬ��������һ���µĽ�ʬ
                for (int m = 0; Zombies[i][9][m] != -1; m++)
                {
                    if (ZombiesNow[i][9][k] == Zombies[i][9][m])
                    {
                        HasSameZombie = 1;
                        break;
                    }
                }
                if (HasSameZombie == 0)
                {
                    int m = 0;
                    for (; ZombiesAccurate[i][m][0] != 0;)
                    {
                        m++;
                    }
                    ZombiesAccurate[i][m][0] = ZombiesNow[i][9][k];//��ʬ����
                    ZombiesAccurate[i][m][1] = ZombiesBlood[ZombiesNow[i][9][k]];//��ʬѪ��
                    ZombiesAccurate[i][m][2] = 100;//��ʬλ�ã�Ϊ����洢���˴�������10
                }
            }
        }
        //����һ��������ѩ���������
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                for (int k = 0; ZombiesNow[i][j][k] != -1; k++)
                {
                    if (ZombiesNow[i][j][k] == 4)
                    {
                        Sled[i] = 1;
                    }
                    if (ZombiesNow[i][j][k] == 5)
                    {
                        Giant[i] = 1;
                    }
                }
            }
        }
        //�����ʬ��������������ϢĨ���������ʬ�����յ㣬��һ�е���Ϣ��Ĩ��
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (ZombiesAccurate[i][j][0] == 0)
                {
                    continue;
                }
                if (ZombiesAccurate[i][j][2] <= 0)
                {
                    for (int k = 0; k < 10; k++)
                    {
                        for (int n = 0; n < 3; n++)
                        {
                            ZombiesAccurate[i][k][n] = 0;
                        }
                    }
                    break;
                }
                if (ZombiesAccurate[i][j][1] <= 0)
                {
                    ZombiesAccurate[i][j][0] = 0;
                    ZombiesAccurate[i][j][1] = 0;
                    ZombiesAccurate[i][j][2] = 0;
                    continue;
                }
            }
        }
        //�����ƽ����Ľ�ʬ�ı��
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (ZombiesAccurate[i][j][0] != 0)
                {
                    if (Nearest[i] == -1)
                    {
                        Nearest[i] = j;
                    }
                    else
                    {
                        if (ZombiesAccurate[i][j][2] < ZombiesAccurate[i][Nearest[i]][2])
                        {
                            Nearest[i] = j;
                        }
                    }
                }
            }
        }
        //����ÿ�غϽ�ʬ�Ŀ�Ѫ
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (Nearest[i] != -1)
            {
                ZombiesAccurate[i][Nearest[i]][1] -= PeashooterNum[i][0] * 20;//��ǰ����ʬ�ܵ��㶹���˺�
                for (int j = 0; j < 10; j++)
                {
                    if (ZombiesAccurate[i][j][2] == ZombiesAccurate[i][Nearest[i]][2])
                    {
                        ZombiesAccurate[i][j][1] -= PeashooterNum[i][1] * 45;//��ǰ����ʬ�������ڵ����н�ʬ�ܵ����㶹���˺�
                    }
                }
            }
        }
        //���㽩ʬλ��
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (ZombiesAccurate[i][j][0] != 3 && ZombiesAccurate[i][j][0] != 4)
                {
                    if ((ZombiesAccurate[i][j][0] != 0 && PlantsNow[i][ZombiesAccurate[i][j][2] / 10] == 0) || ZombiesAccurate[i][j][2] == 100)
                    {
                        ZombiesAccurate[i][j][2] -= ZombiesSpeed[ZombiesAccurate[i][j][0]];
                        if (Nearest[i] != -1 && ZombiesAccurate[i][j][2] == ZombiesAccurate[i][Nearest[i]][2] && HasWinterPeashooter[i] == 1)
                        {
                            ZombiesAccurate[i][j][2] += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][j][0]];
                        }
                    }
                }
                if (ZombiesAccurate[i][j][0] == 3 && ZombiesAccurate[i][j][2] > 7)//����ǳŸ�����ʬ
                {
                    ZombiesAccurate[i][j][2] -= ZombiesSpeed[ZombiesAccurate[i][j][0]];
                }
                else if (ZombiesAccurate[i][j][0] == 3 && ZombiesAccurate[i][j][2] == 7)
                {
                    ZombiesAccurate[i][j][2] -= 10;
                }
                else if (ZombiesAccurate[i][j][0] == 3 && ZombiesAccurate[i][j][2] < 6 && PlantsNow[i][6] > 0)
                {
                    ZombiesAccurate[i][j][0] = 6;
                    ZombiesAccurate[i][j][2] -= ZombiesSpeed[ZombiesAccurate[i][j][0]];
                }
                else if (ZombiesAccurate[i][j][0] == 3 && ZombiesAccurate[i][j][2] <= 6 && PlantsNow[i][6] == 0)
                {
                    ZombiesAccurate[i][j][2] -= ZombiesSpeed[ZombiesAccurate[i][j][0]];
                }
                if (ZombiesAccurate[i][j][0] == 4)
                {
                    if (ZombiesAccurate[i][j][2] <= 63)
                    {
                        ZombiesAccurate[i][j][2]--;
                    }
                    if (ZombiesAccurate[i][j][2] == 65)
                    {
                        ZombiesAccurate[i][j][2] = 63;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 66)
                    {
                        ZombiesAccurate[i][j][2] = 65;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 67)
                    {
                        ZombiesAccurate[i][j][2] = 66;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 68)
                    {
                        ZombiesAccurate[i][j][2] = 67;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 70)
                    {
                        ZombiesAccurate[i][j][2] = 68;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 72)
                    {
                        ZombiesAccurate[i][j][2] = 70;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 74)
                    {
                        ZombiesAccurate[i][j][2] = 72;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 76)
                    {
                        ZombiesAccurate[i][j][2] = 74;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 77)
                    {
                        ZombiesAccurate[i][j][2] = 76;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 79)
                    {
                        ZombiesAccurate[i][j][2] = 77;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 81)
                    {
                        ZombiesAccurate[i][j][2] = 79;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 84)
                    {
                        ZombiesAccurate[i][j][2] = 81;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 86)
                    {
                        ZombiesAccurate[i][j][2] = 84;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 88)
                    {
                        ZombiesAccurate[i][j][2] = 86;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 91)
                    {
                        ZombiesAccurate[i][j][2] = 88;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 94)
                    {
                        ZombiesAccurate[i][j][2] = 91;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 97)
                    {
                        ZombiesAccurate[i][j][2] = 94;
                        break;
                    }
                    if (ZombiesAccurate[i][j][2] == 100)
                    {
                        ZombiesAccurate[i][j][2] = 97;
                        break;
                    }
                }
            }
        }
        //���ϼ�����˽�ʬ�ľ�ȷ��Ϣ������ȷ���������ⶼ�������·�
        //����ֲ��
        int NearestPlant[5] = { -1, -1, -1, -1, -1 };//���Ҷ˵�ֲ��λ�ã���������������Ϻ�������
        int CanResolve[5] = { 0 };//�����һ�е�������Խ������ôΪ1
        int NutDelay[5] = { 0, 0, 0, 0, 0 };//�洢��������ӻ�������
        int FarestVacancy[5] = { 0 };
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (PlantsNow[i][j] - Plants[i][j] == 4)//���¼��
                {
                    NutBlood[i][j] = 4000;
                }
            }
        }
        //�������Ŀ�Ѫ
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            int ZombieNum = 0;//������ͬһ��Ľ�ʬ����
            for (int k = 0; ZombiesNow[i][6][k] != -1; k++)
            {
                if (ZombiesNow[i][6][k] == 4 || ZombiesNow[i][6][k] == 5)//����о��˺�ѩ��������ô�������ɱ
                {
                    NutBlood[i][6] = 0;
                    NutDelay[i] = 0;
                    break;
                }
                else
                {
                    NutBlood[i][6] -= 75;
                    ZombieNum++;
                }
            }
            if (NutBlood[i][6] <= 0)
            {
                NutBlood[i][6] = 0;
            }
            if (ZombieNum != 0)
            {
                NutDelay[i] = NutBlood[i][6] / (ZombieNum * 75);//������ӻ��������Ǽ��Ѫ�����Խ�ʬ�ܹ�����
            }
        }
        //����������Ҷ˵�ֲ��λ��
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (PlantsNow[i][j] && j > NearestPlant[i] && PlantsNow[i][j] != 4 && PlantsNow[i][j] != 5 && PlantsNow[i][j] != 6)
                {
                    NearestPlant[i] = j;
                }
            }
        }
        //�����������˵Ŀ�λ������ֲ��
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            for (int j = 0; j < 10; j++)
            {
                if (PlantsNow[i][j] == 0)
                {
                    FarestVacancy[i] = j;
                    break;
                }
            }
        }
        //�����ж�һ���ܷ���ס
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (Nearest[i] != -1)//����н�ʬ
            {
                int TimeToKill = -NutDelay[i];//ɱ����ʬ��Ҫ����ʱ�䣬����������һʱ�䣬����������ɸ���
                int BloodToDamage = ZombiesAccurate[i][Nearest[i]][1];//��Ҫ��ɵ��˺�
                int DistanceToWait = ZombiesAccurate[i][Nearest[i]][2];//��ʬ�������ʱ����ǰ���ľ���
                if (PeashooterNum[i][0] != 0 || PeashooterNum[i][1] != 0)//�����һ�����㶹
                {
                    for (; BloodToDamage > 0; TimeToKill++)
                    {
                        BloodToDamage -= PeashooterNum[i][0] * 20;
                        BloodToDamage -= PeashooterNum[i][1] * 45;
                    }
                    DistanceToWait -= ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                    if (HasWinterPeashooter[i] == 1)
                    {
                        DistanceToWait += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                    }
                }
                else
                {
                    DistanceToWait = 0;//��һ��û���㶹����ô��ʬ������ֹ��ǰ��
                }
                if (DistanceToWait - 10 * NearestPlant[i] <= 0 || NearestPlant[i] == -1)//�����һ�и���û��ֲ����߽�ʬ��ֲ�����뽫�ﵽ��Сʱ
                {
                    if (PeashooterNum[i][0] == 0 && PeashooterNum[i][1] == 0 && ZombiesAccurate[i][Nearest[i]][0] != 4 && ZombiesAccurate[i][Nearest[i]][0] != 5 && PlantCD[2] == 0 && Sun >= 100 && FarestVacancy[i] < 6)
                        //�����һ�л�û���㶹���ҽ�ʬ����ѩ�������߾��˲��ҿ������㶹�Ļ����Ǿ����㶹
                    {
                        player->PlacePlant(3, i, FarestVacancy[i]);
                        PeashooterNum[i][0]++;
                        for (int j = 0; j < 10; j++)
                        {
                            if (PlantsNow[i][j] == 0)
                            {
                                FarestVacancy[i] = j;
                                break;
                            }
                        }
                        if (FarestVacancy[i] > NearestPlant[i])
                        {
                            NearestPlant[i]++;
                        }
                        PlantCD[2] = 10;
                        Sun -= 100;
                        //������������Ƿ�����Ҳ�����ٽ���һ��������жϣ�
                        TimeToKill = -NutDelay[i];
                        BloodToDamage = ZombiesAccurate[i][Nearest[i]][1];
                        DistanceToWait = ZombiesAccurate[i][Nearest[i]][2];
                        if (PeashooterNum[i][0] != 0 || PeashooterNum[i][1] != 0)
                        {
                            for (; BloodToDamage > 0; TimeToKill++)
                            {
                                BloodToDamage -= PeashooterNum[i][0] * 20;
                                BloodToDamage -= PeashooterNum[i][1] * 45;
                            }
                            DistanceToWait -= ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                            if (HasWinterPeashooter[i] == 1)
                            {
                                DistanceToWait += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                            }
                        }
                        else
                        {
                            DistanceToWait = 0;
                        }
                        if (DistanceToWait - 10 * NearestPlant[i] > 0)//��������
                        {
                            CanResolve[i] = 1;
                            continue;//���ý��к������ж��ˣ�ֱ��������һ��
                        }
                    }
                    if (PlantCD[2] != 0 || Sun < 100)//����ֲ����㶹�������ܲ����ֱ��㶹
                    {
                        if (Sun >= 400 && PlantCD[1] == 0 && PeashooterNum[i][0] + PeashooterNum[i][1] < 4 && FarestVacancy[i] < 6)
                        {
                            player->PlacePlant(2, i, FarestVacancy[i]);
                            PeashooterNum[i][1]++;
                            for (int j = 0; j < 10; j++)
                            {
                                if (PlantsNow[i][j] == 0)
                                {
                                    FarestVacancy[i] = j;
                                    break;
                                }
                            }
                            if (FarestVacancy[i] > NearestPlant[i])
                            {
                                NearestPlant[i]++;
                            }
                            PlantCD[1] = 30;
                            Sun -= 400;
                            TimeToKill = -NutDelay[i];
                            BloodToDamage = ZombiesAccurate[i][Nearest[i]][1];
                            DistanceToWait = ZombiesAccurate[i][Nearest[i]][2];
                            if (PeashooterNum[i][0] != 0 || PeashooterNum[i][1] != 0)
                            {
                                for (; BloodToDamage > 0; TimeToKill++)
                                {
                                    BloodToDamage -= PeashooterNum[i][0] * 20;
                                    BloodToDamage -= PeashooterNum[i][1] * 45;
                                }
                                DistanceToWait -= ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                if (HasWinterPeashooter[i] == 1)
                                {
                                    DistanceToWait += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                }
                            }
                            else
                            {
                                DistanceToWait = 0;
                            }
                            if (DistanceToWait - 10 * NearestPlant[i] > 0)
                            {
                                CanResolve[i] = 1;
                                continue;
                            }
                        }
                    }
                    if (Sled[i] == 0 && Giant[i] == 0)//���û�о��˻���ѩ�������������㶹�ܲ��ܽ��
                    {
                        if (PlantCD[2] == 0 && Sun >= 100 && PeashooterNum[i][0] <= 1 && FarestVacancy[i] < 6)
                        {
                            player->PlacePlant(3, i, FarestVacancy[i]);
                            PeashooterNum[i][0]++;
                            for (int j = 0; j < 10; j++)
                            {
                                if (PlantsNow[i][j] == 0)
                                {
                                    FarestVacancy[i] = j;
                                    break;
                                }
                            }
                            if (FarestVacancy[i] > NearestPlant[i])
                            {
                                NearestPlant[i]++;
                            }
                            Sun -= 100;
                            PlantCD[2] = 10;
                            TimeToKill = -NutDelay[i];
                            BloodToDamage = ZombiesAccurate[i][Nearest[i]][1];
                            DistanceToWait = ZombiesAccurate[i][Nearest[i]][2];
                            if (PeashooterNum[i][0] != 0 || PeashooterNum[i][1] != 0)
                            {
                                for (; BloodToDamage > 0; TimeToKill++)
                                {
                                    BloodToDamage -= PeashooterNum[i][0] * 20;
                                    BloodToDamage -= PeashooterNum[i][1] * 45;
                                }
                                DistanceToWait -= ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                if (HasWinterPeashooter[i] == 1)
                                {
                                    DistanceToWait += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                }
                            }
                            else
                            {
                                DistanceToWait = 0;
                            }
                            if (DistanceToWait - 10 * NearestPlant[i] > 0)
                            {
                                CanResolve[i] = 1;
                                continue;
                            }
                        }
                        if (PlantCD[1] == 0 && Sun >= 400 && PeashooterNum[i][0] + PeashooterNum[i][1] < 4 && FarestVacancy[i] < 6)
                        {
                            player->PlacePlant(2, i, FarestVacancy[i]);
                            PeashooterNum[i][0]++;
                            for (int j = 0; j < 10; j++)
                            {
                                if (PlantsNow[i][j] == 0)
                                {
                                    FarestVacancy[i] = j;
                                    break;
                                }
                            }
                            if (FarestVacancy[i] > NearestPlant[i])
                            {
                                NearestPlant[i]++;
                            }
                            PlantCD[1] = 30;
                            Sun -= 100;
                            TimeToKill = -NutDelay[i];
                            BloodToDamage = ZombiesAccurate[i][Nearest[i]][1];
                            DistanceToWait = ZombiesAccurate[i][Nearest[i]][2];
                            if (PeashooterNum[i][0] != 0 || PeashooterNum[i][1] != 0)
                            {
                                for (; BloodToDamage > 0; TimeToKill++)
                                {
                                    BloodToDamage -= PeashooterNum[i][0] * 20;
                                    BloodToDamage -= PeashooterNum[i][1] * 45;
                                }
                                DistanceToWait -= ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                if (HasWinterPeashooter[i] == 1)
                                {
                                    DistanceToWait += 1 / 2 * ZombiesSpeed[ZombiesAccurate[i][Nearest[i]][0]] * TimeToKill;
                                }
                            }
                            else
                            {
                                DistanceToWait = 0;
                            }
                            if (DistanceToWait - 10 * NearestPlant[i] > 0)
                            {
                                CanResolve[i] = 1;
                                continue;
                            }
                        }
                    }
                    if (ZombiesAccurate[i][Nearest[i]][2] > 60 && Sled[i] == 0 && Giant[i] == 0 && PlantCD[3] == 0 && Sun >= 50 && PlantsNow[i][6] == 0 && NearestPlant[i] != -1)//�����û��������ҽ�ʬ�ڵ�����֮ǰ�����ҽ�ʬ����ѩ�������߾��ˣ��������ּ�����Ǿ��ڵ������ּ��
                    {
                        player->PlacePlant(4, i, 6);
                        Sun -= 50;
                        PlantCD[3] = 40;
                        NutBlood[i][6] = 4000;
                        CanResolve[i] = 1;//���ڲ�������ͨ��ʬ���ǳŸ���������Ͱ��ʬ���޷�������+�㶹������Ĭ�Ͽ��Խ��
                        continue;
                    }
                }
                else
                {
                    CanResolve[i] = 1;
                }
            }
            else
            {
                CanResolve[i] = 1;
            }
        }
        for (int i = 0; i < 5; i++)//���������ˣ�������ѩ�������߾��ˣ���ô�Ͷ������Ϻ�����
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (CanResolve[i] == 0)
            {
                if (PlantCD[5] == 0 && Sun >= 50)
                {
                    player->PlacePlant(6, i, ZombiesAccurate[i][Nearest[i]][2] / 10);
                    PlantCD[5] = 60;
                    Sun -= 50;
                    for (int j = 0; j < 10; j++)
                    {
                        if (ZombiesAccurate[i][j][2] == ZombiesAccurate[i][Nearest[i]][2])
                        {
                            ZombiesAccurate[i][j][1] -= 1800 * 3;
                        }
                    }
                    continue;
                }
                if (PlantCD[4] == 0 && Sun >= 125)
                {
                    player->PlacePlant(5, i, 7);
                    PlantCD[4] = 60;
                    Sun -= 125;
                    for (int j = 0; j < 10; j++)
                    {
                        ZombiesAccurate[i][j][1] -= 1800 * 3;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++)//�����ʣ��CD�����⣬��ô������һЩֲ��
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (SunflowerNum[i] == 0 && Sun >= 75 && PlantCD[0] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(1, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                SunflowerNum[i]++;
                Sun -= 50;
                PlantCD[0] = 10;
            }
            if (PeashooterNum[i][0] == 0 && Sun > 350 - 75 && PlantCD[2] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(3, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                PeashooterNum[i][0] ++;
                Sun -= 100;
                PlantCD[2] = 10;
            }
            if (PeashooterNum[i][1] == 0 && Sun > 600 - 75 && PlantCD[1] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(2, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                PeashooterNum[i][1]++;
                Sun -= 400;
                PlantCD[1] = 30;
            }
        }
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (SunflowerNum[i] == 1 && Sun >= 150 - 75 && PlantCD[0] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(1, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                Sun -= 50;
                SunflowerNum[i]++;
                PlantCD[0] = 10;
            }
            if (PeashooterNum[i][0] == 1 && Sun > 250 - 75 && PlantCD[2] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(3, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                PeashooterNum[i][0]++;
                Sun -= 100;
                PlantCD[2] = 10;
            }
            if (PeashooterNum[i][1] == 1 && Sun > 600 - 75 && PlantCD[1] == 0 && FarestVacancy[i] < 6)
            {
                player->PlacePlant(2, i, FarestVacancy[i]);
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 0)
                    {
                        FarestVacancy[i] = j;
                        break;
                    }
                }
                if (FarestVacancy[i] > NearestPlant[i])
                {
                    NearestPlant[i]++;
                }
                PeashooterNum[i][1]++;
                Sun -= 400;
                PlantCD[1] = 30;
            }
        }
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (PlantCD[5] == 0 && SunflowerNum[i] == 2 && PeashooterNum[i][0] == 2 && PeashooterNum[i][1] == 2 && Sun > 200)
            {
                player->PlacePlant(6, i, 8);
                PlantCD[5] = 60;
                Sun -= 50;
            }
        }
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (PlantCD[3] == 0 && SunflowerNum[i] == 2 && PeashooterNum[i][0] >= 1 && PeashooterNum[i][1] >= 1 && Sun > 500)
            {
                player->PlacePlant(4, i, 6);
                PlantCD[3] = 40;
                Sun -= 50;
            }
        }
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
            {
                continue;
            }
            if (PlantCD[1] == 0 && SunflowerNum[i] == 2 && PeashooterNum[i][0] + PeashooterNum[i][1] == 4 && Sun > 800)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (PlantsNow[i][j] == 3)
                    {
                        player->removePlant(i, j);
                        player->PlacePlant(2, i, j);
                        PlantCD[1] == 30;
                        Sun -= 400;
                        break;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++)//����һ�غϽ�ʬ��Ϣͬ��Ϊ��һ�غϽ�ʬ��Ϣ
        {
            for (int j = 0; j < 10; j++)
            {
                for (int k = 0; k < 10; k++)
                {
                    Zombies[i][j][k] = -1;
                }
                for (int k = 0; ZombiesNow[i][j][k] != -1; k++)
                {
                    Zombies[i][j][k] = ZombiesNow[i][j][k];
                }
            }
        }
        for (int i = 0; i < 5; i++)//����һ�غ�ֲ����Ϣͬ��Ϊ��һ�غ�ֲ����Ϣ
        {
            for (int j = 0; j < 10; j++)
            {
                Plants[i][j] = PlantsNow[i][j];
            }
        }
    }
    else
    {
        int Rows = player->Camp->getRows();
        int Columns = player->Camp->getColumns();
        int Step = player->getTime();
        int* PlantCD = player->Camp->getPlantCD(); //��ʬCD;
        int** Plants = player->Camp->getCurrentPlants();
        int*** Zombies = player->Camp->getCurrentZombies();
        int* LeftLines = player->Camp->getLeftLines(); // LeftLines[i]==0 means broken
        int Sun = player->Camp->getSun();              //�¹�

        const int Plant_defense[7] = { 0, 10, 60, 20, 40, 100, 30 };
        const int Zombie_offense[6] = { 0, 10, 30, 15, 60, 100 };

        int Line_flag[5] = { 1 };
        for (int i = 0; i < 5; i++)
        {
            if (Zombies[i][9][0] != -1 || LeftLines[i] == 0)
            {
                Line_flag[i] = 0;
            }
        }

        int Line_defense[5] = { 0 };
        int Nut_num[5] = { 0 };
        for (int i = 0; i < 5; i++)
        {
            if (LeftLines[i] == 0)
                Line_defense[i] = 10000;
            for (int j = 0; j < 10; j++)
            {
                Line_defense[i] += (int)(Plant_defense[Plants[i][j]] * 1.157 * (1 - pow(2.718, (-2 + j / 5.0))));
                if (Plants[i][j] == 6)
                    Nut_num[i]++;
            }
        }

        int Line_offense[5] = { 0 };
        int Line_score[5] = { 0 };
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                for (int k = 0; Zombies[i][j][k] != -1; k++)
                {
                    Line_offense[i] += (int)(Zombie_offense[Zombies[i][j][k]] * 1.157 * (1 - pow(2.718, (-2 + j / 5.0))));
                }
            }
            Line_score[i] = Line_offense[i] - Line_defense[i];
        }

        int Line_attack[5] = { 1, 2, 3, 1, 0 }; //���ݱ���Ч�水�к�����(���)
        int Line_erase[5] = { 1, 2, 3, 2, 0 };  //���ݱ���Ч�水�к�����(��С)

        int count = 0;
        for (int i = 0; i < 5; i++)
        {
            if (Line_flag[i] != 0)
            {
                Line_attack[count] = i;
                count++;
            }
        }
        for (int i = 0; i < count; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (Line_score[Line_attack[j]] < Line_score[Line_attack[j + 1]])
                {
                    int temp = Line_attack[j];
                    Line_attack[j] = Line_attack[j + 1];
                    Line_attack[j + 1] = temp;
                }
            }
        }

        count = 0;
        for (int i = 0; i < 5; i++)
        {
            if (Line_flag[i] != 0)
            {
                Line_erase[count] = i;
                count++;
            }
        }
        for (int i = 0; i < count; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (Line_score[Line_erase[j]] > Line_score[Line_erase[j + 1]])
                {
                    int temp = Line_erase[j];
                    Line_erase[j] = Line_erase[j + 1];
                    Line_erase[j + 1] = temp;
                }
            }
        }

        if (Step == 1)
        {
            player->PlaceZombie(1, 0);
            player->PlaceZombie(2, 1);
            player->PlaceZombie(3, 2);
        }
        else if (Step < 500) //��̽+��һ��
        {
            if (Step > 400 && Sun > 300)
            {
                player->PlaceZombie(5, Line_attack[0]);
                Sun -= 300;
            }

            if (Nut_num[Line_attack[0]] == 1 && Line_score[Line_attack[0]] > 30)
            {
                player->PlaceZombie(3, Line_attack[0]);
                Sun -= 125;
            }
            else
            {
                if (Sun >= 200 && Sun < 250 && Line_score[Line_attack[0]] > 30)
                {
                    player->PlaceZombie(1, Line_attack[0]);
                    Sun -= 50;
                }
                else
                {
                    if (Sun >= 250)
                        player->PlaceZombie(2, Line_attack[0]);
                }
            }

            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
        }

        else if (Step == 500) //��ɢ��
        {
            player->PlaceZombie(1, Line_attack[0]);
            Sun -= 50;

            if (Sun >= 150)
            {
                for (int i = 0; i < 5; i++) //�Ÿ���͵��
                {
                    if (Sun >= 150 && Line_defense[i] <= 10 && Line_offense[i] == 0)
                    {
                        player->PlaceZombie(3, i);
                        Sun -= 125;
                    }
                }
            }

            if (Sun >= 200)
            {
                player->PlaceZombie(2, Line_attack[1]);
                Sun -= 125;
            }
        }

        else if (Step > 500 && Step < 1000) //��Ͱ��·
        {
            if (Step < 550)
            {
                player->PlaceZombie(5, Line_erase[0]);
                Sun -= 300;
            }

            for (int i = 0; i < 5; i++) //�Ÿ���͵��
            {
                if (Sun >= 150 && Line_defense[i] <= 10 && Line_offense[i] == 0)
                {
                    player->PlaceZombie(3, i);
                    Sun -= 125;
                }
            }

            if (Sun > 0)
                player->PlaceZombie(2, Line_attack[0]);

            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
        }

        else if (Step == 1000) //һ��� ƭ���Ϻ�����
        {
            player->PlaceZombie(1, Line_attack[0]);
        }
        else if (Step == 1005)
        {
            player->PlaceZombie(2, Line_attack[0]);
        }
        else if (Step == 1016)
        {
            player->PlaceZombie(1, Line_attack[0]);
        }
        else if (Step > 1016 && Step < 1500)
        {
            for (int i = 0; i < 5; i++) //�Ÿ���͵��
            {
                if (Sun >= 150 && Line_defense[i] <= 10 && Line_offense[i] == 0)
                {
                    player->PlaceZombie(3, i);
                    Sun -= 125;
                }
            }

            if (Step < 1060)
            {
                player->PlaceZombie(5, Line_erase[0]);
                Sun -= 300;
            }

            if (Sun > 0)
                player->PlaceZombie(2, Line_attack[0]);

            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
            player->PlaceZombie(5, Line_erase[0]);
        }

        else if (Step == 1500) //����·��һ·
        {
            player->PlaceZombie(1, Line_attack[0]);
            Sun -= 50;
            if (Sun >= 200)
            {
                player->PlaceZombie(2, Line_attack[0]);
                Sun -= 125;
            }
            if (Sun >= 150)
            {
                for (int i = 0; i < 5; i++) //�Ÿ���͵��
                {
                    if (Sun >= 150 && Line_defense[i] <= 10 && Line_offense[i] == 0)
                    {
                        player->PlaceZombie(3, i);
                        Sun -= 125;
                    }
                }
            }
            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
            player->PlaceZombie(5, Line_erase[0]);
        }
        else if (Step > 1500 && Step < 1900) //�����©
        {
            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
            player->PlaceZombie(5, Line_erase[0]);
        }
        else if (Step >= 1900 && Step <= 2000) //�չ�
        {
            for (int i = 0; i < 5; i++) //�Ÿ���͵��
            {
                if (Sun >= 150 && Line_defense[i] <= 10 && Line_offense[i] == 0)
                {
                    player->PlaceZombie(3, i);
                    Sun -= 125;
                }
            }
            int Zombie_type = rand() % 2 + 2;
            player->PlaceZombie(Zombie_type, Line_attack[0]);
            player->PlaceZombie(5, Line_erase[0]);
            player->PlaceZombie(1, Line_attack[0]);
            player->PlaceZombie(2, Line_attack[1]);
            player->PlaceZombie(3, Line_attack[2]);
            player->PlaceZombie(5, Line_erase[0]);
        }
    }
}