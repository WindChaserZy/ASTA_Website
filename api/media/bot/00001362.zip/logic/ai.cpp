/**
 * This file is preprocessed by an amalgamater
 * to protect its copyright
 *
 * Please do not try to parse it
 * 
 * Amalgamater is written by Futrime<https://github.com/Futrime>
 */

#include "ai.h"

/**
 * @file 1.ai.cpp
 * @author Futrime (futrime@outlook.com)
 * @brief AI Edition One
 * @details This AI calls PlantAncientAgent and ZombieReflexAgent.
 * @version 1.0.0
 * @date 2022-04-27
 *
 * @copyright Copyright (c) 2022 Futrime
 *
 */

#include <iostream>

/*** Start of inlined file: Game.cpp ***/
#ifndef __GAME_CPP__
#define __GAME_CPP__

#include <algorithm>
#include <bitset>
#include <cmath>
#include <exception>
#include <iostream>
#include <string>
#include <vector>


/*** Start of inlined file: ai.h ***/
#ifndef _FC19_AI_H_
#define _FC19_AI_H_

/*** Start of inlined file: Interface.h ***/
#ifndef INTERFACE_H_
#define INTERFACE_H_
class ICamp
{
public:
	virtual int** getCurrentPlants() = 0;
	virtual int*** getCurrentZombies() = 0;
	virtual int getSun() = 0;
	virtual int* getPlantCD() = 0;
	virtual int* getLeftLines() = 0;
	virtual int getRows() = 0;
	virtual int getColumns() = 0;
	virtual int getCurrentType() = 0;
};
class IPlayer
{
public:
	ICamp* Camp;
	virtual void PlacePlant(int type, int x, int y) = 0;
	virtual void PlaceZombie(int type, int y) = 0;
	virtual int getTime() = 0;
	virtual int getScore() = 0;
	virtual int getKillPlantsScore() = 0;
	virtual int getKillZombiesScore() = 0;
	virtual int getNotBrokenLines() = 0;
	virtual int getBrokenLinesScore() = 0;
	virtual int getLeftPlants() = 0;
	virtual void removePlant(int x, int y) = 0;
};

#endif
/*** End of inlined file: Interface.h ***/


#ifdef _MSC_VER
extern "C" _declspec(dllexport) void  player_ai(IPlayer * Player);
#endif

#ifdef __GNUC__
extern "C" void player_ai(IPlayer * _Player);
#endif

#endif
/*** End of inlined file: ai.h ***/


/*** Start of inlined file: Entity.cpp ***/
#ifndef __ENTITY_CPP__
#define __ENTITY_CPP__

#include <exception>
#include <string>


/*** Start of inlined file: Utility.cpp ***/
#ifndef __UTILITY_CPP__
#define __UTILITY_CPP__

#include <bitset>
#include <exception>
#include <iostream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

const struct
{
	int PLANT = 0;
	int ZOMBIE = 1;
} CAMP;

const struct
{
	int NOPLANT = 0;
	int SUNFLOWER = 1;
	int WINTERPEASHOOTER = 2;
	int PEASHOOTER = 3;
	int SMALLNUT = 4;
	int PEPPER = 5;
	int SQUASH = 6;
} PLANT;

const string PLANT_STRING[7] = {"NOPLANT", "SUNFLOWER", "WINTERPEASHOOTER", "PEASHOOTER", "SMALLNUT", "PEPPER", "SQUASH"};

const struct
{
	int NOZOMBIE = 0;
	int NORMAL = 1;
	int BUCKET = 2;
	int POLEVAULT = 3;
	int SLED = 4;
	int GARGANTUAR = 5;
} ZOMBIE;

const string ZOMBIE_STRING[6] = {"NOZOMBIE", "NORMAL", "BUCKET", "POLEVAULT", "SLED", "GARGANTUAR"};

const struct
{
	int SUNFLOWER = 300;
	int WINTERPEASHOOTER = 300;
	int PEASHOOTER = 300;
	int SMALLNUT = 4000;
	int PEPPER = 300;
	int SQUASH = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_HP::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_HP;

const struct
{
	int SUNFLOWER = 50;
	int WINTERPEASHOOTER = 400;
	int PEASHOOTER = 100;
	int SMALLNUT = 50;
	int PEPPER = 125;
	int SQUASH = 50;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_COST::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_COST;

const struct
{
	int WINTERPEASHOOTER = 60;
	int PEASHOOTER = 20;
	int PEPPER = 1800;
	int SQUASH = 1800;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1: // SUNFLOWER
			return 0;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4: // SMALLNUT
			return 0;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_ATK::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_ATK;

const struct
{
	int SUNFLOWER = 10;
	int WINTERPEASHOOTER = 30;
	int PEASHOOTER = 10;
	int SMALLNUT = 40;
	int PEPPER = 60;
	int SQUASH = 60;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_CD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_CD;

const struct
{
	int WINTERPEASHOOTER = 3;
	int PEASHOOTER = 2;
	int operator[](int type) const
	{
		switch (type)
		{
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		}

		/* Check legality */
		if (type != 2 && type != 3)
		{
			throw invalid_argument("(PLANT_PERIOD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_PERIOD;

const struct
{
	int NORMAL = 270;
	int BUCKET = 550 + 270;
	int POLEVAULT = 200;
	int SLED = 1600;
	int GARGANTUAR = 3000;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOZOMBIE
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_HP::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_HP;

const struct
{
	int NORMAL = 50;
	int BUCKET = 125;
	int POLEVAULT = 125;
	int SLED = 300;
	int GARGANTUAR = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_COST::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_COST;

const struct
{
	int NORMAL = 75;
	int BUCKET = 75;
	int POLEVAULT = 75;
	int SLED = 999999;
	int GARGANTUAR = 999999;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_ATK::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_ATK;

const struct
{
	int NORMAL = 15;
	int BUCKET = 20;
	int POLEVAULT = 20;
	int SLED = 25;
	int GARGANTUAR = 25;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_CD::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_CD;

const struct
{
	double DEFAULT = 0.2;
	double POLEVAULT[2] = {0.4, 0.2222222222222222};
	double SLED[5] = {0.3333333333333333, 0.28125, 0.2291666666666667, 0.1770833333333333, 0.125};
} ZOMBIE_SPEED;

template <typename T>
class Position
{
public:
	T x, y;

	/**
	 * @brief Construct a new Position object
	 *
	 */
	Position()
	{
		this->x = -1;
		this->y = -1;
	}

	/**
	 * @brief Construct a new Position object
	 *
	 * @param x
	 * @param y
	 */
	Position(T x, T y) : x(x), y(y)
	{
	}

	friend ostream &operator<<(ostream &os, Position<T> pos)
	{
		return os << "<" << pos.x << ", " << pos.y << ">";
	}
};

class Action
{
protected:
	bitset<7> plant_switch_;
	bitset<6> zombie_switch_;
	Position<int> plant_position_[7];
	Position<int> zombie_position_[6];
	vector<Position<int>> plant_removal_;
	vector<int> plant_sequence_;
	vector<int> zombie_sequence_;

public:
	/**
	 * @brief Construct a new Action object
	 *
	 */
	Action()
	{
	}

	/**
	 * @brief Get removal actions of plant camp
	 *
	 * @return vector<Position<int>> A vector of removal actions
	 */
	vector<Position<int>> getRemovalList()
	{
		return this->plant_removal_;
	}

	/**
	 * @brief Get the target position of a slot
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return Position<int> The target position
	 */
	Position<int> getPosition(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::getPosition) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw invalid_argument("(Action::getPosition) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw invalid_argument("(Action::getPosition) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_position_[slot];
		}
		else
		{
			return this->zombie_position_[slot];
		}
	}

	/**
	 * @brief Get the placement sequence
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @return vector<int> The placement sequence, whose elements are plant/zombie types
	 */
	vector<int> getSequence(int camp)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::getSequence) Invalid camp!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_sequence_;
		}
		else
		{
			return this->zombie_sequence_;
		}
	}

	/**
	 * @brief Check if a slot is set in this action
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return true The slot is set
	 * @return false The slot is not set
	 */
	bool isSet(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::isSet) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw invalid_argument("(Action::isSet) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw invalid_argument("(Action::isSet) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_switch_[slot];
		}
		else
		{
			return this->zombie_switch_[slot];
		}
	}

	/**
	 * @brief Remove a plant. Plant placement is prior to plant removal.
	 *
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 * @param force true Ignore non-fatal illegal removal
	 * @param force false Check all illegal removal
	 */
	void removePlant(int x, int y, bool force = false)
	{
		/* Check legality */
		if (x < 0 || x > 4 || y < 0 || y > 9)
		{
			throw invalid_argument("(Action::removePlant) Out of map!");
		}
		for (int i = 0; i < this->plant_removal_.size(); ++i)
		{
			if (plant_removal_[i].x == x &&
				plant_removal_[i].y == y)
			{ // if the removal has already been performed
				if (force)
				{
					return; // do not add duplicated removal
				}
				else
				{
					throw runtime_error("(Action::removePlant) Duplicated plant removal!");
				}
			}
		}

		this->plant_removal_.push_back(Position<int>(x, y));
	}

	/**
	 * @brief Place a plant. Plant placement is prior to plant removal.
	 *
	 * @param type The type of the plant, should be PLANT.X
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 * @param force true Ignore non-fatal illegal placement
	 * @param force false Check all illegal placement
	 */
	void placePlant(int type, int x, int y, bool force = false)
	{
		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(Action::placePlant) Wrong plant type!");
		}
		if (x < 0 || x > 4 || y < 0 || y > 9)
		{
			throw invalid_argument("(Action::placePlant) Out of map!");
		}
		if (this->plant_switch_[type] && !force)
		{
			throw runtime_error("(Action::placePlant) Duplicated plant placement!");
		}

		this->plant_switch_[type] = true;
		this->plant_position_[type].x = x;
		this->plant_position_[type].y = y;

		if (force)
		{
			for (auto it = this->plant_sequence_.begin(); it != this->plant_sequence_.end(); ++it)
			{
				if (*it == type)
				{
					this->plant_sequence_.erase(it); // remove previous placement
					break;
				}
			}
		}

		this->plant_sequence_.push_back(type);
	}

	/**
	 * @brief Place a zombie
	 *
	 * @param type The type of the zombie, should be ZOMBIE.x
	 * @param x The x position to place, within [0, 4]
	 * @param force true Ignore non-fatal illegal placement
	 * @param force false Check all illegal placement
	 */
	void placeZombie(int type, int x, bool force = false)
	{
		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(Action::placeZombie) Wrong zombie type!");
		}
		if (x < 0 || x > 4)
		{
			throw invalid_argument("(Action::placeZombie) Out of map!");
		}
		if (this->zombie_switch_[type] && !force)
		{
			throw runtime_error("(Action::placeZombie) Duplicated zombie placement!");
		}

		this->zombie_switch_.set(type, true);
		this->zombie_position_[type].x = x;
		this->zombie_position_[type].y = 10;

		if (force)
		{
			for (auto it = this->zombie_sequence_.begin(); it != this->zombie_sequence_.end(); ++it)
			{
				if (*it == type)
				{
					this->zombie_sequence_.erase(it); // remove previous placement
					break;
				}
			}
		}

		this->zombie_sequence_.push_back(type);
	}

	/**
	 * @brief Merge an action of plant camp and an action of zombie camp
	 *
	 * @param action_plant An action of plant camp
	 * @param action_zombie An action of zombie camp
	 * @return Action
	 */
	static Action merge(Action action_plant, Action action_zombie)
	{
		Action result;

		vector<int> sequence_plant = action_plant.getSequence(CAMP.PLANT);
		vector<Position<int>> removal_list = action_plant.getRemovalList();
		vector<int> sequence_zombie = action_zombie.getSequence(CAMP.ZOMBIE);

		for (auto it = sequence_plant.begin(); it != sequence_plant.end(); ++it)
		{
			Position<int> pos = action_plant.getPosition(CAMP.PLANT, *it);
			result.placePlant(*it, pos.x, pos.y);
		}

		for (auto it = removal_list.begin(); it != removal_list.end(); ++it)
		{
			result.removePlant(it->x, it->y);
		}

		for (auto it = sequence_zombie.begin(); it != sequence_zombie.end(); ++it)
		{
			int x = action_zombie.getPosition(CAMP.ZOMBIE, *it).x;
			result.placeZombie(*it, x);
		}

		return result;
	}
};

int generateID()
{
	static int id = 0;
	++id;
	return id;
}

#endif
/*** End of inlined file: Utility.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class Entity
{
protected:
	int spawn_time_;
	int type_;
	int hp_;
	int id_;
	Position<int> position_;

public:
	/**
	 * @brief Construct a new Entity object
	 *
	 * @param spawn_time The spawning time of the entity
	 * @param type The type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 * @param position The position of the entity
	 */
	Entity(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get the spawning time of the entity
	 *
	 * @return int The spawning time
	 */
	int getSpawnTime();

	/**
	 * @brief Get the type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 *
	 * @return int The type of the entity, fitting PLANT.X or ZOMBIE.X
	 */
	int getType();

	/**
	 * @brief Get the health of the entity
	 *
	 * @return int The health of the entity, >= 0
	 */
	virtual int getHealth();

	/**
	 * @brief Reduce the health of the entity
	 *
	 * @param value The number of health to reduce
	 * @return int The health left
	 */
	int reduceHealth(int value);

	/**
	 * @brief Get the position of the entity
	 *
	 * @return Position<int> The position of the entity
	 */
	Position<int> getPosition();

	/**
	 * @brief Get the id of the entity
	 *
	 * @return int The id
	 */
	int getID();
};

class Plant : public Entity
{
protected:
	int last_attack_time_ = -999999;

public:
	/**
	 * @brief Construct a new Plant object
	 *
	 */
	Plant();

	/**
	 * @brief Construct a new Plant object
	 *
	 * @param spawn_time The spawing time of the plant
	 * @param type The type of the plant
	 * @param position The position of the plant
	 */
	Plant(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get last attack time
	 *
	 * @return int Last attack time
	 */
	int getLastAttackTime();

	/**
	 * @brief Set last attack time
	 *
	 * @param time Last attack time
	 */
	void setLastAttackTime(int time);

	/**
	 * @brief Print a plant object
	 *
	 * @param oss The output stream
	 * @param plant The plant
	 * @return ostream& The result output stream
	 */
	friend ostream &operator<<(ostream &oss, Plant plant);
};

class Zombie : public Entity
{
protected:
	Position<double> position_real_;
	int state_ = 0; // Polevault and Sled's state
	int frozen_state_ = 0;
	int time_;

public:
	/**
	 * @brief Construct a new Zombie object
	 *
	 */
	Zombie();

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<double> position);

	/**
	 * @brief Get the health of the zombie
	 *
	 * @return int The health of the zombie, >= 0
	 */
	int getHealth();

	/**
	 * @brief Set the current time for calculating health
	 *
	 * @param time The current time
	 */
	void setNowTime(int time);

	/**
	 * @brief Get the position of the zombie
	 *
	 * @return Position<int> The position of the zombie
	 */
	Position<int> getPosition();

	/**
	 * @brief Get the real position of the zombie
	 *
	 * @return Position<double> The real position of the zombie
	 */
	Position<double> getRealPosition();

	/**
	 * @brief Set the real position of the zombie
	 *
	 * @param position The real position of the zombie
	 */
	void setRealPosition(Position<double> position);

	/**
	 * @brief Get the state of the zombie
	 *
	 * @return int The state number
	 */
	int getState();

	/**
	 * @brief Set the state of the zombie
	 *
	 * @param state The state number
	 */
	void setState(int state);

	/**
	 * @brief Get if the zombie is frozen
	 *
	 * @return int The ticks from unfreezing
	 */
	int getFrozenState();

	/**
	 * @brief Set if the zombie is frozen
	 *
	 * @param state int The ticks from unfreezing
	 */
	void setFrozenState(int state);

	/**
	 * @brief Print a zombie object
	 *
	 * @param oss The output stream
	 * @param plant The zombie
	 * @return ostream& The result output stream
	 */
	friend ostream &operator<<(ostream &oss, Zombie zombie);
};

/****************
 * Definitions
 ****************/

Entity::Entity(int spawn_time, int type, Position<int> position)
	: spawn_time_(spawn_time), type_(type), position_(position), id_(generateID())
{
	/* Check legality */
	if (spawn_time < 0)
	{
		throw invalid_argument("(Entity::Entity) Invalid spawn time!");
	}
}

int Entity::getSpawnTime()
{
	return this->spawn_time_;
}

int Entity::getType()
{
	return this->type_;
}

int Entity::getHealth()
{
	return this->hp_;
}

int Entity::reduceHealth(int value)
{
	/* Check legality */
	if (value < 0)
	{
		throw invalid_argument("(Entity::reduceHealth) Invalid value!");
	}

	this->hp_ -= value;
	return this->hp_;
}

Position<int> Entity::getPosition()
{
	return this->position_;
}

int Entity::getID()
{
	return this->id_;
}

Plant::Plant() : Plant(0, PLANT.NOPLANT, Position<int>())
{
}

Plant::Plant(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position)
{
	/* Check legality */
	if (type < 0 || type > 6)
	{
		throw invalid_argument("(Plant::Plant) Invalid type!");
	}

	this->hp_ = PLANT_HP[type];
}

int Plant::getLastAttackTime()
{
	return this->last_attack_time_;
}

void Plant::setLastAttackTime(int time)
{
	/* Check legality */
	if (time < 0)
	{
		throw invalid_argument("(Plant::setLastAttackTime) Invalid time!");
	}

	this->last_attack_time_ = time;
}

ostream &operator<<(ostream &oss, Plant plant)
{
	oss << "Plant(type=" << PLANT_STRING[plant.getType()]
		<< ", position=" << plant.getPosition()
		<< ", health=" << plant.getHealth()
		<< ", spawn_time=" << plant.getSpawnTime()
		<< ")";
	return oss;
}

Zombie::Zombie() : Zombie(0, ZOMBIE.NOZOMBIE, Position<double>())
{
}

Zombie::Zombie(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position), position_real_(position.x, position.y), time_(spawn_time)
{
	/* Check legality */
	if (type < 0 || type > 5)
	{
		throw invalid_argument("(Zombie::Zombie) Invalid type!");
	}

	this->hp_ = ZOMBIE_HP[type];
}

Zombie::Zombie(int spawn_time, int type, Position<double> position)
	: Entity(spawn_time, type, Position<int>(static_cast<int>(floor(position.x + 0.001)), static_cast<int>(floor(position.y + 0.001)))), position_real_(position.x, position.y), time_(spawn_time)
{
	/* Check legality */
	if (type < 0 || type > 5)
	{
		throw invalid_argument("(Zombie::Zombie) Invalid type!");
	}

	this->hp_ = ZOMBIE_HP[type];
}

int Zombie::getHealth()
{
	return this->hp_ + static_cast<int>(ZOMBIE_HP[this->type_] * (max(1.0, this->time_ / 1000.0) - 1.0));
	// doubt: what the fuck is the algorithm of Game.exe!
}

void Zombie::setNowTime(int time)
{
	/* Check legality */
	if (time < 0)
	{
		throw invalid_argument("(Zombie::setNowTime) Invalid time!");
	}

	this->time_ = time;
}

ostream &operator<<(ostream &oss, Zombie zombie)
{
	oss << "Zombie(type=" << ZOMBIE_STRING[zombie.getType()]
		<< ", position=" << zombie.getRealPosition()
		<< ", health=" << zombie.getHealth()
		<< ", spawn_time=" << zombie.getSpawnTime()
		<< ")";
	return oss;
}

Position<int> Zombie::getPosition()
{
	Position<int> pos(this->position_);
	if (pos.y == 10)
	{ // doubt: how to solve this problem?
		pos.y = 9;
	}
	else if (pos.y == 9 && this->type_ == ZOMBIE.POLEVAULT && this->state_ == 1)
	{
		pos.y = 8;
	}
	return pos;
}

Position<double> Zombie::getRealPosition()
{
	return this->position_real_;
}

void Zombie::setRealPosition(Position<double> position)
{
	int x = static_cast<int>(floor(position.x + 0.001));
	int y = static_cast<int>(floor(position.y + 0.001));

	/* Check legality */
	if (x < 0 || x > 4 || y < -1 || y > 10) // -1 for polevault
	{
		throw invalid_argument("(Zombie::setRealPosition) Out of map!");
	}

	this->position_.x = x;
	this->position_.y = y;
	this->position_real_.x = position.x;
	this->position_real_.y = position.y;
}

int Zombie::getState()
{
	return this->state_;
}

void Zombie::setState(int state)
{
	this->state_ = state;
}

int Zombie::getFrozenState()
{
	return this->frozen_state_;
}

void Zombie::setFrozenState(int state)
{
	/* Check legality */
	if (state < 0)
	{
		throw invalid_argument("(Zombie::setFrozenState) Invalid frozen state!");
	}

	this->frozen_state_ = state;
}

#endif
/*** End of inlined file: Entity.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class GameState
{
protected:
	int inference_state_ = 0; // 0: normal 1: inaccurate 2: invalid
	bool debug_mode_ = false;
	ostream *os = nullptr;

	/* Global Information */
	IPlayer *player_ = nullptr;
	int time_ = 0;
	bitset<5> broken_lines_;
	int score_base_ = 0;

	/* Camp Information */
	int camp_;
	int other_camp_;
	vector<Plant> plant_;
	vector<Zombie> zombie_;
	int sun_plant_ = 400;
	int sun_zombie_ = 299; // at tick 0
	int cd_plant_[7] = {0};
	int cd_zombie_[6] = {0};
	int score_plant_ = 0;
	int score_zombie_ = 0;

public:
	/**
	 * @brief Construct a new Game State object
	 *
	 * @param camp The current camp
	 */
	GameState(int camp);

	/**
	 * @brief Destroy the Game State object
	 *
	 */
	~GameState();

	/**
	 * @brief Get the battlefront of a line
	 *
	 * @param x The line
	 * @return int The y position of the battlefront, 10 if no zombie on this row
	 */
	int getBattlefront(int x);

	/**
	 * @brief Get the broken lines
	 *
	 * @return bitset<5> True if broken
	 */
	bitset<5> getBrokenLines();

	/**
	 * @brief Get the current camp
	 *
	 * @return int The current camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getCamp();

	/**
	 * @brief Get the left cooldown time of a slot
	 *
	 * @param camp The camp
	 * @param slot The slot
	 * @return int The left cooldown time
	 */
	int getCD(int camp, int slot);

	/**
	 * @brief Get the zombie appeared earliest whose y position >= col
	 *
	 * @param row The row to query
	 * @param col The col
	 * @return Zombie The zombie, Zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 10)) if no zombie
	 */
	Zombie getEarliestZombie(int row, int col = 0);

	/**
	 * @brief Get the zombie whose y position >= col and closest to the house
	 *
	 * @param row The row to query
	 * @param col The col
	 * @return Zombie The zombie, Zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 10)) if no zombie
	 */
	Zombie getFirstZombie(int row, int col = 0);

	/**
	 * @brief Get the inference state
	 *
	 * @return 0 The inference algorithm is working properly
	 * @return 1 The inference algorithm is not working properly
	 * @return 2 The inference algorithm is collapsed
	 */
	int getInferenceState();

	/**
	 * @brief Get the other camp
	 *
	 * @return int The other camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getOtherCamp();

	/**
	 * @brief Get the plant at the position
	 *
	 * @param x The x position
	 * @param y The y position
	 * @return Plant The plant
	 */
	Plant getPlant(int x, int y);

	/**
	 * @brief Get plants fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The plant type, -1 for all (optional)
	 * @return vector<Plant>
	 */
	vector<Plant> getPlantList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Get the IPlayer handler
	 *
	 * @return IPlayer* The handler
	 */
	IPlayer *getPlayer();

	/**
	 * @brief Get the score
	 *
	 * @param camp The camp
	 * @return int The score of the camp
	 */
	int getScore(int camp);

	/**
	 * @brief Get the sun count
	 *
	 * @param camp The camp
	 * @return int The sun count of the camp
	 */
	int getSun(int camp);

	/**
	 * @brief Get the time
	 *
	 * @return int The time
	 */
	int getTime();

	/**
	 * @brief Get zombies fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The zombie type, -1 for all (optional)
	 * @return vector<Zombie>
	 */
	vector<Zombie> getZombieList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Set the debug mode
	 *
	 * @param mode true Debug mode on
	 * @param mode false Debug mode off
	 * @param os ostream * The ostream to print errors
	 */
	void setDebugMode(bool mode, ostream *os = &cerr);

	/**
	 * @brief Convert the game state to a std::vector
	 *
	 * @return vector<double> The std::vector
	 */
	vector<double> to_vector();

	/**
	 * @brief Generate a predicted state after applying an action
	 *
	 * @param action The action to apply
	 * @return GameState* The predicted state
	 */
	GameState *generateSuccessor(Action action);

	/**
	 * @brief Infer the next state
	 *
	 */
	void infer();

	/**
	 * @brief Infer the next state according to an action
	 *
	 * @param action The action
	 */
	void infer(Action action);

	/**
	 * @brief Update the state
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Print the game state
	 *
	 * @param os The ostream
	 * @param game_state The game state
	 * @return ostream& The result ostream
	 */
	friend ostream &operator<<(ostream &os, GameState *game_state);
};

class History
{
protected:
	vector<GameState> history_;

public:
	/**
	 * @brief Construct a new History object
	 *
	 */
	History();

	/**
	 * @brief Insert a game state to the history
	 *
	 * @param game_state The game state
	 */
	void insert(GameState *game_state);

	/**
	 * @brief Get a game state
	 *
	 * @param time The time of the game state
	 * @return GameState* The game state
	 */
	GameState *operator[](int time);

	/**
	 * @brief Get the unique identifier of the history object
	 *
	 * @return unsigned long long The identifier
	 */
	unsigned long long getIdentifier();
};

class Game
{
protected:
	IPlayer *player_;
	GameState *game_state_;

public:
	/**
	 * @brief Construct a new Game object
	 *
	 * @param player The IPlayer object
	 */
	Game(IPlayer *player);

	/**
	 * @brief Destroy the Game object
	 *
	 */
	~Game();

	/**
	 * @brief Get the current state
	 *
	 * @return GameState* The current state
	 */
	GameState *getGameState();

	/**
	 * @brief Update the game environment
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Apply an action
	 *
	 * @param action The action to apply
	 * @param force true Apply the action and resolve conflicts automatically
	 * @param force false Apply the action and check conflicts
	 */
	void applyAction(Action action, bool force = false);
};

/****************
 * Definitions
 ****************/

GameState::GameState(int camp) : camp_(camp), other_camp_(1 - camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::GameState) Invalid camp!");
	}
}

GameState::~GameState()
{
}

IPlayer *GameState::getPlayer()
{
	return this->player_;
}

int GameState::getTime()
{
	return this->time_;
}

bitset<5> GameState::getBrokenLines()
{
	return this->broken_lines_;
}

int GameState::getCamp()
{
	return this->camp_;
}

int GameState::getOtherCamp()
{
	return this->other_camp_;
}

Plant GameState::getPlant(int x, int y)
{
	/* Check legality */
	if (x < 0 || x > 4 || y < 0 || y > 10)
	{
		throw invalid_argument("(GameState::getPlant) Out of map!");
	}

	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x == iter->getPosition().x &&
			y == iter->getPosition().y)
		{
			return *iter;
		}
	}

	return Plant(); // if there exists no plant
}

vector<Plant> GameState::getPlantList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 10)
	{
		throw invalid_argument("(GameState::getPlantList) Out of map!");
	}
	if (type < -1 || type > 6)
	{
		throw invalid_argument("(GameState::getPlantList) Invalid type!");
	}

	vector<Plant> result;
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

vector<Zombie> GameState::getZombieList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 10)
	{
		throw invalid_argument("(GameState::getZombieList) Out of map!");
	}
	if (type < -1 || type > 5)
	{
		throw invalid_argument("(GameState::getZombieList) Invalid type!");
	}

	vector<Zombie> result;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

Zombie GameState::getFirstZombie(int row, int col)
{
	vector<Zombie> possible_zombie_list = this->getZombieList(row);
	Zombie first_zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 999999));
	for (vector<Zombie>::iterator it = possible_zombie_list.begin();
		 it != possible_zombie_list.end();
		 ++it)
	{
		if (it->getPosition().y < col)
		{
			continue;
		}
		if (abs(it->getRealPosition().y - first_zombie.getRealPosition().y) < 0.001)
		{ // to avoid floating point comparison error
			if (it->getSpawnTime() < first_zombie.getSpawnTime())
			{
				first_zombie = *it;
			}
		}
		else if (it->getRealPosition().y < first_zombie.getRealPosition().y)
		{
			first_zombie = *it;
		}
	}
	return first_zombie;
}

Zombie GameState::getEarliestZombie(int row, int col)
{
	vector<Zombie> possible_zombie_list = this->getZombieList(row);
	Zombie earliest_zombie(this->getTime(), ZOMBIE.NOZOMBIE, Position<double>(row, 10));
	for (vector<Zombie>::iterator it = possible_zombie_list.begin();
		 it != possible_zombie_list.end();
		 ++it)
	{
		if (it->getPosition().y < col)
		{
			continue;
		}
		if (it->getSpawnTime() <= earliest_zombie.getSpawnTime())
		{
			earliest_zombie = *it;
		}
	}
	return earliest_zombie;
}

int GameState::getSun(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::getCD) Invalid camp!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->sun_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->sun_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getCD(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::getCD) Invalid camp!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw invalid_argument("(GameState::getCD) Invalid slot!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw invalid_argument("(GameState::getCD) Invalid slot!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->cd_plant_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->cd_zombie_[slot];
	}

	return 0; // to avoid compilation warning
}

int GameState::getScore(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(GameState::getScore) Invalid camp!");
		}
	}

	if (camp == CAMP.PLANT)
	{
		return this->score_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->score_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getBattlefront(int x)
{
	/* Check legality */
	if (x < 0 || x > 4)
	{
		throw invalid_argument("(GameState::getBattlefront) Out of map!");
	}

	int battle_front = 10;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (iter->getPosition().x == x)
		{
			battle_front = min(battle_front, iter->getPosition().y);
		}
	}
	return battle_front;
}

int GameState::getInferenceState()
{
	return this->inference_state_;
}

void GameState::setDebugMode(bool mode, ostream *os)
{
	this->debug_mode_ = mode;
	this->os = os;
}

void GameState::update(IPlayer *player)
{
	this->player_ = player;

	if (player->getTime() == 1)
	{
		this->score_base_ = player->getScore();
	}

	if (this->inference_state_ != 2)
	{
		try
		{
			this->infer();

			/* Check if the platform does not support static variables */
			if (this->time_ != player->getTime())
			{
				throw runtime_error("(GameState::update) Time error!");
			}

			/* Update according to player */
			/* Update plant list */
			int **raw_plant_map = player->Camp->getCurrentPlants();
			for (int x = 0; x <= 4; ++x)
			{
				for (int y = 0; y <= 9; ++y)
				{
					if (this->getPlant(x, y).getType() != raw_plant_map[x][y])
					{ // if the plant is removed or placed or changed
						if (this->getPlant(x, y).getType() != PLANT.NOPLANT)
						{ // if removed or changed
							for (vector<Plant>::iterator it = this->plant_.begin();
								 it != this->plant_.end();
								 ++it)
							{
								if (it->getPosition().x == x &&
									it->getPosition().y == y)
								{
									this->plant_.erase(it); // remove the plant from plant list
									break;
								}
							}
						}
						if (raw_plant_map[x][y] != PLANT.NOPLANT)
						{                                                 // if placed or changed
							this->plant_.push_back(Plant(this->time_ - 1, // place at last tick
														 raw_plant_map[x][y],
														 Position<int>(x, y)));
							this->cd_plant_[raw_plant_map[x][y]] = PLANT_CD[raw_plant_map[x][y]] - 1; // CD has already gone one tick
							this->sun_plant_ -= PLANT_COST[raw_plant_map[x][y]];
						}
					}
				}
			}

			/* Update zombie list */
			int ***raw_zombie_map = player->Camp->getCurrentZombies();
			for (int x = 0; x <= 4; ++x)
			{
				int zombie_cnt = 0;
				for (int z = 0; raw_zombie_map[x][9][z] != -1; ++z)
				{
					++zombie_cnt;
				}
				if (zombie_cnt > this->getZombieList(x, 9).size() + this->getZombieList(x, 10).size())
				{ // after inference, all zombies' y position will < 10
					for (size_t z = this->getZombieList(x, 9).size(); z < zombie_cnt; ++z)
					{
						this->zombie_.push_back(Zombie(
							this->time_ - 1, // place at last tick
							raw_zombie_map[x][9][z],
							Position<double>(x, 10)));
						this->cd_zombie_[raw_zombie_map[x][9][z]] = ZOMBIE_CD[raw_zombie_map[x][9][z]] - 1; // CD has already gone one tick;
						this->sun_zombie_ -= ZOMBIE_COST[raw_zombie_map[x][9][z]];
					}
				}
			}

			/* Perform zombie boost again */
			if (this->time_ % 500 == 0)
			{ // trigger zombie boost
				for (int i = 1; i <= 5; ++i)
				{
					this->cd_zombie_[i] = 0;
				}
			}

			/* Check accuracy */
			if (this->inference_state_ == 0)
			{
				for (int i = 1; i <= 4; ++i)
				{
					if (this->broken_lines_[i] != (this->player_->Camp->getLeftLines()[i] == 0))
					{
						this->inference_state_ = 1;
					}
				}
				if (this->camp_ == CAMP.PLANT)
				{
					if (this->score_plant_ != this->player_->getScore() - this->score_base_ ||
						this->sun_plant_ != this->player_->Camp->getSun())
					{
						this->inference_state_ = 1;
					}
					for (int i = 1; i <= 6; ++i)
					{
						if (this->cd_plant_[i] != this->player_->Camp->getPlantCD()[i - 1])
						{
							this->inference_state_ = 1;
						}
					}
				}
				else
				{
					if (this->score_zombie_ != this->player_->getScore() - this->score_base_ ||
						this->sun_zombie_ != this->player_->Camp->getSun())
					{
						this->inference_state_ = 1;
					}
					for (int i = 1; i <= 5; ++i)
					{
						if (this->cd_zombie_[i] != this->player_->Camp->getPlantCD()[i - 1])
						{
							this->inference_state_ = 1;
						}
					}
				}

				if (this->inference_state_ == 1 && this->debug_mode_)
				{
					*(this->os) << "******** " << this->time_ << " ********" << endl;
					*(this->os) << this;
					*(this->os) << "Real sun: " << this->player_->Camp->getSun() << endl;
					*(this->os) << "Real CD: [0, ";
					for (int i = 0; i < ((this->camp_ == CAMP.PLANT) ? 6 : 5); ++i)
					{
						*(this->os) << this->player_->Camp->getPlantCD()[i] << ", ";
					}
					*(this->os) << "]" << endl;
					*(this->os) << "Real score: " << this->player_->getScore() - this->score_base_ << endl;
					*(this->os) << "[WARNING]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> Inference algorithm is not working properly! Trying to correct..." << endl
								<< endl;
				}
			}
		}
		catch (const exception &e)
		{
			this->inference_state_ = 2; // the inference algorithm is collapsed
			if (this->debug_mode_)
			{
				*(this->os) << "******** " << this->player_->getTime() << " ********" << endl;
				*(this->os) << this;
				*(this->os) << "[ERROR]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> " << e.what() << endl;
				*(this->os) << "[INFO]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> Disabling inference algorithm..." << endl
							<< endl;
			}
		}
	}

	/* Error correction */
	if (this->inference_state_ == 1 || this->inference_state_ == 2)
	{
		for (int i = 0; i <= 4; ++i)
		{
			this->broken_lines_[i] = (this->player_->Camp->getLeftLines()[i] == 0);
		}

		if (this->camp_ == CAMP.PLANT)
		{
			this->sun_plant_ = this->player_->Camp->getSun();
			if (this->sun_zombie_ < 0)
			{
				this->sun_zombie_ += 900; // to avoid error in inference
			}
			this->score_plant_ = this->player_->getScore() - this->score_base_;
			for (int i = 1; i <= 6; ++i)
			{
				this->cd_plant_[i] = this->player_->Camp->getPlantCD()[i - 1];
			}
			for (int i = 0; i <= 5; ++i)
			{
				this->cd_zombie_[i] = 0;
			}
		}
		else
		{
			this->sun_zombie_ = this->player_->Camp->getSun();
			if (this->sun_plant_ < 0)
			{
				this->sun_plant_ += 775; // to avoid error in inference
			}
			this->score_zombie_ = this->player_->getScore() - this->score_base_;
			for (int i = 1; i <= 5; ++i)
			{
				this->cd_zombie_[i] = this->player_->Camp->getPlantCD()[i - 1];
			}
			for (int i = 0; i <= 6; ++i)
			{
				this->cd_plant_[i] = 0;
			}
		}
	}

	if (this->inference_state_ == 2)
	{
		this->time_ = this->player_->getTime();
		this->plant_.clear();
		this->zombie_.clear();
		for (int x = 0; x <= 4; ++x)
		{
			for (int y = 0; y <= 9; ++y)
			{
				int plant_type = this->player_->Camp->getCurrentPlants()[x][y];
				this->plant_.push_back(Plant(this->time_, plant_type, Position<int>(x, y)));
			}
		}
		for (int x = 0; x <= 4; ++x)
		{
			for (int y = 0; y <= 9; ++y)
			{
				for (int z = 0; this->player_->Camp->getCurrentZombies()[x][y][z] != -1; ++z)
				{
					this->zombie_.push_back(Zombie(this->time_, this->player_->Camp->getCurrentZombies()[x][y][z], Position<double>(x, y + 0.04)));
				}
			}
		}
		if (this->camp_ == CAMP.PLANT)
		{
			this->sun_zombie_ = 1000;              // heuristic
			this->score_zombie_ = 4 * this->time_; // heuristic
		}
		else
		{
			this->sun_plant_ = 1000;              // heuristic
			this->score_plant_ = 3 * this->time_; // heuristic
		}
	}
}

vector<double> GameState::to_vector()
{
	vector<double> result;
	result.push_back(this->time_ / 2000.0);
	result.push_back(this->sun_plant_ / 1000.0);
	result.push_back(this->sun_zombie_ / 1000.0);
	for (int i = 1; i <= 6; ++i)
	{
		result.push_back(static_cast<double>(this->cd_plant_[i]) / PLANT_CD[i]);
	}
	for (int i = 1; i <= 5; ++i)
	{
		result.push_back(static_cast<double>(this->cd_zombie_[i]) / ZOMBIE_CD[i]);
	}
	for (int x = 0; x <= 4; ++x)
	{
		for (int y = 0; y <= 9; ++y)
		{
			int plant_type = this->getPlant(x, y).getType();
			result.push_back((plant_type >> 2) & 1);
			result.push_back((plant_type >> 1) & 1);
			result.push_back(plant_type & 1);
		}
	}
	for (int x = 0; x <= 4; ++x)
	{
		vector<Zombie> zombie_list = this->getZombieList(x);
		for (int i = 0; i < 5; ++i)
		{
			if (i >= zombie_list.size())
			{
				for (int j = 0; j < 5; ++j)
				{
					result.push_back(0);
				}
				continue;
			}
			Zombie zombie = zombie_list.at(i);
			int zombie_type = zombie.getType();
			result.push_back((zombie_type >> 2) & 1);
			result.push_back((zombie_type >> 1) & 1);
			result.push_back(zombie_type & 1);
			result.push_back(static_cast<double>(zombie.getHealth()) / ZOMBIE_HP[zombie_type]);
			result.push_back(zombie.getRealPosition().y / 10);
		}
	}
	return result;
}

GameState *GameState::generateSuccessor(Action action)
{
	GameState *gs = new GameState(*this);
	gs->infer(action);
	return gs;
}

void GameState::infer()
{
	/* Update zombies' time property */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		it->setNowTime(this->time_); // because this->time_ is the time of last tick
	}

	/* Perform plant attack and sun production */
	for (vector<Plant>::iterator it = this->plant_.begin();
		 it != this->plant_.end();
		 ++it)
	{
		Position<int> pos = it->getPosition();
		if (it->getType() == PLANT.PEPPER)
		{
			for (vector<Zombie>::iterator it1 = this->zombie_.begin();
				 it1 != this->zombie_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x)
				{
					it1->reduceHealth(1800);
				}
			}
			it->reduceHealth(300); // pepper will kill itself
		}
		else if (it->getType() == PLANT.SQUASH)
		{
			for (vector<Zombie>::iterator it1 = this->zombie_.begin();
				 it1 != this->zombie_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					it1->getPosition().y == pos.y)
				{
					it1->reduceHealth(1800);
					it->reduceHealth(300); // squash will kill itself
				}
			}
		}
		else if (it->getType() == PLANT.PEASHOOTER)
		{
			Zombie target = this->getFirstZombie(pos.x, pos.y);
			Zombie earliest = this->getEarliestZombie(pos.x, pos.y);
			int reference_time = max(earliest.getSpawnTime(), it->getSpawnTime());
			if (((this->time_ - it->getLastAttackTime() > 3) && ((this->time_ - reference_time) % 3 == 1)) ||
				(this->time_ - it->getLastAttackTime() == 3))
			{
				for (vector<Zombie>::iterator it1 = this->zombie_.begin();
					 it1 != this->zombie_.end();
					 ++it1)
				{
					if (it1->getID() == target.getID())
					{
						it1->reduceHealth(20);
						it->setLastAttackTime(this->time_);
					}
				}
			}
		}
		else if (it->getType() == PLANT.WINTERPEASHOOTER)
		{
			Zombie target = this->getFirstZombie(pos.x, pos.y);
			Zombie earliest = this->getEarliestZombie(pos.x, pos.y);
			int reference_time = max(earliest.getSpawnTime(), it->getSpawnTime());
			if (((this->time_ - it->getLastAttackTime() > 4) && ((this->time_ - reference_time) % 4 == 1)) ||
				(this->time_ - it->getLastAttackTime() == 4))
			{
				for (vector<Zombie>::iterator it1 = this->zombie_.begin();
					 it1 != this->zombie_.end();
					 ++it1)
				{
					if (it1->getID() == target.getID() ||
					(it1->getPosition().x == target.getPosition().x && it1->getPosition().y == target.getPosition().y))
					{
						it1->reduceHealth(60);
						it1->setFrozenState(10); // freeze the zombie for 10 sec
						it->setLastAttackTime(this->time_);
					}
				}
			}
		}
		else if (it->getType() == PLANT.SUNFLOWER)
		{
			if ((this->getTime() - it->getSpawnTime()) % 21 == 1)
			{
				this->sun_plant_ += 25;
			}
		}
	}

	/* Remove dead zombies */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();)
	{
		if (it->getHealth() <= 0)
		{
			this->score_plant_ += ZOMBIE_COST[it->getType()]; // zombies' death contributes to plant camp's score
			it = this->zombie_.erase(it);
		}
		else
		{
			++it;
		}
	}

	/* Perform zombie attack */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		Position<int> pos = it->getPosition();
		if (it->getType() == ZOMBIE.NORMAL ||
			it->getType() == ZOMBIE.BUCKET ||
			it->getType() == ZOMBIE.POLEVAULT)
		{
			for (vector<Plant>::iterator it1 = this->plant_.begin();
				 it1 != this->plant_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					it1->getPosition().y == pos.y)
				{
					if (it->getFrozenState() == 0)
					{
						it1->reduceHealth(static_cast<int>(
							75 * max(1.0, this->time_ / 1000.0))); // zombies' ATK will increase after tick 1000
					}
					else
					{
						it1->reduceHealth(static_cast<int>(
							37.5 * max(1.0, this->time_ / 1000.0))); // zombies' ATK will increase after tick 1000
					}
				}
			}
		}
		else if (it->getType() == ZOMBIE.SLED ||
				 it->getType() == ZOMBIE.GARGANTUAR)
		{
			for (vector<Plant>::iterator it1 = this->plant_.begin();
				 it1 != this->plant_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					(it1->getPosition().y == pos.y))
				{
					it1->reduceHealth(999999);
				}
			}
		}
	}

	/* Remove dead plants */
	for (vector<Plant>::iterator it = this->plant_.begin();
		 it != this->plant_.end();)
	{
		if (it->getHealth() <= 0)
		{
			this->score_zombie_ += PLANT_COST[it->getType()]; // plants' death contributes to zombie camp's score
			this->sun_zombie_ += PLANT_COST[it->getType()] / 5 +
								 static_cast<int>(
									 sqrt(PLANT_HP[it->getType()]));
			it = this->plant_.erase(it);
		}
		else
		{
			++it;
		}
	}

	/* Perform zombie movement */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		Position<double> pos_real = it->getRealPosition();
		Position<int> pos = it->getPosition();
		if (it->getType() == ZOMBIE.NORMAL ||
			it->getType() == ZOMBIE.BUCKET)
		{
			if (this->getPlant(pos.x, pos.y).getType() == PLANT.NOPLANT)
			{ // if there's no plant, the zombie can move

				if (it->getFrozenState())
				{ // if the zombie is frozen, its speed cuts to half
					pos_real.y -= ZOMBIE_SPEED.DEFAULT * 0.5;
				}
				else
				{ // if the zombie is not frozen
					pos_real.y -= ZOMBIE_SPEED.DEFAULT;
				}
			}
		}
		else if (it->getType() == ZOMBIE.POLEVAULT)
		{
			if (this->getPlant(pos.x, pos.y).getType() == PLANT.NOPLANT)
			{ // if there's no plant, the zombie can move normally
				if (it->getFrozenState())
				{ // if the zombie is frozen, its speed cuts to half
					pos_real.y -= ZOMBIE_SPEED.POLEVAULT[it->getState()] * 0.5;
				}
				else
				{ // if the zombie is not frozen
					pos_real.y -= ZOMBIE_SPEED.POLEVAULT[it->getState()];
				}
			}
			else if (it->getState() == 0)
			{ // if there's plant and the zombie is not skipped, the zombie will skip the plant
				pos_real.y -= 1;
				it->setState(1); // set the zombie as skipped state
			}
		}
		else if (it->getType() == ZOMBIE.SLED)
		{
			int y = (pos_real.y + 0.001 > 10) ? 10 : pos.y; // to correct the speed
			if (it->getFrozenState())
			{ // if the zombie is frozen, its speed cuts to half
				pos_real.y -= ZOMBIE_SPEED.SLED[min(10 - y, 4)] * 0.5;
			}
			else
			{ // if the zombie is not frozen
				pos_real.y -= ZOMBIE_SPEED.SLED[min(10 - y, 4)];
			}
		}
		else if (it->getType() == ZOMBIE.GARGANTUAR)
		{
			if (it->getFrozenState())
			{ // if the zombie is frozen, its speed cuts to half
				pos_real.y -= ZOMBIE_SPEED.DEFAULT * 0.5;
			}
			else
			{ // if the zombie is not frozen
				pos_real.y -= ZOMBIE_SPEED.DEFAULT;
			}
		}

		it->setRealPosition(pos_real);

		/* Update frozen state */
		if (it->getFrozenState() > 0)
		{                                                 // if the zombie is frozen
			it->setFrozenState(it->getFrozenState() - 1); // reduce remaining frozen time
		}

		/* Update broken lines */
		if (pos_real.y < -0.001 && !this->broken_lines_[pos.x]) // doubt: what is the condition?
		{
			this->broken_lines_.set(pos.x);
			this->score_zombie_ += 3000 - this->time_; // doubt: which tick to calculate?
		}
	}

	/* Remove entities in broken rows */
	for (int row = 0; row <= 4; ++row)
	{
		if (this->broken_lines_[row])
		{
			for (vector<Plant>::iterator it = this->plant_.begin();
				 it != this->plant_.end();)
			{ // remove plants in the broken line
				if (it->getPosition().x == row)
				{
					it = this->plant_.erase(it);
				}
				else
				{
					++it;
				}
			}
			for (vector<Zombie>::iterator it = this->zombie_.begin();
				 it != this->zombie_.end();)
			{ // remove zombies in the broken line
				if (it->getPosition().x == row)
				{
					it = this->zombie_.erase(it);
				}
				else
				{
					++it;
				}
			}
		}
	}

	/* Perform CD reduction */
	for (int i = 1; i <= 6; ++i)
	{ // reduce plant CDs
		this->cd_plant_[i] = max(0, this->cd_plant_[i] - 1);
	}

	for (int i = 1; i <= 5; ++i)
	{ // reduce zombie CDs
		this->cd_zombie_[i] = max(0, this->cd_zombie_[i] - 1);
	}

	/* Perform zombie camp's sun increase */
	this->sun_zombie_ += this->time_ / 200 + 1;

	/* Perform zombie boost */
	if (this->time_ % 500 == 499)
	{ // trigger zombie boost
		for (int i = 1; i <= 5; ++i)
		{
			this->cd_zombie_[i] = 0;
		}
		this->sun_zombie_ += 200;
	}

	++this->time_;
}

void GameState::infer(Action action)
{
	int camp = this->getCamp();

	/* Plant removal */
	for (int i = 0; i < action.getRemovalList().size(); ++i)
	{
		Position<int> removal = action.getRemovalList().at(i);

		/* Check legality */
		if (this->getPlant(removal.x, removal.y).getType() == PLANT.NOPLANT)
		{
			throw runtime_error("(GameState::infer) Plant removal on empty place!");
		}

		for (vector<Plant>::iterator it = this->plant_.begin();
			 it != this->plant_.end();)
		{ // remove a plant
			if (it->getPosition().x == removal.x &&
				it->getPosition().y == removal.y)
			{
				it = this->plant_.erase(it);
			}
			else
			{
				++it;
			}
		}
	}

	/* Plant placement */
	int sun_consumption = 0;
	for (int slot = 1; slot <= 6; ++slot)
	{
		if (action.isSet(CAMP.PLANT, slot))
		{
			if (this->getBrokenLines()[action.getPosition(CAMP.PLANT, slot).x])
			{
				throw runtime_error("(GameState::infer) Plant placement in broken line!");
			}
			if (this->getCD(CAMP.PLANT, slot) > 0)
			{
				throw runtime_error("(GameState::infer) Plant cooldown unfinished!");
			}
			sun_consumption += PLANT_COST[slot];
		}
	}
	if (sun_consumption > this->getSun(CAMP.PLANT))
	{
		throw runtime_error("(GameState::infer) Plant sun insufficient!");
	}

	for (int slot = 1; slot <= 6; ++slot)
	{
		if (action.isSet(CAMP.PLANT, slot))
		{
			Position<int> position = action.getPosition(CAMP.PLANT, slot);

			for (vector<Plant>::iterator it = this->plant_.begin();
				 it != this->plant_.end();)
			{ // remove a plant
				if (it->getPosition().x == position.x &&
					it->getPosition().y == position.y)
				{
					it = this->plant_.erase(it);
				}
				else
				{
					++it;
				}
			}

			this->plant_.push_back(Plant(
				this->time_,
				slot,
				position));
			this->cd_plant_[slot] = PLANT_CD[slot] - 1; // CD has already gone one tick
		}
	}

	this->sun_plant_ -= sun_consumption;

	/* Zombie placement */
	sun_consumption = 0;
	for (int slot = 1; slot <= 5; ++slot)
	{
		if (action.isSet(CAMP.ZOMBIE, slot))
		{
			if (this->getBrokenLines()[action.getPosition(CAMP.ZOMBIE, slot).x])
			{
				throw runtime_error("(GameState::infer) Zombie placement in broken line!");
			}
			if (this->getCD(CAMP.ZOMBIE, slot) > 0)
			{
				throw runtime_error("(GameState::infer) Zombie cooldown unfinished!");
			}
			sun_consumption += ZOMBIE_COST[slot];
		}
	}
	if (sun_consumption > this->getSun(CAMP.ZOMBIE))
	{
		throw runtime_error("(GameState::infer) Zombie sun insufficient!");
	}

	for (int slot = 1; slot <= 5; ++slot)
	{
		if (action.isSet(CAMP.ZOMBIE, slot))
		{
			this->zombie_.push_back(
				Zombie(
					this->time_,
					slot,
					action.getPosition(CAMP.ZOMBIE, slot)));
			this->cd_zombie_[slot] = ZOMBIE_CD[slot] - 1; // CD has already gone one tick
		}
	}

	this->sun_zombie_ -= sun_consumption;

	this->infer();
}

ostream &operator<<(ostream &os, GameState *game_state)
{
	os << "GameState(time_="
	   << game_state->time_
	   << ",\n          broken_lines_="
	   << game_state->broken_lines_
	   << ",\n          camp_="
	   << game_state->camp_
	   << ",\n          other_camp_="
	   << game_state->other_camp_
	   << ",\n          sun_plant_="
	   << game_state->sun_plant_
	   << ",\n          sun_zombie_="
	   << game_state->sun_zombie_
	   << ",\n          cd_plant_=[";
	for (int i = 0; i < 7; ++i)
	{
		os << game_state->cd_plant_[i] << ", ";
	}
	os << "],\n          cd_zombie_=[";
	for (int i = 0; i < 6; ++i)
	{
		os << game_state->cd_zombie_[i] << ", ";
	}
	os << "],\n          score_plant_="
	   << game_state->score_plant_
	   << ",\n          score_zombie_="
	   << game_state->score_zombie_
	   << ",\n          )\n";

	return os;
}

History::History() : history_(2001, GameState(0))
{
}

void History::insert(GameState *game_state)
{
	int time = game_state->getTime();

	/* Check legality */
	if (time < 0 || time > 2000)
	{
		throw invalid_argument("(History::insert) Invalid game state time!");
	}

	this->history_.at(time) = *game_state;
}

GameState *History::operator[](int time)
{
	/* Check legality */
	if (time < 0 || time > 2000)
	{
		throw invalid_argument("(History::[]) Invalid game state time!");
	}

	return &(this->history_.at(time));
}

unsigned long long History::getIdentifier()
{
	unsigned long long result = 0;
	unsigned long long hash = 19260817;
	for (int i = 0; i <= 2000; ++i)
	{
		GameState &gs = this->history_.at(i);
		if (gs.getTime() == 0)
		{
			continue;
		}

		result = result * hash + gs.getTime();
		result = result * hash + gs.getBrokenLines().to_ullong();
		result = result * hash + gs.getCamp();
		result = result * hash + gs.getTime();
		result = result * hash + gs.getScore(CAMP.PLANT);
		result = result * hash + gs.getScore(CAMP.ZOMBIE);
		result = result * hash + gs.getSun(CAMP.PLANT);
		result = result * hash + gs.getSun(CAMP.ZOMBIE);
		for (int i = 1; i <= 6; ++i)
		{
			result = result * hash + gs.getCD(CAMP.PLANT, i);
		}
		for (int i = 1; i <= 5; ++i)
		{
			result = result * hash + gs.getCD(CAMP.ZOMBIE, i);
		}
		vector<Plant> plant_list = gs.getPlantList();
		for (auto it = plant_list.begin(); it != plant_list.end(); ++it)
		{
			result = result * hash + it->getType();
			result = result * hash + it->getHealth();
			result = result * hash + it->getID();
			result = result * hash + it->getSpawnTime();
			result = result * hash + it->getPosition().x;
			result = result * hash + it->getPosition().y;
			result = result * hash + it->getLastAttackTime();
		}
		vector<Zombie> zombie_list = gs.getZombieList();
		for (auto it = zombie_list.begin(); it != zombie_list.end(); ++it)
		{
			result = result * hash + it->getFrozenState();
			result = result * hash + it->getHealth();
			result = result * hash + it->getID();
			result = result * hash + it->getPosition().x;
			result = result * hash + it->getPosition().y;
			result = result * hash + it->getSpawnTime();
			result = result * hash + it->getState();
			result = result * hash + it->getType();
		}
	}

	return result;
}

Game::Game(IPlayer *player)
{
	this->player_ = player;
	this->game_state_ = new GameState(player->Camp->getCurrentType());
}

Game::~Game()
{
}

GameState *Game::getGameState()
{
	return this->game_state_;
}

void Game::update(IPlayer *player)
{
	this->player_ = player;
	this->game_state_->update(player);
}

void Game::applyAction(Action action, bool force)
{
	int camp = this->game_state_->getCamp();
	if (camp == CAMP.PLANT)
	{
		if (!force)
		{
			/* Check legality */
			for (int slot = 1; slot <= 5; ++slot)
			{
				if (action.isSet(CAMP.ZOMBIE, slot))
				{
					throw runtime_error("(Game::applyAction) No access to zombie action!");
				}
			}
		}

		/* Plant removal */
		for (int i = 0; i < action.getRemovalList().size(); ++i)
		{
			Position<int> removal = action.getRemovalList().at(i);

			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getPlant(removal.x, removal.y).getType() == PLANT.NOPLANT)
				{
					throw runtime_error("(Game::applyAction) Plant removal on empty place!");
				}
			}

			this->player_->removePlant(removal.x, removal.y);
		}

		/* Plant placement */
		int remaining_sun = this->game_state_->getSun(CAMP.PLANT);
		vector<int> sequence = action.getSequence(CAMP.PLANT);
		for (auto it = sequence.begin(); it != sequence.end(); ++it)
		{
			Position<int> pos = action.getPosition(CAMP.PLANT, *it);
			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getBrokenLines()[pos.x])
				{
					throw runtime_error("(Game::applyAction) Plant placement in broken line!");
				}
				if (this->game_state_->getCD(CAMP.PLANT, *it) > 0)
				{
					throw runtime_error("(Game::applyAction) Plant cooldown unfinished!");
				}
				if (PLANT_COST[*it] > remaining_sun)
				{
					throw runtime_error("(Game::applyAction) Plant sun insufficient!");
				}
			}
			this->player_->removePlant(pos.x, pos.y);
			this->player_->PlacePlant(*it, pos.x, pos.y);
			remaining_sun -= PLANT_COST[*it];
		}
	}
	else if (camp == CAMP.ZOMBIE)
	{
		/* Check legality */
		if (!force)
		{
			for (int slot = 1; slot <= 6; ++slot)
			{
				if (action.isSet(CAMP.PLANT, slot))
				{
					throw runtime_error("(Game::applyAction) No access to plant action!");
				}
			}
		}

		/* Zombie placement */
		int remaining_sun = this->game_state_->getSun(CAMP.ZOMBIE);
		vector<int> sequence = action.getSequence(CAMP.ZOMBIE);
		for (auto it = sequence.begin(); it != sequence.end(); ++it)
		{
			int x = action.getPosition(CAMP.ZOMBIE, *it).x;
			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getBrokenLines()[action.getPosition(CAMP.ZOMBIE, *it).x])
				{
					throw runtime_error("(Game::applyAction) Zombie placement in broken line!");
				}
				if (this->game_state_->getCD(CAMP.ZOMBIE, *it) > 0)
				{
					throw runtime_error("(Game::applyAction) Zombie cooldown unfinished!");
				}
				if (ZOMBIE_COST[*it] > remaining_sun)
				{
					throw runtime_error("(Game::applyAction) Zombie sun insufficient!");
				}
			}
			this->player_->PlaceZombie(*it, x);
			remaining_sun -= ZOMBIE_COST[*it];
		}
	}
}

class Agent
{
public:
	/**
	 * @brief Get the action the agent performs
	 *
	 * @param game_state A game state
	 * @return Action The action
	 */
	virtual Action getAction(GameState *game_state) = 0;

	/**
	 * @brief Judge if the agent is available under the game state
	 *
	 * @param game_state A game state
	 * @return true The agent is available
	 * @return false The agent is not available
	 */
	virtual bool isAvailable(GameState *game_state)
	{
		return true;
	}
};

#endif
/*** End of inlined file: Game.cpp ***/



/*** Start of inlined file: PlantAncientAgent.cpp ***/
#ifndef __LEGACY_AI_CPP__
#define __LEGACY_AI_CPP__

#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>

using namespace std;

namespace legacy_ai
{
	constexpr int ZOMBIE_KIND = 5;
	constexpr int PLANT_KIND = 6;
	constexpr int TOTAL_TIME = 2000;
	constexpr int COLUMN = 10;
	constexpr int ROW = 5;
	GameState *game_state;
	// FILE *file;
	// errno_t err = fopen_s(&file, "D:\\2022 spring_semester\\pvz\\fc19_userpackage-master\\FC19_UI\\data.txt", "w+");
	enum PlantType
	{
		NOPLANT = 0,
		SUNFLOWER,
		WINTERPEASHOOTER,
		PEASHOOTER,
		SMALLNUT,
		PEPPER,
		SQUASH
	};

	//僵 尸 种 类 4
	enum ZombieType
	{
		NOZOMBIE = 0,
		NORMAL,
		BUCKET,
		POLEVAULT,
		SLED,
		GARGANTUAR
	};

	// zrf 's code starts
	const int plantCost[7] = {0, 50, 400, 100, 50, 125, 50};
	const int plantCd[7] = {0, 10, 30, 10, 40, 60, 60};
	const int zombieCost[6] = {0, 50, 125, 125, 300, 300};
	const int zombieCd[6] = {0, 15, 20, 20, 25, 25};
	const int plantHp[7] = {0, 300, 300, 300, 4000, 0, 0};
	const int plantDps[7] = {0, 0, 20, 10, 0, 0, 0};
	int zombieHp[6] = {0, 270, 820, 200, 1600, 3000};
	struct Sunflower
	{
		int row, column, cd;
		Sunflower(int Row, int Column)
		{
			cd = 24;
			row = Row, column = Column;
		}
	}; //跟踪向日葵
	int *zombieNum(int ***zombies)
	{
		int cnt[7] = {}, *p = cnt;
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
				for (int k = 0; k < 10; k++)
				{
					if (zombies[i][j][k] = -1)
						break;
					else
						cnt[zombies[i][j][k]]++;
				}
		return p;
	} //将zombies分类计数
	int *zombieNum(int zombies[5][10][10])
	{
		int cnt[7] = {}, *p = cnt;
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
				for (int k = 0; k < 10; k++)
				{
					if (zombies[i][j][k] = -1)
						break;
					else
						cnt[zombies[i][j][k]]++;
				}
		return p;
	} //重载
	struct Zombie
	{
		int num;
		int hp;
		int coX, coY;
		Zombie(int Num, int row)
		{
			coX = row, coY = 9;
			hp = zombieHp[Num];
			num = Num;
		}
		// int speed;   ?
	};
	struct Plant
	{
		int num;
		int hp;
		int coX, coY;
		int dps;
		Plant(int Num, int row, int col)
		{
			num = Num;
			coX = row, coY = col;
			hp = plantHp[Num];
			dps = plantDps[Num];
		}
	};
	struct Actionlist
	{
		int plantPlace[5][10] = {}, zombiePlace[5] = {};
		int plantRemove[5][10] = {};
	};
	class Game
	{
	public:
		int time, sun, moon;
		int plants[5][10], zombies[5][10][10];
		int cdPlant[7], cdZombie[6];	 //记录双方在当前tick下冷却
		int dps[5];						 //记录每行dps
		int flagPlant[7], flagZombie[6]; //记录冷却是否(1/0)完成
		int flagShovel[5][10];			 //记录某个位置是否(1/0)进行铲除操作
		int zombieCostPerRow[5];
		vector<Sunflower> sunFlowers;
		vector<Plant> vectorPlants;
		vector<Zombie> vectorZombies;

		void plantremove(int i, int j, IPlayer *player)
		{
			player->removePlant(i, j);
			flagShovel[i][j] = 1;
		}
		void maintain(IPlayer *player)
		{
			time++;
			int **Plants = player->Camp->getCurrentPlants();	// currentPlants
			int ***Zombies = player->Camp->getCurrentZombies(); // currentZombies
			moon += int(time / 200.0) + 1;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
				{
					if (plants[i][j] > Plants[i][j] && plants[i][j] != PEPPER && plants[i][j] != SQUASH)
					{
						if (flagShovel[i][j] == 1)
						{
							flagShovel[i][j] = 0;
						}
						else
						{
							int num = plants[i][j];
							moon += plantCost[num] / 5 + int(sqrt(plantHp[num]));
							dps[i] -= plantDps[num];
							if (num == 1)
							{
								for (int k = 0; k < sunFlowers.size(); k++)
									if (sunFlowers[k].row == i && sunFlowers[k].column == j)
									{
										sunFlowers.erase(sunFlowers.begin() + k);
										break;
									}
							}
						}
					} //植物阵亡
					else if (plants[i][j] < Plants[i][j])
					{
						int num = Plants[i][j];
						sun -= plantCost[num];
						dps[i] += plantDps[num];
						cdPlant[num] = plantCd[num];
						flagPlant[num] = 0;
						if (num == 1)
						{
							sun += 25;
							sunFlowers.push_back(Sunflower(i, j));
						}
						vectorPlants.push_back(Plant(Plants[i][j], i, j));
					} //植物种植
					plants[i][j] = Plants[i][j];
					int flag = 0;
					for (int k = 0; k < vectorPlants.size(); k++)
					{
						if (vectorPlants[k].coX == i && vectorPlants[k].coY == j)
						{
							if (vectorPlants[k].num != Plants[i][j])
							{
								vectorPlants.erase(vectorPlants.begin() + k);
								k--;
								if (Plants[i][j] != 0)
									vectorPlants.push_back(Plant(Plants[i][j], i, j));
							}
							flag = 1;
							break;
						}
					}
					if (flag == 0 && Plants[i][j] != 0)
						vectorPlants.push_back(Plant(Plants[i][j], i, j));
				}
			int *z = zombieNum(zombies), *Z = zombieNum(Zombies);
			for (int i = 0; i < 5; i++)
			{
				int rowZombie[6] = {}, RowZombie[6] = {}; //前者为保存的状态，后者为当前状态
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
					{
						if (zombies[i][j][k] = -1)
							break;
						else
							rowZombie[zombies[i][j][k]]++;
					}
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
					{
						if (Zombies[i][j][k] = -1)
							break;
						else
							RowZombie[Zombies[i][j][k]]++;
						;
					}
				for (int j = 0; j < 6; j++)
					if (RowZombie[j] > rowZombie[j])
						zombieCostPerRow[i] += zombieCost[j];
			}
			for (int i = 0; i < 7; i++)
			{
				if (z[i] < Z[i])
				{

				} // zombie die
				else if (z[i] > Z[i])
				{
					moon -= zombieCost[i];
					cdZombie[i] = zombieCd[i];
					flagZombie[i] = 0;
				} // zombie placed
			}

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 10; j++)
				{
					int k = 0;
					while (Zombies[i][j][k] != -1)
					{
						zombies[i][j][k] = Zombies[i][j][k];
						k++;
					}
				}
			}

			vector<int> have_erased;
			for (int i = 0; i < vectorZombies.size(); i++)
			{
				int have_erased_flag = 0;
				for (int z = 0; z < have_erased.size(); z += 2)
				{
					if (vectorZombies[i].coX == have_erased[z] && vectorZombies[i].coY == have_erased[z + 1])
					{
						have_erased_flag = 1;
						break;
					}
				}

				if (Plants[vectorZombies[i].coX][vectorZombies[i].coY] != SMALLNUT || have_erased_flag == 1)
				{
					continue;
				}
				else
				{
					int num = vectorZombies[i].num;
					int original_num_of_this_kind = 0, now_num_of_this_kind = 0;
					int k = 0;
					while (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
					{
						if (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num)
						{
							original_num_of_this_kind++;
						}
						k++;
					}
					k = 0;
					while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
					{
						if (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num)
						{
							now_num_of_this_kind++;
						}
						k++;
					}
					if (original_num_of_this_kind - now_num_of_this_kind > 0)
					{
						vector<int> serialNum;
						for (int j = 0; j < vectorZombies.size(); j++)
						{
							if (vectorZombies[j].num == num && vectorZombies[i].coY == vectorZombies[j].coY && vectorZombies[i].coX == vectorZombies[j].coX)
							{
								serialNum.push_back(j);
							}
						}
						if (now_num_of_this_kind == 0)
						{
							for (int i = serialNum.size() - 1; i >= 0; i--)
							{
								vectorZombies.erase(serialNum[i] + vectorZombies.begin());
							}
						}
						if (original_num_of_this_kind - now_num_of_this_kind == 1)
						{ // find the smallest hp
							int small_hp = 5000, small_hp_num = 0;
							for (int k = 0; k < serialNum.size(); k++)
							{
								if (small_hp > vectorZombies[serialNum[k]].hp)
								{
									small_hp = vectorZombies[serialNum[k]].hp;
									small_hp_num = k;
								}
							}
							vectorZombies.erase(small_hp_num + vectorZombies.begin());
						}

						have_erased.push_back(vectorZombies[i].coX);
						have_erased.push_back(vectorZombies[i].coY);
					}
				}
			}
			for (int i = 0; i < vectorZombies.size(); i++)
			{
				int num = vectorZombies[i].num;
				int k = 0;
				int flag_self = 0;
				int flag_near = 0;
				while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
				{
					if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k])
					{
						break;
					}
					else
					{
						flag_self = 1;
					}
				}
				k = 0;
				while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY - 1][k] != -1)
				{
					if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k])
					{
						vectorZombies[i].coY--;
					}
					else
					{
						flag_near = 1;
					}
				}
				if (flag_self == 1 && flag_near == 1)
				{
					vectorZombies.erase(vectorZombies.begin() + i);
					i--;
				}
			}

			for (int i = 0; i < 7; i++)
			{
				if (cdPlant[i] > 0)
					cdPlant[i]--;
				if (cdPlant[i] == 0)
					flagPlant[i] = 1;
			}

			for (int i = 0; i < 6; i++)
			{
				if (cdZombie[i] > 0)
					cdZombie[i]--;
				if (cdZombie[i] == 0)
					flagZombie[i] = 1;
			}
			for (int i = 0; i < sunFlowers.size(); i++)
			{
				if (sunFlowers[i].cd > 0)
					sunFlowers[i].cd--;
				if (sunFlowers[i].cd == 0)
				{
					sun += 25;
					sunFlowers[i].cd = 24;
				}
			}

		} //将上一tick的状态转移至当前tick
		Game()
		{
			time = 0;
			sun = 400, moon = 300;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					plants[i][j] = 0, flagShovel[i][j] = 0;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
						zombies[i][j][k] = 0;
			for (int i = 0; i < 5; i++)
				dps[i] = 0, zombieCostPerRow[i] = 0;
			for (int i = 0; i < 7; i++)
				cdPlant[i] = 0, flagPlant[i] = 1;
			for (int i = 0; i < 6; i++)
				cdZombie[i] = 0, flagZombie[i] = 1;
		}											   // initialize
		Game tranState(Actionlist q, IPlayer *player); //推算一系列操作q后状态
	};												   // global status
	Game Game::tranState(Actionlist q, IPlayer *player)
	{
		Game newGame;
		{
			newGame.time = this->time, newGame.sun = this->sun, newGame.moon = this->moon;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					newGame.plants[i][j] = this->plants[i][j], flagShovel[i][j] = this->flagShovel[i][j];
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
						newGame.zombies[i][j][k] = this->zombies[i][j][k];
			for (int i = 0; i < 7; i++)
				newGame.cdPlant[i] = this->cdPlant[i], newGame.flagPlant[i] = this->flagPlant[i];
			for (int i = 0; i < 6; i++)
				newGame.cdZombie[i] = this->cdZombie[i], newGame.flagZombie[i] = this->flagZombie[i];
			for (int i = 0; i < 5; i++)
				newGame.dps[i] = this->dps[i], newGame.zombieCostPerRow[i] = this->zombieCostPerRow[i];
		}
		// newGame=Game
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
			{
				if (q.plantPlace[i][j] > 0)
				{
					int num = q.plantPlace[i][j];
					newGame.sun -= plantCost[num];
					newGame.cdPlant[num] = plantCd[num];
					newGame.flagPlant[num] = 0;
					newGame.dps[i] += plantDps[num];
					newGame.plants[i][j] = num;
				}
				if (q.zombiePlace[i] > 0)
				{
					int num = q.zombiePlace[i];
					newGame.moon -= zombieCost[num];
					newGame.cdZombie[num] = zombieCd[num];
					newGame.flagZombie[num] = 0;
				}
			}
		newGame.maintain(player);
		//对操作进行运算
		return newGame;
	}
	// void

	class Zombies_num
	{
	public:
		int normal;
		int bucket;
		int polevault;
		int sled;
		int gargantuar;
		int total_num;

		Zombies_num()
		{
			this->normal = this->bucket = this->polevault = this->sled = this->gargantuar = this->total_num = 0;
		}
		void compute_num(int ***zombies, int rows, int columns)
		{
			int num = 0;
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					int k = 0;
					while (zombies[i][j][k] != -1)
					{
						switch (zombies[i][j][k])
						{
						case NORMAL:
							this->normal++;
							break;
						case BUCKET:
							this->bucket++;
							break;
						case POLEVAULT:
							this->polevault++;
							break;
						case SLED:
							this->sled++;
							break;
						case GARGANTUAR:
							this->gargantuar++;
							break;
						}
						num++;
						k++;
					}
				}
			}
		}
	};
	class Plants_num
	{
	public:
		int sunflower;
		int winterpeashooter;
		int peashooter;
		int smallnut;
		int pepper;
		int squash;

		Plants_num()
		{
			this->sunflower = this->winterpeashooter = this->peashooter = this->smallnut = this->pepper = this->squash = 0;
		}
		void compute_num(int **plants, int rows, int columns)
		{
			for (int i = 0; i < rows; i++)
				for (int j = 0; j < columns; j++)
				{
					switch (plants[i][j])
					{
					case SUNFLOWER:
						this->sunflower++;
						break;
					case WINTERPEASHOOTER:
						this->winterpeashooter++;
						break;
					case PEASHOOTER:
						this->peashooter++;
						break;
					case SMALLNUT:
						this->smallnut++;
						break;
					case PEPPER:
						this->pepper++;
						break;
					case SQUASH:
						this->squash++;
						break;
					}
				}
		}
	};

	int calculate_zombie_nums(int ***zombies, int rows, int columns)
	{
		int num = 0;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++)
			{
				int k = 0;
				while (zombies[i][j][k] != -1)
				{
					num++;
					k++;
				}
			}
		}
		return num;
	}
	int choose_Lines_not_Broken(int *Left_lines, int **plants, int column)
	{
		for (int i = 0;; i++)
		{
			if (Left_lines[i] == 1 && plants[i][column] == NOPLANT)
				return i;
		}
		return rand() % ROW;
	}
	typedef struct pos_and_value
	{
		int pos[2];
		double value;
	} pos_and_value;

	class value_plant_func
	{
	public:
		double noplant;
		pos_and_value sunflower;
		pos_and_value peashooter;
		pos_and_value winterpeashooter;
		pos_and_value smallnut;
		pos_and_value pepper;
		pos_and_value squash;
		int generating_row;
		IPlayer *player;
		Game game;
		// double value[PLANT_KIND + 1];
		// int choice[PLANT_KIND + 1] = {this->noplant, this->sunflower, this->peashooter, this->winterpeashooter, this->smallnut, this->pepper, this->squash};

		int NotBrokenLinesNum;
		int KillZombiesScore;
		int LeftPlants;
		int Score;
		int time;
		int *PlaceCD;
		int **Plants;
		int ***Zombies;
		int *LeftLines;
		int Sun;
		int zombie_nums;

		value_plant_func(int NotBrokenLinesNum,
						 int KillZombiesScore,
						 int Score,
						 int time,
						 int *PlaceCD,
						 int **Plants,
						 int ***Zombies,
						 int *LeftLines,
						 int Sun, IPlayer *player,
						 Game game)
		{
			this->NotBrokenLinesNum = NotBrokenLinesNum;
			this->KillZombiesScore = KillZombiesScore;
			this->Score = Score;
			this->time = time;
			this->PlaceCD = PlaceCD;
			this->Plants = Plants;
			this->Zombies = Zombies;
			this->LeftLines = LeftLines;
			this->Sun = Sun;
			this->player = player;
			this->generating_row = 3;
			this->game = game;
		}
		int **sum_plants_per_row()
		{ // [rows,plants_kind] = num_per_row
			int **plants_num_format = (int **)malloc(ROW * sizeof(int *));
			for (int i = 0; i < ROW; i++)
			{
				plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND);
				memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int));
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					switch (this->Plants[i][j])
					{
					case SUNFLOWER:
						plants_num_format[i][SUNFLOWER]++;
						break;
					case WINTERPEASHOOTER:
						plants_num_format[i][WINTERPEASHOOTER]++;
						break;
					case PEASHOOTER:
						plants_num_format[i][PEASHOOTER]++;
						break;
					case SMALLNUT:
						plants_num_format[i][SMALLNUT]++;
						break;
					case PEPPER:
						plants_num_format[i][PEPPER]++;
						break;
					case SQUASH:
						plants_num_format[i][SQUASH]++;
						break;
					}
				}
			}
			return plants_num_format;
		}
		void beginning_operation()
		{
			if (this->time == 3)
			{
				this->player->PlacePlant(SUNFLOWER, this->generating_row, 1);
				// this->player->PlacePlant(SMALLNUT, this->generating_row, COLUMN - 1);
			}
		}
		void GameState_2_400()
		{
			if (this->time > 2 && this->time < 150)
			{
				int alarming_flag = -1;
				for (int i = 0; i < ROW; i++)
				{
					if (i != this->generating_row)
					{
						if (time < 25)
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (this->Zombies[i][j][k] != -1)
								{
									if (j < 3)
										alarming_flag = i;
									if (this->Sun >= 70)
										switch (this->Zombies[i][j][k])
										{
										case POLEVAULT:
										case SLED:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										case BUCKET:
											if (this->PlaceCD[SQUASH] == 0)
												this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											else if (j <= 5)
												this->player->PlacePlant(PEPPER, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										case GARGANTUAR:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											if (j < 4)
												this->player->PlacePlant(PEPPER, i, 8);
											break;
										case NORMAL:
											this->player->PlacePlant(PEASHOOTER, i, 0);
											this->player->PlacePlant(SMALLNUT, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										}
									k++;
								}
							}
					}
					else
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (this->Zombies[this->generating_row][j][k] != -1)
							{
								if (this->Sun >= 70)
									switch (this->Zombies[this->generating_row][j][k])
									{
									case POLEVAULT:
									case BUCKET:
									case SLED:
										this->player->PlacePlant(SQUASH, this->generating_row, 5);
										break;
									case GARGANTUAR:
										this->player->PlacePlant(SQUASH, this->generating_row, (j - 1 < 0 ? 0 : j - 1));
										if (j < 4)
											this->player->PlacePlant(PEPPER, this->generating_row, 8);
										break;
									case NORMAL:
										this->player->PlacePlant(SMALLNUT, this->generating_row, (j - 1 < 0 ? 1 : j - 1));
										break;
									}
								if (j < (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 + 1 && this->PlaceCD[SQUASH - 1] != 0)
								{
									this->player->PlacePlant(PEPPER, i, 8);
								}
								k++;
							}
						}
				}
				int num = 0, pos = 0;
				for (int i = 0; i < COLUMN; i++)
				{
					if (Plants[this->generating_row][i] == SUNFLOWER)
					{
						num++;
					}
					if (Plants[this->generating_row][i] != NOPLANT)
					{
						pos = i;
					}
				}
				if (num < 5)
					this->player->PlacePlant(SUNFLOWER, this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1);
				if (alarming_flag != -1)
				{
					if (this->PlaceCD[SQUASH - 1] == 0)
					{
						this->player->PlacePlant(SQUASH, alarming_flag, COLUMN - 1);
					}
					else
						this->player->PlacePlant(PEPPER, alarming_flag, COLUMN - 1);
				}
			}
		}

		void GameState_50_200()
		{
			if (this->time > 50 && this->time < 200)
			{
				if (this->Sun >= 400)
					this->player->PlacePlant(WINTERPEASHOOTER, this->generating_row, 0);
			}
		}
		void value_peashooter_origin()
		{
			if (this->time > 10)
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					double **loss = (double **)malloc(ROW * sizeof(double *));
					for (int i = 0; i < ROW; i++)
					{
						loss[i] = (double *)malloc(COLUMN * sizeof(double));
						memset(loss[i], 0, COLUMN * sizeof(double));
					}
					double max = -10000, max_index[2] = {0, 0};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							if (this->Plants[i][j] != NOPLANT)
								loss[i][j] = -10000;
							else
							{
								//对行的参数
								double row = (i == this->generating_row ? -10 : 0);
								loss[i][j] += row;

								//对列的参数
								// double column = (25);
								// loss[i][j] += column * exp(-column) - 10;

								//对僵尸参数
								double zombie[ZOMBIE_KIND] = {6, -10, -2, -40, -20};
								for (int column0 = 0; j < COLUMN; j++)
								{
									int k = 0;
									while (Zombies[i][column0][k] != -1)
									{
										loss[i][j] += zombie[Zombies[i][column0][k] - 1] / (+COLUMN - j);
										k++;
									}
								}

								//对植物参数
								double plant[PLANT_KIND] = {2, 0, -2, 5, 2, 0};
								for (int column0 = 0; j < COLUMN; j++)
								{
									if (this->Plants[i][column0] != NOPLANT)
										loss[i][j] += plant[this->Plants[i][column0]] * (1 + (column0 - COLUMN / 2) / 40);
								}

								//对时间的参数
								double time_rate = 30;
								loss[i][j] += time_rate * (1 / (1 + exp((+this->time - TOTAL_TIME / 5) / 600)) - 0.5);
							}
							if (max < loss[i][j])
							{
								max_index[0] = i;
								max_index[1] = j;
							}
						}
					this->peashooter.pos[0] = max_index[0];
					this->peashooter.pos[1] = max_index[1];
					this->peashooter.value = max;
				}
		}
		bool have_type_of_zombies(int *zombie, int type)
		{
			int k = 0;
			while (zombie[k] != -1)
			{
				if (zombie[k] == type)
					return true;
				k++;
			}
			return false;
		}
		int search_for_nearest_zombie(int ***zombie, int row, int column)
		{
			int nearest = 100;
			for (int j = 0; j < COLUMN; j++)
			{
				int k = 0;
				while (Zombies[row][j][k] != -1)
				{
					if (nearest > j - column)
						nearest = j - column;
					k++;
				}
			}
			return nearest;
		}
		void judge_Lines_not_broken(double *final_choice)
		{
			for (int i = 0; i < ROW; i++)
			{
				if (this->LeftLines[i] == 0)
				{
					final_choice[i] = -100000;
				}
			}
		}
		void value_peashooter0()
		{
			if (this->time > 30)
			{
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					for (int i = 0; i < ROW; i++)
					{
						if (LeftLines[i] == 1)
						{
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (Zombies[i][j][k] != -1)
								{
									k++;
								}
								if (k == 1 && Zombies[i][j][0] == NORMAL && j >= COLUMN - 2)
								{
									this->player->PlacePlant(PEASHOOTER, i, 0);
								}
								else if (k > 0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) && Sun < 400 && time < 500 && j < 5)
								{
									int start = 0;
									while (Plants[i][start] != NOPLANT)
									{
										start++;
									}
									if (search_for_nearest_zombie(Zombies, i, start) >= 1)
									{
										player->PlacePlant(PEASHOOTER, i, start);
									}
								}
							}
						}
					}
				}
			}
		}
		void value_peashooter()
		{
			double score[5] = {0, 0, 0, 0, 0};
			double plant_cost[7] = {0, 10, -6, -8, 15, 10, 0};
			judge_Lines_not_broken(score);

			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					double distance_cost = 1;
					switch (Plants[i][j])
					{
					case SUNFLOWER:
						distance_cost *= 1 + j / 100;
					}
					score[i] += plant_cost[Plants[i][j]] * distance_cost;
				}
			}

			double zombie_cost[5] = {10, 5, -5, -20, -20};
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					int k = 0;
					while (Zombies[i][j][k] != -1)
					{
						double distance_cost = 1;
						switch (Zombies[i][j][k])
						{
						case NORMAL:
							distance_cost = 1 - j / 30;
						}
						score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost;
						k++;
					}
				}
			}
			int *serial_num = rank(score, ROW);
			int i = 0;
			for (; i < 10; i++)
			{
				if (Plants[serial_num[0]][i] == NOPLANT)
					break;
			}
			if (i <= 3)
			{
				if (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) ||
					  have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR)))
					player->PlacePlant(PEASHOOTER, serial_num[0], i);
			}
			free(serial_num);
		}
		int *rank(double *array, int len)
		{
			double max = array[0];
			int *serial_num = (int *)malloc(len * sizeof(int));
			for (int i = 0; i < len; i++)
			{
				serial_num[i] = i;
			}
			for (int i = 0; i < len - 1; i++)
			{
				for (int j = 0; j < len - 1; j++)
				{
					if (array[j] < array[j + 1])
					{
						double swap = array[j];
						array[j] = array[j + 1];
						array[j + 1] = swap;
						int serial_swap = serial_num[j];
						serial_num[j] = serial_num[j + 1];
						serial_num[j + 1] = serial_swap;
					}
				}
			}
			return serial_num;
		}
		// void value_sunflower()
		// {
		// 	int sunflower_num = 0;
		// 	for (int i = 0; i < ROW; i++)
		// 		for (int j = 0; j < COLUMN; j++)
		// 		{
		// 			if (Plants[i][j] == SUNFLOWER)
		// 			{
		// 				sunflower_num++;
		// 			}
		// 		}
		// 	double b = -0.01 * (this->time - 300) * (this->time - 300) / 10000 + 1;
		// 	if (this->time > 9 && sunflower_num < 9 + (b < 0 ? 0 : b) && this->Sun < 1000)
		// 		if (this->PlaceCD[SUNFLOWER - 1] == 0)
		// 		{
		// 			double score[5] = {0, 0, 0, 0, 0};
		// 			judge_Lines_not_broken(score);
		// 			for (int i = 0; i < ROW; i++)
		// 			{
		// 				for (int j = 0; j < COLUMN; j++)
		// 				{
		// 					if (Plants[i][j] == SUNFLOWER)
		// 						score[i] -= 120;
		// 					if (Plants[i][j] == PEASHOOTER)
		// 						score[i] += 50 * (1 * (exp(-j / 5)));
		// 					if (Plants[i][j] == WINTERPEASHOOTER)
		// 						score[i] += 100 * (1 * (exp(-j / 5)));
		// 					if (Plants[i][j] == SMALLNUT)
		// 						score[i] += 100 * (-0.01 * (j - 5) * (j - 5) + 1);
		// 				}
		// 			}
		// 			for (int i = 0; i < ROW; i++)
		// 				for (int j = 0; j < COLUMN; j++)
		// 				{
		// 					int k = 0;
		// 					while (Zombies[i][j][k] != -1)
		// 					{
		// 						if (Zombies[i][j][k] == NORMAL)
		// 							score[i] -= 10 * (1 / (0.1 + j));
		// 						if (Zombies[i][j][k] == BUCKET)
		// 							score[i] -= 50 * (1 / (0.1 + j));
		// 						if (Zombies[i][j][k] == POLEVAULT)
		// 							score[i] -= 30 * (1 / (0.1 + j));
		// 						if (Zombies[i][j][k] == GARGANTUAR)
		// 							score[i] -= 100 * (1 / (0.1 + j));
		// 						if (Zombies[i][j][k] == SLED)
		// 							score[i] -= 80 * (1 / (0.1 + j));
		// 						k++;
		// 					}
		// 				}

		// 			// int sunflower_num_in_generating_row = 0;
		// 			// for (int j = 0; j < COLUMN; j++)
		// 			// {
		// 			//     if (Plants[this->generating_row][j] == SUNFLOWER)
		// 			//         sunflower_num_in_generating_row++;
		// 			// }
		// 			// score[this->generating_row] += 100 * (1 / (sunflower_num_in_generating_row + 2));

		// 			int *serial_num = rank(score, ROW);
		// 			int j = 0;
		// 			while (Plants[serial_num[0]][j + 2] != NOPLANT && j < 8)
		// 			{
		// 				j++;
		// 			}
		// 			if (j < 8)
		// 				if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) ||
		// 					  have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR)))
		// 					player->PlacePlant(SUNFLOWER, serial_num[0], j + 2);
		// 			free(serial_num);
		// 		}
		// }
		void value_sunflower()
		{
			int sunflower_num = 0;
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == SUNFLOWER)
					{
						sunflower_num++;
					}
				}
			double b = -((this->time - 1000) / 2000) * 5 + 1;
			if (this->time > 9 && sunflower_num < 13 + (b < 0 ? 0 : b) && this->Sun < 5500)
				if (this->PlaceCD[SUNFLOWER - 1] == 0)
				{
					double score[5] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[i][j] == SUNFLOWER)
								score[i] -= 120;
							if (Plants[i][j] == PEASHOOTER)
								score[i] += 50 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == WINTERPEASHOOTER)
								score[i] += 100 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == SMALLNUT)
								score[i] += 100 * (-0.01 * (j - 5) * (j - 5) + 1);
						}
					}
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								if (Zombies[i][j][k] == NORMAL)
									score[i] -= 10 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == BUCKET)
									score[i] -= 50 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == POLEVAULT)
									score[i] -= 30 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == GARGANTUAR)
									score[i] -= 100 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == SLED)
									score[i] -= 80 * (1 / (0.1 + j));
								k++;
							}
						}

					// int sunflower_num_in_generating_row = 0;
					// for (int j = 0; j < COLUMN; j++)
					// {
					//     if (Plants[this->generating_row][j] == SUNFLOWER)
					//         sunflower_num_in_generating_row++;
					// }
					// score[this->generating_row] += 100 * (1 / (sunflower_num_in_generating_row + 2));

					int *serial_num = rank(score, ROW);
					int j = 0;
					while ((Plants[serial_num[0]][j + 2] != NOPLANT) && j < 7)
					{
						j++;
						if ((time > 900 && Plants[serial_num[0]][j + 2] == SMALLNUT))
							break;
					}
					if (j < 7)
						if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) ||
							  have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR)))
						{
							player->removePlant(serial_num[0], j + 2);
							player->PlacePlant(SUNFLOWER, serial_num[0], j + 2);
						}
					free(serial_num);
				}
		}
		void value_smallmnut()
		{
			if (this->PlaceCD[SMALLNUT - 1] == 0)
				if (this->time > 20)
				{
					double score[ROW] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);

					// value plants
					double plants_score[7] = {0, 5, 20, 20, -300, -2, 0};
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							double distance_cost = 1;
							switch (Plants[i][j])
							{
							case SUNFLOWER:
								distance_cost = 1.5 - 0.05 * j;
								break;
							case PEASHOOTER:
								distance_cost = 2 - 0.09 * j;
								break;
							case WINTERPEASHOOTER:
								distance_cost = 2 - 0.1 * j;
								break;
							}
							score[i] += plants_score[Plants[i][j]] * distance_cost;
						}
					}

					// value zombies;
					double zombie_cost[5] = {2.0, 10, 12, -1000, -2000};
					int nearest_zombie_per_row[5] = {10, 10, 10, 10, 10};
					for (int i = 0; i < ROW; i++)
					{
						for (int j = COLUMN - 1; j >= 0; j--)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								double distance_cost = 1;
								switch (Zombies[i][j][k])
								{
								case NORMAL:
									distance_cost = 1.2 - 0.02 * (j);
									break;
								case POLEVAULT:
									distance_cost = 1.1 - 0.01 * j;
									break;
								case BUCKET:
									distance_cost = 1.3 - 0.04 * j;
									break;
								}
								score[i] += zombie_cost[(Zombies[i][j][k] - 1)] * distance_cost;
								k++;
								nearest_zombie_per_row[i] = j;
							}
						}
					}
					// for(int i=0;i< ROW; i++){
					//     score[i] += this->time/2;
					// }
					int *serial_num = rank(score, ROW);
					// for (int i = 0; i < ROW; i++)
					// {
					//     int j = 0;

					// if (Plants[serial_num[i]][nearest_zombie_per_row[serial_num[i]] - 1])
					int j = COLUMN - 1;
					if (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT)
					{
						for (; j >= 4; j--)
						{
							if (Plants[serial_num[0]][j] == NOPLANT)
								break;
						}
						if (j != -1)
							player->PlacePlant(SMALLNUT, serial_num[0], min(j, 7));
					}
					else
					{
						int target_y = (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 0 : (nearest_zombie_per_row[serial_num[0]] - 1);
						target_y = min(target_y, 7);
						player->PlacePlant(SMALLNUT, serial_num[0], target_y);
					}
					free(serial_num);
				}
		}
		// void value_winterpeashooter()
		// {
		// 	if (this->PlaceCD[WINTERPEASHOOTER - 1] == 0)
		// 	{
		// 		if (this->time > 70)
		// 		{
		// 			double score[5] = {0.0, 0, 0, 0, 0};
		// 			judge_Lines_not_broken(score);

		// 			// value plant;
		// 			double plant_cost[7] = {0.0, -2.5, -4, -5, -10, 6, 0};
		// 			if (time > 450)
		// 			{
		// 				plant_cost[4] = 2;
		// 			}
		// 			for (int i = 0; i < ROW; i++)
		// 			{
		// 				for (int j = 0; j < COLUMN; j++)
		// 				{
		// 					score[i] += plant_cost[Plants[i][j]];
		// 				}
		// 			}

		// 			double zombie_cost[5] = {5, 20, 10, 2, -4};
		// 			for (int i = 0; i < ROW; i++)
		// 				for (int j = 0; j < COLUMN; j++)
		// 				{
		// 					int k = 0;
		// 					while (Zombies[i][j][k] != -1)
		// 					{
		// 						score[i] += zombie_cost[Zombies[i][j][k] - 1];
		// 						k++;
		// 					}
		// 				}
		// 			int *serial_num = rank(score, ROW);
		// 			if (this->time < 300)
		// 			{
		// 				int j = 0;

		// 				while (Plants[serial_num[0]][j] != NOPLANT && j < 8)
		// 				{
		// 					j++;
		// 				}

		// 				if (j < 5)
		// 				{
		// 					if (search_for_nearest_zombie(Zombies, serial_num[0], j) >= 1)
		// 					{
		// 						player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j);
		// 					}
		// 				}
		// 			}
		// 			else
		// 			{
		// 				int limit = (int)(this->time / 400) + 3;
		// 				for (int i = 0; i < limit; i++)
		// 				{
		// 					if ((Plants[serial_num[0]][i] == PEASHOOTER && this->time > 600) || (Plants[serial_num[0]][i] == SUNFLOWER))
		// 					{
		// 						if (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun > 400)
		// 						{
		// 							player->removePlant(serial_num[0], i);
		// 							player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
		// 							break;
		// 						}
		// 					}
		// 				}
		// 			}
		// 			free(serial_num);
		// 		}
		// 	}
		// }
		void value_winterpeashooter()
		{
			if (this->PlaceCD[WINTERPEASHOOTER - 1] == 0)
			{
				if (this->time > 40)
				{
					double score[5] = {0.0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);

					// value plant;
					double plant_cost[7] = {1, 2.5, -8, -4, -10, 6, 0};
					if (time > 400)
					{
						plant_cost[SMALLNUT] = 2;
					}
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							score[i] += plant_cost[Plants[i][j]];
						}
					}

					double zombie_cost[5] = {5, 20, 10, 2, 0};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								score[i] += zombie_cost[Zombies[i][j][k] - 1];
								k++;
							}
						}
					int *serial_num = rank(score, ROW);
					if (this->time < 200)
					{
						int j = 0;

						while (Plants[serial_num[0]][j] != NOPLANT && j < 8)
						{
							j++;
						}

						if (j < 6)
						{
							if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) ||
								  have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR)))
								if (search_for_nearest_zombie(Zombies, serial_num[0], j) >= 1)
								{
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j);
								}
						}
					}
					else
					{
						int limit = ((this->time) / 500) + 3;
						for (int i = 0; i < limit; i++)
						{
							if ((Plants[serial_num[0]][i] == PEASHOOTER && this->time > 450) || (Plants[serial_num[0]][i] == SMALLNUT && this->time > 1000) || (Plants[serial_num[0]][i] == SUNFLOWER))
							{
								if (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun > 400)
								{
									player->removePlant(serial_num[0], i);
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
									break;
								}
							}
							else if (this->Sun > 400 && Plants[serial_num[0]][i] == NOPLANT)
							{
								if (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) ||
									  have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR)))
								{
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
									break;
								}
							}
						}
						// printf("%d:hh ",time);
					}
					free(serial_num);
				}
			}
		}
		// void value_squash()
		// {
		// 	if (this->PlaceCD[SQUASH - 1] == 0 && this->time > 50)
		// 	{
		// 		double score[5] = {0, 0, 0, 0, 0};

		// 		double plant_cost[7] = {0, 5, 20, 3, -10, -100, -200};

		// 		for (int i = 0; i < 5; i++)
		// 		{
		// 			for (int j = 0; j < COLUMN; j++)
		// 			{
		// 				double distance_cost = 0.2 + 0.08 * j;
		// 				score[i] += plant_cost[Plants[i][j]] * distance_cost;
		// 			}
		// 		}

		// 		double zombie_cost[5] = {-5, 10, 2, 100, 200};
		// 		for (int i = 0; i < ROW; i++)
		// 			for (int j = 0; j < COLUMN; j++)
		// 			{
		// 				int k = 0;
		// 				while (Zombies[i][j][k] != -1)
		// 				{
		// 					double distance_cost = 11 / (j + 1);
		// 					score[i] += zombie_cost[Zombies[i][j][k] - 1] * distance_cost;
		// 					k++;
		// 				}
		// 			}
		// 		int *serial_num = rank(score, ROW);

		// 		int nearest_zombie = 10;
		// 		for (int j = COLUMN - 1; j >= 0; j--)
		// 		{
		// 			int k = 0;
		// 			while (Zombies[serial_num[0]][j][k] != -1)
		// 			{
		// 				nearest_zombie = j;
		// 				k++;
		// 			}
		// 		}

		// 		if (nearest_zombie - 1 >= 0 && nearest_zombie != 9)
		// 		{
		// 			if (Plants[serial_num[0]][nearest_zombie - 1] == NOPLANT)
		// 			{
		// 				player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
		// 			}
		// 			else if (Plants[serial_num[0]][nearest_zombie - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 1] != SMALLNUT && Plants[serial_num[0]][nearest_zombie - 1] != NOPLANT && time > 400 && this->Sun > 50)
		// 			{
		// 				player->removePlant(serial_num[0], nearest_zombie - 1);
		// 				player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
		// 			}
		// 		}
		// 		else
		// 		{
		// 			for (int j = COLUMN - 1; j >= 0; j--)
		// 			{
		// 				if (Plants[serial_num[0]][j] != NOPLANT && j >= 6)
		// 				{
		// 					player->PlacePlant(SQUASH, serial_num[0], j);
		// 				}
		// 			}
		// 		}
		// 		free(serial_num);
		// 	}
		// }
		void value_squash()
		{
			if (this->PlaceCD[SQUASH - 1] == 0)
			{
				double score[5] = {0, 0, 0, 0, 0};

				double plant_cost[7] = {0, 5, 20, 3, -10, -100, -200};

				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						double distance_cost = 0.2 + 0.08 * j;
						score[i] += plant_cost[Plants[i][j]] * distance_cost;
					}
				}

				double zombie_cost[5] = {-5, 10, 2, 100, 200};
				for (int i = 0; i < ROW; i++)
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 11 / (j + 1);
							score[i] += zombie_cost[Zombies[i][j][k] - 1] * distance_cost;
							k++;
						}
					}
				int *serial_num = rank(score, ROW);

				int nearest_zombie = 8;
				for (int j = COLUMN - 1; j >= 0; j--)
				{
					int k = 0;
					while (Zombies[serial_num[0]][j][k] != -1)
					{
						nearest_zombie = j;
						k++;
					}
				}
				if (nearest_zombie - 1 >= 0)
				{
					if (Plants[serial_num[0]][nearest_zombie - 1] == NOPLANT)
					{
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
					else if (Plants[serial_num[0]][nearest_zombie - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 1] != SQUASH && Plants[serial_num[0]][nearest_zombie - 1] != SMALLNUT && Plants[serial_num[0]][nearest_zombie - 1] != NOPLANT && time > 400 && this->Sun > 50)
					{
						player->removePlant(serial_num[0], nearest_zombie - 1);
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
					else if (Plants[serial_num[0]][nearest_zombie] == SMALLNUT && time > 1000)
					{
						player->removePlant(serial_num[0], nearest_zombie);
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie);
					}
					else if (Plants[serial_num[0]][nearest_zombie] == NOPLANT)
					{
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie);
					}
				}
				else
				{
					for (int j = COLUMN - 1; j >= 0; j--)
					{
						if (Plants[serial_num[0]][j] != NOPLANT && j >= 6)
						{
							player->PlacePlant(SQUASH, serial_num[0], j);
						}
					}
				}
				int flag = 0;

				for (int i = 0; i < ROW; i++)
					if (Sun > 4000 && game_state->getPlantList(-1, -1, SUNFLOWER).size() >= 20000 / Sun && time > 650 && (Plants[serial_num[i]][nearest_zombie] == SUNFLOWER || Plants[serial_num[i]][nearest_zombie] == SMALLNUT))
					{
						player->removePlant(serial_num[i], nearest_zombie);
						player->PlacePlant(SQUASH, serial_num[i], nearest_zombie);
						flag = 1;
						break;
					}
				if (flag == 0)
				{
					for (int i = 0; i < ROW; i++)
						if (Sun > 4000 && game_state->getPlantList(-1, -1, SUNFLOWER).size() >= 20000 / Sun && time > 1050 && (Plants[serial_num[i]][nearest_zombie - 2] == SUNFLOWER || Plants[serial_num[i]][nearest_zombie - 2] == SMALLNUT))
						{
							player->removePlant(serial_num[i], nearest_zombie - 2);
							player->PlacePlant(SQUASH, serial_num[i], nearest_zombie - 2);
							break;
						}
				}

				free(serial_num);
			}
		}
		void value_pepper()
		{
			if (this->PlaceCD[PEPPER - 1] == 0 && this->PlaceCD[SQUASH - 1] != 0)
			{
				double score[ROW] = {0, 0, 0, 0, 0};
				int warning_flag[5] = {0, 0, 0, 0, 0};
				int have_zombies[5] = {0, 0, 0, 0, 0};
				double zombie_cost[5] = {1, 3, 2, 20, 80};
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 10 / (1 + j);
							score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 1];
							have_zombies[i] = 1;
							if (j <= 3)
								warning_flag[i] = 1;
							k++;
						}
					}
				}

				double plant_cost[7] = {0, 0, -20, -3, -1, -80, -80};

				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						score[i] += plant_cost[Plants[i][j]];
					}
				}

				double time_cost = 10 * (1 / (1 + exp((time - 1000) / 500)));

				int *serial_num = rank(score, ROW);
				int deal_with_warning_flag = 0;

				for (int i = 0; i < ROW; i++)
				{
					if (warning_flag[serial_num[i]] == 1)
					{ //加入detect wrong
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[i]][j] == NOPLANT)
							{
								player->PlacePlant(PEPPER, serial_num[i], j);
								flag = 1;
								deal_with_warning_flag = 1;
							}
							if (flag == 1)
								break;
						}
						break;
					}
				}
				if (deal_with_warning_flag == 0)
				{
					if (score[0] >= 0)
					{
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[0]][j] == NOPLANT && have_zombies[serial_num[0]] == 1)
							{
								player->PlacePlant(PEPPER, serial_num[0], j);
								flag = 1;
							}
							if (flag == 1)
								break;
						}
					}
				}

				// for (int i = 0; i < ROW; i++)
				// {
				//     printf("%lf ", score[i]);
				// }
				// printf("\n");
				free(serial_num);
			}
		}
		void value()
		{ //加入time_cost;!!!!!
			this->value_peashooter();
			this->value_sunflower();
			if (time < 650)
				this->value_smallmnut();
			this->value_winterpeashooter();
			this->value_squash();
			this->value_pepper();
			// double max = -100000;
			// double value[7] = {this->noplant, this->sunflower.value, this->winterpeashooter.value, this->peashooter.value, this->smallnut.value, this->squash.value, this->pepper.value};
			// this->player->PlacePlant(PEASHOOTER, this->peashooter.pos[0], this->peashooter.pos[1]);
		}
		void make_decision()
		{
			this->beginning_operation();
			this->GameState_2_400();
			// this->GameState_50_200();
			if (this->time > 20)
				this->value();
		}
		void eliminate_plants(GameState *game_state)
		{
			// for (int i = 0; i < ROW; i++)
			// {
			//     for (int j = 1; j < COLUMN; j++)
			//     {
			//         int k = 0;
			//         while (Zombies[i][j][k] != -1)
			//         {
			//             if ((Zombies[i][j][k] == SLED || Zombies[i][j][k] == GARGANTUAR) &&
			//                 (Plants[i][j - 1] != NOPLANT && Plants[i][j - 1] != PEPPER && Plants[i][j - 1] != SQUASH))
			//                 this->player->removePlant(i, j - 1);
			//             k++;
			//         }
			//     }
			// }
			// int farthest_plants[5] = {0};
			// for (int i = 0; i < ROW; i++)
			// {
			//     for (int j = 0; j < COLUMN; j++)
			//     {
			//         if ()
			//         {
			//             farthest_plants[i] = j;
			//         }
			//     }
			// }
			GameState new_game_state = *game_state;
			new_game_state.infer();
			// new_game_state.infer();

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] != NOPLANT && Plants[i][j] != SQUASH && Plants[i][j] != PEPPER)
					{
						if (new_game_state.getZombieList(i, j, GARGANTUAR).size() > 0 || new_game_state.getZombieList(i, j, SLED).size() > 0)
							this->player->removePlant(i, j);
						// printf("remove %d\n", Plants[i][j]);
					}
				}
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();

			GameState step5_game_state = new_game_state;
			int whether_be_broken[5] = {0, 0, 0, 0, 0};
			if (time < 200)
				for (int step = 0; step <= 60; step++)
				{
					step5_game_state.infer();
					for (int i = 0; i < ROW; i++)
						if (step5_game_state.getBrokenLines()[i] == true && whether_be_broken[i] == 0)
						{
							whether_be_broken[i] = step;
						}
				}

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if ((whether_be_broken[i] > 0 || time > 300) && new_game_state.getPlant(i, j).getType() != Plants[i][j] && Plants[i][j] != NOPLANT && Plants[i][j] != SQUASH && Plants[i][j] != PEPPER)
					{
						this->player->removePlant(i, j);
						// printf("remove %d step: %d\n", Plants[i][j], time);
					}
				}

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					::Plant P = game_state->getPlant(i, j);
					if (P.getType() == SMALLNUT && P.getHealth() < 200)
					{
						player->removePlant(i, j);
					}
				}
		}
	};
	class value_zombie_func //  应加入多次进攻未果 换线的操作
	{
	public:
		int nozombie;
		int normal_choice;
		int bucket_choice;
		int polevault_choice;
		int sled_choice;
		int gargantuar_choice;
		double value[ZOMBIE_KIND];
		int choice[ZOMBIE_KIND] = {this->normal_choice, this->bucket_choice, this->polevault_choice, this->sled_choice, this->gargantuar_choice}; // KIND->ROW

		int BrokenLinesScore;
		int KillPlantsScore;
		int LeftPlants;
		int Score;
		int time;
		int *PlaceCD;
		int **Plants;
		int ***Zombies;
		int *LeftLines;
		int Sun;
		int zombie_nums;
		int give_up_whole_attack;
		Game game;
		IPlayer *player;

		value_zombie_func(int BrokenLinesScore,
						  int KillPlantsScore,
						  int Score,
						  int time,
						  int *PlaceCD,
						  int **Plants,
						  int ***Zombies,
						  int *LeftLines,
						  int Sun,
						  int zombie_nums,
						  Game game,
						  IPlayer *player)
		{
			this->normal_choice = this->bucket_choice = this->polevault_choice = this->sled_choice = this->gargantuar_choice = 0;
			this->BrokenLinesScore = BrokenLinesScore;
			this->KillPlantsScore = KillPlantsScore;
			this->Score = Score;
			this->time = time;
			this->PlaceCD = PlaceCD;
			this->Plants = Plants;
			this->Zombies = Zombies;
			this->LeftLines = LeftLines;
			this->Sun = Sun;
			this->zombie_nums = zombie_nums;
			this->game = game;
			this->give_up_whole_attack = 0;
			this->player = player;
			for (int i = 0; i < ZOMBIE_KIND; i++)
				this->value[i] = 0;
			memset(this->choice, 0, ZOMBIE_KIND * (sizeof(int)));
		}
		// void input_data()
		// {
		//     for (int i = 0; i < ROW; i++)
		//     {
		//         fputc(this->choice[i], file);
		//         fprintf(file, " %.6f ", this->value[i]);
		//     }
		//     fprintf(file, "\n");
		// }
		int judge_whether_big_cost_in_one_row(int *cost)
		{
			double average = 0, square_distance = 0;
			for (int i = 0; i < ROW; i++)
			{
				average += cost[i];
			}
			average /= 5;
			for (int i = 0; i < ROW; i++)
			{
				square_distance += (cost[i] - average) * (cost[i] - average);
			}
			square_distance = pow(square_distance, 0.5);
			square_distance /= 5;

			if (square_distance > pow(this->time, 0.2) * 400)
			{
				return 1;
			}
			else
				return 0;
		}
		void make_decision(int *decision) //[ KIND , ROW ]
		{
			// int *cost = this->game.zombieCostPerRow;
			// if (judge_whether_big_cost_in_one_row(cost) == 0)
			// {
			double max = -10000;

			for (int i = 0; i < 5; i++)
			{
				if (max < this->value[i])
				{
					max = this->value[i];
					decision[0] = i + 1;
					decision[1] = this->choice[i];
				}
			}
			if (this->give_up_whole_attack == 1 && this->Sun < 900)
			{
				decision[0] = NOZOMBIE;
				decision[1] = 0;
			}
			else if (this->give_up_whole_attack == 1 && this->Sun >= 900 && this->time < 1350)
			{

				int attacking_lines1 = 0;
				int attacking_lines2 = 0;
				int leftlins_flag = 0;
				for (int i = 0; i < 5; i++)
				{
					if (LeftLines[i] == 1)
					{
						attacking_lines1 = i;

						break;
					}
				}
				for (int i = 0; i < 5; i++)
				{
					if (LeftLines[i] == 1 && i != attacking_lines1)
					{
						attacking_lines2 = i;
						break;
					}
					if (i == 4)
						leftlins_flag = 1;
				}
				if (leftlins_flag == 0)
				{
					decision[0] = GARGANTUAR;
					decision[1] = attacking_lines1;

					this->player->PlaceZombie(GARGANTUAR, attacking_lines1);
					this->player->PlaceZombie(BUCKET, attacking_lines1);
					this->player->PlaceZombie(NORMAL, attacking_lines2);
					this->player->PlaceZombie(POLEVAULT, attacking_lines2);
					this->player->PlaceZombie(SLED, attacking_lines2);
				}
				else
				{
					this->player->PlaceZombie(GARGANTUAR, attacking_lines1);
					this->player->PlaceZombie(BUCKET, attacking_lines1);
					this->player->PlaceZombie(NORMAL, attacking_lines1);
					this->player->PlaceZombie(POLEVAULT, attacking_lines1);
					this->player->PlaceZombie(SLED, attacking_lines1);
				}
			}
			// for (int i = 0; i <ROW;i++)
			// printf("%lf ",value[i]);
			// printf("\n");
			// }
			// else
			// {
			//     double min = value[0];

			//     for (int i = 0; i < 5; i++)
			//     {
			//         if (min > this->value[i])
			//         {
			//             min = this->value[i];
			//             decision[0] = i + 1;
			//             decision[1] = this->choice[i];
			//         }
			//     }
			//     if (this->zombie_nums > (this->time / 100 + 4))
			//     {
			//         decision[0] = decision[1] = NOZOMBIE;
			//     }
			// }
		}
		// void value_nozombie()
		// {
		//     int final_choice[ROW] = {0, 0, 0, 0, 0};
		//     /*
		//             this->NotBrokenLinesNum = NotBrokenLinesNum;
		//             this->KillZombiesScore = KillZombiesScore;
		//             this->LeftPlants = LeftPlants;
		//             this->Score = Score;
		//             this->time = time;
		//             this->PlaceCD = PlaceCD;
		//             this->Plants = Plants;
		//             this->Zombies = Zombies;
		//             this->LeftLines = LeftLines;
		//             this->Sun = Sun;
		//     */
		//     for (int i = 0; i < ROW; i++)
		//     {
		//         final_choice[i] += 0;
		//     }
		// }
		bool whether_need_compute(int kind)
		{ //需要为0 不需要为1
			if (this->PlaceCD[kind - 1] > 0 || this->time < 120)
			{
				this->choice[kind - 1] = 0;
				this->value[kind - 1] = -100000;
				return true;
			}
			else
				return false;
		}
		void whether_give_up_attack(double *score)
		{
			int num[5] = {0, 0, 0, 0, 0};

			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == WINTERPEASHOOTER)
						num[i]++;
				}
			}
			int give_up_lines = 0;
			for (int i = 0; i < ROW; i++)
			{
				if (num[i] >= 4)
				{
					score[i] = -100000;
					give_up_lines++;
				}
			}
			int sum_all_lines = 0;
			for (int i = 0; i < ROW; i++)
			{
				if (this->LeftLines[i] == 1)
				{
					sum_all_lines++;
				}
			}
			if (give_up_lines == sum_all_lines)
				this->give_up_whole_attack = 1;
		}
		double zombie_cost(int row, double *zombies_paras, double distance_cost, double distance_rate, int kind)
		{
			double cost = 0.0;
			if (this->LeftLines[row] == 0)
			{
				cost = -100000;
			}
			else
			{
				int num_per_row = 0;
				double too_many_zombies_cost = -1.5;
				for (int j = 0; j < COLUMN; j++)
				{
					int k = 0;
					while (this->Zombies[row][j][k] != -1)
					{
						switch (kind)
						{
						case POLEVAULT:
							cost += zombies_paras[this->Zombies[row][j][k] - 1] * ((COLUMN - j - distance_cost) * (COLUMN - j - distance_cost));
							break;
						default:
							cost += zombies_paras[this->Zombies[row][j][k] - 1] * (-distance_rate * (COLUMN - j - distance_cost) * (COLUMN - j - distance_cost) + 2);
						}
						k++;
						num_per_row++;
					}
				}
				cost += num_per_row * too_many_zombies_cost;
			}
			return cost;
		}
		int **sum_plants_per_row()
		{ // [rows,plants_kind] = num_per_row
			int **plants_num_format = (int **)malloc(ROW * sizeof(int *));
			for (int i = 0; i < ROW; i++)
			{
				plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND);
				memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int));
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					switch (this->Plants[i][j])
					{
					case SUNFLOWER:
						plants_num_format[i][SUNFLOWER - 1]++;
						break;
					case WINTERPEASHOOTER:
						plants_num_format[i][WINTERPEASHOOTER - 1]++;
						break;
					case PEASHOOTER:
						plants_num_format[i][PEASHOOTER - 1]++;
						break;
					case SMALLNUT:
						plants_num_format[i][SMALLNUT - 1]++;
						break;
					case PEPPER:
						plants_num_format[i][PEPPER - 1]++;
						break;
					case SQUASH:
						plants_num_format[i][SQUASH - 1]++;
						break;
					}
				}
			}
			return plants_num_format;
		}
		double plant_cost(int row, int **plants_num_format, double *plants_para, int kind)
		{
			double origin_para[PLANT_KIND];
			for (int i = 0; i < PLANT_KIND; i++)
			{
				origin_para[i] = plants_para[i];
			}
			double cost = 0.0;
			switch (kind)
			{
			case NORMAL:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
					plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER - 1] * 1 + plants_num_format[row][WINTERPEASHOOTER - 1] * 2);
				break;
			case BUCKET:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
					plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER - 1] * 0.2 + plants_num_format[row][WINTERPEASHOOTER - 1]);
				break;
			case POLEVAULT:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
				{
					plants_para[SMALLNUT - 1] *= ((1.5 - plants_num_format[row][SMALLNUT - 1]) * (3 - plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1]));
				}
				break;
			case SLED:
				// if (plants_num_format[row][SMALLNUT - 1] > 1 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
				// {
				//     plants_para[SMALLNUT - 1] *= (plants_num_format[row][SMALLNUT - 1] * plants_num_format[row][SMALLNUT - 1]) * (plants_num_format[row][WINTERPEASHOOTER - 1]);
				// }
				if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2)
				{
					plants_para[WINTERPEASHOOTER - 1] = 6 - 2 * plants_num_format[row][WINTERPEASHOOTER - 1];
				}
				break;
			case GARGANTUAR:
				if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2)
				{
					plants_para[WINTERPEASHOOTER - 1] = 8 - 2 * plants_num_format[row][WINTERPEASHOOTER - 1];
				}
				break;
			}
			plants_para[SUNFLOWER - 1] *= (1 + 1 / (COLUMN - plants_num_format[row][SUNFLOWER - 1] + 1));

			// for (int j = 0; j < PLANT_KIND; j++)
			//     printf(" %lf ", plants_para[j]);
			//     printf("\n");

			for (int j = 0; j < COLUMN; j++)
			{
				if (Plants[row][j] != NOPLANT)
					cost += plants_para[Plants[row][j] - 1] * (plants_para[Plants[row][j] - 1] > 0 ? (j + 1) * (j + 1) : (COLUMN - j));
			}
			for (int i = 0; i < PLANT_KIND; i++)
			{
				plants_para[i] = origin_para[i];
			}
			return cost;
		}
		int max_index(double *a, int length)
		{
			double max = -10000;
			int index = 0;
			for (int i = 0; i < length; i++)
			{
				if (max < a[i])
				{
					max = a[i];
					index = i;
				}
			}
			return index;
		}
		/*
				NORMAL,
				BUCKET,
				POLEVAULT,
				SLED,
				GARGANTUAR
		*/

		/*
			SUNFLOWER,
			WINTERPEASHOOTER,
			PEASHOOTER,
			SMALLNUT,
			PEPPER,
			SQUASH
		*/

		void value_normal()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			if (this->whether_need_compute(NORMAL))
			{
				return;
			}
			whether_give_up_attack(final_choice);
			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {-5, 4, 2, 3, 1};
			double distance_cost = 1, distance_rate = 0.05;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, NORMAL);
			}

			//遍历plant

			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {8, -8, -2, -2, -100, 20};
			int **sum_plants_per_row0 = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row0, plants_para, NORMAL);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row0[i]);
			}
			free(sum_plants_per_row0);
			//考虑time
			double time_cost = 20 * (1 / (1 + exp((this->time - TOTAL_TIME / 2) / 500)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 60, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 400)) * 15 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[NORMAL - 1] = this->max_index(final_choice, ROW);
			this->value[NORMAL - 1] = final_choice[this->choice[NORMAL - 1]];
		}

		void value_bucket()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(BUCKET))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {2.5, -4, this->time < 100 ? -100 : -5, 2, -2};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, BUCKET);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {6, -2, 6, -1, -100, -4};
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, BUCKET);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);

			//考虑time
			double time_cost = 20 * (1 / (1 + exp((-this->time + TOTAL_TIME / 3) / 400)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 150, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 400)) * 5 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[BUCKET - 1] = this->max_index(final_choice, ROW);
			this->value[BUCKET - 1] = final_choice[this->choice[BUCKET - 1]];
		}

		void value_polevault()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(POLEVAULT))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {1, this->time < 100 ? -100 : -5, -1.5, 2, -3};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, POLEVAULT);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {4, -50, -8, 7, -100, -10}; //偏好建国
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, POLEVAULT);
			}

			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);

			//考虑time
			double time_cost = 10 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 300)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 120, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 500)) * 6 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[POLEVAULT - 1] = this->max_index(final_choice, ROW);
			this->value[POLEVAULT - 1] = final_choice[this->choice[POLEVAULT - 1]];
		}

		void value_sled()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(SLED))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {3, -2, -1, -7, -4};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, SLED);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {3, 10, 2, 7, -100, -30}; //偏好建国 and 冰豌豆
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, SLED);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);
			double time_cost;
			//考虑time
			if (time < 600)
				time_cost = 15 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5);
			else
			{
				time_cost = 30 * (1 / (1 + exp((+this->time - TOTAL_TIME / 5) / 300)) - 0.5);
			}
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 200, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp(-this->Sun + sun_baseline + 100) / 500) * 10 : 0);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			// for (int i = 0; i < ROW; i++)
			// {

			//     printf("%lf\t", final_choice[i]);
			// }
			this->choice[SLED - 1] = this->max_index(final_choice, ROW);
			this->value[SLED - 1] = final_choice[this->choice[SLED - 1]];
		}
		void value_gargantuar()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(GARGANTUAR))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {2, -4, -5, -20, -15};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, GARGANTUAR);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {1, 10, 2, 8, -100, -10}; //偏好建国 and 冰豌豆
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, GARGANTUAR);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);
			//考虑time
			double time_cost;
			if (abs(this->time - 500) < 25 || abs(this->time - 1000) < 25 || abs(this->time - 1500) < 25)
				time_cost = 1000;
			time_cost = 120 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 300, sun_sub = 1;
			double sun_cost = 1 / (1 + max(exp((-this->Sun + sun_baseline) / 500.0), 10000.0)) * 10;
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[GARGANTUAR - 1] = this->max_index(final_choice, ROW);
			this->value[GARGANTUAR - 1] = final_choice[this->choice[GARGANTUAR - 1]];
		}
	};
	static Game game;
	void player_ai(IPlayer *player)
	{
		// game.maintain(player);

		/*
		class ICamp
		{
		public:
			virtual int** getCurrentPlants() = 0;

			获 取 现 在 场 上 存 活 的 植 物 情 况。
			Plants [ i ] [ j ] 即 为 第 i 行 j 列 的 植 物 情 况， 0代 表 不 存 在

			virtual int*** getCurrentZombies() = 0;

			Zombies [ i ] [ j ] 即 为 第 i 行 j 列 格 子 中 的 所 有 僵 尸，
			如 果 该 格 子 中 有k（k>=0） 个 僵 尸， 则Zombies [ i ] [ j ] 的 长 度 为k+1，
			最 后 一 位Zombies [ i ] [ j ] [ k ] 为−1， 代 表 这 一 格 结 束

			virtual int getSun() = 0;

			获 取 己 方 阵 营 当 前 所 剩 的 阳 光 （月 光） 数

			virtual int* getPlantCD() = 0;

			获 取 植 物 或 僵 尸 种 植 冷 却 时 间， 植 物 方 调 用 时 仅 返 回 植 物 的 种 植CD， 僵 尸 方 同 理。
			植 物 方 返 回 的 数 组 依 次 是 太 阳 花， 冰 豌 豆 射 手， 豌 豆 射 手， 坚 果 墙， 火 爆 辣 椒， 倭 瓜；
			僵 尸 方 返 回 的 数 组 依 次 是 普 通 僵 尸， 铁 桶 僵 尸， 撑 杆 跳 僵 尸， 雪 橇 车 僵 尸， 伽 刚 特 尔。 数 组 下 标 从0开 始

			virtual int* getLeftLines() = 0

			获 取 植 物 方 各 行 是 否 被 攻 破， 长 度 为 行 数， 1为 该 行 未 被 攻 破， 0为 被 攻 破

			virtual int getRows() = 0;获 取 场 地 的 行 数

			virtual int getColumns() = 0;获 取 场 地 的 列 数

			virtual int getCurrentType() = 0;
		};
		class IPlayer
		{
		public:
			ICamp* Camp;
			virtual void PlacePlant(int type, int x, int y) = 0;  横着数为x 竖着数为y

			//参 数： 放 置 的 行 数x , 列 数y， 植 物 的 种 类type , 从1~6依 次 为 太 阳 花， 冰 豌 豆 射 手， 豌 豆 射 手， 坚 果
			墙， 火 爆 辣 椒， 倭 瓜 3 //作 用： 植 物 方 调 用 种 植 植 物。 僵 尸 方 调 用 无 效。 注 意 一 个 回 合 内 一 种 植 物 只 能 种 植 一 次，
			一 个 回 合 种 植 多 株 相 同 植 物 只 取 第 一 次。  当 要 种 植 植 物 的 种 植 CD 不 为 0 或 者 阳 光 不 足 或 者 待 种 植 的 位 置 已 经 存 在 植 物 则 种 植 无 效。

			virtual void PlaceZombie(int type, int y) = 0;

			放 置 的 列 数y， 僵 尸 的 种 类type , 从1~5依 次 为 普 通 僵 尸， 铁 桶 僵 尸， 撑 杆 跳 僵 尸， 雪 橇 车 僵 尸， 伽 刚 特 尔。
			作 用： 僵 尸 方 调 用 放 置 僵 尸。 植 物 方 调 用 无 效。 注 意 一 个 回 合 内 一 种 僵 尸 只 能 放 置 一 次，
			一 个 回 合 放 置 多 只 相 同 僵 尸 只 取 第 一 次。 当 要 放 置 的 僵 尸 放 置CD不 为0或 者 阳 光 不 足 则 放 置 无 效。

			virtual int getTime() = 0; 获 取 当 前 回 合 数
			virtual int getScore() = 0;获 取 己 方 分 数
			virtual int getKillPlantsScore() = 0;获 取 己 方 作 为 僵 尸 方 时 通 过 杀 死 植 物 得 到 的 分 数
			virtual int getKillZombiesScore() = 0;获 取 己 方 作 为 植 物 方 时 通 过 杀 死 僵 尸 得 到 的 分 数
			virtual int getNotBrokenLines() = 0;  返 回 己 方 作 为 植 物 方 时 未 被 攻 破 的 行 数
			virtual int getBrokenLinesScore() = 0;   返 回 己 方 作 为 僵 尸 方 时 通 过 攻 破 一 整 行 获 得 的 分 数
			virtual int getLeftPlants() = 0;;获 取 己 方 作 为 植 物 方 时 结 束 时 剩 余 的 植 物 个 数
		};*/
		int Type = player->Camp->getCurrentType();
		//植 物 种 类 2

		if (Type == 0)
		{ //植物方
			int NotBrokenLinesNum = player->getNotBrokenLines();
			int KillZombiesScore = player->getKillZombiesScore();
			int LeftPlants = player->getLeftPlants();
			int Score = player->getScore();
			int time0 = player->getTime();
			int rows = player->Camp->getRows();
			int columns = player->Camp->getColumns();
			int *PlaceCD = player->Camp->getPlantCD();
			int **Plants = player->Camp->getCurrentPlants();
			int ***Zombies = player->Camp->getCurrentZombies();
			int *LeftLines = player->Camp->getLeftLines();
			int Sun = player->Camp->getSun();
			// Zombies_num zombies_num;
			// zombies_num.compute_num(Zombies, rows, columns);
			// Plants_num plants_num;
			// plants_num.compute_num(Plants, rows, columns);
			// player->PlacePlant(SUNFLOWER, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.sunflower / 5 + 1)) % 5, plants_num.sunflower / 5 + 1);
			// player->PlacePlant(SMALLNUT, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.smallnut / 5 + 2)+3)%5, plants_num.smallnut / 5 + 2);
			// if (plants_num.sunflower < 3)
			//     player->PlacePlant(SUNFLOWER, 0, plants_num.sunflower + 1);
			// player->PlacePlant(SMALLNUT, 0, plants_num.smallnut + 5);
			// player->PlacePlant(SQUASH, 0, 4);
			// player->PlacePlant(SQUASH, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.squash / 5 + 4) ) % 5, (plants_num.squash) / 5 + 4);
			// if (time0 > 6)
			//     player->PlacePlant(PEASHOOTER, (choose_Lines_not_Broken(LeftLines, Plants, (plants_num.peashooter) / 5)+1)%5, (plants_num.peashooter + 4) / 5);
			// if (Sun > 400)
			// player->PlacePlant(WINTERPEASHOOTER, 0, 0);

			value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player, game);
			value.make_decision();
			if (time0 > 600)
				value.eliminate_plants(game_state);
		}
		if (Type == 1)
		{
			//僵尸方
			int BrokenLinesScore = player->getBrokenLinesScore();
			int KillPlantsScore = player->getKillPlantsScore();
			int Score = player->getScore();
			int time = player->getTime();
			int rows = player->Camp->getRows();
			int columns = player->Camp->getColumns();
			int *PlaceCD = player->Camp->getPlantCD();
			int **Plants = player->Camp->getCurrentPlants();
			int ***Zombies = player->Camp->getCurrentZombies();
			int *LeftLines = player->Camp->getLeftLines();
			int Sun = player->Camp->getSun();
			if (time > 3)
			{
				int zombie_num = calculate_zombie_nums(Zombies, 4, 9);
				value_zombie_func value(BrokenLinesScore, KillPlantsScore, Score, time, PlaceCD, Plants, Zombies, LeftLines, Sun, zombie_num, game, player);
				value.value_normal();
				value.value_bucket();
				value.value_polevault();
				value.value_sled();
				value.value_gargantuar();
				int decision[2] = {0, 0};
				value.make_decision(decision);

				// for (int i = 0; i < rows; i++)
				// {
				//     for (int j = 0; j < columns; j++)
				//     {
				//         int k = 0;
				//         while (Zombies[i][j][k] != -1)
				//         {
				//             // . . .
				//             k++;
				//         }
				//     }
				// }
				if (decision[0] != NOZOMBIE)
				{
					player->PlaceZombie((decision[0] > ZOMBIE_KIND ? NORMAL : decision[0]), decision[1] > ROW - 1 ? ROW - 1 : decision[1]);
				}
			}
			else
			{
				player->PlaceZombie(POLEVAULT, 1);
				player->PlaceZombie(NORMAL, 2);
				player->PlaceZombie(BUCKET, 3);
			}
		}
	}

} // namespace legacy_ai

#endif
/*** End of inlined file: LegacyAI.cpp ***/

class PlantLegacyAgent
{
public:
	Action getAction(GameState *game_state)
	{
		Action action;
		legacy_ai::game_state = game_state;
		legacy_ai::player_ai(game_state->getPlayer());
		return action;
	}
};

static PlantLegacyAgent agent_plant;
/*** End of inlined file: PlantAncientAgent.cpp ***/


/*** Start of inlined file: ZombieReflexAgent.cpp ***/
#include <algorithm>
#include <bitset>
#include <random>
#include <cstdlib>
#include <vector>
#include <utility>

#include <iostream>


/*** Start of inlined file: Debug.cpp ***/
#ifndef __DEBUG_CPP__
#define __DEBUG_CPP__

#include <iostream>
#include <sstream>
#include <exception>
#include <string>
#include <vector>
#include <utility>

using namespace std;

struct
{
	ostream *os = &cout;

	/**
	 * @brief Print a vector
	 *
	 * @tparam T The type of vector elements
	 * @param v The vector
	 * @param ending The ending string
	 */
	template <typename T>
	void log(vector<T> v, string ending = string("\n")) const
	{
		*(this->os) << "[";
		for (typename vector<T>::iterator iter = v.begin(); iter != v.end(); ++iter)
		{
			this->log(*iter, string("\0"));
			if (iter != v.end() - 1)
			{
				*(this->os) << ", ";
			}
		}
		*(this->os) << "]" << ending;
	}

	/**
	 * @brief Print a 2D vector
	 *
	 * @tparam T The type of vector elements
	 * @param v The vector
	 * @param ending The ending string
	 * @param row_ending The ending string of each row
	 */
	template <typename T>
	void log(vector<vector<T>> v, string ending = string("\n"), string row_ending = string("\n")) const
	{
		*(this->os) << "[";
		for (typename vector<T>::iterator iter = v.begin(); iter != v.end(); ++iter)
		{
			this->log(*iter, string("\0"));
			if (iter != v.end() - 1)
			{
				*(this->os) << "," << row_ending;
			}
		}
		*(this->os) << "]" << ending;
	}

	/**
	 * @brief Print a C style array
	 *
	 * @tparam T The type of array elements
	 * @param v The array
	 * @param n The number of elements to print
	 * @param ending The ending string
	 */
	template <typename T>
	void log(T *v, size_t n, string ending = string("\n")) const
	{
		*(this->os) << "[";
		for (size_t i = 0; i < n; ++i)
		{
			this->log(v[i], string("\0"));
			if (i != n - 1)
			{
				*(this->os) << ", ";
			}
		}
		*(this->os) << "]" << ending;
	}

	/**
	 * @brief Print a C style 2D array
	 *
	 * @tparam T The type of array elements
	 * @param v The array
	 * @param m The number of rows to print
	 * @param n The number of elements in a row to print
	 * @param ending The ending string
	 * @param row_ending The ending string of each row
	 */
	template <typename T>
	void log(T **v, size_t m, size_t n, string ending = string("\n"), string row_ending = string("\n")) const
	{
		*(this->os) << "[";
		for (size_t i = 0; i < n; ++i)
		{
			this->log(v[i], string("\0"));
			if (i != n - 1)
			{
				*(this->os) << "," << row_ending;
			}
		}
		*(this->os) << "]" << ending;
	}

	/**
	 * @brief Print a pair
	 *
	 * @tparam T1 The type of v.first
	 * @tparam T2 The type of v.second
	 * @param v The pair
	 * @param ending The ending string
	 */
	template <typename T1, typename T2>
	void log(pair<T1, T2> v, string ending = string("\n")) const
	{
		*(this->os) << "(" << v.first << ", " << v.second << ")" << ending;
	}

	/**
	 * @brief Print a value
	 *
	 * @tparam T The type of the value
	 * @param v The value
	 * @param ending The ending string
	 */
	template <typename T>
	void log(T v, string ending = string("\n")) const
	{
		*(this->os) << v << ending;
	}

	/**
	 * @brief Print an error value
	 *
	 * @tparam T The type of the error value
	 * @param e The error value
	 */
	template <typename T>
	void error(T e) const
	{
		ostringstream oss;
		oss << e;
		throw runtime_error(oss.str());
	}
} console;

#endif
/*** End of inlined file: Debug.cpp ***/

using namespace std;

class ZombieAgent
{
protected:
	/* Paramters */
	// Parameters for getDifficultyScore()
	const double SCORE_TABLE_PLANT[7][10] = { // [slot][y]
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, -2, -4, -6, -8, -10},
		{40, 40, 40, 40, 40, 35, 30, 25, 20, 15},
		{10, 10, 10, 10, 10, 9, 8, 7, 6, 5},
		{1, 1, 1, 1, 1, 1, 2, 3, 4, 5},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1800, 1800, 1800, 1800, 1800, 1800, 1800, 2400, 3000, 3600}};

	const double SCORE_TABLE_ZOMBIE[6] = {0, 5.4, 41, 5.7, 30 + 10, 60}; // [slot]

	// Parameters for onEarlyStage()
	const vector<int> EARLY_ZOMBIE_PRIORITY = {ZOMBIE.BUCKET, ZOMBIE.POLEVAULT, ZOMBIE.NORMAL};

	// Parameters for onWaveStage()
	const vector<int> WAVE_ZOMBIE_PRIORITY = {ZOMBIE.GARGANTUAR, ZOMBIE.SLED, ZOMBIE.BUCKET};
	const int WAVE_PLACEMENT_GAP = 7;

	/* Class-wide variables for storaging data */
	int stage = -1;      // the stage of the game for choosing different logics
	int prev_stage = -1; // the previous stage
	Action *action = new Action();

	bool canPlaceZombie(int x, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.ZOMBIE) < ZOMBIE_COST[slot] ||
			gs->getCD(CAMP.ZOMBIE, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/**
	 * @brief Get the difficulty score
	 *
	 * @param game_state The game state
	 * @param row The row to judge
	 * @return double The difficulty score
	 */
	double getDifficultyScore(GameState *game_state, int row)
	{
		double score = 0.0;
		vector<Plant> plant_list = game_state->getPlantList(row);
		for (vector<Plant>::iterator it = plant_list.begin();
			 it != plant_list.end();
			 ++it)
		{
			score += SCORE_TABLE_PLANT[it->getType()][it->getPosition().y];
		}
		vector<Zombie> zombie_list = game_state->getZombieList(row);
		for (vector<Zombie>::iterator it = zombie_list.begin();
			 it != zombie_list.end();
			 ++it)
		{
			score -= SCORE_TABLE_ZOMBIE[it->getType()];
		}
		return score;
	}

	/**
	 * @brief Get the weakest rows
	 *
	 * @param game_state The game state
	 * @return vector<pair<int, double>> A list of (row, difficulty_score)
	 */
	vector<pair<int, double>> getWeakestRows(GameState *game_state)
	{
		/* Get available rows and sort by difficulty score */
		vector<pair<int, double>> difficulty_score;
		for (int i = 4; i >= 0; --i)
		{
			if (!game_state->getBrokenLines()[i])
			{
				difficulty_score.push_back(pair<int, double>(i, this->getDifficultyScore(game_state, i)));
			}
		}
		auto cmp = [](pair<int, double> a, pair<int, double> b)
		{ return a < b; };
		sort(difficulty_score.begin(), difficulty_score.end(), cmp);
		return difficulty_score;
	}

	/**
	 * @brief Judge if it's the early stage of the game
	 *
	 * @param game_state The game state
	 * @return true if it's the early stage of the game
	 * @return false if it's not the early stage of the game
	 */
	bool judgeEarlyStage(GameState *game_state)
	{
		if (game_state->getTime() < 100 && game_state->getTime() > 1)
		{
			return true;
		}
		return false;
	}

	/**
	 * @brief Logic for early stage
	 *
	 * @param game_state The game state
	 */
	void onEarlyStage(GameState *game_state)
	{
		/* Static variables and their initializers */
		vector<pair<int, double>> weakest_rows = this->getWeakestRows(game_state);

		for (vector<pair<int, double>>::iterator it = weakest_rows.begin();
			 it != weakest_rows.end();
			 ++it)
		{
			if (!game_state->getZombieList(it->first).empty())
			{ // if there is a zombie in a row, skip the row
				continue;
			}

			for (vector<int>::const_iterator it1 = EARLY_ZOMBIE_PRIORITY.begin();
				 it1 != EARLY_ZOMBIE_PRIORITY.end();
				 ++it1)
			{
				if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE_COST[*it1] &&
					game_state->getCD(CAMP.ZOMBIE, *it1) == 0)
				{
					this->action->placeZombie(*it1, it->first);
					return;
				}
			}
		}
	}

	/**
	 * @brief Judge if a wave is ready or finished
	 *
	 * @param game_state
	 * @return true The wave is ready or ongoing
	 * @return false The wave is not ready
	 */
	bool judgeWaveStage(GameState *game_state)
	{
		// If boost stage is around the corner, exit wave stage
		if ((game_state->getTime() % 500 > 400 &&
			 game_state->getSun(CAMP.ZOMBIE) < 1000) || // to earn enough sun for boost stage
			game_state->getTime() % 500 < 20)
		{
			return false;
		}

		static bool is_ongoing = false;
		if (!is_ongoing && game_state->getSun(CAMP.ZOMBIE) > min(max(game_state->getTime(), 600), 1500))
		{
			is_ongoing = true;
		}
		else if (is_ongoing && game_state->getSun(CAMP.ZOMBIE) < 100)
		{
			is_ongoing = false;
		}
		return is_ongoing;
	}

	/**
	 * @brief Logic for early stage
	 *
	 * @param game_state The game state
	 */
	Action onWaveStage(GameState *game_state)
	{
		Action action;
		if ((game_state->getTime() >= 1497 &&
			 game_state->getTime() < 1940))
		{
			if (game_state->getSun(CAMP.ZOMBIE) < 600)
			{
				return action;
			}

			vector<int> target_rows;

			for (int i = 4; i >= 0; --i)
			{
				if (!game_state->getBrokenLines()[i])
				{
					target_rows.push_back(i);
				}
			}

			if (target_rows.size() >= 2)
			{
				for (int i = 0; i < 3; ++i)
				{
					int row = target_rows.at(min((game_state->getTime()) % 2, static_cast<int>(target_rows.size() - 1)));
					if (i == 0 && canPlaceZombie(row, ZOMBIE.SLED, game_state))
					{
						action.placeZombie(ZOMBIE.SLED, row);
						return action;
					}
					if (i == 1 && canPlaceZombie(row, ZOMBIE.GARGANTUAR, game_state))
					{
						action.placeZombie(ZOMBIE.GARGANTUAR, row);
						return action;
					}
					if (i == 2 && canPlaceZombie(row, ZOMBIE.BUCKET, game_state))
					{
						action.placeZombie(ZOMBIE.BUCKET, row);
						action.placeZombie(ZOMBIE.NORMAL, row);
						return action;
					}
				}
			}
			else
			{
				for (int i = 0; i < 3; ++i)
				{
					int row = target_rows.at(0);
					if (i == 0 && canPlaceZombie(row, ZOMBIE.GARGANTUAR, game_state))
					{
						action.placeZombie(ZOMBIE.GARGANTUAR, row);
						return action;
					}
					if (i == 2 && canPlaceZombie(row, ZOMBIE.BUCKET, game_state))
					{
						action.placeZombie(ZOMBIE.BUCKET, row);
						action.placeZombie(ZOMBIE.NORMAL, row);
						return action;
					}
				}
			}
		}
		return action;
	}

	/**
	 * @brief Judge if it's boost time
	 *
	 * @param game_state The game state
	 * @return true If it's boost time
	 * @return false If it's not boost time
	 */
	bool judgeBoostStage(GameState *game_state)
	{
		if (game_state->getTime() % 500 >= 490 ||
			(game_state->getTime() > 500 && game_state->getTime() % 500 < 10))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * @brief Logic for boost stage
	 *
	 * @param game_state The game stage
	 */
	void onBoostStage(GameState *game_state)
	{
		/* Static variables and their initializers */

		const int time = game_state->getTime();
		const vector<pair<int, double>> weakest_rows = this->getWeakestRows(game_state);

		if (time == 499)
		{
			if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE.GARGANTUAR &&
				game_state->getCD(CAMP.ZOMBIE, ZOMBIE.GARGANTUAR) == 0)
			{
				this->action->placeZombie(ZOMBIE.GARGANTUAR, weakest_rows[0].first);
			}
		}
		else if (time == 501)
		{
			int row = 0;
			for (vector<pair<int, double>>::const_iterator it = weakest_rows.begin();
				 it != weakest_rows.end();
				 ++it)
			{
				if (game_state->getZombieList(it->first, -1, ZOMBIE.GARGANTUAR).empty())
				{
					row = it->first;
				}
			}

			if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE.GARGANTUAR &&
				game_state->getCD(CAMP.ZOMBIE, ZOMBIE.GARGANTUAR) == 0)
			{
				this->action->placeZombie(ZOMBIE.GARGANTUAR, row);
			}
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		delete this->action;
		this->action = new Action();

		/* Get the current stage */
		this->prev_stage = this->stage;
		if (this->stage == -1)
		{ // if the last stage has been cleared
			vector<int> available_stages;
			if (this->judgeEarlyStage(game_state))
			{
				available_stages.push_back(0);
			}
			if (this->judgeWaveStage(game_state))
			{
				available_stages.push_back(1);
			}
			if (this->judgeBoostStage(game_state))
			{
				available_stages.push_back(2);
			}

			if (!available_stages.empty())
			{
				this->stage = available_stages[0];
			}
		}
		else
		{ // judge if it's time to clear the stage
			this->stage = (this->stage == 0 && !this->judgeEarlyStage(game_state)) ? -1 : this->stage;
			this->stage = (this->stage == 1 && !this->judgeWaveStage(game_state)) ? -1 : this->stage;
			this->stage = (this->stage == 2 && !this->judgeBoostStage(game_state)) ? -1 : this->stage;
		}

		switch (this->stage)
		{
		case 0:
			this->onEarlyStage(game_state);
			break;
		case 1:
			return(this->onWaveStage(game_state));
			break;
		case 2:
			this->onBoostStage(game_state);
			break;
		default:
			break;
		}

		return *(this->action);
	}
};

static ZombieAgent agent_zombie;
/*** End of inlined file: ZombieReflexAgent.cpp ***/


/*** Start of inlined file: PlantLieFlatAgent.cpp ***/
class PlantLieFlatAgent
{
protected:
	bool canPlacePlant(int x, int y, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.PLANT) < PLANT_COST[slot] ||
			gs->getCD(CAMP.PLANT, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		Action action;

		int row1 = __LINE__ % 3;
		int row2 = row1 + 2;

		if (game_state->getPlant(row1, 0).getType() != PLANT.WINTERPEASHOOTER &&
			game_state->getPlant(row1, 0).getType() != PLANT.NOPLANT)
		{
			action.removePlant(row1, 0);
		}
		if (game_state->getPlant(row2, 0).getType() != PLANT.WINTERPEASHOOTER &&
			game_state->getPlant(row2, 0).getType() != PLANT.NOPLANT)
		{
			action.removePlant(row2, 0);
		}

		if (game_state->getZombieList(row1).size() != 0)
		{
			Position<int> pos = game_state->getZombieList(row1).at(game_state->getZombieList(row1).size() - 1).getPosition();
			int x = pos.x, y = pos.y;
			for (int slot_index = 0; slot_index < 4; ++slot_index)
			{
				const int slot_queue[4] = {4, 3, 1, 6};
				int slot = slot_queue[slot_index];
				if (canPlacePlant(x, y, slot, game_state) &&
					game_state->getPlant(x, y).getType() == PLANT.NOPLANT)
				{
					action.placePlant(slot, x, y);
					return action;
				}
			}
		}

		if (canPlacePlant(row2, 9, PLANT.PEPPER, game_state))
		{
			action.placePlant(PLANT.PEPPER, row2, 9);
			return action;
		}

		for (int x = 0; x <= 4; ++x)
		{
			for (int y_index = 0; y_index <= 9; ++y_index)
			{
				const int y_queue[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
				int y = y_queue[y_index];
				if (canPlacePlant(x, y, PLANT.SUNFLOWER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.SUNFLOWER &&
					x != row1 && x != row2)
				{
					action.placePlant(PLANT.SUNFLOWER, x, y);
					return action;
				}
				if (canPlacePlant(x, y, PLANT.WINTERPEASHOOTER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.WINTERPEASHOOTER &&
					x == row2 &&
					y <= 4 &&
					game_state->getSun(CAMP.PLANT) >= 450)
				{
					action.placePlant(PLANT.WINTERPEASHOOTER, x, y);
					return action;
				}
				if (canPlacePlant(x, y, PLANT.WINTERPEASHOOTER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.WINTERPEASHOOTER &&
					x == row1 &&
					game_state->getSun(CAMP.PLANT) >= 450 &&
					game_state->getPlantList(row2, -1, PLANT.WINTERPEASHOOTER).size() == 4)
				{
					action.placePlant(PLANT.WINTERPEASHOOTER, x, y);
					return action;
				}
			}
		}

		return action;
	}
};

static PlantLieFlatAgent agent_plant_lie_flat;
/*** End of inlined file: PlantLieFlatAgent.cpp ***/


/*** Start of inlined file: ZombieLieFlatAgent.cpp ***/
class ZombieLieFlatAgent
{
protected:
	bool canPlaceZombie(int x, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.ZOMBIE) < ZOMBIE_COST[slot] ||
			gs->getCD(CAMP.ZOMBIE, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		vector<int> target_rows;
		for (int i = 0; i <= 4; ++i)
		{
			if (game_state->getPlant(i, 0).getType() != PLANT.SUNFLOWER &&
				game_state->getPlant(i, 0).getType() != PLANT.NOPLANT)
			{
				target_rows.push_back(i);
			}
		}

		if (game_state->getTime() > 890 &&
			game_state->getPlantList(-1, -1, PLANT.SUNFLOWER).size() > 25)
		{
			int row = __LINE__ % 5;
			while (game_state->getPlant(row, 0).getType() != PLANT.SUNFLOWER)
			{
				row = (row + 1) % 5;
			}
			if (canPlaceZombie(row, ZOMBIE.NORMAL, game_state))
			{
				Action action1;
				action1.placeZombie(ZOMBIE.NORMAL, row);
				return action1;
			}
		}

		if (game_state->getTime() >= 390)
		{
			if (canPlaceZombie(target_rows.at(0), ZOMBIE.GARGANTUAR, game_state))
			{
				GameState gs = *game_state;
				Action action1;
				action1.placeZombie(ZOMBIE.GARGANTUAR, target_rows.at(0));
				gs.infer(action1);
				for (int i = 0; i < 200; ++i)
				{
					gs.infer();
				}

				if (!gs.getBrokenLines()[target_rows.at(0)])
				{
					return action1;
				}
			}

			if (canPlaceZombie(target_rows.at(0), ZOMBIE.SLED, game_state))
			{
				GameState gs = *game_state;
				Action action1;
				action1.placeZombie(ZOMBIE.SLED, target_rows.at(0));
				gs.infer(action1);
				for (int i = 0; i < 200; ++i)
				{
					gs.infer();
				}

				if (!gs.getBrokenLines()[target_rows.at(0)])
				{
					return action1;
				}
			}

			for (int slot = 1; slot <= 3; ++slot)
			{
				if (canPlaceZombie(target_rows.at(1), slot, game_state) &&
					game_state->getSun(CAMP.ZOMBIE) - ZOMBIE_COST[slot] >= 600)
				{
					GameState gs = *game_state;
					Action action1;
					action1.placeZombie(slot, target_rows.at(1));
					gs.infer(action1);
					for (int i = 0; i < 100; ++i)
					{
						gs.infer();
					}

					if (!gs.getBrokenLines()[target_rows.at(1)])
					{
						return action1;
					}
				}
			}
		}

		return Action();
	}
};

static ZombieLieFlatAgent agent_zombie_lie_flat;
/*** End of inlined file: ZombieLieFlatAgent.cpp ***/

using namespace std;

using namespace std;

void player_ai(IPlayer *player)
{
	static Game *game = new Game(player);
	static History *history = new History();
	static bool random_first_mode = false;

	const vector<unsigned long long> RANDOM_SEED = {
		17144294874095792984, // 12pr2
		13419500148984122010, // 12zr2
		2806304766567999452,  // 21pr1
		9703402511232314587,  // 21zr1

		2760398726652686362,  // 1lepr1
		10495476869881568972, // 1lezr1
		16311340434481636538, // le1pr2
		16002625154267435628, // le1zr2
	};

	/* Start a new game when the camp swapped */
	if (player->Camp->getCurrentType() != game->getGameState()->getCamp())
	{
		delete game;
		delete history;
		game = new Game(player);
		history = new History();
		random_first_mode = false;
	}

	game->getGameState()->setDebugMode(false);

	try
	{
		game->update(player);
		history->insert(game->getGameState());

		if (game->getGameState()->getTime() == 50 && !random_first_mode)
		{
			auto code = history->getIdentifier();
			// cout << code << endl;
			for (auto it = RANDOM_SEED.begin(); it != RANDOM_SEED.end(); ++it)
			{
				if (*it == code)
				{
					random_first_mode = true;
					break;
				}
			}
		}

		Action action;
		if (random_first_mode)
		{
			if (game->getGameState()->getCamp() == CAMP.PLANT)
			{
				if (game->getGameState()->getTime() > 100)
				{
					action = agent_plant_lie_flat.getAction(game->getGameState());
				}
				else
				{
					action = agent_plant.getAction(game->getGameState());
				}
			}
			else if (game->getGameState()->getCamp() == CAMP.ZOMBIE)
			{
				action = agent_zombie_lie_flat.getAction(game->getGameState());
			}
		}
		else
		{
			if (game->getGameState()->getCamp() == CAMP.PLANT)
			{
				action = agent_plant.getAction(game->getGameState());
			}
			else if (game->getGameState()->getCamp() == CAMP.ZOMBIE)
			{
				action = agent_zombie.getAction(game->getGameState());
			}
		}

		game->applyAction(action, true);
	}
	catch (const exception &e)
	{
		// cerr << "******** " << game->getGameState()->getTime() << " ********" << endl;
		// cerr << "[ERROR]<CAMP " << ((game->getGameState()->getCamp() == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << game->getGameState()->getTime() << "> " << e.what() << endl
		//      << endl;
	}
}
