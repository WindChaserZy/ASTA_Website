/**
 * This file is preprocessed by an amalgamater
 * to protect its copyright
 *
 * Please do not try to parse it
 * 
 * Amalgamater is written by Futrime<https://github.com/Futrime>
 */

#include "ai.h"


/*** Start of inlined file: ai.h ***/
#ifndef _FC19_AI_H_
#define _FC19_AI_H_

/*** Start of inlined file: Interface.h ***/
#ifndef INTERFACE_H_
#define INTERFACE_H_
class ICamp
{
public:
	virtual int** getCurrentPlants() = 0;
	virtual int*** getCurrentZombies() = 0;
	virtual int getSun() = 0;
	virtual int* getPlantCD() = 0;
	virtual int* getLeftLines() = 0;
	virtual int getRows() = 0;
	virtual int getColumns() = 0;
	virtual int getCurrentType() = 0;
};
class IPlayer
{
public:
	ICamp* Camp;
	virtual void PlacePlant(int type, int x, int y) = 0;
	virtual void PlaceZombie(int type, int y) = 0;
	virtual int getTime() = 0;
	virtual int getScore() = 0;
	virtual int getKillPlantsScore() = 0;
	virtual int getKillZombiesScore() = 0;
	virtual int getNotBrokenLines() = 0;
	virtual int getBrokenLinesScore() = 0;
	virtual int getLeftPlants() = 0;
	virtual void removePlant(int x, int y) = 0;
};

#endif
/*** End of inlined file: Interface.h ***/


#ifdef _MSC_VER
extern "C" _declspec(dllexport) void  player_ai(IPlayer * Player);
#endif

#ifdef __GNUC__
extern "C" void player_ai(IPlayer * _Player);
#endif

#endif
/*** End of inlined file: ai.h ***/

void player_ai(IPlayer *player)
{
	static int a = 0;
	if (a == 1)
	{
		player->PlacePlant(3, 0, 0);
	}
	a = 1;
}
