
/**
 * This file is preprocessed by an obfuscator
 * to protect its copyright
 *
 * Please do not try to parse it
 *
 * Obfuscator is written by Futrime<https://github.com/Futrime>
 */

#include "ai.h"


#include <iostream>

#include <stdlib.h>

#include <math.h>

#include <cstring>

#include <vector>

#include <queue>


/*** Start of inlined file: Game.cpp ***/
#ifndef __GAME_CPP__
#define __GAME_CPP__

#include <algorithm>
#include <bitset>
#include <string>
#include <vector>

#include "ai.h"


/*** Start of inlined file: Entity.cpp ***/
#ifndef __ENTITY_CPP__
#define __ENTITY_CPP__


/*** Start of inlined file: Utility.cpp ***/
#ifndef __UTILITY_CPP__
#define __UTILITY_CPP__

#include <bitset>
#include <string>

using namespace std;

/****************
 * Declarations
 ****************/

const struct
{
	int PLANT = 0;
	int ZOMBIE = 1;
} CAMP;

const struct
{
	int NOPLANT = 0;
	int SUNFLOWER = 1;
	int WINTERPEASHOOTER = 2;
	int PEASHOOTER = 3;
	int SMALLNUT = 4;
	int PEPPER = 5;
	int SQUASH = 6;
} PLANT;

const struct
{
	int NOZOMBIE = 0;
	int NORMAL = 1;
	int BUCKET = 2;
	int POLEVAULT = 3;
	int SLED = 4;
	int GARGANTUAR = 5;
} ZOMBIE;

template <typename T>
class Position
{
public:
	T x, y;

	/**
	 * @brief Construct a new Position object
	 *
	 */
	Position();

	/**
	 * @brief Construct a new Position object
	 *
	 * @param x
	 * @param y
	 */
	Position(T x, T y);
};

class Action
{
protected:
	bitset<7> plant_switch_;
	bitset<6> zombie_switch_;
	Position<int> plant_position_[7];
	Position<int> zombie_position_[6];

public:
	/**
	 * @brief Construct a new Action object
	 *
	 */
	Action();

	/**
	 * @brief Check if a slot is set in this action
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return true The slot is set
	 * @return false The slot is not set
	 */
	bool isSet(int camp, int slot);

	/**
	 * @brief Get the target position of a slot
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return Position<int> The target position
	 */
	Position<int> getPosition(int camp, int slot);

	/**
	 * @brief Place a plant
	 *
	 * @param type The type of the plant, should be PLANT.X
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 */
	void placePlant(int type, int x, int y);

	/**
	 * @brief Place a zombie
	 *
	 * @param type The type of the zombie, should be ZOMBIE.x
	 * @param x The x position to place, within [0, 4]
	 */
	void placeZombie(int type, int x);
};

/****************
 * Definitions
 ****************/

template <typename T>
Position<T>::Position()
{
	this->x = -1;
	this->y = -1;
}

template <typename T>
Position<T>::Position(T x, T y) : x(x), y(y)
{
}

Action::Action()
{
}

bool Action::isSet(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(Action::isSet) Wrong camp number!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw string("(Action::isSet) Wrong slot number!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw string("(Action::isSet) Wrong slot number!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->plant_switch_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->zombie_switch_[slot];
	}

	return false; // to avoid compilation warning
}

Position<int> Action::getPosition(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(Action::getPosition) Wrong camp number!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw string("(Action::getPosition) Wrong slot number!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw string("(Action::getPosition) Wrong slot number!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->plant_position_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->zombie_position_[slot];
	}

	return Position<int>(); // to avoid compilation warning
}

void Action::placePlant(int type, int x, int y)
{
	/* Check legality */
	if (type < 0 || type > 6)
	{
		throw string("(Action::placePlant) Wrong plant type!");
	}
	if (x < 0 || x > 4 || y < 0 || y > 9)
	{
		throw string("(Action::placePlant) Wrong position!");
	}

	this->plant_switch_.set(type, true);
	this->plant_position_[type].x = x;
	this->plant_position_[type].y = y;
}

void Action::placeZombie(int type, int x)
{
	/* Check legality */
	if (type < 0 || type > 5)
	{
		throw string("(Action::placeZombie) Wrong plant type!");
	}
	if (x < 0 || x > 4)
	{
		throw string("(Action::placeZombie) Wrong position!");
	}

	this->zombie_switch_.set(type, true);
	this->zombie_position_[type].x = x;
}

#endif
/*** End of inlined file: Utility.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class Entity
{
protected:
	int spawn_time_;
	int type_;
	int hp_;
	Position<int> position_;

public:
	/**
	 * @brief Construct a new Entity object
	 *
	 * @param spawn_time The spawning time of the entity
	 * @param type The type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 * @param position The position of the entity
	 */
	Entity(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get the spawning time of the entity
	 *
	 * @return int The spawning time
	 */
	int getSpawnTime();

	/**
	 * @brief Get the type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 *
	 * @return int The type of the entity, fitting PLANT.X or ZOMBIE.X
	 */
	int getType();

	/**
	 * @brief Get the health of the entity
	 *
	 * @return int The health of the entity, >= 0
	 */
	int getHealth();

	/**
	 * @brief Reduce the health of the entity
	 *
	 * @param value The number of health to reduce
	 * @return int The health left
	 */
	int reduceHealth(int value);

	/**
	 * @brief Get the position of the entity
	 *
	 * @return Position<int> The position of the entity
	 */
	Position<int> getPosition();
};

class Plant : public Entity
{
protected:
	/* data */
public:
	static const struct
	{
		int SUNFLOWER = 300;
		int WINTERPEASHOOTER = 300;
		int PEASHOOTER = 300;
		int SMALLNUT = 4000;
		int PEPPER = 300;
		int SQUASH = 300;
	} HP;

	static const struct
	{
		int SUNFLOWER = 50;
		int WINTERPEASHOOTER = 400;
		int PEASHOOTER = 100;
		int SMALLNUT = 50;
		int PEPPER = 125;
		int SQUASH = 50;
	} COST;

	static const struct
	{
		int WINTERPEASHOOTER = 60;
		int PEASHOOTER = 20;
		int PEPPER = 1800;
		int SQUASH = 1800;
	} ATK;

	static const struct
	{
		int SUNFLOWER = 10;
		int WINTERPEASHOOTER = 30;
		int PEASHOOTER = 10;
		int SMALLNUT = 40;
		int PEPPER = 60;
		int SQUASH = 60;
	} CD;

	static const struct
	{
		int WINTERPEASHOOTER = 3;
		int PEASHOOTER = 2;
	} PERIOD;

	/**
	 * @brief Construct a new Plant object
	 *
	 */
	Plant();

	/**
	 * @brief Construct a new Plant object
	 *
	 * @param spawn_time The spawing time of the plant
	 * @param type The type of the plant
	 * @param position The position of the plant
	 */
	Plant(int spawn_time, int type, Position<int> position);
};

class Zombie : public Entity
{
protected:
	Position<double> position_real_;
	int state_ = 0; // Polevault and Sled's state
	bool frozen_state_ = false;

public:
	static const struct
	{
		int NORMAL = 270;
		int BUCKET = 550 + 270;
		int POLEVAULT = 200;
		int SLED = 1600;
		int GARGANTUAR = 3000;
	} HP;

	static const struct
	{
		int NORMAL = 50;
		int BUCKET = 125;
		int POLEVAULT = 125;
		int SLED = 300;
		int GARGANTUAR = 300;
	} COST;

	static const struct
	{
		int NORMAL = 75;
		int BUCKET = 75;
		int POLEVAULT = 75;
		int SLED = 999999;
		int GARGANTUAR = 999999;
	} ATK;

	static const struct
	{
		double NORMAL = 0.2;
		double BUCKET = 0.2;
		double POLEVAULT[2] = {0.4, 0.2222222222222222};
		double SLED[5] = {0.3333333333333333, 0.28125, 0.2291666666666667, 0.1770833333333333, 0.125};
		double GARGANTUAR = 0.2;
	} SPEED;

	Zombie(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get the real position of the zombie
	 *
	 * @return Position<double> The real position of the entity
	 */
	Position<double> getRealPosition();

	/**
	 * @brief Get the state of the zombie
	 *
	 * @return int The state number
	 */
	int getState();

	/**
	 * @brief Set the state of the zombie
	 *
	 * @param state The state number
	 */
	void setState(int state);

	/**
	 * @brief Get if the zombie is frozen
	 *
	 * @return true The zombie is frozen
	 * @return false The zombie is not frozen
	 */
	bool getFrozenState();

	/**
	 * @brief Set if the zombie is frozen
	 *
	 * @param state true The zombie is frozen
	 * @param state false The zombie is not frozen
	 */
	void setFrozenState(bool state);
};

/****************
 * Definitions
 ****************/

Entity::Entity(int spawn_time, int type, Position<int> position)
	: spawn_time_(spawn_time), type_(type), position_(position)
{
}

int Entity::getSpawnTime()
{
	return this->spawn_time_;
}

int Entity::getType()
{
	return this->type_;
}

int Entity::getHealth()
{
	return this->hp_;
}

int Entity::reduceHealth(int value)
{
	this->hp_ -= value;
	return this->hp_;
}

Position<int> Entity::getPosition()
{
	return this->position_;
}

Plant::Plant() : Entity(0, PLANT.NOPLANT, Position<int>())
{
}

Plant::Plant(int spawn_time, int type, Position<int> position) : Entity(spawn_time, type, position)
{
}

Zombie::Zombie(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position), position_real_(position.x, position.y + 1)
{
}

Position<double> Zombie::getRealPosition()
{
	return this->position_real_;
}

int Zombie::getState()
{
	return this->state_;
}

void Zombie::setState(int state)
{
	this->state_ = state;
}

bool Zombie::getFrozenState()
{
	return this->frozen_state_;
}

void Zombie::setFrozenState(bool state)
{
	this->frozen_state_ = state;
}

#endif
/*** End of inlined file: Entity.cpp ***/


#include <iostream>

using namespace std;

/****************
 * Declarations
 ****************/

class GameState
{
protected:
	/* Global Information */
	int time_ = 0;
	bitset<5> broken_lines_;

	/* Camp Information */
	int camp_;
	int other_camp_;
	vector<Plant> plant_;
	vector<Zombie> zombie_;
	int sun_plant_ = 400;
	int sun_zombie_ = 300;
	int cd_plant_[7] = {0};
	int cd_zombie_[6] = {0};
	int score_plant_ = 5000;
	int score_zombie_ = 0;

public:
	/**
	 * @brief Construct a new Game State object
	 *
	 * @param camp The current camp
	 */
	GameState(int camp);

	/**
	 * @brief Get the time
	 *
	 * @return int The time
	 */
	int getTime();

	/**
	 * @brief Get the broken lines
	 *
	 * @return bitset<5> True if broken
	 */
	bitset<5> getBrokenLines();

	/**
	 * @brief Get the current camp
	 *
	 * @return int The current camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getCamp();

	/**
	 * @brief Get the other camp
	 *
	 * @return int The other camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getOtherCamp();

	/**
	 * @brief Get the plant at the position
	 *
	 * @param x The x position
	 * @param y The y position
	 * @return Plant The plant
	 */
	Plant getPlant(int x, int y);

	/**
	 * @brief Get plants fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @return vector<Plant>
	 */
	vector<Plant> getPlantList(int x = -1, int y = -1);

	/**
	 * @brief Get zombies fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @return vector<Zombie>
	 */
	vector<Zombie> getZombieList(int x = -1, int y = -1);

	/**
	 * @brief Get the sun count
	 *
	 * @param camp The camp
	 * @return int The sun count of the camp
	 */
	int getSun(int camp);

	/**
	 * @brief Get the left cooldown time of a slot
	 *
	 * @param camp The camp
	 * @param slot The slot
	 * @return int The left cooldown time
	 */
	int getCD(int camp, int slot);

	/**
	 * @brief Get the score
	 *
	 * @param camp The camp
	 * @return int The score of the camp
	 */
	int getScore(int camp);

	/**
	 * @brief Get the battlefront of a line
	 *
	 * @param x The line
	 * @return int The y position of the battlefront
	 */
	int getBattlefront(int x);

	/**
	 * @brief Update the state
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Infer the next state
	 *
	 */
	void infer();

	/**
	 * @brief Generate a predicted state after applying an action
	 *
	 * @param action The action to apply
	 * @return GameState* The predicted state
	 */
	GameState *generateSuccessor(Action action);
};

class Game
{
protected:
	IPlayer *player_;
	GameState *game_state_;

public:
	/**
	 * @brief Construct a new Game object
	 *
	 * @param player The IPlayer object
	 */
	Game(IPlayer *player);

	/**
	 * @brief Destroy the Game object
	 *
	 */
	~Game();

	/**
	 * @brief Get the current state
	 *
	 * @return GameState* The current state
	 */
	GameState *getGameState();

	/**
	 * @brief Update the game environment
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Apply an action
	 *
	 * @param action The action to apply
	 */
	void applyAction(Action action);
};

/****************
 * Definitions
 ****************/

GameState::GameState(int camp) : camp_(camp), other_camp_(1 - camp)
{
}

int GameState::getTime()
{
	return this->time_;
}

bitset<5> GameState::getBrokenLines()
{
	return this->broken_lines_;
}

int GameState::getCamp()
{
	return this->camp_;
}

int GameState::getOtherCamp()
{
	return this->other_camp_;
}

Plant GameState::getPlant(int x, int y)
{
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x == iter->getPosition().x &&
			y == iter->getPosition().y)
		{
			return *iter;
		}
	}

	return Plant(); // if there exists no plant
}

vector<Plant> GameState::getPlantList(int x, int y)
{
	vector<Plant> result;
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

vector<Zombie> GameState::getZombieList(int x, int y)
{
	vector<Zombie> result;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

int GameState::getSun(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(GameState::getCD) Wrong camp number!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->sun_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->sun_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getCD(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(GameState::getCD) Wrong camp number!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw string("(GameState::getCD) Wrong slot number!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw string("(GameState::getCD) Wrong slot number!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->cd_plant_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->cd_zombie_[slot];
	}

	return 0; // to avoid compilation warning
}

int GameState::getScore(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		if (camp < 0 || camp > 1)
		{
			throw string("(Action::isSet) Wrong camp number!");
		}
	}

	if (camp == CAMP.PLANT)
	{
		return this->score_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->score_zombie_;
	}

	return 0; // to avoid compilation warning
}

void GameState::update(IPlayer *player)
{
	/* Update time */
	this->time_ = player->getTime();

	/* Update broken lines */
	for (int i = 0; i < 5; ++i)
	{
		if (player->Camp->getLeftLines()[i])
		{
			this->broken_lines_.reset(i);
		}
		else
		{
			this->broken_lines_.set(i);
		}
	}

	/* Update plant list */
	int **raw_plant_map = player->Camp->getCurrentPlants();
	for (int x = 0; x < 5; ++x)
	{
		for (int y = 0; y < 10; ++y)
		{
			Plant plant;
			vector<Plant>::iterator iter = this->plant_.begin();
			for (; iter != this->plant_.end(); ++iter)
			{
				if (iter->getPosition().x == x &&
					iter->getPosition().y == y)
				{
					plant = *iter;
					break;
				}
			}
			if (raw_plant_map[x][y] == PLANT.NOPLANT &&
				plant.getType() != PLANT.NOPLANT)
			{ // if there removes a plant
				this->plant_.erase(iter);
			}
			if (raw_plant_map[x][y] != PLANT.NOPLANT &&
				plant.getType() == PLANT.NOPLANT)
			{ // if there places a new plant
				this->plant_.push_back(
					Plant(this->getTime(),
						  raw_plant_map[x][y],
						  Position<int>(x, y)));
			}
		}
	}

	/* Update zombie list */
	// int ***raw_zombie_map = player->Camp->getCurrentZombies();
	// for (int x = 0; x < 5; ++x)
	// {
	//     for (int y = 0; y < 10; ++y)
	//     {
	//         Plant plant;
	//         vector<Plant>::iterator iter = this->plant_.begin();
	//         for (; iter != this->plant_.end(); ++iter)
	//         {
	//             if (iter->getPosition().x == x &&
	//                 iter->getPosition().y == y)
	//             {
	//                 plant = *iter;
	//                 break;
	//             }
	//         }
	//         if (raw_plant_map[x][y] == PLANT.NOPLANT &&
	//             plant.getType() != PLANT.NOPLANT)
	//         { // if there removes a plant
	//             this->plant_.erase(iter);
	//         }
	//         if (raw_plant_map[x][y] != PLANT.NOPLANT &&
	//             plant.getType() == PLANT.NOPLANT)
	//         { // if there places a new plant
	//             this->plant_.push_back(
	//                 Plant(this->getTime(),
	//                       raw_plant_map[x][y],
	//                       Position<int>(x, y)));
	//         }
	//     }
	// }

	/* Update sun, CD and score */
	if (this->camp_ == CAMP.PLANT)
	{
		this->sun_plant_ = player->Camp->getSun();

		for (int i = 0; i < 6; ++i)
		{
			this->cd_plant_[i + 1] = player->Camp->getPlantCD()[i];
		}

		this->score_plant_ = player->getScore();

		/* Predict zombie's information */

	}
	else if (this->camp_ == CAMP.ZOMBIE)
	{
		this->sun_zombie_ = player->Camp->getSun();
		for (int i = 0; i < 5; ++i)
		{
			this->cd_zombie_[i + 1] = player->Camp->getPlantCD()[i];
		}
		this->score_zombie_ = player->getScore();

		/* Predict plant's information */

	}
}

void GameState::infer()
{
}

GameState *GameState::GameState::generateSuccessor(Action action)
{
	GameState *next_game_state = new GameState(*this);
	return next_game_state;
}

Game::Game(IPlayer *player)
{
	this->player_ = player;
	this->game_state_ = new GameState(player->Camp->getCurrentType());
}

Game::~Game()
{
	delete this->game_state_;
}

GameState *Game::getGameState()
{
	return this->game_state_;
}

void Game::update(IPlayer *player)
{
	this->player_ = player;
	this->game_state_->update(player);
}

void Game::applyAction(Action action)
{
	int camp = this->game_state_->getCamp();
	if (camp == CAMP.PLANT)
	{
		for (int slot = 1; slot <= 6; ++slot)
		{
			if (action.isSet(camp, slot))
			{
				Position<int> position = action.getPosition(camp, slot);

				/* Check legality */
				if (this->game_state_->getCD(camp, slot) > 0)
				{
					throw string("(Game::applyAction) Cooldown not finished!");
				}
				if (this->game_state_->getBrokenLines()[position.x])
				{
					throw string("(Game::applyAction) The line is broken!");
				}

				this->player_->removePlant(position.x, position.y);
				this->player_->PlacePlant(slot, position.x, position.y);
			}
		}
	}
	else if (camp == CAMP.ZOMBIE)
	{
		for (int slot = 1; slot <= 5; ++slot)
		{
			if (action.isSet(camp, slot))
			{
				/* Check legality */
				if (this->game_state_->getCD(camp, slot) > 0)
				{
					throw string("(Game::applyAction) Cooldown not finished!");
				}
				if (this->game_state_->getBrokenLines()[action.getPosition(camp, slot).x])
				{
					throw string("(Game::applyAction) The line is broken!");
				}

				this->player_->PlaceZombie(slot, action.getPosition(camp, slot).x);
			}
		}
	}
}

#endif
/*** End of inlined file: Game.cpp ***/

using namespace std;
#define ZOMBIE_KIND 5

#define PLANT_KIND 6

#define TOTAL_TIME 2000

#define COLUMN 10

#define ROW 5

#define _includeaih enum PlantType { NOPLANT = 0, SUNFLOWER,
#define _includeiostream WINTERPEASHOOTER, PEASHOOTER, SMALLNUT, PEPPER, SQUASH }; enum
#define _includestdlibh ZombieType { NOZOMBIE = 0, NORMAL, BUCKET,
#define _includemathh POLEVAULT, SLED, GARGANTUAR }; const int plantCost[7]
#define _includecstring = {0, 50, 400, 100, 50, 125,
#define _includevector 50}; const int plantCd[7] = {0, 10,
#define _includequeue 30, 10, 40, 60, 60}; const int
#define _usingnamespacestd zombieCost[6] = {0, 50, 125, 125, 300,
#define _defineZOMBIEKIND5 300}; const int zombieCd[6] = {0, 15,
#define _definePLANTKIND6 20, 20, 25, 25}; const int plantHp[7]
#define _defineTOTALTIME2000 = {0, 300, 300, 300, 4000, 0,
#define _defineCOLUMN10 0}; const int plantDps[7] = {0, 0,
#define _defineROW5 20, 10, 0, 0, 0}; int zombieHp[6]
#define _FILEfile = {0, 270, 820, 200, 1600, 3000};
#define _errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw struct Sunflower { int row, column, cd;
#define _enumPlantTypeNOPLANT0 Sunflower(int Row, int Column) { cd =
#define _SUNFLOWER 24; row = Row, column = Column;
#define _WINTERPEASHOOTER } }; int *zombieNum(int ***zombies) { int
#define _PEASHOOTER cnt[7] = {}, *p = cnt; for
#define _SMALLNUT (int i = 0; i < 5;
#define _PEPPER i++) for (int j = 0; j
#define _SQUASHenumZombieTypeNOZOMBIE0 < 10; j++) for (int k =
#define _NORMAL 0; k < 10; k++) { if
#define _BUCKET (zombies[i][j][k] = -1) break; else cnt[zombies[i][j][k]]++; }
#define _POLEVAULT return p; } int *zombieNum(int zombies[5][10][10]) {
#define _SLED int cnt[7] = {}, *p = cnt;
#define _GARGANTUAR for (int i = 0; i <
#define _zrfscodestarts 5; i++) for (int j = 0;
#define _constintplantCost70504001005012550 j < 10; j++) for (int k
#define _constintplantCd70103010406060 = 0; k < 10; k++) {
#define _constintzombieCost6050125125300300 if (zombies[i][j][k] = -1) break; else cnt[zombies[i][j][k]]++;
#define _constintzombieCd601520202525 } return p; } struct Zombie1 {
#define _constintplantHp70300300300400000 int num; int hp; int coX, coY;
#define _constintplantDps7002010000 Zombie1(int Num, int row) { coX =
#define _intzombieHp6027082020016003000 row, coY = 9; hp = zombieHp[Num];
#define _structSunflowerintrowcolumncd num = Num; } }; struct Plant1
#define _SunflowerintRowintColumncd24 { int num; int hp; int coX,
#define _rowRowcolumnColumn coY; int dps; Plant1(int Num, int row,
#define _intzombieNumintzombiesintcnt7pcnt int col) { num = Num; coX
#define _forinti0i5i = row, coY = col; hp =
#define _forintj0j10j plantHp[Num]; dps = plantDps[Num]; } }; struct
#define _forintk0k10kifzombiesijk1 Actionlist { int plantPlace[5][10] = {}, zombiePlace[5]
#define _break = {}; int plantRemove[5][10] = {}; };
#define _else class Game1 { public: int time, sun,
#define _cntzombiesijkreturnp moon; int plants[5][10], zombies[5][10][10]; int cdPlant[7], cdZombie[6];
#define _zombies int dps[5]; int flagPlant[7], flagZombie[6]; int flagShovel[5][10];
#define _intzombieNumintzombies51010intcnt7pcnt int zombieCostPerRow[5]; vector<Sunflower> sunFlowers; vector<Plant1> vectorPlants; vector<Zombie1>
#define _forinti0i5i_ vectorZombies; void plantremove(int i, int j, IPlayer
#define _forintj0j10j_ *player) { player->removePlant(i, j); flagShovel[i][j] = 1;
#define _forintk0k10kifzombiesijk1_ } void maintain(IPlayer *player) { time++; int
#define _break_ **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies();
#define _else_ moon += int(time / 200.0) + 1;
#define _cntzombiesijkreturnpstructZombieintnum for (int i = 0; i <
#define _inthp 5; i++) for (int j = 0;
#define _intcoXcoY j < 10; j++) { if (plants[i][j]
#define _ZombieintNumintrowcoXrowcoY9 > Plants[i][j] && plants[i][j] != PEPPER &&
#define _hpzombieHpNum plants[i][j] != SQUASH) { if (flagShovel[i][j] ==
#define _numNumintspeedstructPlantintnum 1) { flagShovel[i][j] = 0; } else
#define _inthp_ { int num = plants[i][j]; moon +=
#define _intcoXcoY_ plantCost[num] / 5 + int(sqrt(plantHp[num])); dps[i] -=
#define _intdps plantDps[num]; if (num == 1) { for
#define _PlantintNumintrowintcolnumNum (int k = 0; k < sunFlowers.size();
#define _coXrowcoYcol k++) if (sunFlowers[k].row == i && sunFlowers[k].column
#define _hpplantHpNum == j) { sunFlowers.erase(sunFlowers.begin() + k); break;
#define _dpsplantDpsNum } } } } else if (plants[i][j]
#define _structActionlistintplantPlace510zombiePlace5 < Plants[i][j]) { int num = Plants[i][j];
#define _intplantRemove510classGamepublic sun -= plantCost[num]; dps[i] += plantDps[num]; cdPlant[num]
#define _inttimesunmoon = plantCd[num]; flagPlant[num] = 0; if (num
#define _intplants510zombies51010 == 1) { sun += 25; sunFlowers.push_back(Sunflower(i,
#define _intcdPlant7cdZombie6tick j)); } vectorPlants.push_back(Plant1(Plants[i][j], i, j)); } plants[i][j]
#define _intdps5dps = Plants[i][j]; int flag = 0; for
#define _intflagPlant7flagZombie610 (int k = 0; k < vectorPlants.size();
#define _intflagShovel51010 k++) { if (vectorPlants[k].coX == i &&
#define _intzombieCostPerRow5 vectorPlants[k].coY == j) { if (vectorPlants[k].num !=
#define _vectorSunflowersunFlowers Plants[i][j]) { vectorPlants.erase(vectorPlants.begin() + k); k--; if
#define _vectorPlantvectorPlants (Plants[i][j] != 0) vectorPlants.push_back(Plant1(Plants[i][j], i, j)); }
#define _vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij flag = 1; break; } } if
#define _flagShovelij1voidmaintainIPlayerplayertime (flag == 0 && Plants[i][j] != 0)
#define _intPlantsplayerCampgetCurrentPlantscurrentPlants vectorPlants.push_back(Plant1(Plants[i][j], i, j)); } int *z =
#define _intZombiesplayerCampgetCurrentZombiescurrentZombies zombieNum(zombies), *Z = zombieNum(Zombies); for (int i
#define _mooninttime20001 = 0; i < 5; i++) {
#define _forinti0i5i__ int rowZombie[6] = {}, RowZombie[6] = {};
#define _forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij for (int j = 0; j <
#define _moonplantCostnum5intsqrtplantHpnum 10; j++) for (int k = 0;
#define _dpsiplantDpsnum k < 10; k++) { if (zombies[i][j][k]
#define _ifnum1forintk0ksunFlowerssizek = -1) break; else rowZombie[zombies[i][j][k]]++; } for
#define _ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink (int j = 0; j < 10;
#define _break__ j++) for (int k = 0; k
#define _elseifplantsijPlantsijintnumPlantsij < 10; k++) { if (Zombies[i][j][k] =
#define _sunplantCostnum -1) break; else RowZombie[Zombies[i][j][k]]++; ; } for
#define _dpsiplantDpsnum_ (int j = 0; j < 6;
#define _cdPlantnumplantCdnum j++) if (RowZombie[j] > rowZombie[j]) zombieCostPerRow[i] +=
#define _flagPlantnum0 zombieCost[j]; } for (int i = 0;
#define _ifnum1sun25 i < 7; i++) { if (z[i]
#define _sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij < Z[i]) { } else if (z[i]
#define _intflag0 > Z[i]) { moon -= zombieCost[i]; cdZombie[i]
#define _forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink = zombieCd[i]; flagZombie[i] = 0; } }
#define _k for (int i = 0; i <
#define _ifPlantsij0 5; i++) { for (int j =
#define _vectorPlantspushbackPlantPlantsijijflag1 0; j < 10; j++) { int
#define _break___ k = 0; while (Zombies[i][j][k] != -1)
#define _ifflag0Plantsij0 { zombies[i][j][k] = Zombies[i][j][k]; k++; } }
#define _vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies } vector<int> have_erased; for (int i =
#define _forinti0i5iintrowZombie6RowZombie6 0; i < vectorZombies.size(); i++) { int
#define _forintj0j10j__ have_erased_flag = 0; for (int z =
#define _forintk0k10kifzombiesijk1__ 0; z < have_erased.size(); z += 2)
#define _break____ { if (vectorZombies[i].coX == have_erased[z] && vectorZombies[i].coY
#define _else__ == have_erased[z + 1]) { have_erased_flag =
#define _rowZombiezombiesijkforintj0j10j 1; break; } } if (Plants[vectorZombies[i].coX][vectorZombies[i].coY] !=
#define _forintk0k10kifZombiesijk1 SMALLNUT || have_erased_flag == 1) { continue;
#define _break_____ } else { int num = vectorZombies[i].num;
#define _else___ int original_num_of_this_kind = 0, now_num_of_this_kind = 0;
#define _RowZombieZombiesijk int k = 0; while (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] !=
#define _forintj0j6j -1) { if (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num) {
#define _ifRowZombiejrowZombiej original_num_of_this_kind++; } k++; } k = 0;
#define _zombieCostPerRowizombieCostjforinti0i7iifziZi while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1) { if (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]
#define _zombiedie == num) { now_num_of_this_kind++; } k++; }
#define _elseifziZimoonzombieCosti if (original_num_of_this_kind - now_num_of_this_kind > 0) {
#define _cdZombieizombieCdi vector<int> serialNum; for (int j = 0;
#define _flagZombiei0 j < vectorZombies.size(); j++) { if (vectorZombies[j].num
#define _zombieplaced == num && vectorZombies[i].coY == vectorZombies[j].coY &&
#define _forinti0i5iforintj0j10jintk0 vectorZombies[i].coX == vectorZombies[j].coX) { serialNum.push_back(j); } }
#define _whileZombiesijk1zombiesijkZombiesijk if (now_num_of_this_kind == 0) { for (int
#define _k_ i = serialNum.size() - 1; i >=
#define _vectorinthaveerased 0; i--) { vectorZombies.erase(serialNum[i] + vectorZombies.begin()); }
#define _forinti0ivectorZombiessizeiinthaveerasedflag0 } if (original_num_of_this_kind - now_num_of_this_kind == 1)
#define _forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1 { int small_hp = 5000, small_hp_num =
#define _breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum 0; for (int k = 0; k
#define _intoriginalnumofthiskind0nownumofthiskind0 < serialNum.size(); k++) { if (small_hp >
#define _intk0 vectorZombies[serialNum[k]].hp) { small_hp = vectorZombies[serialNum[k]].hp; small_hp_num =
#define _whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0 k; } } vectorZombies.erase(small_hp_num + vectorZombies.begin()); }
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum have_erased.push_back(vectorZombies[i].coX); have_erased.push_back(vectorZombies[i].coY); } } } for (int
#define _forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj i = 0; i < vectorZombies.size(); i++)
#define _ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin { int num = vectorZombies[i].num; int k
#define _iforiginalnumofthiskindnownumofthiskind1 = 0; int flag_self = 0; int
#define _findthesmallesthp flag_near = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
#define _intsmallhp5000smallhpnum0 { if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { break;
#define _forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp } else { flag_self = 1; }
#define _smallhpnumk } k = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY -
#define _vectorZombieserasesmallhpnumvectorZombiesbegin 1][k] != -1) { if (num ==
#define _haveerasedpushbackvectorZombiesicoX Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { vectorZombies[i].coY--; } else { flag_near
#define _haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum = 1; } } if (flag_self ==
#define _intk0_ 1 && flag_near == 1) { vectorZombies.erase(vectorZombies.begin()
#define _intflagself0 + i); i--; } } for (int
#define _intflagnear0 i = 0; i < 7; i++)
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1 { if (cdPlant[i] > 0) cdPlant[i]--; if
#define _k0 (cdPlant[i] == 0) flagPlant[i] = 1; }
#define _whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1 for (int i = 0; i <
#define _ifflagself1flagnear1vectorZombieserasevectorZombiesbegini 6; i++) { if (cdZombie[i] > 0)
#define _iforinti0i7iifcdPlanti0 cdZombie[i]--; if (cdZombie[i] == 0) flagZombie[i] =
#define _cdPlanti 1; } for (int i = 0;
#define _ifcdPlanti0 i < sunFlowers.size(); i++) { if (sunFlowers[i].cd
#define _flagPlanti1 > 0) sunFlowers[i].cd--; if (sunFlowers[i].cd == 0)
#define _forinti0i6iifcdZombiei0 { sun += 25; sunFlowers[i].cd = 24;
#define _cdZombiei } } } Game1() { time =
#define _ifcdZombiei0 0; sun = 400, moon = 300;
#define _flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0 for (int i = 0; i <
#define _sunFlowersicd 5; i++) for (int j = 0;
#define _ifsunFlowersicd0sun25 j < 10; j++) plants[i][j] = 0,
#define _sunFlowersicd24ticktick flagShovel[i][j] = 0; for (int i =
#define _Gametime0 0; i < 5; i++) for (int
#define _sun400moon300 j = 0; j < 10; j++)
#define _forinti0i5i___ for (int k = 0; k <
#define _forintj0j10j___ 10; k++) zombies[i][j][k] = 0; for (int
#define _plantsij0flagShovelij0 i = 0; i < 5; i++)
#define _forinti0i5i____ dps[i] = 0, zombieCostPerRow[i] = 0; for
#define _forintj0j10j____ (int i = 0; i < 7;
#define _forintk0k10k i++) cdPlant[i] = 0, flagPlant[i] = 1;
#define _zombiesijk0 for (int i = 0; i <
#define _forinti0i5i_____ 6; i++) cdZombie[i] = 0, flagZombie[i] =
#define _dpsi0zombieCostPerRowi0 1; } Game1 tranState(Actionlist q, IPlayer *player);
#define _forinti0i7i }; Game1 Game1::tranState(Actionlist q, IPlayer *player) {
#define _cdPlanti0flagPlanti1 Game1 newGame; { newGame.time = this->time, newGame.sun
#define _forinti0i6i = this->sun, newGame.moon = this->moon; for (int
#define _cdZombiei0flagZombiei1 i = 0; i < 5; i++)
#define _initialize for (int j = 0; j <
#define _GametranStateActionlistqIPlayerplayerq 10; j++) newGame.plants[i][j] = this->plants[i][j], flagShovel[i][j] =
#define _globalstatus this->flagShovel[i][j]; for (int i = 0; i
#define _GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon < 5; i++) for (int j =
#define _forinti0i5i______ 0; j < 10; j++) for (int
#define _forintj0j10j_____ k = 0; k < 10; k++)
#define _newGameplantsijthisplantsijflagShovelijthisflagShovelij newGame.zombies[i][j][k] = this->zombies[i][j][k]; for (int i =
#define _forinti0i5i_______ 0; i < 7; i++) newGame.cdPlant[i] =
#define _forintj0j10j______ this->cdPlant[i], newGame.flagPlant[i] = this->flagPlant[i]; for (int i
#define _forintk0k10k_ = 0; i < 6; i++) newGame.cdZombie[i]
#define _newGamezombiesijkthiszombiesijk = this->cdZombie[i], newGame.flagZombie[i] = this->flagZombie[i]; for (int
#define _forinti0i7i_ i = 0; i < 5; i++)
#define _newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti newGame.dps[i] = this->dps[i], newGame.zombieCostPerRow[i] = this->zombieCostPerRow[i]; }
#define _forinti0i6i_ for (int i = 0; i <
#define _newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei 5; i++) for (int j = 0;
#define _forinti0i5i________ j < 10; j++) { if (q.plantPlace[i][j]
#define _newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame > 0) { int num = q.plantPlace[i][j];
#define _forinti0i5i_________ newGame.sun -= plantCost[num]; newGame.cdPlant[num] = plantCd[num]; newGame.flagPlant[num]
#define _forintj0j10jifqplantPlaceij0intnumqplantPlaceij = 0; newGame.dps[i] += plantDps[num]; newGame.plants[i][j] =
#define _newGamesunplantCostnum num; } if (q.zombiePlace[i] > 0) {
#define _newGamecdPlantnumplantCdnum int num = q.zombiePlace[i]; newGame.moon -= zombieCost[num];
#define _newGameflagPlantnum0 newGame.cdZombie[num] = zombieCd[num]; newGame.flagZombie[num] = 0; }
#define _newGamedpsiplantDpsnum } newGame.maintain(player); return newGame; } class Zombies_num
#define _newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei { public: int normal; int bucket; int
#define _newGamemoonzombieCostnum polevault; int sled; int gargantuar; int total_num;
#define _newGamecdZombienumzombieCdnum Zombies_num() { this->normal = this->bucket = this->polevault
#define _newGameflagZombienum0 = this->sled = this->gargantuar = this->total_num =
#define _newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic 0; } void compute_num(int ***zombies, int rows,
#define _intnormal int columns) { int num = 0;
#define _intbucket for (int i = 0; i <
#define _intpolevault rows; i++) { for (int j =
#define _intsled 0; j < columns; j++) { int
#define _intgargantuar k = 0; while (zombies[i][j][k] != -1)
#define _inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0 { switch (zombies[i][j][k]) { case NORMAL: this->normal++;
#define _forinti0irowsiforintj0jcolumnsjintk0 break; case BUCKET: this->bucket++; break; case POLEVAULT:
#define _whilezombiesijk1switchzombiesijkcaseNORMAL this->polevault++; break; case SLED: this->sled++; break; case
#define _thisnormal GARGANTUAR: this->gargantuar++; break; } num++; k++; }
#define _break______ } } } }; class Plants_num {
#define _caseBUCKET public: int sunflower; int winterpeashooter; int peashooter;
#define _thisbucket int smallnut; int pepper; int squash; Plants_num()
#define _break_______ { this->sunflower = this->winterpeashooter = this->peashooter =
#define _casePOLEVAULT this->smallnut = this->pepper = this->squash = 0;
#define _thispolevault } void compute_num(int **plants, int rows, int
#define _break________ columns) { for (int i = 0;
#define _caseSLED i < rows; i++) for (int j
#define _thissled = 0; j < columns; j++) {
#define _break_________ switch (plants[i][j]) { case SUNFLOWER: this->sunflower++; break;
#define _caseGARGANTUAR case WINTERPEASHOOTER: this->winterpeashooter++; break; case PEASHOOTER: this->peashooter++;
#define _thisgargantuar break; case SMALLNUT: this->smallnut++; break; case PEPPER:
#define _breaknum this->pepper++; break; case SQUASH: this->squash++; break; }
#define _kclassPlantsnumpublic } } }; int calculate_zombie_nums(int ***zombies, int
#define _intsunflower rows, int columns) { int num =
#define _intwinterpeashooter 0; for (int i = 0; i
#define _intpeashooter < rows; i++) { for (int j
#define _intsmallnut = 0; j < columns; j++) {
#define _intpepper int k = 0; while (zombies[i][j][k] !=
#define _intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi -1) { num++; k++; } } }
#define _forintj0jcolumnsjswitchplantsijcaseSUNFLOWER return num; } int choose_Lines_not_Broken(int *Left_lines, int
#define _thissunflower **plants, int column) { for (int i
#define _break__________ = 0; ; i++) { if (Left_lines[i]
#define _caseWINTERPEASHOOTER == 1 && plants[i][column] == NOPLANT) return
#define _thiswinterpeashooter i; } return rand() % ROW; }
#define _break___________ typedef struct pos_and_value { int pos[2]; double
#define _casePEASHOOTER value; } pos_and_value; class value_plant_func { public:
#define _thispeashooter double noplant; pos_and_value sunflower; pos_and_value peashooter; pos_and_value
#define _break____________ winterpeashooter; pos_and_value smallnut; pos_and_value pepper; pos_and_value squash;
#define _caseSMALLNUT int generating_row; IPlayer *player; Game1 game; int
#define _thissmallnut NotBrokenLinesNum; int KillZombiesScore; int LeftPlants; int Score;
#define _break_____________ int time; int *PlaceCD; int **Plants; int
#define _casePEPPER ***Zombies; int *LeftLines; int Sun; int zombie_nums;
#define _thispepper value_plant_func(int NotBrokenLinesNum, int KillZombiesScore, int Score, int
#define _break______________ time, int *PlaceCD, int **Plants, int ***Zombies,
#define _caseSQUASH int *LeftLines, int Sun, IPlayer *player, Game1
#define _thissquash game) { this->NotBrokenLinesNum = NotBrokenLinesNum; this->KillZombiesScore =
#define _breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0 KillZombiesScore; this->Score = Score; this->time = time;
#define _forinti0irowsiforintj0jcolumnsjintk0_ this->PlaceCD = PlaceCD; this->Plants = Plants; this->Zombies
#define _whilezombiesijk1num = Zombies; this->LeftLines = LeftLines; this->Sun =
#define _kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT Sun; this->player = player; this->generating_row = 1;
#define _returnireturnrandROWtypedefstructposandvalueintpos2 this->game = game; } int **sum_plants_per_row() {
#define _doublevalue int **plants_num_format = (int **)malloc(ROW * sizeof(int
#define _posandvalueclassvalueplantfuncpublic *)); for (int i = 0; i
#define _doublenoplant < ROW; i++) { plants_num_format[i] = (int
#define _posandvaluesunflower *)malloc(sizeof(int) * PLANT_KIND); memset(plants_num_format[i], 0, PLANT_KIND *
#define _posandvaluepeashooter sizeof(int)); } for (int i = 0;
#define _posandvaluewinterpeashooter i < ROW; i++) { for (int
#define _posandvaluesmallnut j = 0; j < COLUMN; j++)
#define _posandvaluepepper { switch (this->Plants[i][j]) { case SUNFLOWER: plants_num_format[i][SUNFLOWER]++;
#define _posandvaluesquash break; case WINTERPEASHOOTER: plants_num_format[i][WINTERPEASHOOTER]++; break; case PEASHOOTER:
#define _intgeneratingrow plants_num_format[i][PEASHOOTER]++; break; case SMALLNUT: plants_num_format[i][SMALLNUT]++; break; case
#define _IPlayerplayer PEPPER: plants_num_format[i][PEPPER]++; break; case SQUASH: plants_num_format[i][SQUASH]++; break;
#define _Gamegame } } } return plants_num_format; } void
#define _doublevaluePLANTKIND1 beginning_operation() { if (this->time <= 3) {
#define _intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum this->player->PlacePlant(SUNFLOWER, this->generating_row, 1); this->player->PlacePlant(SMALLNUT, this->generating_row, COLUMN); }
#define _intKillZombiesScore } void GameState_2_400() { if (this->time >
#define _intLeftPlants 2 && this->time < 150) { int
#define _intScore alarming_flag = -1; for (int i =
#define _inttime 0; i < ROW; i++) { if
#define _intPlaceCD (i != this->generating_row) { if (time <
#define _intPlants 20) for (int j = 0; j
#define _intZombies < COLUMN; j++) { int k =
#define _intLeftLines 0; while (this->Zombies[i][j][k] != -1) { if
#define _intSun (j < 3) alarming_flag = i; if
#define _intzombienumsvalueplantfuncintNotBrokenLinesNum (this->Sun >= 70) switch (this->Zombies[i][j][k]) { case
#define _intKillZombiesScore_ POLEVAULT: case SLED: this->player->PlacePlant(SQUASH, i, (j -
#define _intScore_ 1 < 0 ? 0 : j
#define _inttime_ - 1)); break; case BUCKET: if (this->PlaceCD[SQUASH]
#define _intPlaceCD_ == 0) this->player->PlacePlant(SQUASH, i, (j - 1
#define _intPlants_ < 0 ? 0 : j -
#define _intZombies_ 1)); else if (j < 3) this->player->PlacePlant(PEPPER,
#define _intLeftLines_ i, (j - 1 < 0 ?
#define _intSunIPlayerplayer 0 : j - 1)); break; case
#define _GamegamethisNotBrokenLinesNumNotBrokenLinesNum GARGANTUAR: this->player->PlacePlant(SQUASH, i, (j - 1 <
#define _thisKillZombiesScoreKillZombiesScore 0 ? 0 : j - 1));
#define _thisScoreScore if (j < 4) this->player->PlacePlant(PEPPER, i, 8);
#define _thistimetime break; case NORMAL: this->player->PlacePlant(PEASHOOTER, i, 0); this->player->PlacePlant(SMALLNUT,
#define _thisPlaceCDPlaceCD i, (j - 1 < 0 ?
#define _thisPlantsPlants 0 : j - 1)); break; }
#define _thisZombiesZombies k++; } } } else for (int
#define _thisLeftLinesLeftLines j = 0; j < COLUMN; j++)
#define _thisSunSun { int k = 0; while (this->Zombies[this->generating_row][j][k]
#define _thisplayerplayer != -1) { if (this->Sun >= 70)
#define _thisgeneratingrow1 switch (this->Zombies[this->generating_row][j][k]) { case POLEVAULT: case BUCKET:
#define _thisgamegameintsumplantsperrow case SLED: this->player->PlacePlant(SQUASH, this->generating_row, 5); break; case
#define _rowsplantskindnumperrow GARGANTUAR: this->player->PlacePlant(SQUASH, this->generating_row, (j - 1 <
#define _intplantsnumformatintmallocROWsizeofint 0 ? 0 : j - 1));
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND if (j < 4) this->player->PlacePlant(PEPPER, this->generating_row, 8);
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER break; case NORMAL: this->player->PlacePlant(SMALLNUT, this->generating_row, (j -
#define _plantsnumformatiSUNFLOWER 1 < 0 ? 1 : j
#define _break_______________ - 1)); break; } if (j <
#define _caseWINTERPEASHOOTER_ (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 + 1 && this->PlaceCD[SQUASH
#define _plantsnumformatiWINTERPEASHOOTER - 1] != 0) { this->player->PlacePlant(PEPPER, i,
#define _break________________ 8); } k++; } } } int
#define _casePEASHOOTER_ num = 0, pos = 0; for
#define _plantsnumformatiPEASHOOTER (int i = 0; i < COLUMN;
#define _break_________________ i++) { if (Plants[this->generating_row][i] == SUNFLOWER) {
#define _caseSMALLNUT_ num++; } if (Plants[this->generating_row][i] != NOPLANT) {
#define _plantsnumformatiSMALLNUT pos = i; } } if (num
#define _break__________________ < 5) this->player->PlacePlant(SUNFLOWER, this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1);
#define _casePEPPER_ if (alarming_flag != -1) { if (this->PlaceCD[SQUASH
#define _plantsnumformatiPEPPER - 1] == 0) { this->player->PlacePlant(SQUASH, alarming_flag,
#define _break___________________ COLUMN - 1); } else this->player->PlacePlant(PEPPER, alarming_flag,
#define _caseSQUASH_ COLUMN - 1); } } } void
#define _plantsnumformatiSQUASH GameState_50_200() { if (this->time > 50 &&
#define _breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1 this->time < 200) { if (this->Sun >=
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1 400) this->player->PlacePlant(WINTERPEASHOOTER, this->generating_row, 0); } } void
#define _voidGameState250ifthistime2thistime200intalarmingflag1 value_peashooter_origin() { if (this->time > 10) if
#define _forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0 (this->PlaceCD[PEASHOOTER - 1] == 0) { double
#define _whilethisZombiesijk1ifj3 **loss = (double **)malloc(ROW * sizeof(double *));
#define _alarmingflagi for (int i = 0; i <
#define _ifthisSun70 ROW; i++) { loss[i] = (double *)malloc(COLUMN
#define _switchthisZombiesijkcasePOLEVAULT * sizeof(double)); memset(loss[i], 0, COLUMN * sizeof(double));
#define _caseSLED_ } double max = -10000, max_index[2] =
#define _thisplayerPlacePlantSQUASHij100j1 {0, 0}; for (int i = 0;
#define _break____________________ i < ROW; i++) for (int j
#define _caseBUCKET_ = 0; j < COLUMN; j++) {
#define _ifthisPlaceCDSQUASH0 if (this->Plants[i][j] != NOPLANT) loss[i][j] = -10000;
#define _thisplayerPlacePlantSQUASHij100j1_ else { double row = (i ==
#define _elseifj3 this->generating_row ? -10 : 0); loss[i][j] +=
#define _thisplayerPlacePlantPEPPERij100j1 row; double column = (25); loss[i][j] +=
#define _break_____________________ column * exp(-column) - 10; double zombie[ZOMBIE_KIND]
#define _caseGARGANTUAR_ = {6, -10, -2, -40, -20}; for
#define _thisplayerPlacePlantSQUASHij100j1__ (int column0 = 0; j < COLUMN;
#define _ifj4 j++) { int k = 0; while
#define _thisplayerPlacePlantPEPPERi8 (Zombies[i][column0][k] != -1) { loss[i][j] += zombie[Zombies[i][column0][k]
#define _break______________________ - 1] / (+COLUMN - j); k++;
#define _caseNORMAL } } double plant[PLANT_KIND] = {2, 0,
#define _thisplayerPlacePlantPEASHOOTERi1 -2, 5, 2, 0}; for (int column0
#define _thisplayerPlacePlantSMALLNUTij100j1 = 0; j < COLUMN; j++) {
#define _breakkelse if (this->Plants[i][column0] != NOPLANT) loss[i][j] += plant[this->Plants[i][column0]]
#define _forintj0jCOLUMNjintk0 * (1 + (column0 - COLUMN /
#define _whilethisZombiesthisgeneratingrowjk1ifthisSun70 2) / 40); } double time_rate =
#define _switchthisZombiesthisgeneratingrowjk 30; loss[i][j] += time_rate * (1 /
#define _casePOLEVAULT_ (1 + exp((+this->time - TOTAL_TIME / 5)
#define _caseBUCKET__ / 200)) - 0.5); } if (max
#define _caseSLED__ < loss[i][j]) { max_index[0] = i; max_index[1]
#define _thisplayerPlacePlantSQUASHthisgeneratingrow5 = j; } } this->peashooter.pos[0] = max_index[0];
#define _break_______________________ this->peashooter.pos[1] = max_index[1]; this->peashooter.value = max; }
#define _caseGARGANTUAR__ } bool have_type_of_zombies(int *zombie, int type) {
#define _thisplayerPlacePlantSQUASHthisgeneratingrowj100j1 int k = 0; while (zombie[k] !=
#define _ifj4_ -1) { if (zombie[k] == type) return
#define _thisplayerPlacePlantPEPPERthisgeneratingrow8 true; k++; } return false; } int
#define _break________________________ search_for_nearest_zombie(int ***zombie, int row, int column) {
#define _caseNORMAL_ int nearest = 100; for (int j
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k = 0; j < COLUMN; j++) {
#define _thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1 int k = 0; while (Zombies[row][j][k] !=
#define _ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else -1) { if (nearest > j -
#define _thisplayerPlacePlantPEPPERalarmingflagCOLUMN1 column) nearest = j - column; k++;
#define _voidGameState50200ifthistime50thistime200ifthisSun400 } } return nearest; } void judge_Lines_not_broken(double
#define _thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0 *final_choice) { for (int i = 0;
#define _voidvaluepeashooteroriginifthistime50 i < ROW; i++) { if (this->LeftLines[i]
#define _ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble == 0) { final_choice[i] = -100000; }
#define _forinti0iROWilossidoublemallocCOLUMNsizeofdouble } } void value_peashooter0() { if (this->time
#define _memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200 > 30) { if (this->PlaceCD[PEASHOOTER - 1]
#define _forinti0iROWi == 0) { for (int i =
#define _forintj0jCOLUMNjifthisPlantsijNOPLANT 0; i < ROW; i++) { if
#define _lossij10000 (LeftLines[i] == 1) { for (int j
#define _else____ = 0; j < COLUMN; j++) {
#define _doublerowithisgeneratingrow100 int k = 0; while (Zombies[i][j][k] !=
#define _lossijrow -1) { k++; } if (k ==
#define _doublecolumn25 1 && Zombies[i][j][0] == NORMAL && j
#define _lossijcolumnexpcolumn10 >= COLUMN - 2) { this->player->PlacePlant(PEASHOOTER, i,
#define _doublezombieZOMBIEKIND61024020 0); } else if (k > 0
#define _forintcolumn00jCOLUMNjintk0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) &&
#define _whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj Sun < 400 && time < 500
#define _k__ && j < 5) { int start
#define _doubleplantPLANTKIND202520 = 0; while (Plants[i][start] != NOPLANT) {
#define _forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT start++; } if (search_for_nearest_zombie(Zombies, i, start) >=
#define _lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30 1) { player->PlacePlant(PEASHOOTER, i, start); } }
#define _lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i } } } } } } void
#define _maxindex1j value_peashooter() { double score[5] = {0, 0,
#define _thispeashooterpos0maxindex0 0, 0, 0}; double plant_cost[7] = {0,
#define _thispeashooterpos1maxindex1 10, -6, -8, 15, 10, 0}; judge_Lines_not_broken(score);
#define _thispeashootervaluemax for (int i = 0; i <
#define _boolhavetypeofzombiesintzombieinttypeintk0 ROW; i++) { for (int j =
#define _whilezombiek1ifzombiektype 0; j < COLUMN; j++) { double
#define _returntrue distance_cost = 1; switch (Plants[i][j]) { case
#define _kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0 SUNFLOWER: distance_cost *= 1 + j /
#define _forintj0jCOLUMNjintk0_ 100; } score[i] += plant_cost[Plants[i][j]] * distance_cost;
#define _whileZombiesrowjk1ifnearestjcolumn } } double zombie_cost[5] = {10, 5,
#define _nearestjcolumn -5, -20, -20}; for (int i =
#define _k___ 0; i < ROW; i++) { for
#define _returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0 (int j = 0; j < COLUMN;
#define _whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0 j++) { int k = 0; while
#define _whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart (Zombies[i][j][k] != -1) { double distance_cost =
#define _intrankdoublearrayintlendoublemaxarray0 1; switch (Zombies[i][j][k]) { case NORMAL: distance_cost
#define _intserialnumintmalloclensizeofint = 1 - j / 30; }
#define _forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost;
#define _arrayjarrayj1 k++; } } } int *serial_num =
#define _arrayj1swap rank(score, ROW); int i = 0; for
#define _intserialswapserialnumj (; i < 10; i++) { if
#define _serialnumjserialnumj1 (Plants[serial_num[0]][i] == NOPLANT) break; } if (i
#define _serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10 <= 3) { if (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1],
#define _ifthisPlaceCDSUNFLOWER0doublescore500000 SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i +
#define _judgeLinesnotbrokenscore 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR))) player->PlacePlant(PEASHOOTER, serial_num[0],
#define _forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER i); } free(serial_num); } int *rank(double *array,
#define _scorei10 int len) { double max = array[0];
#define _ifPlantsijPEASHOOTER int *serial_num = (int *)malloc(len * sizeof(int));
#define _scorei501expj for (int i = 0; i <
#define _ifPlantsijWINTERPEASHOOTER len; i++) { serial_num[i] = i; }
#define _scorei1001expj for (int i = 0; i <
#define _ifPlantsijSMALLNUT len - 1; i++) { for (int
#define _scorei100001j5j51 j = 0; j < len -
#define _forinti0iROWi_ 1; j++) { if (array[j] < array[j
#define _forintj0jCOLUMNjintk0__ + 1]) { double swap = array[j];
#define _whileZombiesijk1ifZombiesijkNORMAL array[j] = array[j + 1]; array[j +
#define _scorei10101j 1] = swap; int serial_swap = serial_num[j];
#define _ifZombiesijkBUCKET serial_num[j] = serial_num[j + 1]; serial_num[j +
#define _scorei50101j 1] = serial_swap; } } } return
#define _ifZombiesijkPOLEVAULT serial_num; } void value_sunflower() { int sunflower_num
#define _scorei30101j = 0; for (int i = 0;
#define _ifZombiesijkGARGANTUAR i < ROW; i++) for (int j
#define _scorei100101j = 0; j < COLUMN; j++) {
#define _ifZombiesijkSLED if (Plants[i][j] == SUNFLOWER) { sunflower_num++; }
#define _scorei80101j } double b = -0.01 * (this->time
#define _kintsunflowernumingeneratingrow0 * -300) * (this->time * -300) /
#define _forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER 10000 + 1; if (this->time > 9
#define _sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW && sunflower_num < 9 + (b <
#define _forinti0iROWiintj0 0 ? 0 : b) && this->Sun
#define _whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j < 1000) if (this->PlaceCD[SUNFLOWER - 1] ==
#define _voidvaluesmallmnutifthisPlaceCDSMALLNUT0 0) { double score[5] = {0, 0,
#define _ifthistime20doublescoreROW00000 0, 0, 0}; judge_Lines_not_broken(score); for (int i
#define _judgeLinesnotbrokenscorevalueplants = 0; i < ROW; i++) {
#define _doubleplantsscore7052020710 for (int j = 0; j <
#define _forinti0iROWiforintj0jCOLUMNjdoubledistancecost1 COLUMN; j++) { if (Plants[i][j] == SUNFLOWER)
#define _switchPlantsijcaseSUNFLOWER score[i] -= 120; if (Plants[i][j] == PEASHOOTER)
#define _distancecost15005j score[i] += 50 * (1 * (exp(-j)));
#define _break_________________________ if (Plants[i][j] == WINTERPEASHOOTER) score[i] += 100
#define _casePEASHOOTER__ * (1 * (exp(-j))); if (Plants[i][j] ==
#define _distancecost2009j SMALLNUT) score[i] += 100 * (-0.01 *
#define _break__________________________ (j - 5) * (j - 5)
#define _caseWINTERPEASHOOTER__ + 1); } } for (int i
#define _distancecost201j = 0; i < ROW; i++) for
#define _breakscoreiPlantsijplantsscoreidistancecostvaluezombies (int j = 0; j < COLUMN;
#define _doublezombiecost520101246 j++) { int k = 0; while
#define _intnearestzombieperrow500000 (Zombies[i][j][k] != -1) { if (Zombies[i][j][k] ==
#define _forinti0iROWiforintjCOLUMN1j0jintk0 NORMAL) score[i] -= 10 * (1 /
#define _whileZombiesijk1doubledistancecost1 (0.1 + j)); if (Zombies[i][j][k] == BUCKET)
#define _switchZombiesijk score[i] -= 50 * (1 / (0.1
#define _caseNORMAL__ + j)); if (Zombies[i][j][k] == POLEVAULT) score[i]
#define _distancecost12002j -= 30 * (1 / (0.1 +
#define _break___________________________ j)); if (Zombies[i][j][k] == GARGANTUAR) score[i] -=
#define _casePOLEVAULT__ 100 * (1 / (0.1 + j));
#define _distancecost11001j if (Zombies[i][j][k] == SLED) score[i] -= 80
#define _break____________________________ * (1 / (0.1 + j)); k++;
#define _caseBUCKET___ } } int *serial_num = rank(score, ROW);
#define _distancecost13004j int j = 0; while (Plants[serial_num[0]][j +
#define _breakscoreizombiecostZombiesijk1distancecost 2] != NOPLANT && j < 8)
#define _k____ { j++; } if (j < 8)
#define _nearestzombieperrowij if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j],
#define _intserialnumrankscoreROW SLED) || have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) ||
#define _forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1 have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR))) player->PlacePlant(SUNFLOWER, serial_num[0], j + 2);
#define _voidvaluethisvaluepeashooter free(serial_num); } } void value_smallmnut() { if
#define _thisvaluesunflower (this->PlaceCD[SMALLNUT - 1] == 0) if (this->time
#define _thisvaluesmallmnut > 20) { double score[ROW] = {0,
#define _doublemax100000 0, 0, 0, 0}; judge_Lines_not_broken(score); double plants_score[7]
#define _doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue = {0, 5, 20, 20, -300, -2,
#define _thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation 0}; for (int i = 0; i
#define _thisGameState250 < ROW; i++) { for (int j
#define _thisGameState50200 = 0; j < COLUMN; j++) {
#define _thisvalue double distance_cost = 1; switch (Plants[i][j]) {
#define _classvaluezombiefuncpublic case SUNFLOWER: distance_cost = 1.5 - 0.05
#define _intnozombie * j; break; case PEASHOOTER: distance_cost =
#define _intnormalchoice 2 - 0.09 * j; break; case
#define _intbucketchoice WINTERPEASHOOTER: distance_cost = 2 - 0.1 *
#define _intpolevaultchoice j; break; } score[i] += plants_score[Plants[i][j]] *
#define _intsledchoice distance_cost; } } double zombie_cost[5] = {2.0,
#define _intgargantuarchoice 10, 12, -1000, -2000}; int nearest_zombie_per_row[5] =
#define _doublevalueZOMBIEKIND {9, 9, 9, 9, 9}; for (int
#define _intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore i = 0; i < ROW; i++)
#define _intKillPlantsScore { for (int j = COLUMN -
#define _intLeftPlants_ 1; j >= 0; j--) { int
#define _intScore__ k = 0; while (Zombies[i][j][k] != -1)
#define _inttime__ { double distance_cost = 1; switch (Zombies[i][j][k])
#define _intPlaceCD__ { case NORMAL: distance_cost = 1.2 -
#define _intPlants__ 0.02 * (j); break; case POLEVAULT: distance_cost
#define _intZombies__ = 1.1 - 0.01 * j; break;
#define _intLeftLines__ case BUCKET: distance_cost = 1.3 - 0.04
#define _intSun_ * j; break; } score[i] += zombie_cost[(Zombies[i][j][k]
#define _intzombienums - 1)] * distance_cost; k++; nearest_zombie_per_row[i] =
#define _GamegamevaluezombiefuncintBrokenLinesScore j; } } } int *serial_num =
#define _intKillPlantsScore_ rank(score, ROW); int j = COLUMN -
#define _intScore___ 1; if (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT)
#define _inttime___ { for (; j >= 0; j--)
#define _intPlaceCD___ { if (Plants[serial_num[0]][j] == NOPLANT) break; }
#define _intPlants___ player->PlacePlant(SMALLNUT, serial_num[0], j); } else player->PlacePlant(SMALLNUT, serial_num[0],
#define _intZombies___ (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 0
#define _intLeftLines___ : (nearest_zombie_per_row[serial_num[0]] - 1)); free(serial_num); } }
#define _intSun__ void value_winterpeashooter() { if (this->PlaceCD[WINTERPEASHOOTER - 1]
#define _intzombienums_ == 0) { if (this->time > 80)
#define _Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0 { double score[5] = {0.0, 0, 0,
#define _thisBrokenLinesScoreBrokenLinesScore 0, 0}; judge_Lines_not_broken(score); double plant_cost[7] = {0.0,
#define _thisKillPlantsScoreKillPlantsScore -2.5, -4, -5, -10, 6, 0}; if
#define _thisScoreScore_ (time > 500) { plant_cost[4] = 2;
#define _thistimetime_ } for (int i = 0; i
#define _thisPlaceCDPlaceCD_ < ROW; i++) { for (int j
#define _thisPlantsPlants_ = 0; j < COLUMN; j++) {
#define _thisZombiesZombies_ score[i] += plant_cost[Plants[i][j]]; } } double zombie_cost[5]
#define _thisLeftLinesLeftLines_ = {5, 20, 20, -2, -4}; for
#define _thisSunSun_ (int i = 0; i < ROW;
#define _thiszombienumszombienums i++) for (int j = 0; j
#define _thisgamegame < COLUMN; j++) { int k =
#define _forinti0iZOMBIEKINDi 0; while (Zombies[i][j][k] != -1) { score[i]
#define _thisvaluei0 += zombie_cost[Zombies[i][j][k] - 1]; k++; } }
#define _memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile int *serial_num = rank(score, ROW); if (this->time
#define _fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0 < 300) { int j = 0;
#define _forinti0iROWiaveragecostiaverage5 while (Plants[serial_num[0]][j] != NOPLANT && j <
#define _forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05 8) { j++; } if (j <
#define _squaredistance5ifsquaredistancepowthistime001100return1else 5) { if (search_for_nearest_zombie(Zombies, serial_num[0], j) >=
#define _return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow 1) { player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j); } }
#define _ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei } else { int limit = (int)(this->time
#define _decision0i1 / 400) + 3; for (int i
#define _decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei = 0; i < limit; i++) {
#define _decision0i1_ if ((Plants[serial_num[0]][i] == PEASHOOTER && this->time >
#define _decision1thischoicei 600) || (Plants[serial_num[0]][i] == SUNFLOWER)) { if
#define _ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun
#define _thisKillZombiesScoreKillZombiesScore_ > 400) { player->removePlant(serial_num[0], i); player->PlacePlant(WINTERPEASHOOTER, serial_num[0],
#define _thisLeftPlantsLeftPlants i); break; } } } } free(serial_num);
#define _thisScoreScore__ } } } void value_squash() { if
#define _thistimetime__ (this->PlaceCD[SQUASH - 1] == 0 && this->time
#define _thisPlaceCDPlaceCD__ > 50) { double score[5] = {0,
#define _thisPlantsPlants__ 0, 0, 0, 0}; double plant_cost[7] =
#define _thisZombiesZombies__ {0, 5, 20, 3, -10, -100, -200};
#define _thisLeftLinesLeftLines__ for (int i = 0; i <
#define _thisSunSunforinti0iROWifinalchoicei0 5; i++) { for (int j =
#define _boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10 0; j < COLUMN; j++) { double
#define _thisvaluekind1100000 distance_cost = 0.2 + 0.08 * j;
#define _returntrueelse score[i] += plant_cost[Plants[i][j]] * distance_cost; } }
#define _returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00 double zombie_cost[5] = {-5, 10, 2, 100,
#define _ifthisLeftLinesrow0cost100000elseintnumperrow0 200}; for (int i = 0; i
#define _doubletoomanyzombiescost15 < ROW; i++) for (int j =
#define _forintj0jCOLUMNjintk0___ 0; j < COLUMN; j++) { int
#define _whilethisZombiesrowjk1switchkindcasePOLEVAULT k = 0; while (Zombies[i][j][k] != -1)
#define _costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost { double distance_cost = 11 / (j
#define _break_____________________________ + 1); score[i] += zombie_cost[Zombies[i][j][k] - 1]
#define _default * distance_cost; k++; } } int *serial_num
#define _costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k = rank(score, ROW); int nearest_zombie = 9;
#define _numperrow for (int j = COLUMN - 1;
#define _costnumperrowtoomanyzombiescostreturncostintsumplantsperrow j >= 0; j--) { int k
#define _rowsplantskindnumperrow_ = 0; while (Zombies[serial_num[0]][j][k] != -1) {
#define _intplantsnumformatintmallocROWsizeofint_ nearest_zombie = j; k++; } } if
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_ (nearest_zombie - 1 >= 0) if (Plants[serial_num[0]][nearest_zombie
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_ - 1] == NOPLANT) { player->PlacePlant(SQUASH, serial_num[0],
#define _plantsnumformatiSUNFLOWER1 nearest_zombie - 1); } else if (Plants[serial_num[0]][nearest_zombie
#define _break______________________________ - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie -
#define _caseWINTERPEASHOOTER___ 1] != NOPLANT && time > 400
#define _plantsnumformatiWINTERPEASHOOTER1 && this->Sun > 50) { player->removePlant(serial_num[0], nearest_zombie
#define _break_______________________________ - 1); player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
#define _casePEASHOOTER___ } free(serial_num); } } void value_pepper(){ }
#define _plantsnumformatiPEASHOOTER1 void value() { this->value_peashooter(); this->value_sunflower(); this->value_smallmnut(); this->value_winterpeashooter();
#define _break________________________________ this->value_squash(); } void make_decision() { this->beginning_operation(); this->GameState_2_400();
#define _caseSMALLNUT__ if (this->time > 25) this->value(); } };
#define _plantsnumformatiSMALLNUT1 class value_zombie_func { public: int nozombie; int
#define _break_________________________________ normal_choice; int bucket_choice; int polevault_choice; int sled_choice;
#define _casePEPPER__ int gargantuar_choice; double value[ZOMBIE_KIND]; int choice[ZOMBIE_KIND] =
#define _plantsnumformatiPEPPER1 {this->normal_choice, this->bucket_choice, this->polevault_choice, this->sled_choice, this->gargantuar_choice}; int BrokenLinesScore;
#define _break__________________________________ int KillPlantsScore; int LeftPlants; int Score; int
#define _caseSQUASH__ time; int *PlaceCD; int **Plants; int ***Zombies;
#define _plantsnumformatiSQUASH1 int *LeftLines; int Sun; int zombie_nums; Game1
#define _breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00 game; value_zombie_func(int BrokenLinesScore, int KillPlantsScore, int Score,
#define _switchkindcaseNORMAL int time, int *PlaceCD, int **Plants, int
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10 ***Zombies, int *LeftLines, int Sun, int zombie_nums,
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12 Game1 game) { this->normal_choice = this->bucket_choice =
#define _break___________________________________ this->polevault_choice = this->sled_choice = this->gargantuar_choice = 0;
#define _caseBUCKET____ this->BrokenLinesScore = BrokenLinesScore; this->KillPlantsScore = KillPlantsScore; this->Score
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10 = Score; this->time = time; this->PlaceCD =
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1 PlaceCD; this->Plants = Plants; this->Zombies = Zombies;
#define _break____________________________________ this->LeftLines = LeftLines; this->Sun = Sun; this->zombie_nums
#define _casePOLEVAULT___ = zombie_nums; this->game = game; for (int
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED i = 0; i < ZOMBIE_KIND; i++)
#define _ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break this->value[i] = 0; memset(this->choice, 0, ZOMBIE_KIND *
#define _caseGARGANTUAR___ (sizeof(int))); } int judge_whether_big_cost_in_one_row(int *cost) { double
#define _ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11 average = 0, square_distance = 0; for
#define _plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11 (int i = 0; i < ROW;
#define _forintj0jCOLUMNjifPlantsrowjNOPLANT i++) { average += cost[i]; } average
#define _costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000 /= 5; for (int i = 0;
#define _intindex0 i < ROW; i++) { square_distance +=
#define _forinti0ilengthiifmaxaimaxai (cost[i] - average) * (cost[i] - average);
#define _indexi } square_distance = pow(square_distance, 0.5); square_distance /=
#define _returnindex 5; if (square_distance > pow(this->time, 0.2) *
#define _NORMAL_ 400) { return 1; } else return
#define _BUCKET_ 0; } void make_decision(int *decision) { double
#define _POLEVAULT_ max = -10000; for (int i =
#define _SLED_ 0; i < 5; i++) { if
#define _GARGANTUARSUNFLOWER (max < this->value[i]) { max = this->value[i];
#define _WINTERPEASHOOTER_ decision[0] = i + 1; decision[1] =
#define _PEASHOOTER_ this->choice[i]; } } } bool whether_need_compute(int kind)
#define _SMALLNUT_ { if (this->PlaceCD[kind - 1] > 0)
#define _PEPPER_ { this->choice[kind - 1] = 0; this->value[kind
#define _SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000 - 1] = -100000; return true; }
#define _judgeLinesnotbrokenfinalchoice else return false; } double zombie_cost(int row,
#define _ifthiswhetherneedcomputeNORMALreturn double *zombies_paras, double distance_cost, double distance_rate, int
#define _zombie kind) { double cost = 0.0; if
#define _doublezombiesparasZOMBIEKIND54231 (this->LeftLines[row] == 0) { cost = -100000;
#define _doubledistancecost1distancerate005 } else { int num_per_row = 0;
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL double too_many_zombies_cost = -1.5; for (int j
#define _plant = 0; j < COLUMN; j++) {
#define _intplantsnumformatROWPLANTKIND0 int k = 0; while (this->Zombies[row][j][k] !=
#define _doubleplantsparaPLANTKIND88221005 -1) { switch (kind) { case POLEVAULT:
#define _intsumplantsperrow0thissumplantsperrow cost += zombies_paras[this->Zombies[row][j][k] - 1] * ((COLUMN
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL - j - distance_cost) * (COLUMN -
#define _time j - distance_cost)); break; default: cost +=
#define _doubletimecost2011expthistimeTOTALTIME210005 zombies_paras[this->Zombies[row][j][k] - 1] * (-distance_rate * (COLUMN
#define _forinti0iROWi__ - j - distance_cost) * (COLUMN -
#define _finalchoiceitimecostSun j - distance_cost) + 2); } k++;
#define _doublesunbaseline60sunsub02 num_per_row++; } } cost += num_per_row *
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub too_many_zombies_cost; } return cost; } int **sum_plants_per_row()
#define _forinti0iROWi___ { int **plants_num_format = (int **)malloc(ROW *
#define _finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW sizeof(int *)); for (int i = 0;
#define _thisvalueNORMAL1finalchoicethischoiceNORMAL1 i < ROW; i++) { plants_num_format[i] =
#define _voidvaluebucketdoublefinalchoiceROW00000 (int *)malloc(sizeof(int) * PLANT_KIND); memset(plants_num_format[i], 0, PLANT_KIND
#define _judgeLinesnotbrokenfinalchoice_ * sizeof(int)); } for (int i =
#define _ifthiswhetherneedcomputeBUCKETreturn 0; i < ROW; i++) { for
#define _zombie_ (int j = 0; j < PLANT_KIND;
#define _doublezombiesparasZOMBIEKIND254thistime100100522 j++) { plants_num_format[i][j] = 0; } }
#define _doubledistancecost25distancerate01 for (int i = 0; i <
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET ROW; i++) { for (int j =
#define _plant_ 0; j < COLUMN; j++) { switch
#define _intplantsnumformatROWPLANTKIND0_ (this->Plants[i][j]) { case SUNFLOWER: plants_num_format[i][SUNFLOWER - 1]++;
#define _doubleplantsparaPLANTKIND63231004 break; case WINTERPEASHOOTER: plants_num_format[i][WINTERPEASHOOTER - 1]++; break;
#define _intsumplantsperrowthissumplantsperrow case PEASHOOTER: plants_num_format[i][PEASHOOTER - 1]++; break; case
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET SMALLNUT: plants_num_format[i][SMALLNUT - 1]++; break; case PEPPER:
#define _time_ plants_num_format[i][PEPPER - 1]++; break; case SQUASH: plants_num_format[i][SQUASH
#define _doubletimecost2011expthistimeTOTALTIME310005 - 1]++; break; } } } return
#define _forinti0iROWi____ plants_num_format; } double plant_cost(int row, int **plants_num_format,
#define _finalchoiceitimecostSun_ double *plants_para, int kind) { double origin_para[PLANT_KIND];
#define _doublesunbaseline150sunsub05 for (int i = 0; i <
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub PLANT_KIND; i++) { origin_para[i] = plants_para[i]; }
#define _forinti0iROWi_____ double cost = 0.0; switch (kind) {
#define _finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW case NORMAL: if (plants_num_format[row][SMALLNUT - 1] >
#define _thisvalueBUCKET1finalchoicethischoiceBUCKET1 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER
#define _voidvaluepolevaultdoublefinalchoiceROW00000 - 1] > 0) plants_para[SMALLNUT - 1]
#define _judgeLinesnotbrokenfinalchoice__ *= (plants_num_format[row][PEASHOOTER - 1] * 1 +
#define _ifthiswhetherneedcomputePOLEVAULTreturn plants_num_format[row][WINTERPEASHOOTER - 1] * 2); break; case
#define _zombie__ BUCKET: if (plants_num_format[row][SMALLNUT - 1] > 0
#define _doublezombiesparasZOMBIEKIND1thistime10010051523 && plants_num_format[row][WINTERPEASHOOTER - 1] > 0) plants_para[SMALLNUT
#define _doubledistancecost25distancerate01_ - 1] *= (plants_num_format[row][PEASHOOTER - 1] *
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT 0.2 + plants_num_format[row][WINTERPEASHOOTER - 1]); break; case
#define _plant__ POLEVAULT: if (plants_num_format[row][SMALLNUT - 1] > 0
#define _intplantsnumformatROWPLANTKIND0__ && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER -
#define _doubleplantsparaPLANTKIND52181001 1] > 0) { plants_para[SMALLNUT - 1]
#define _intsumplantsperrowthissumplantsperrow_ *= ((1.5 - plants_num_format[row][SMALLNUT - 1]) *
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT (3 - plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER
#define _time__ - 1])); } break; case SLED: if
#define _doubletimecost2011expthistimeTOTALTIME510005 (plants_num_format[row][SMALLNUT - 1] > 1 && plants_num_format[row][PEASHOOTER
#define _forinti0iROWi______ - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] >
#define _finalchoiceitimecostSun__ 0) { plants_para[SMALLNUT - 1] *= (plants_num_format[row][SMALLNUT
#define _doublesunbaseline120sunsub04 - 1] * plants_num_format[row][SMALLNUT - 1]) *
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub (plants_num_format[row][WINTERPEASHOOTER - 1]); } if (plants_num_format[row][WINTERPEASHOOTER -
#define _forinti0iROWi_______ 1] >= 2) { plants_para[WINTERPEASHOOTER - 1]
#define _finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW = 6 - 2 * plants_num_format[row][WINTERPEASHOOTER -
#define _thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1 1]; } break; case GARGANTUAR: if (plants_num_format[row][WINTERPEASHOOTER
#define _voidvaluesleddoublefinalchoiceROW00000 - 1] > 1) { plants_para[WINTERPEASHOOTER -
#define _judgeLinesnotbrokenfinalchoice___ 1] *= (plants_num_format[row][WINTERPEASHOOTER - 1] + 1);
#define _ifthiswhetherneedcomputeSLEDreturn } if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2)
#define _zombie___ { plants_para[WINTERPEASHOOTER - 1] = 6 -
#define _doublezombiesparasZOMBIEKIND32174 2 * plants_num_format[row][WINTERPEASHOOTER - 1]; } break;
#define _doubledistancecost25distancerate01__ } plants_para[SUNFLOWER - 1] *= (1 +
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED 1 / (COLUMN - plants_num_format[row][SUNFLOWER - 1]
#define _plant___ + 1)); for (int j = 0;
#define _intplantsnumformatROWPLANTKIND0___ j < COLUMN; j++) { if (Plants[row][j]
#define _doubleplantsparaPLANTKIND510361001and != NOPLANT) cost += plants_para[Plants[row][j] - 1]
#define _intsumplantsperrowthissumplantsperrow__ * (plants_para[Plants[row][j] - 1] > 0 ?
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED (j + 1) * (j + 1)
#define _time___ : (COLUMN - j)); } for (int
#define _doubletimecost2011expthistimeTOTALTIME520005 i = 0; i < PLANT_KIND; i++)
#define _forinti0iROWi________ { plants_para[i] = origin_para[i]; } return cost;
#define _finalchoiceitimecostSun___ } int max_index(double *a, int length) {
#define _doublesunbaseline200sunsub05 double max = -10000; int index =
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub 0; for (int i = 0; i
#define _forinti0iROWi_________ < length; i++) { if (max <
#define _finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW a[i]) { max = a[i]; index =
#define _thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000 i; } } return index; } void
#define _judgeLinesnotbrokenfinalchoice____ value_normal() { double final_choice[ROW] = {0, 0,
#define _ifthiswhetherneedcomputeGARGANTUARreturn 0, 0, 0}; if (this->whether_need_compute(NORMAL)) { return;
#define _zombie____ } double zombies_paras[ZOMBIE_KIND] = {-5, 4, 2,
#define _doublezombiesparasZOMBIEKIND2452015 3, 1}; double distance_cost = 1, distance_rate
#define _doubledistancecost25distancerate01___ = 0.05; for (int i = 0;
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR i < ROW; i++) { final_choice[i] +=
#define _plant____ this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, NORMAL); } int
#define _intplantsnumformatROWPLANTKIND0____ plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i =
#define _doubleplantsparaPLANTKIND01002510010and 0; i < ROW; i++) for (int
#define _intsumplantsperrowthissumplantsperrow___ j = 0; j < PLANT_KIND; j++)
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND]
#define _time____ = {8, -8, -2, -2, -100, 5};
#define _doubletimecost int **sum_plants_per_row0 = this->sum_plants_per_row(); for (int i
#define _ifabsthistime50025absthistime100025absthistime150025 = 0; i < ROW; i++) {
#define _timecost100 final_choice[i] += this->plant_cost(i, sum_plants_per_row0, plants_para, NORMAL); }
#define _timecost10011expthistimeTOTALTIME540004 for (int i = 0; i <
#define _forinti0iROWi__________ ROW; i++) { free(sum_plants_per_row0[i]); } free(sum_plants_per_row0); double
#define _finalchoiceitimecostSun____ time_cost = 20 * (1 / (1
#define _doublesunbaseline350sunsub06 + exp((this->time - TOTAL_TIME / 2) /
#define _doublesuncost11expthisSunsunbaseline10020010 100)) - 0.5); for (int i =
#define _forinti0iROWi___________ 0; i < ROW; i++) final_choice[i] +=
#define _finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW time_cost; double sun_baseline = 60, sun_sub =
#define _thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1 1; double sun_cost = (this->Sun - sun_baseline
#define _externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame > 0 ? 1 / (1 +
#define _gamemaintainplayerclassICamppublic exp((-this->Sun + sun_baseline) / 200)) * 15
#define _virtualintgetCurrentPlants0 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
#define _Plantsijij0virtualintgetCurrentZombies0Zombiesijij for (int i = 0; i <
#define _kk0Zombiesijk1 ROW; i++) final_choice[i] += sun_cost; this->choice[NORMAL -
#define _Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic 1] = this->max_index(final_choice, ROW); this->value[NORMAL - 1]
#define _ICampCamp = final_choice[this->choice[NORMAL - 1]]; } void value_bucket()
#define _virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0 { double final_choice[ROW] = {0, 0, 0,
#define _virtualintgetScore0 0, 0}; if (this->whether_need_compute(BUCKET)) { return; }
#define _virtualintgetKillPlantsScore0 double zombies_paras[ZOMBIE_KIND] = {2.5, -4, this->time <
#define _virtualintgetKillZombiesScore0 100 ? -100 : -5, 2, -2};
#define _virtualintgetNotBrokenLines0 double distance_cost = 2.5, distance_rate = 0.1;
#define _virtualintgetBrokenLinesScore0 for (int i = 0; i <
#define _virtualintgetLeftPlants0intTypeplayerCampgetCurrentType ROW; i++) { final_choice[i] += this->zombie_cost(i, zombies_paras,
#define _ifType0intNotBrokenLinesNumplayergetNotBrokenLines distance_cost, distance_rate, BUCKET); } int plants_num_format[ROW][PLANT_KIND] =
#define _intKillZombiesScoreplayergetKillZombiesScore {{0}}; for (int i = 0; i
#define _intLeftPlantsplayergetLeftPlants < ROW; i++) for (int j =
#define _intScoreplayergetScore 0; j < PLANT_KIND; j++) { plants_num_format[i][j]
#define _inttime0playergetTime = 0; } double plants_para[PLANT_KIND] = {6,
#define _introwsplayerCampgetRows 1, 6, 2.5, -100, -4}; int **sum_plants_per_row
#define _intcolumnsplayerCampgetColumns = this->sum_plants_per_row(); for (int i = 0;
#define _intPlaceCDplayerCampgetPlantCD i < ROW; i++) { final_choice[i] +=
#define _intPlantsplayerCampgetCurrentPlants this->plant_cost(i, sum_plants_per_row, plants_para, BUCKET); } for (int
#define _intZombiesplayerCampgetCurrentZombies i = 0; i < ROW; i++)
#define _intLeftLinesplayerCampgetLeftLines { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost =
#define _intSunplayerCampgetSun 20 * (1 / (1 + exp((-this->time
#define _Zombiesnumzombiesnum + TOTAL_TIME / 3) / 200)) -
#define _zombiesnumcomputenumZombiesrowscolumns 0.5); for (int i = 0; i
#define _Plantsnumplantsnum < ROW; i++) final_choice[i] += time_cost; double
#define _plantsnumcomputenumPlantsrowscolumns sun_baseline = 150, sun_sub = 1; double
#define _playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51 sun_cost = (this->Sun - sun_baseline > 0
#define _playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52 ? 1 / (1 + exp(-this->Sun +
#define _ifplantsnumsunflower3 sun_baseline)) * 5 : -pow(sun_baseline - this->Sun,
#define _playerPlacePlantSUNFLOWER0plantsnumsunflower1 1 / sun_sub)); for (int i =
#define _playerPlacePlantSMALLNUT0plantsnumsmallnut5 0; i < ROW; i++) final_choice[i] +=
#define _playerPlacePlantSQUASH04 sun_cost; this->choice[BUCKET - 1] = this->max_index(final_choice, ROW);
#define _playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54 this->value[BUCKET - 1] = final_choice[this->choice[BUCKET - 1]];
#define _iftime06 } void value_polevault() { double final_choice[ROW] =
#define _playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45 {0, 0, 0, 0, 0}; if (this->whether_need_compute(POLEVAULT))
#define _ifSun400 { return; } double zombies_paras[ZOMBIE_KIND] = {1,
#define _playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame this->time < 100 ? -100 : -5,
#define _valuemakedecisionifType1 -1.5, 2, -3}; double distance_cost = 2.5,
#define _intBrokenLinesScoreplayergetBrokenLinesScore distance_rate = 0.1; for (int i =
#define _intKillPlantsScoreplayergetKillPlantsScore 0; i < ROW; i++) { final_choice[i]
#define _intScoreplayergetScore_ += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, POLEVAULT); }
#define _inttimeplayergetTime int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i
#define _introwsplayerCampgetRows_ = 0; i < ROW; i++) for
#define _intcolumnsplayerCampgetColumns_ (int j = 0; j < PLANT_KIND;
#define _intPlaceCDplayerCampgetPlantCD_ j++) { plants_num_format[i][j] = 0; } double
#define _intPlantsplayerCampgetCurrentPlants_ plants_para[PLANT_KIND] = {4, -50, -8, 7, -100,
#define _intZombiesplayerCampgetCurrentZombies_ -1}; int **sum_plants_per_row = this->sum_plants_per_row(); for (int
#define _intLeftLinesplayerCampgetLeftLines_ i = 0; i < ROW; i++)
#define _intSunplayerCampgetSun_ { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, POLEVAULT);
#define _iftime3intzombienumcalculatezombienumsZombies49 } for (int i = 0; i
#define _valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row);
#define _valuevaluenormal double time_cost = 10 * (1 /
#define _valuevaluebucket (1 + exp((-this->time + TOTAL_TIME / 5)
#define _valuevaluepolevault / 100)) - 0.5); for (int i
#define _valuevaluesled = 0; i < ROW; i++) final_choice[i]
#define _valuevaluegargantuar += time_cost; double sun_baseline = 120, sun_sub
#define _intdecision200 = 1; double sun_cost = (this->Sun -
#define _valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0 sun_baseline > 0 ? 1 / (1
#define _whileZombiesijk1 + exp((-this->Sun + sun_baseline) / 200)) *
#define _kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1 6 : -pow(sun_baseline - this->Sun, 1 /
#define _elseplayerPlaceZombiePOLEVAULT1 sun_sub)); for (int i = 0; i
#define _playerPlaceZombieNORMAL2 < ROW; i++) final_choice[i] += sun_cost; this->choice[POLEVAULT
#define _playerPlaceZombieBUCKET3 - 1] = this->max_index(final_choice, ROW); this->value[POLEVAULT - 1] = final_choice[this->choice[POLEVAULT - 1]]; } void value_sled() { double final_choice[ROW] = {0, 0, 0, 0, 0}; if (this->whether_need_compute(SLED)) { return; } double zombies_paras[ZOMBIE_KIND] = {3, -2, -1, -7, -4}; double distance_cost = 2.5, distance_rate = 0.1; for (int i = 0; i < ROW; i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, SLED); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; i < ROW; i++) for (int j = 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = {5, 10, 3, 8, -100, 1}; int **sum_plants_per_row = this->sum_plants_per_row(); for (int i = 0; i < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, SLED); } for (int i = 0; i < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost = 15 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 200)) - 0.5); for (int i = 0; i < ROW; i++) final_choice[i] += time_cost; double sun_baseline = 200, sun_sub = 1; double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp(-this->Sun + sun_baseline + 100) / 200) * 10 : -pow(sun_baseline - this->Sun, 1 / sun_sub)); for (int i = 0; i < ROW; i++) final_choice[i] += sun_cost; this->choice[SLED - 1] = this->max_index(final_choice, ROW); this->value[SLED - 1] = final_choice[this->choice[SLED - 1]]; } void value_gargantuar() { double final_choice[ROW] = {0, 0, 0, 0, 0}; if (this->whether_need_compute(GARGANTUAR)) { return; } double zombies_paras[ZOMBIE_KIND] = {2, -4, -5, -20, -15}; double distance_cost = 2.5, distance_rate = 0.1; for (int i = 0; i < ROW; i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, GARGANTUAR); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; i < ROW; i++) for (int j = 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = {0, 10, 2, 5, -100, -10}; int **sum_plants_per_row = this->sum_plants_per_row(); for (int i = 0; i < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, GARGANTUAR); } for (int i = 0; i < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost; if (abs(this->time - 500) < 25 || abs(this->time - 1000) < 25 || abs(this->time - 1500) < 25) time_cost = 100; time_cost = 100 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5); for (int i = 0; i < ROW; i++) final_choice[i] += time_cost; double sun_baseline = 350, sun_sub = 1; double sun_cost = 1 / (1 + exp(-this->Sun + sun_baseline + 100) / 200) * 10; for (int i = 0; i < ROW; i++) final_choice[i] += sun_cost; this->choice[GARGANTUAR - 1] = this->max_index(final_choice, ROW); this->value[GARGANTUAR - 1] = final_choice[this->choice[GARGANTUAR - 1]]; } }; static Game1 game; void player_ai(IPlayer *player) { int Type = player->Camp->getCurrentType(); if (Type == 0) { int NotBrokenLinesNum = player->getNotBrokenLines(); int KillZombiesScore = player->getKillZombiesScore(); int LeftPlants = player->getLeftPlants(); int Score = player->getScore(); int time0 = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player, game); value.make_decision(); } if (Type == 1) { int BrokenLinesScore = player->getBrokenLinesScore(); int KillPlantsScore = player->getKillPlantsScore(); int Score = player->getScore(); int time = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); if (time > 3) { int zombie_num = calculate_zombie_nums(Zombies, 4, 9); value_zombie_func value(BrokenLinesScore, KillPlantsScore, Score, time, PlaceCD, Plants, Zombies, LeftLines, Sun, zombie_num, game); value.value_normal(); value.value_bucket(); value.value_polevault(); value.value_sled(); value.value_gargantuar(); int decision[2] = {0, 0}; value.make_decision(decision); if (decision[0] != NOZOMBIE) { player->PlaceZombie((decision[0] > ZOMBIE_KIND ? NORMAL : decision[0]), decision[1] > ROW - 1 ? ROW - 1 : decision[1]); } } else { player->PlaceZombie(POLEVAULT, 1); player->PlaceZombie(NORMAL, 2); player->PlaceZombie(BUCKET, 3); } } }

_includeaih
_includeiostream
_includestdlibh
_includemathh
_includecstring
_includevector
_includequeue
_usingnamespacestd
_defineZOMBIEKIND5
_definePLANTKIND6
_defineTOTALTIME2000
_defineCOLUMN10
_defineROW5
_FILEfile
_errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw
_enumPlantTypeNOPLANT0
_SUNFLOWER
_WINTERPEASHOOTER
_PEASHOOTER
_SMALLNUT
_PEPPER
_SQUASHenumZombieTypeNOZOMBIE0
_NORMAL
_BUCKET
_POLEVAULT
_SLED
_GARGANTUAR
_zrfscodestarts
_constintplantCost70504001005012550
_constintplantCd70103010406060
_constintzombieCost6050125125300300
_constintzombieCd601520202525
_constintplantHp70300300300400000
_constintplantDps7002010000
_intzombieHp6027082020016003000
_structSunflowerintrowcolumncd
_SunflowerintRowintColumncd24
_rowRowcolumnColumn
_intzombieNumintzombiesintcnt7pcnt
_forinti0i5i
_forintj0j10j
_forintk0k10kifzombiesijk1
_break
_else
_cntzombiesijkreturnp
_zombies
_intzombieNumintzombies51010intcnt7pcnt
_forinti0i5i_
_forintj0j10j_
_forintk0k10kifzombiesijk1_
_break_
_else_
_cntzombiesijkreturnpstructZombieintnum
_inthp
_intcoXcoY
_ZombieintNumintrowcoXrowcoY9
_hpzombieHpNum
_numNumintspeedstructPlantintnum
_inthp_
_intcoXcoY_
_intdps
_PlantintNumintrowintcolnumNum
_coXrowcoYcol
_hpplantHpNum
_dpsplantDpsNum
_structActionlistintplantPlace510zombiePlace5
_intplantRemove510classGamepublic
_inttimesunmoon
_intplants510zombies51010
_intcdPlant7cdZombie6tick
_intdps5dps
_intflagPlant7flagZombie610
_intflagShovel51010
_intzombieCostPerRow5
_vectorSunflowersunFlowers
_vectorPlantvectorPlants
_vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij
_flagShovelij1voidmaintainIPlayerplayertime
_intPlantsplayerCampgetCurrentPlantscurrentPlants
_intZombiesplayerCampgetCurrentZombiescurrentZombies
_mooninttime20001
_forinti0i5i__
_forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij
_moonplantCostnum5intsqrtplantHpnum
_dpsiplantDpsnum
_ifnum1forintk0ksunFlowerssizek
_ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink
_break__
_elseifplantsijPlantsijintnumPlantsij
_sunplantCostnum
_dpsiplantDpsnum_
_cdPlantnumplantCdnum
_flagPlantnum0
_ifnum1sun25
_sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij
_intflag0
_forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink
_k
_ifPlantsij0
_vectorPlantspushbackPlantPlantsijijflag1
_break___
_ifflag0Plantsij0
_vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies
_forinti0i5iintrowZombie6RowZombie6
_forintj0j10j__
_forintk0k10kifzombiesijk1__
_break____
_else__
_rowZombiezombiesijkforintj0j10j
_forintk0k10kifZombiesijk1
_break_____
_else___
_RowZombieZombiesijk
_forintj0j6j
_ifRowZombiejrowZombiej
_zombieCostPerRowizombieCostjforinti0i7iifziZi
_zombiedie
_elseifziZimoonzombieCosti
_cdZombieizombieCdi
_flagZombiei0
_zombieplaced
_forinti0i5iforintj0j10jintk0
_whileZombiesijk1zombiesijkZombiesijk
_k_
_vectorinthaveerased
_forinti0ivectorZombiessizeiinthaveerasedflag0
_forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1
_breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum
_intoriginalnumofthiskind0nownumofthiskind0
_intk0
_whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum
_forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj
_ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin
_iforiginalnumofthiskindnownumofthiskind1
_findthesmallesthp
_intsmallhp5000smallhpnum0
_forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp
_smallhpnumk
_vectorZombieserasesmallhpnumvectorZombiesbegin
_haveerasedpushbackvectorZombiesicoX
_haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum
_intk0_
_intflagself0
_intflagnear0
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1
_k0
_whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1
_ifflagself1flagnear1vectorZombieserasevectorZombiesbegini
_iforinti0i7iifcdPlanti0
_cdPlanti
_ifcdPlanti0
_flagPlanti1
_forinti0i6iifcdZombiei0
_cdZombiei
_ifcdZombiei0
_flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0
_sunFlowersicd
_ifsunFlowersicd0sun25
_sunFlowersicd24ticktick
_Gametime0
_sun400moon300
_forinti0i5i___
_forintj0j10j___
_plantsij0flagShovelij0
_forinti0i5i____
_forintj0j10j____
_forintk0k10k
_zombiesijk0
_forinti0i5i_____
_dpsi0zombieCostPerRowi0
_forinti0i7i
_cdPlanti0flagPlanti1
_forinti0i6i
_cdZombiei0flagZombiei1
_initialize
_GametranStateActionlistqIPlayerplayerq
_globalstatus
_GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon
_forinti0i5i______
_forintj0j10j_____
_newGameplantsijthisplantsijflagShovelijthisflagShovelij
_forinti0i5i_______
_forintj0j10j______
_forintk0k10k_
_newGamezombiesijkthiszombiesijk
_forinti0i7i_
_newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti
_forinti0i6i_
_newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei
_forinti0i5i________
_newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame
_forinti0i5i_________
_forintj0j10jifqplantPlaceij0intnumqplantPlaceij
_newGamesunplantCostnum
_newGamecdPlantnumplantCdnum
_newGameflagPlantnum0
_newGamedpsiplantDpsnum
_newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei
_newGamemoonzombieCostnum
_newGamecdZombienumzombieCdnum
_newGameflagZombienum0
_newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic
_intnormal
_intbucket
_intpolevault
_intsled
_intgargantuar
_inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0
_forinti0irowsiforintj0jcolumnsjintk0
_whilezombiesijk1switchzombiesijkcaseNORMAL
_thisnormal
_break______
_caseBUCKET
_thisbucket
_break_______
_casePOLEVAULT
_thispolevault
_break________
_caseSLED
_thissled
_break_________
_caseGARGANTUAR
_thisgargantuar
_breaknum
_kclassPlantsnumpublic
_intsunflower
_intwinterpeashooter
_intpeashooter
_intsmallnut
_intpepper
_intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi
_forintj0jcolumnsjswitchplantsijcaseSUNFLOWER
_thissunflower
_break__________
_caseWINTERPEASHOOTER
_thiswinterpeashooter
_break___________
_casePEASHOOTER
_thispeashooter
_break____________
_caseSMALLNUT
_thissmallnut
_break_____________
_casePEPPER
_thispepper
_break______________
_caseSQUASH
_thissquash
_breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0
_forinti0irowsiforintj0jcolumnsjintk0_
_whilezombiesijk1num
_kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT
_returnireturnrandROWtypedefstructposandvalueintpos2
_doublevalue
_posandvalueclassvalueplantfuncpublic
_doublenoplant
_posandvaluesunflower
_posandvaluepeashooter
_posandvaluewinterpeashooter
_posandvaluesmallnut
_posandvaluepepper
_posandvaluesquash
_intgeneratingrow
_IPlayerplayer
_Gamegame
_doublevaluePLANTKIND1
_intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum
_intKillZombiesScore
_intLeftPlants
_intScore
_inttime
_intPlaceCD
_intPlants
_intZombies
_intLeftLines
_intSun
_intzombienumsvalueplantfuncintNotBrokenLinesNum
_intKillZombiesScore_
_intScore_
_inttime_
_intPlaceCD_
_intPlants_
_intZombies_
_intLeftLines_
_intSunIPlayerplayer
_GamegamethisNotBrokenLinesNumNotBrokenLinesNum
_thisKillZombiesScoreKillZombiesScore
_thisScoreScore
_thistimetime
_thisPlaceCDPlaceCD
_thisPlantsPlants
_thisZombiesZombies
_thisLeftLinesLeftLines
_thisSunSun
_thisplayerplayer
_thisgeneratingrow1
_thisgamegameintsumplantsperrow
_rowsplantskindnumperrow
_intplantsnumformatintmallocROWsizeofint
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER
_plantsnumformatiSUNFLOWER
_break_______________
_caseWINTERPEASHOOTER_
_plantsnumformatiWINTERPEASHOOTER
_break________________
_casePEASHOOTER_
_plantsnumformatiPEASHOOTER
_break_________________
_caseSMALLNUT_
_plantsnumformatiSMALLNUT
_break__________________
_casePEPPER_
_plantsnumformatiPEPPER
_break___________________
_caseSQUASH_
_plantsnumformatiSQUASH
_breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1
_thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1
_voidGameState250ifthistime2thistime200intalarmingflag1
_forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0
_whilethisZombiesijk1ifj3
_alarmingflagi
_ifthisSun70
_switchthisZombiesijkcasePOLEVAULT
_caseSLED_
_thisplayerPlacePlantSQUASHij100j1
_break____________________
_caseBUCKET_
_ifthisPlaceCDSQUASH0
_thisplayerPlacePlantSQUASHij100j1_
_elseifj3
_thisplayerPlacePlantPEPPERij100j1
_break_____________________
_caseGARGANTUAR_
_thisplayerPlacePlantSQUASHij100j1__
_ifj4
_thisplayerPlacePlantPEPPERi8
_break______________________
_caseNORMAL
_thisplayerPlacePlantPEASHOOTERi1
_thisplayerPlacePlantSMALLNUTij100j1
_breakkelse
_forintj0jCOLUMNjintk0
_whilethisZombiesthisgeneratingrowjk1ifthisSun70
_switchthisZombiesthisgeneratingrowjk
_casePOLEVAULT_
_caseBUCKET__
_caseSLED__
_thisplayerPlacePlantSQUASHthisgeneratingrow5
_break_______________________
_caseGARGANTUAR__
_thisplayerPlacePlantSQUASHthisgeneratingrowj100j1
_ifj4_
_thisplayerPlacePlantPEPPERthisgeneratingrow8
_break________________________
_caseNORMAL_
_thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k
_thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1
_ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else
_thisplayerPlacePlantPEPPERalarmingflagCOLUMN1
_voidGameState50200ifthistime50thistime200ifthisSun400
_thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0
_voidvaluepeashooteroriginifthistime50
_ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble
_forinti0iROWilossidoublemallocCOLUMNsizeofdouble
_memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200
_forinti0iROWi
_forintj0jCOLUMNjifthisPlantsijNOPLANT
_lossij10000
_else____
_doublerowithisgeneratingrow100
_lossijrow
_doublecolumn25
_lossijcolumnexpcolumn10
_doublezombieZOMBIEKIND61024020
_forintcolumn00jCOLUMNjintk0
_whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj
_k__
_doubleplantPLANTKIND202520
_forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT
_lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30
_lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i
_maxindex1j
_thispeashooterpos0maxindex0
_thispeashooterpos1maxindex1
_thispeashootervaluemax
_boolhavetypeofzombiesintzombieinttypeintk0
_whilezombiek1ifzombiektype
_returntrue
_kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0
_forintj0jCOLUMNjintk0_
_whileZombiesrowjk1ifnearestjcolumn
_nearestjcolumn
_k___
_returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0
_whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0
_whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart
_intrankdoublearrayintlendoublemaxarray0
_intserialnumintmalloclensizeofint
_forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj
_arrayjarrayj1
_arrayj1swap
_intserialswapserialnumj
_serialnumjserialnumj1
_serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10
_ifthisPlaceCDSUNFLOWER0doublescore500000
_judgeLinesnotbrokenscore
_forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER
_scorei10
_ifPlantsijPEASHOOTER
_scorei501expj
_ifPlantsijWINTERPEASHOOTER
_scorei1001expj
_ifPlantsijSMALLNUT
_scorei100001j5j51
_forinti0iROWi_
_forintj0jCOLUMNjintk0__
_whileZombiesijk1ifZombiesijkNORMAL
_scorei10101j
_ifZombiesijkBUCKET
_scorei50101j
_ifZombiesijkPOLEVAULT
_scorei30101j
_ifZombiesijkGARGANTUAR
_scorei100101j
_ifZombiesijkSLED
_scorei80101j
_kintsunflowernumingeneratingrow0
_forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER
_sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW
_forinti0iROWiintj0
_whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j
_voidvaluesmallmnutifthisPlaceCDSMALLNUT0
_ifthistime20doublescoreROW00000
_judgeLinesnotbrokenscorevalueplants
_doubleplantsscore7052020710
_forinti0iROWiforintj0jCOLUMNjdoubledistancecost1
_switchPlantsijcaseSUNFLOWER
_distancecost15005j
_break_________________________
_casePEASHOOTER__
_distancecost2009j
_break__________________________
_caseWINTERPEASHOOTER__
_distancecost201j
_breakscoreiPlantsijplantsscoreidistancecostvaluezombies
_doublezombiecost520101246
_intnearestzombieperrow500000
_forinti0iROWiforintjCOLUMN1j0jintk0
_whileZombiesijk1doubledistancecost1
_switchZombiesijk
_caseNORMAL__
_distancecost12002j
_break___________________________
_casePOLEVAULT__
_distancecost11001j
_break____________________________
_caseBUCKET___
_distancecost13004j
_breakscoreizombiecostZombiesijk1distancecost
_k____
_nearestzombieperrowij
_intserialnumrankscoreROW
_forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1
_voidvaluethisvaluepeashooter
_thisvaluesunflower
_thisvaluesmallmnut
_doublemax100000
_doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue
_thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation
_thisGameState250
_thisGameState50200
_thisvalue
_classvaluezombiefuncpublic
_intnozombie
_intnormalchoice
_intbucketchoice
_intpolevaultchoice
_intsledchoice
_intgargantuarchoice
_doublevalueZOMBIEKIND
_intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore
_intKillPlantsScore
_intLeftPlants_
_intScore__
_inttime__
_intPlaceCD__
_intPlants__
_intZombies__
_intLeftLines__
_intSun_
_intzombienums
_GamegamevaluezombiefuncintBrokenLinesScore
_intKillPlantsScore_
_intScore___
_inttime___
_intPlaceCD___
_intPlants___
_intZombies___
_intLeftLines___
_intSun__
_intzombienums_
_Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0
_thisBrokenLinesScoreBrokenLinesScore
_thisKillPlantsScoreKillPlantsScore
_thisScoreScore_
_thistimetime_
_thisPlaceCDPlaceCD_
_thisPlantsPlants_
_thisZombiesZombies_
_thisLeftLinesLeftLines_
_thisSunSun_
_thiszombienumszombienums
_thisgamegame
_forinti0iZOMBIEKINDi
_thisvaluei0
_memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile
_fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0
_forinti0iROWiaveragecostiaverage5
_forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05
_squaredistance5ifsquaredistancepowthistime001100return1else
_return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow
_ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei
_decision0i1
_decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei
_decision0i1_
_decision1thischoicei
_ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum
_thisKillZombiesScoreKillZombiesScore_
_thisLeftPlantsLeftPlants
_thisScoreScore__
_thistimetime__
_thisPlaceCDPlaceCD__
_thisPlantsPlants__
_thisZombiesZombies__
_thisLeftLinesLeftLines__
_thisSunSunforinti0iROWifinalchoicei0
_boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10
_thisvaluekind1100000
_returntrueelse
_returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00
_ifthisLeftLinesrow0cost100000elseintnumperrow0
_doubletoomanyzombiescost15
_forintj0jCOLUMNjintk0___
_whilethisZombiesrowjk1switchkindcasePOLEVAULT
_costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost
_break_____________________________
_default
_costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k
_numperrow
_costnumperrowtoomanyzombiescostreturncostintsumplantsperrow
_rowsplantskindnumperrow_
_intplantsnumformatintmallocROWsizeofint_
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_
_plantsnumformatiSUNFLOWER1
_break______________________________
_caseWINTERPEASHOOTER___
_plantsnumformatiWINTERPEASHOOTER1
_break_______________________________
_casePEASHOOTER___
_plantsnumformatiPEASHOOTER1
_break________________________________
_caseSMALLNUT__
_plantsnumformatiSMALLNUT1
_break_________________________________
_casePEPPER__
_plantsnumformatiPEPPER1
_break__________________________________
_caseSQUASH__
_plantsnumformatiSQUASH1
_breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00
_switchkindcaseNORMAL
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12
_break___________________________________
_caseBUCKET____
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1
_break____________________________________
_casePOLEVAULT___
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED
_ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break
_caseGARGANTUAR___
_ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11
_plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11
_forintj0jCOLUMNjifPlantsrowjNOPLANT
_costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000
_intindex0
_forinti0ilengthiifmaxaimaxai
_indexi
_returnindex
_NORMAL_
_BUCKET_
_POLEVAULT_
_SLED_
_GARGANTUARSUNFLOWER
_WINTERPEASHOOTER_
_PEASHOOTER_
_SMALLNUT_
_PEPPER_
_SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000
_judgeLinesnotbrokenfinalchoice
_ifthiswhetherneedcomputeNORMALreturn
_zombie
_doublezombiesparasZOMBIEKIND54231
_doubledistancecost1distancerate005
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL
_plant
_intplantsnumformatROWPLANTKIND0
_doubleplantsparaPLANTKIND88221005
_intsumplantsperrow0thissumplantsperrow
_forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL
_time
_doubletimecost2011expthistimeTOTALTIME210005
_forinti0iROWi__
_finalchoiceitimecostSun
_doublesunbaseline60sunsub02
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub
_forinti0iROWi___
_finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW
_thisvalueNORMAL1finalchoicethischoiceNORMAL1
_voidvaluebucketdoublefinalchoiceROW00000
_judgeLinesnotbrokenfinalchoice_
_ifthiswhetherneedcomputeBUCKETreturn
_zombie_
_doublezombiesparasZOMBIEKIND254thistime100100522
_doubledistancecost25distancerate01
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET
_plant_
_intplantsnumformatROWPLANTKIND0_
_doubleplantsparaPLANTKIND63231004
_intsumplantsperrowthissumplantsperrow
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET
_time_
_doubletimecost2011expthistimeTOTALTIME310005
_forinti0iROWi____
_finalchoiceitimecostSun_
_doublesunbaseline150sunsub05
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub
_forinti0iROWi_____
_finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW
_thisvalueBUCKET1finalchoicethischoiceBUCKET1
_voidvaluepolevaultdoublefinalchoiceROW00000
_judgeLinesnotbrokenfinalchoice__
_ifthiswhetherneedcomputePOLEVAULTreturn
_zombie__
_doublezombiesparasZOMBIEKIND1thistime10010051523
_doubledistancecost25distancerate01_
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT
_plant__
_intplantsnumformatROWPLANTKIND0__
_doubleplantsparaPLANTKIND52181001
_intsumplantsperrowthissumplantsperrow_
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT
_time__
_doubletimecost2011expthistimeTOTALTIME510005
_forinti0iROWi______
_finalchoiceitimecostSun__
_doublesunbaseline120sunsub04
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub
_forinti0iROWi_______
_finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW
_thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1
_voidvaluesleddoublefinalchoiceROW00000
_judgeLinesnotbrokenfinalchoice___
_ifthiswhetherneedcomputeSLEDreturn
_zombie___
_doublezombiesparasZOMBIEKIND32174
_doubledistancecost25distancerate01__
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED
_plant___
_intplantsnumformatROWPLANTKIND0___
_doubleplantsparaPLANTKIND510361001and
_intsumplantsperrowthissumplantsperrow__
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED
_time___
_doubletimecost2011expthistimeTOTALTIME520005
_forinti0iROWi________
_finalchoiceitimecostSun___
_doublesunbaseline200sunsub05
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub
_forinti0iROWi_________
_finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW
_thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000
_judgeLinesnotbrokenfinalchoice____
_ifthiswhetherneedcomputeGARGANTUARreturn
_zombie____
_doublezombiesparasZOMBIEKIND2452015
_doubledistancecost25distancerate01___
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR
_plant____
_intplantsnumformatROWPLANTKIND0____
_doubleplantsparaPLANTKIND01002510010and
_intsumplantsperrowthissumplantsperrow___
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR
_time____
_doubletimecost
_ifabsthistime50025absthistime100025absthistime150025
_timecost100
_timecost10011expthistimeTOTALTIME540004
_forinti0iROWi__________
_finalchoiceitimecostSun____
_doublesunbaseline350sunsub06
_doublesuncost11expthisSunsunbaseline10020010
_forinti0iROWi___________
_finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW
_thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1
_externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame
_gamemaintainplayerclassICamppublic
_virtualintgetCurrentPlants0
_Plantsijij0virtualintgetCurrentZombies0Zombiesijij
_kk0Zombiesijk1
_Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic
_ICampCamp
_virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0
_virtualintgetScore0
_virtualintgetKillPlantsScore0
_virtualintgetKillZombiesScore0
_virtualintgetNotBrokenLines0
_virtualintgetBrokenLinesScore0
_virtualintgetLeftPlants0intTypeplayerCampgetCurrentType
_ifType0intNotBrokenLinesNumplayergetNotBrokenLines
_intKillZombiesScoreplayergetKillZombiesScore
_intLeftPlantsplayergetLeftPlants
_intScoreplayergetScore
_inttime0playergetTime
_introwsplayerCampgetRows
_intcolumnsplayerCampgetColumns
_intPlaceCDplayerCampgetPlantCD
_intPlantsplayerCampgetCurrentPlants
_intZombiesplayerCampgetCurrentZombies
_intLeftLinesplayerCampgetLeftLines
_intSunplayerCampgetSun
_Zombiesnumzombiesnum
_zombiesnumcomputenumZombiesrowscolumns
_Plantsnumplantsnum
_plantsnumcomputenumPlantsrowscolumns
_playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51
_playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52
_ifplantsnumsunflower3
_playerPlacePlantSUNFLOWER0plantsnumsunflower1
_playerPlacePlantSMALLNUT0plantsnumsmallnut5
_playerPlacePlantSQUASH04
_playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54
_iftime06
_playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45
_ifSun400
_playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame
_valuemakedecisionifType1
_intBrokenLinesScoreplayergetBrokenLinesScore
_intKillPlantsScoreplayergetKillPlantsScore
_intScoreplayergetScore_
_inttimeplayergetTime
_introwsplayerCampgetRows_
_intcolumnsplayerCampgetColumns_
_intPlaceCDplayerCampgetPlantCD_
_intPlantsplayerCampgetCurrentPlants_
_intZombiesplayerCampgetCurrentZombies_
_intLeftLinesplayerCampgetLeftLines_
_intSunplayerCampgetSun_
_iftime3intzombienumcalculatezombienumsZombies49
_valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame
_valuevaluenormal
_valuevaluebucket
_valuevaluepolevault
_valuevaluesled
_valuevaluegargantuar
_intdecision200
_valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0
_whileZombiesijk1
_kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1
_elseplayerPlaceZombiePOLEVAULT1
_playerPlaceZombieNORMAL2
_playerPlaceZombieBUCKET3

