#ifndef INTERFACE_H_
#define INTERFACE_H_
#include <vector>
#include "../json/json.h"
using std::vector;
class ICamp
{
public:
	int** getCurrentPlants() const{
		int** currentPlants = new int* [5];
		for(int i = 0; i < 5; i++){
			currentPlants[i] = new int[10];
			for(int j = 0; j < 10; j++){
				currentPlants[i][j] = data["getCurrentPlants"][i][j].asInt();
			}
		}
		return currentPlants;
	} //5*10
	int*** getCurrentZombies() const{
		int*** currentZombies = new int** [5];
		for(int i = 0; i < 5; i++){
			currentZombies[i] = new int*[10];
			for(int j = 0; j < 10; j++){
				int x = 0;
				if (data["getCurrentZombies"][i][j] == Json::nullValue){
					x = 0;
				}else{
					x = data["getCurrentZombies"][i][j].size();
				}
				currentZombies[i][j] = new int[x+1];
				for(int k = 0; k < x; k++){
					currentZombies[i][j][k] = data["getCurrentZombies"][i][j][k].asInt();
				}
				currentZombies[i][j][x] = -1;
			}
		}
		return currentZombies;
	} //5*10*x
	int getSun() const{
		return data["getSun"].asInt();
	}
	int* getPlantCD() const{
		int length = getCurrentType()==0 ? 6 : 5;
		int* PlantCD = new int [length];
		for(int i = 0; i < length; i++){
			PlantCD[i] = data["getPlantCD"][i].asInt();
		}
		return PlantCD;
	} // Plants 6 Zombies 5
	int* getLeftLines() const{
		int* LeftLines = new int [5];
		for(int i = 0; i < 5; i++){
			LeftLines[i] = data["getLeftLines"][i].asInt();
		}
		return LeftLines;
	} // 5
	int getRows() const{
		return data["getRows"].asInt();
	}
	int getColumns() const{
		return data["getColumns"].asInt();
	}
	int getCurrentType() const{
		return data["getCurrentType"].asInt();
	}
	~ICamp() = default;
	Json::Value data;
	ICamp(Json::Value _data):data(_data){};
};
class IPlayer
{
public:
	ICamp* Camp;
	Json::Value action;
	Json::Value data;
	IPlayer(Json::Value _data, ICamp* _Camp):data(_data), Camp(_Camp){
		action.clear();
	};
	Json::Value asJson() const{
		Json::Value result;
		result["getTime"] = getTime();
		result["getScore"] = getScore();
		result["getKillPlantsScore"] = getKillPlantsScore();
		result["getKillZombiesScore"] = getKillZombiesScore();
		result["getNotBrokenLines"] = getNotBrokenLines();
		result["getBrokenLinesScore"] = getBrokenLinesScore();
		result["getLeftPlants"] = getLeftPlants();
	}
	void PlacePlant(int type, int x, int y){
		Json::Value plantData;
		plantData["name"] = string("PlacePlant");
		plantData["type"] = type;
		plantData["x"] = x;
		plantData["y"] = y;
		action.append(plantData);
	}
	void PlaceZombie(int type, int y){
		Json::Value plantData;
		plantData["name"] = string("PlaceZombie");
		plantData["type"] = type;
		plantData["y"] = y;
		action.append(plantData);
	}
	int getTime() const{
		return data["getTime"].asInt();
	}
	int getScore() const{
		return data["getScore"].asInt();
	}
	int getKillPlantsScore() const{
		return data["getKillPlantsScore"].asInt();
	}
	int getKillZombiesScore() const{
		return data["getKillZombiesScore"].asInt();
	}
	int getNotBrokenLines() const{
		return data["getNotBrokenLines"].asInt();
	}
	int getBrokenLinesScore() const{
		return data["getBrokenLinesScore"].asInt();
	}
	int getLeftPlants() const{
		return data["getLeftPlants"].asInt();
	}
	void removePlant(int x, int y){
		Json::Value plantData;
		plantData["name"] = string("removePlant");
		plantData["x"] = x;
		plantData["y"] = y;
		action.append(plantData);
	}
};

#endif