#include <vector>
#include <queue>
#include "ai.h"


const int plantSun[7] = { 0, 50, 400, 100, 50, 125, 50 };
const int zombieSun[6] = { 0, 50, 125, 125, 300, 300 };
const int zombieBlood[6] = { 0, 270, 820, 200, 1600, 3000 };

struct Map
{
	int** Plant;    // (i, j) 's plant
	int*** Zombies; // (i, j) 's zombies
	std::vector<std::pair<int, int>> plantsPosition[7];  // position of the plants which are type i
	std::vector<std::pair<int, int>> zombiesPosition[6]; // position of the zombies which are type i

	int Sun;
	int* CD;
	int* LeftLines;

	Map(IPlayer* player) 
	{
		Sun = player->Camp->getSun();
		CD = player->Camp->getPlantCD();          // from 0
		LeftLines = player->Camp->getLeftLines(); // 1 exist, 0 don't exist
		Plant = player->Camp->getCurrentPlants();
		Zombies = player->Camp->getCurrentZombies();
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (Zombies[i][j][k] != -1)
				{
					zombiesPosition[Zombies[i][j][k]].push_back(std::pair<int, int>(i, j));
					k++;
				}

				plantsPosition[Plant[i][j]].push_back(std::pair<int, int>(i, j));
			}
		}
	}

};


struct PlantAction
{
	int Type;
	int i, j;
	int priority;
	PlantAction(int Type, int i, int j, int priority) :Type(Type), i(i), j(j), priority(priority) {}

	bool operator<(const PlantAction& x) const
	{
		return priority < x.priority;
	}
};


struct ZombieAction
{
	int Type;
	int i;
	int priority;
	ZombieAction(int Type, int i, int priority) :Type(Type), i(i), priority(priority) {}

	bool operator<(const PlantAction& x) const
	{
		return priority < x.priority;
	}
};


struct RowBlood
{
	int row, blood;

	RowBlood(int row, int blood) :row(row), blood(blood) {}
	bool operator<(const RowBlood& x) const
	{
		return blood > x.blood;
	}
};


PlantAction sunFlower(Map map)
{
	int priority = 0;
	std::priority_queue<RowBlood> rowBlood;

	if (map.plantsPosition[1].size() < 2 && map.Sun <= 150)
		priority = 999999;
	else if (map.plantsPosition[1].size() < 5 && map.Sun <= 200)
		priority = 700;
	else
		priority = 100;

	for (int i = 0; i < 5; i++)
	{
		if (!map.LeftLines[i]) continue;
		int bloods = 0;
		for (int k = 1; k < 6; k++)
		{
			int j = 0;
			while (j < map.zombiesPosition[k].size())
			{
				if (map.zombiesPosition[k][j].first == i)
					bloods += zombieBlood[k];
				j++;
			}
		}
		rowBlood.push(RowBlood(i, bloods));
	}
	
	for (int i = 0; i < rowBlood.size(); i++)
	{
		i = rowBlood.top().row;
		for (int j = 2; j < 6; j++)
		{
			if (map.Plant[i][j] == 0 && !map.CD[0])
			{
				return PlantAction(1, i, j, priority);
			}
		}
		rowBlood.pop();
	}

	priority = 0;
	return PlantAction(1, 0, 0, priority);
}


PlantAction peaShooter(Map map)
{
	int priority = 0;
	int row = 0, column = 0;

	for (int i = 0; i < map.zombiesPosition[1].size(); i++)
	{
		int row = map.zombiesPosition[1][i].first;
		int bloods = 0;
		for (int j = 0; j < 10; j++)
		{
			int k = 0;
			while (map.Zombies[row][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[row][j][k]];
				k++;
			}
		}

		if (bloods < 600)
		{
			for (int j = 0; j < 2; j++)
			{
				if (map.Plant[row][j] == 0 && map.Sun >= 150 && !map.CD[2])
				{
					column = j;
					priority = 600;
					return PlantAction(3, row, column, priority);
				}
			}
		}
	}

	for (int j = 0; j < 6; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!map.Plant[i][j] && map.LeftLines[i] && map.Sun >= 300)
			{
				priority = 400;
				return PlantAction(3, i, j, priority);
			}
		}
	}

	priority = 0;
	return PlantAction(3, 0, 0, priority);
}


PlantAction winterPeaShooter(Map map)
{
	int priority = 0;
	int row = 0, column = 0;
	std::priority_queue<RowBlood> rowBlood;
	if (map.Sun >= 500)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!map.LeftLines[i]) continue;
			int bloods = 0;
			for (int k = 1; k < 6; k++)
			{
				int j = 0;
				while (j < map.zombiesPosition[k].size())
				{
					if (map.zombiesPosition[k][j].first == i)
						bloods += zombieBlood[k];
					j++;
				}
			}
			rowBlood.push(RowBlood(i, bloods));
		}

		for (int i = 0; i < rowBlood.size(); i++)
		{
			i = rowBlood.top().row;
			for (int j = 2; j < 6; j++)
			{
				if (map.Plant[i][j] != 2 && !map.CD[1])
				{
					priority = 99999;
					return PlantAction(2, i, j, priority);
				}
			}
			rowBlood.pop();
		}
	}

	priority = 0;
	return PlantAction(2, 0, 0, priority);
}


PlantAction smallNut(Map map)
{
	int priority = 0;
	int row = 0, column = 0;

	for (int i = 0; i < map.zombiesPosition[1].size(); i++)
	{
		int row = map.zombiesPosition[1][i].first;
		int bloods = 0;
		for (int j = 0; j < 10; j++)
		{
			int k = 0;
			while (map.Zombies[row][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[row][j][k]];
				k++;
			}
		}

		if (bloods < 600)
		{
			for (int j = 0; j < 10; j++)
			{
				if (map.Zombies[row][j][0] != -1 && !map.CD[3])
				{
					priority = 550;
					return PlantAction(4, row, j - 1, priority);
				}
			}
		}
	}

	for (int j = 8; j < 9; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!map.Plant[i][j] && map.LeftLines[i] && map.Sun >= 200 && !map.CD[3])
			{
				priority = 100;
				return PlantAction(4, i, j, priority);
			}
		}
	}

	priority = 0;
	return PlantAction(4, 0, 0, priority);
}


PlantAction pepper(Map map)
{
	int priority = 0;
	int row = 0, column = 0;

	for (int i = 0; i < 5; i++)
	{
		int bloods = 0;
		for (int j = 0; j < 10; j++)
		{
			int k = 0;
			while (map.Zombies[i][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[i][j][k]];
				k++;
			}
		}

		if (bloods >= 3000)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				if (map.Zombies[i][j][0] == -1 && !map.CD[4])
				{
					priority = 999998;
					return PlantAction(5, i, j, priority);
				}
			}
		}
	}

	priority = 0;
	return PlantAction(5, 0, 0, priority);
}


PlantAction squash(Map map)
{
	int priority = 0;
	int row = 0, column = 0;

	for (int i = 0; i < 5; i++)
	{
		for (int j = 1; j < 10; j++)
		{
			int bloods = 0;
			int k = 0;
			while (map.Zombies[i][j][k] != -1)
			{
				bloods += zombieBlood[map.Zombies[i][j][k]];
				k++;
			}

			if (bloods >= 1600)
			{
				for (int k = 5; k > 0; k--)
				{
					for (int j = 0; j < map.zombiesPosition[k].size(); j++)
					{
						if (!map.CD[5])
						{
							priority = 999998;
							return PlantAction(6, map.zombiesPosition[k][j].first, map.zombiesPosition[k][j].second - 1, priority);
						}
					}
				}
			}
		}
	}
	 
	for (int j = 9; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (map.LeftLines[i] && map.Sun >= 250 && !map.CD[5])
			{
				priority = 250;
				return PlantAction(6, i, j, priority);
			}
		}
	}

	priority = 0;
	return PlantAction(6, 0, 0, priority);
}


void plantPlay(IPlayer* player)
{
	Map map(player);
	std::priority_queue<PlantAction> actions;

	actions.push(sunFlower(map));
	actions.push(peaShooter(map));
	actions.push(winterPeaShooter(map));
	actions.push(pepper(map));
	actions.push(smallNut(map));
	actions.push(squash(map));

	int sum = int(actions.size());

	if (actions.top().priority != 0 && !map.CD[actions.top().Type - 1])
	{
		if (actions.top().priority >= 99998)
		{
			player->removePlant(actions.top().i, actions.top().j);
			player->PlacePlant(actions.top().Type, actions.top().i, actions.top().j);
		}
		else if (!map.Plant[actions.top().i][actions.top().j] && plantSun[actions.top().Type] <= map.Sun - 50)
		{
			player->PlacePlant(actions.top().Type, actions.top().i, actions.top().j);
		}
	}
	actions.pop();
	return;
}


class Zombies
{
public:
	int everyRowNum[5] = { 0 };
	int everyRowZombieNum[5][6] = { 0 };
	std::vector<std::pair<int, int>> ZombieType[6];
	Zombies(int*** zombies)
	{
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (zombies[i][j][k]!=-1)
				{	
					everyRowNum[i]++;
					everyRowZombieNum[i][zombies[i][j][k]]++;
					ZombieType[zombies[i][j][k]].push_back(std::pair<int,int>(i, j));
					k++;
				}
			}
		}
	}
};


void placeSunFlower(IPlayer*player, int& sun, int CD, int **plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int j = 2; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 100 && leftLines[i] && !zombies.everyRowNum[i])
			{
				player->PlacePlant(1, i, j);
				sun -= 50;
				return;
			}
		}
	}

	for (int j = 2; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 150 && leftLines[i])
			{
				player->PlacePlant(1, i, j);
				sun -= 50;
			}
		}
	}
}

void placePeaShooter(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowZombieNum[i][1] && !CD && sun >= 150 && leftLines[i])
		{
			if (!plants[i][0])
			{
				player->PlacePlant(3, i, 0);
				placeRow[3] = i;
				sun -= 100;
				return;
			}
			if (!plants[i][1])
			{
				player->PlacePlant(3, i, 1);
				placeRow[3] = i;
				sun -= 100;
				return;
			}
		}
	}

	for (int j = 0; j < 6; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 200 && leftLines[i])
			{
				player->PlacePlant(3, i, j);
				placeRow[3] = i;
				sun -= 100;
			}
		}
	}
}


void placeIcePeaShooter(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] && !CD && sun >= 500 && leftLines[i])
		{
			if (plants[i][0] && plants[i][0] != 2)
			{
				player->removePlant(i, 0);
				player->PlacePlant(2, i, 0);
				sun -= 400;
				return;
			}
			if (plants[i][1] && plants[i][1] != 2)
			{
				player->removePlant(i, 1);
				player->PlacePlant(2, i, 1);
				sun -= 400;
				return;
			}
		}
	}

	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 500 && leftLines[i])
			{
				player->PlacePlant(3, i, j);
				sun -= 400;
				return;
			}
			if (plants[i][j] && !CD && sun >= 500 && leftLines[i])
			{
				if (plants[i][j] != 2)
				{
					player->removePlant(i, j);
					player->PlacePlant(2, i, j);
					sun -= 400;
				}
			}
		}
	}
}

void placeChili(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] >= 4 && !CD && sun >=125 && leftLines[i])
		{
			for (int j = 0; j < 10; j++)
			{
				if (!plants[i][j])
				{
					player->PlacePlant(5, i, j);
					placeRow[5] = i;
					sun -= 125;
				}
			}
		}
	}
}

void placeWogua(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 5; i > 3; i--)
	{
		if (zombies.ZombieType[i].size()!=0 && !CD && sun >= 50 && leftLines[i])
		{

			if (zombies.ZombieType[i][0].second - 1 >= 0 && !plants[zombies.ZombieType[i][0].first][zombies.ZombieType[i][0].second - 1])
			{
				player->PlacePlant(6, zombies.ZombieType[i][0].first, zombies.ZombieType[i][0].second - 1);
				placeRow[6] = i;
				sun -= 50;
			}
		}
	}
}

void placeNut(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] && !CD && sun >= 100 && leftLines[i])
		{
			for (int j = 6; j < 10; j++)
				if (!plants[i][j])
				{
					player->PlacePlant(4, i, j);
					placeRow[4] = i;
					sun -= 50;
					return;
				}
		}
	}

	for (int j = 6; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 150 && leftLines[i])
			{
				player->PlacePlant(4, i, j);
				sun -= 50;
			}
		}
	}
}

void placeNormalZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 50 && leftLines[i])
		{
			player->PlaceZombie(1, i);
			sun -= 50;
		}
}

void placeCaplZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 125 && leftLines[i])
		{
			player->PlaceZombie(2, i);
			sun -= 125;
		}
}

void placeStickZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 125 && leftLines[i])
		{
			player->PlaceZombie(3, i);
			sun -= 125;
		}
}

void placeCarZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300 && leftLines[i])
		{
			player->PlaceZombie(4, i);
			sun -= 300;
		}
}

void placeGangZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300&& leftLines[i])
		{
			player->PlaceZombie(5, i);
			sun -= 300;
		}
}


void player_ai(IPlayer* player)
{
	auto type = player->Camp->getCurrentType();
	auto CD = player->Camp->getPlantCD();
	auto sun = player->Camp->getSun();
	Zombies zombies(player->Camp->getCurrentZombies());
	auto plants = player->Camp->getCurrentPlants();
	auto leftLines = player->Camp->getLeftLines();
	int placeRow[7] = { -1, -1, -1, -1, -1, -1 ,-1 };
	auto time = player->getTime();

	// 植物方
	if (type == 0)
	{
		/*placeChili(player, sun, CD[4], plants, zombies, leftLines, placeRow);
		placeWogua(player, sun, CD[5], plants, zombies, leftLines, placeRow);
		placePeaShooter(player, sun, CD[2], plants, zombies, leftLines, placeRow);
		placeSunFlower(player, sun, CD[0], plants, zombies, leftLines, placeRow);
		placeNut(player, sun, CD[3], plants, zombies, leftLines, placeRow);
		placeIcePeaShooter(player, sun, CD[1], plants, zombies, leftLines, placeRow);*/

		plantPlay(player);
	}

	// 僵尸方
	if (type == 1)
	{
		placeGangZombie(player, sun, CD[4], plants, leftLines, placeRow);
		placeCarZombie(player, sun, CD[3], plants, leftLines, placeRow);
		placeCaplZombie(player, sun, CD[1], plants, leftLines, placeRow);
		placeStickZombie(player, sun, CD[2], plants, leftLines, placeRow);
		placeNormalZombie(player, sun, CD[0], plants, leftLines, placeRow);
	}
}

