#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
void player_ai(IPlayer * player)
{
    // player code here
    int Type = player->Camp->getCurrentType();
    int** Plants = player->Camp->getCurrentPlants();
    int*** Zombies = player->Camp->getCurrentZombies();
    int rows = player->Camp->getRows();
    int columns = player->Camp->getColumns();
    int sun = player->Camp->getSun();
    int time = player->getTime();
    int* LeftLines = player->Camp->getLeftLines();
    int* PlantCD = player->Camp->getPlantCD();

    //����ÿ��ֲ�����в����3stepΪ��׼
    int* rowplantthreat;
    int rowthreatmin = 0;
    rowplantthreat = new int[rows];
    //def �ض�ֲ��������ÿ�����Ƿ���ڼ�����ǰλ��
    int* nut;
    nut = new int[rows];
    //ֲ����ֲ��ַ��ǰ��һλ
    int* rowplantbegin;
    rowplantbegin = new int[rows];
    int rowplantbeginmax = 0;
    int i, j, k = 0;
    int sunflowernum = 0;
    for (int i = 0; i < rows; i++) {
        rowplantbegin[i] = 0;
        for (int j = 0; j < columns; j++) {
            if (Plants[i][j] == 0) {
                rowplantbegin[i] = j;
                break;
            }
        }
    };
    for (int i = 0; i < rows; i++) {
        nut[i] = 0;
        rowplantthreat[i] = 0;
        for (int j = 0; j < columns; j++) {
            if (Plants[i][j] == 2) {
                rowplantthreat[i] += 60 * (columns - j);
            }
            else if (Plants[i][j] == 3) {
                rowplantthreat[i] += 80 * (columns - j);
            }
            else if (Plants[i][j] == 4 && rowplantthreat[i] != 0) {
                rowplantthreat[i] *= 2;
                nut[i] = j;
            };
            if (Plants[i][j] == 1) {
                sunflowernum++;
            };
        };
        if (LeftLines[i] == 0) {
            rowplantthreat[i] = 0;
        }
        if (rowplantbeginmax < rowplantbegin[i]) {
            rowplantbeginmax = i;
        };
        if (rowplantthreat[rowthreatmin] > rowplantthreat[i] && LeftLines[i] != 0) {
            rowthreatmin = i;
        };


    };
    //����ÿ�н�ʬ����в����1stepΪ��׼
    int* rowzombiethreat;
    int* columnszombie;
    int rowthreatmax = 0;
    rowzombiethreat = new int[rows];
    columnszombie = new int[rows];
    for (i = 0; i < rows; i++) {
        rowzombiethreat[i] = 0;
        columnszombie[i] = columns;
        for (j = columns - 1; j >= 0; j--) {
            int k = 0;
            while (Zombies[i][j][k] != -1) {
                columnszombie[i] = j;
                if (Zombies[i][j][k] == 1) {
                    rowzombiethreat[i] += 270 / 5;
                }
                else if (Zombies[i][j][k] == 2) {
                    rowzombiethreat[i] += 1370 / 5;
                }
                else if (Zombies[i][j][k] == 3) {
                    rowzombiethreat[i] += 500 / 2.5;
                }
                else if (Zombies[i][j][k] == 4) {
                    rowzombiethreat[i] += 1350 / 6 + 1350 / 16;
                }
                else if (Zombies[i][j][k] == 5) {
                    rowzombiethreat[i] += 3000 / 5;
                };
                k++;
            };
        };
        rowzombiethreat[i] -= rowplantthreat[i];
        if (rowzombiethreat[rowthreatmax] < rowzombiethreat[i]) {
            rowthreatmax = i;
        };
    };

    if (Type == 0)//ֲ�����
    {
        for (i = 0; i < rows; i++) {
            if (PlantCD[4] == 0 && sun >= 125 && columnszombie[i] <= 2 && sunflowernum != 0) {
                player->PlacePlant(5, i, 9);
            }
        };
        for (i = 0; i < rows; i++) {

            if (i == rowthreatmax && PlantCD[2] == 0 && (PlantCD[1] != 0 || sun <= 400) && sun >= 150 && sunflowernum != 0
                && columnszombie[i] > 2 && (rowzombiethreat[i] != 0 || sun >= 400)) {
                player->PlacePlant(3, rowthreatmax, max(rowplantbegin[rowthreatmax], 1));
            }//���㶹
            if (PlantCD[1] == 0 && sun >= 500 && sunflowernum != 0
                && columnszombie[i] > 2 && (rowzombiethreat[i] != 0 || sun >= 800)) {
                player->PlacePlant(2, rowthreatmax, rowplantbegin[rowthreatmax]);
            }//�ֱ��㶹

        };

        if (sunflowernum < 5 && PlantCD[0] == 0 && columnszombie[rowthreatmax] >= 5
            ) {
            for (i = 0; i < rows; i++) {

                if (sun >= 50 && Plants[i][2] == 0 && LeftLines[i] == 1 && columnszombie[i] > 2) {
                    player->PlacePlant(1, i, 2);
                    sunflowernum++;
                }
            };
        }
        for (i = 0; i < rows; i++) {
            if (columnszombie[i] <= 1 && PlantCD[5] == 0 && sun >= 50 && sunflowernum >= 2) {
                player->PlacePlant(6, i, columnszombie[i]);
            }
            if (i == rowthreatmax && rowplantthreat[i] != 0) {
                if (columnszombie[i] <= 1 && PlantCD[5] == 0 && sun >= 50 && sunflowernum >= 2) {
                    player->PlacePlant(6, i, max(rowplantbegin[i], 3));
                }

                if (PlantCD[4] == 0 && sun >= 125 && columnszombie[i] - rowplantbegin[i] == 1) {
                    player->PlacePlant(5, i, 9);
                }
            }
            if (PlantCD[3] == 0 && sun >= 100 && rowplantthreat[i] != 0 && nut[i] == 0 && rowzombiethreat[i] != 0) {
                player->PlacePlant(4, i, columnszombie[i]);
            }//�ּ��
            if (time >= 800 && PlantCD[5] == 0 && sunflowernum >= 3 && ((time % 500) < 475) && Plants[i][rowplantbegin[i]] != 6) {
                player->PlacePlant(6, i, rowplantbegin[i]);
            }
        };

    }
    else//��ʬ����,�߼�Ϊ����ֲ�﹥����λ�٣���������
    {
        int i = rowthreatmin;
        for (j = 0; j < rows; j++) {
            if (time % 500 == 499 && sun >= 1200 && LeftLines[j] != 0 && j != i) {
                player->PlaceZombie(5, j);
                player->PlaceZombie(2, j);
                player->PlaceZombie(1, j);

            }
        };

        if (time % 500 == 0 && sun >= 700) {
            player->PlaceZombie(5, i);
            player->PlaceZombie(4, i);
            player->PlaceZombie(3, i);
            player->PlaceZombie(2, i);
            player->PlaceZombie(1, i);
        };
        for (i = 0; i < rows; i++) {
            if (rowplantthreat[i] == 0 && sun >= 150 && time < 300) {
                if (PlantCD[0] != 0 && PlantCD[1] == 0 && Zombies[i][columns][0] == -1) {
                    player->PlaceZombie(2, i);
                }
                else {
                    player->PlaceZombie(1, i);
                }
            }
        };
        for (i = 0; i < rows; i++) {
            if (rowplantthreat[i] == 0 && sun >= 500 && time < 800 && time > 300) {
                if (PlantCD[0] != 0 && PlantCD[1] == 0 && Zombies[i][columns][0] == -1) {
                    player->PlaceZombie(2, i);
                }
                else {
                    player->PlaceZombie(1, i);
                }
            }
        };
        i = rowthreatmin;
        if (rowplantthreat[i] == 0 && sun >= 500) {
            if (PlantCD[0] != 0 && PlantCD[1] == 0) {
                player->PlaceZombie(2, i);
            }
            else {
                player->PlaceZombie(1, i);
            }
        };
        if (sun >= 900 && time > 900) {
            if (sun >= 300 && PlantCD[4] == 0) {
                player->PlaceZombie(5, i);
            }
            if (sun >= 200 && PlantCD[3] == 0) {
                player->PlaceZombie(4, i);
            }
            if (sun >= 75 && PlantCD[2] == 0) {
                player->PlaceZombie(3, i);
            }
        };
        if (sun >= 750 && PlantCD[0] == 0) {
            player->PlaceZombie(1, i);
        }
        else if (sun >= 750 && PlantCD[1] == 0) {
            player->PlaceZombie(2, i);
        }
    }
}