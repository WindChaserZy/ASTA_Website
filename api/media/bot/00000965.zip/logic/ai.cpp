#include "ai.h"
//选手代码在下方填入
void player_ai(IPlayer* player) {
    // Breakdown 破碎界限
    // 开工时间 2022.04.22
    // 最后更新 2022.04.23
    // 获取通用战场数据
    int time = player->getTime();
    int type = player->Camp->getCurrentType();
    int*** zombies = player->Camp->getCurrentZombies();
    int** plants = player->Camp->getCurrentPlants();
    int* cooldowns = player->Camp->getPlantCD();
    int sun = player->Camp->getSun();
    int rows = player->Camp->getRows();
    int columns = player->Camp->getColumns();
    int* leftLines = player->Camp->getLeftLines();

    // 基本数据
    const int moonlight_gain[] = { 27, 97, 37, 73, 0, 0 }; //消灭植物获得的月光数
    const int plants_sun[] = { 50, 400, 100, 50, 125, 50 }; //各植物的阳光数
    const int plants_hp[] = { 300,300,300,4000,300,300 }; //各植物的血量最大值
    const int plants_dmg[] = { 0, 60, 20, 0, 1800, 1800 }; //各植物的单次伤害
    const int plants_dmg_interval[] = { 0,3,2,0,0,0 }; //各植物攻击间隔
    const double plants_dps[] = { 0,15,20.0/3,0,0,0 }; //各植物DPS

    const int zombies_hp[] = { 270,820,200,1600,3000 };
    const int zombies_sun[] = { 50, 125, 125, 200, 300 };

    // 实时计算数据
    int i, j, k;
    int squashcount[5][2] = { 0 }; // 倭瓜
    double plants_plain_power[5] = { 0 }; // 植物在各行的火力总和
    double p_total_dpower[5] = { 0 };// 破坏抵抗
    double p_dpowersum = 0;
    double p_total_ipower[5] = { 0 };// 渗透抵抗
    double p_powermap[5][10] = { 0 };
    double p_plain_powermap[5][10] = {0};
    double p_totaldps[5] = { 0 }; // 植物在各行的DPS和
    double zombies_power[5] = { 0 }; // 僵尸的生存能力
    double zombies_powersum = 0;
    int frontiers[5] = { -1 }; // 坚果判断的前线列数
    int rightmost[5] = { -1 }; // 最前方列数
    double p_f_lpower[5] = { 0 }; // 前线左侧
    double p_f_rpower[5] = { 0 }; // 前线右侧
    double plants_valuemap[5][10] = {0}; //在僵尸方计算
    double plants_value[5] = { 0 };
    int slow[5] = { -1,-1,-1,-1,-1 }; // 存在冰豌豆的格子
    //对每一行计算
    for (i = 0;i < rows;i++)
    {
        if (!leftLines[i]) continue;
        // 坚果
        for (j = columns - 1;j >= 0;j--)
        {
            if (rightmost[i] == -1 && plants[i][j] != 0)
            {
                rightmost[i] = j;
            }
            if (plants[i][j] == 4)
            {
                if (frontiers[i] != -1)
                {
                    frontiers[i] = j;
                    break;
                }
                frontiers[i] = j;
            }
        }
        // 倭瓜
        for (j = columns - 1;j >= 0;j--)
        {
            if (plants[i][j] == 6)
            {
                if (j > frontiers[i])
                    squashcount[i][1]++;
                else
                    squashcount[i][0]++;
            }
        }
        // 冰豌豆
        for (j = 0;j < columns;j++)
        {
            if (plants[i][j] == 2)
                slow[i] = j;
        }
        // 植物综合
        int dsteps = 0;
        int asteps = 0; //接触时刻
        double _rdps = 0; // 右侧DPS
        for (j = columns - 1;j >= 0;j--)
        {
            if (plants[i][j] !=0)
            {
                dsteps += plants_hp[plants[i][j] - 1] / 75;
                p_powermap[i][j] = plants_dps[plants[i][j] - 1] * dsteps;
                p_plain_powermap[i][j] = plants_dps[plants[i][j] - 1] * (columns - 1 - j);
                if (slow[i] != -1) // 对于冰豌豆的特殊处理
                {
                    p_powermap[i][j] *= 2;
                    p_plain_powermap[i][j] *= 2;
                }
                p_totaldps[i] += plants_dps[plants[i][j] - 1];
                if (asteps == 0)
                    asteps = dsteps;
            }
            dsteps += 5;
            if (j >= frontiers[i])
                p_f_rpower[i] += p_powermap[i][j];
            else
            {
                p_f_lpower[i] += p_plain_powermap[i][j];
                if (j == frontiers[i])
                {
                    p_total_ipower[i] += p_f_rpower[i];
                    p_total_ipower[i] += p_totaldps[i] * asteps;
                    _rdps = p_totaldps[i];
                }
            }
            plants_plain_power[i] += p_plain_powermap[i][j];
        }
        p_total_dpower[i] = p_f_rpower[i] + p_f_lpower[i];
        p_dpowersum += p_total_dpower[i];
        p_total_ipower[i] += (p_totaldps[i] - _rdps) * dsteps;
        // 僵尸
        int znum = 0;
        for (j = 0;j < columns;j++)
        {
            k = 0;
            while (zombies[i][j][k] != -1)
            {
                if (znum == 0)
                {
                    if(time>1000)
                        zombies_power[i] += (double)zombies_hp[zombies[i][j][k] - 1] * time / 1000 - p_totaldps[i] * (columns - 1 - j) * 5;
                    else
                        zombies_power[i] += zombies_hp[zombies[i][j][k] - 1] - p_totaldps[i] * (columns - 1 - j) * 5;
                }
                else
                {
                    if(time>1000)
                        zombies_power[i] += (double)zombies_hp[zombies[i][j][k] - 1] * time / 1000;
                    else
                        zombies_power[i] += zombies_hp[zombies[i][j][k] - 1];
                }
                k++;
                znum++;
            }
        }
        zombies_powersum += zombies_power[i];
    }

    if (type == 0)  // Plants
    {
        // 判断各行局势
        int lines[5] = { 0,1,2,3,4 };
        int linesStatus[5] = { -1 };
        int status_count[3] = { 0 };
        int bosstile[5] = { -1 };
        int bosstype[5] = { -1 };
        int bossnum[5] = { 0 };
        int leftmost_zombies[5] = { -1 };
        int zombie_density[5][10] = { 0 };
        int max_density_tile[5] = { -1 };
        int total_zombies[5] = { 0 };
        int sunflowers[5] = { 0 };
        int total_sunflowers = 0;
        int wallnuts[5] = { 0 };
        for (i = 0;i < rows;i++)
        {
            if (!leftLines[i]) continue;
            // 读僵尸信息，其实也应该放到前面
            for (j = 0;j < columns;j++)
            {
                k = 0;
                while (zombies[i][j][k] != -1)
                {
                    if (zombies[i][j][k] == 4 || zombies[i][j][k] == 5)
                    {
                        if (bosstile[i] == -1)
                        {
                            bosstile[i] = j;
                            bosstype[i] = zombies[i][j][k];
                        }
                        bossnum[i]++;
                    }
                    zombie_density[i][j]++;
                    total_zombies[i]++;
                    k++;
                }
            }
            int _tmp = 0;
            for (j = 0;j < columns;j++)
            {
                if (zombie_density[i][j] > _tmp)
                {
                    max_density_tile[i] = j;
                    _tmp = zombie_density[i][j];
                }

            }
            // 读植物，向日葵
            for (j = 0;j < columns;j++)
            {
                if (plants[i][j] == 1)
                {
                    sunflowers[i]++;
                    total_sunflowers++;
                }
                if (plants[i][j] == 4)
                {
                    wallnuts[i]++;
                }
            }
            // 判断
            if (bosstile[i] != -1)
            {
                if (plants_plain_power[i] > zombies_power[i] * 1.5)
                    linesStatus[i] = 0;
                else if (plants_plain_power[i] > zombies_power[i])
                    linesStatus[i] = 1;
                else
                    linesStatus[i] = 2;
            }
            else
            {
                if (p_total_ipower[i] > zombies_power[i] * (1 + total_zombies[i] * 0.1) || total_zombies[i]==0)
                    linesStatus[i] = 0;
                else if (p_total_dpower[i] > zombies_power[i] * (1 + total_zombies[i] * 0.1))
                    linesStatus[i] = 1;
                else
                    linesStatus[i] = 2;
            }
            status_count[linesStatus[i]]++;
            // 按从大到小排序
            for (i = 0;i < rows - 1;i++)
            {
                for (j = 0;j < rows - i - 1;j++)
                {
                    if (linesStatus[j] < linesStatus[j + 1])
                    {
                        int _tmp = lines[j + 1];
                        lines[j + 1] = lines[j];
                        lines[j] = _tmp;
                        _tmp = linesStatus[j + 1];
                        linesStatus[j + 1] = linesStatus[j];
                        linesStatus[j] = _tmp;
                    }
                }
            }
        }
        for (i = 0;i < rows;i++)
        {
            int planted = 0;
            if (linesStatus[i] == 2)  // 危急
            {
                //优先种倭瓜
                if (max_density_tile[lines[i]] != -1 && cooldowns[5] == 0 && zombie_density[lines[i]][max_density_tile[lines[i]]] >= 3)
                {
                    if (plants[lines[i]][max_density_tile[lines[i]]] == 0)
                        player->PlacePlant(6, lines[i], max_density_tile[lines[i]]);
                    else
                    {
                        //不知道铲植物会不会给僵尸加成
                        for (j = max_density_tile[lines[i]] - 1;j >= 0 && j >= max_density_tile[lines[i]] - 2;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(6, lines[i], j);
                                planted = 1;
                                break;
                            }
                        }
                    }
                }
                if (bosstile[lines[i]] != -1)
                {
                    //对BOSS用倭瓜
                    if (zombies_hp[bosstype[lines[i]] - 1] - p_totaldps[lines[i]] * (columns - rightmost[lines[i]] - 1) > 0)
                    {
                        if (zombies_hp[bosstype[lines[i]] - 1] - p_totaldps[lines[i]] * (columns - rightmost[lines[i]] - 1) > 1000 && (bossnum[lines[i]] >= 2 || bosstile[lines[i]] <= 5 || p_totaldps[lines[i]] < 15))
                        {
                            for (j = bosstile[lines[i]];j >= 0 && j >= bosstile[lines[i]] - 2;j--)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(6, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                        if ((!planted && zombies_power[lines[i]] > 6000) || (bossnum[lines[i]] >= 2 && zombies_hp[bosstype[lines[i]] - 1] - p_totaldps[lines[i]] * (columns - rightmost[lines[i]] - 1) > 1000))
                        {
                            for (j = 0;j < columns;j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(5, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                //普通的情况
                else
                {
                    if (zombies_power[lines[i]] < 2000 && total_zombies[lines[i]] < 4)
                    {
                        if (wallnuts[lines[i]] <= 2 && cooldowns[3] == 0)
                        {
                            for (j = leftmost_zombies[lines[i]];j >= 2;j--)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(4, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                        //找位置种冰豌豆
                        if (sun > 700 && cooldowns[1] == 0 && slow[lines[i]] == -1)
                        {
                            for (j = 0;j < leftmost_zombies[lines[i]] - 2 || (plants[lines[i]][leftmost_zombies[lines[i]]] == 4 && j < leftmost_zombies[lines[i]]);j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(2, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                            p_total_dpower[lines[i]] *= 2;
                            p_total_dpower[lines[i]] += plants_dps[1] * (leftmost_zombies[lines[i]] - rightmost[lines[i]]);
                        }
                        // 种普通豌豆
                        else if (cooldowns[2] == 0)
                        {
                            for (j = 0;j < leftmost_zombies[lines[i]] - 2 || (plants[lines[i]][leftmost_zombies[lines[i]]] == 4 && j < leftmost_zombies[lines[i]]);j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(3, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                            p_total_dpower[lines[i]] *= 1.1;
                            p_total_dpower[lines[i]] += plants_dps[2] * (leftmost_zombies[lines[i]] - rightmost[lines[i]]);
                        }
                        // 种坚果
                        //if (wallnuts[lines[i]] <= 2 && cooldowns[3] == 0 && (leftmost_zombies[lines[i]] <= 5 || total_zombies[lines[i]] >= 2 || zombies_power[lines[i]]>p_total_dpower[lines[i]] * 1.2))
                        //{
                        //    for (j = leftmost_zombies[lines[i]];j >= 2;j--)
                        //    {
                        //       if (plants[lines[i]][j] == 0)
                        //        {
                        //            player->PlacePlant(4, lines[i], j);
                        //            planted = 1;
                        //            break;
                        //        }
                       //     }
                       // }
                    }
                    if (!planted)
                    {
                        //找倭瓜落点
                        if (cooldowns[5] == 0)
                        {
                            for (j = max_density_tile[lines[i]];j >= 0 && j >= leftmost_zombies[lines[i]] - 2 && j<columns;j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(6, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                        // 辣椒
                        else if (!planted)
                        {
                            if (leftmost_zombies[lines[i]] <= frontiers[lines[i]] || leftmost_zombies[lines[i]] <= 3)
                            {
                                for (j = 0;j < columns;j++)
                                {
                                    if (plants[lines[i]][j] == 0)
                                    {
                                        player->PlacePlant(5, lines[i], j);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if (linesStatus[i] == 1)
            {
                //OpenCV 3.0!!!
                //优先种倭瓜
                if (max_density_tile[lines[i]] != -1 && cooldowns[5] == 0 && zombie_density[lines[i]][max_density_tile[lines[i]]] >= 3)
                {
                    if (plants[lines[i]][max_density_tile[lines[i]]] == 0)
                        player->PlacePlant(6, lines[i], max_density_tile[lines[i]]);
                    else
                    {
                        //不知道铲植物会不会给僵尸加成
                        for (j = max_density_tile[lines[i]] - 1;j >= 0 && j >= max_density_tile[lines[i]] - 2;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(6, lines[i], j);
                                planted = 1;
                                break;
                            }
                        }
                    }
                }
                if (bosstile[lines[i]] != -1)
                {
                    //对BOSS用倭瓜
                    if (zombies_hp[bosstype[lines[i]] - 1] - p_totaldps[lines[i]] * (columns - rightmost[lines[i]] - 1) > 0)
                    {
                        if (zombies_hp[bosstype[lines[i]] - 1] - p_totaldps[lines[i]] * (columns - rightmost[lines[i]] - 1) > 1000 && (bossnum[lines[i]] >= 2 || bosstile[lines[i]] <= 5 || p_totaldps[lines[i]] < 15))
                        {
                            for (j = bosstile[lines[i]];j >= 0 && j >= bosstile[lines[i]] - 2;j--)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(6, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                else
                {
                    //种坚果
                    if (frontiers[lines[i]] <= leftmost_zombies[lines[i]] - 3 && wallnuts[lines[i]] <= 3)
                    {
                        for (j = leftmost_zombies[lines[i]];j >= frontiers[lines[i]] && j>=0;j--)
                        {
                            if (plants[lines[i]][j] != 0)
                            {
                                player->PlacePlant(4, lines[i], j);
                                frontiers[lines[i]] = j;
                                break;
                            }
                        }
                    }
                    //  种豌豆
                    if ((p_totaldps[lines[i]] < 10 && slow[lines[i]] == -1) || (p_totaldps[i] < 6 && slow[lines[i]] != -1))
                    {
                        if (slow[lines[i]] == -1 && sun > 650 && total_sunflowers > 4)
                        {
                            for (j = 0;j <= frontiers[lines[i]] && j < columns;j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(2, lines[i], j);
                                    planted = 1;
                                    break;
                                }
                            }
                        }
                        if (!planted)
                        {
                            for (j = 0;j <= frontiers[lines[i]] && j < columns;j++)
                            {
                                if (plants[lines[i]][j] == 0)
                                {
                                    player->PlacePlant(3, lines[i], j);
                                }
                            }
                        }
                    }
                }
            }
            else if (linesStatus[i] == 0)
            {
                if (sunflowers[lines[i]] < 2)
                {
                    if (frontiers[lines[i]] == -1)
                    {
                        for (j = 1;j < 4;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(1, lines[i], j);
                            }
                        }
                    }
                    else
                    {
                        for (j = 1;j < frontiers[lines[i]]+3 && j<columns;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(1, lines[i], j);
                            }
                        }
                    }
                }
                //  种豌豆
                if ((p_totaldps[lines[i]] < 10 && slow[lines[i]] == -1) || (p_totaldps[i] < 6 && slow[lines[i]] != -1))
                {
                    if (slow[lines[i]] == -1 && sun > 650 && total_sunflowers > 4)
                    {
                        for (j = 0;j <= 4;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(2, lines[i], j);
                                planted = 1;
                                break;
                            }
                        }
                    }
                    if (!planted)
                    {
                        for (j = 0;j < columns;j++)
                        {
                            if (plants[lines[i]][j] == 0)
                            {
                                player->PlacePlant(3, lines[i], j);
                            }
                        }
                    }
                }
                // 种坚果
                if (frontiers[lines[i]] <= rightmost[lines[i]] - 4)
                {
                    player->PlacePlant(4, lines[i], rightmost[lines[i]] + 1);
                }
            }
        }
    }
    if (type == 1)  // Zombies
    {
        // 计算参数
        double moonlight_ratio=(((double)p_dpowersum/(zombies_powersum+sun*5.3+0.1))-1)/(3-1); // TODO
        if(time>1000) moonlight_ratio = (((double)p_dpowersum / (zombies_powersum + sun * 5.3 * time / 1000 + 0.1)) - 1) / (3 - 1);
        if (moonlight_ratio > 1)moonlight_ratio = 1;
        if (moonlight_ratio < 0)moonlight_ratio = 0;
        int lines[5] = { 0,1,2,3,4 };
        double diffpower[5] = { -6000 };
        double efficiency[5] = { -1 };
        //double ratio_pl[5] = { -1 };
        //int priorities[] = { 0,1,2,3,4 };
        //for (i = 0;i < rows;i++)
        //{
        //    if (!leftLines[i]) continue;
        //    ratio_pl[i] = (double)p_total_dpower[i] / (zombies_power[i]+0.1);
        //}
        
        if (moonlight_ratio > 0.4) // 侦察
        {
            for (i = 0;i < rows;i++)
            {
                if (!leftLines[i]) continue;
                diffpower[i] = p_total_ipower[i] - zombies_power[i];
                for (j = 0;j < columns;j++)
                {
                    if (plants[i][j] != 0)
                    {
                        plants_valuemap[i][j] = (double)moonlight_gain[plants[i][j] - 1] * moonlight_ratio + plants_sun[plants[i][j] - 1] * (1 - moonlight_ratio);
                        if (plants[i][j] == 1) plants_valuemap[i][j] += 10;  //TODO
                        plants_value[i] += plants_valuemap[i][j];
                    }
                }
                efficiency[i] = (double)plants_value[i] / (diffpower[i]+0.1);
            }
            // 从小到大排序,不是排diffpower!!!
            for (i = 0;i < rows - 1;i++)
            {
                for (j = 0;j < rows - i - 1;j++)
                {
                    if (efficiency[j] > efficiency[j + 1])
                    {
                        int _tmp = lines[j + 1];
                        lines[j + 1] = lines[j];
                        lines[j] = _tmp;
                        double _dtmp = diffpower[j + 1];
                        diffpower[j + 1] = diffpower[j];
                        diffpower[j] = _tmp;
                        _dtmp = efficiency[j + 1];
                        efficiency[j + 1] = efficiency[j];
                        efficiency[j] = _dtmp;
                    }
                }
            }
            // 先找到特殊情况
            for (i = rows-1;i >=0;i--)
            {
                if (efficiency[i] < -0.01) continue;
                if (!leftLines[lines[i]]) continue;
                if (diffpower[i] < -p_total_ipower[lines[i]] * 0.3)continue;
                //坚果突破
                if (plants[lines[i]][rightmost[lines[i]]] == 4)
                {
                    int wallnuts = 0;
                    int leftmost_zombie = -1;
                    for (j = rightmost[lines[i]];j > frontiers[lines[i]];j--)
                    {
                        if (plants[lines[i]][j] == 4) wallnuts += 1;
                    }
                    for (j = 0;j < columns;j++)
                    {
                        if (zombies[lines[i]][j][0] != -1)
                        {
                            leftmost_zombie = j;
                            break;
                        }
                    }
                    if (wallnuts >= 3)
                    {
                        player->PlaceZombie(4, lines[i]); //冰车
                        continue;
                    }
                    if (squashcount[lines[i]][1] > 0)
                    {
                        if (p_totaldps[lines[i]] < 1 || (p_totaldps[lines[i]] < 10 && leftmost_zombie != -1 && leftmost_zombie <= rightmost[lines[i]] + 2))
                            player->PlaceZombie(3, lines[i]);  //撑杆
                        else if (diffpower[i] < 250)
                            player->PlaceZombie(1, lines[i]); //普通
                        else
                            player->PlaceZombie(2, lines[i]); //铁桶
                    }
                    else if (wallnuts == 1 && p_totaldps[lines[i]] < 1)
                    {
                        player->PlaceZombie(3, lines[i]); //撑杆
                    }
                    
                }
                else
                {
                    if (diffpower[i] < 250)
                        player->PlaceZombie(1, lines[i]); //普通
                    else if (diffpower[i] < 800)
                        player->PlaceZombie(2, lines[i]); //铁桶
                    else if (diffpower[i] < 1550 && squashcount==0)
                        player->PlaceZombie(4, lines[i]); //冰车
                }
                // 上述没有列出的条件就是什么都不做……应该吧
            }
        }
        else if (moonlight_ratio > 0.2) // 进攻
        {
            //重点攻击一行，最右侧僵尸需走出一定距离，不同时存在两只大僵尸
            for (i = 0;i < rows;i++)
            {
                if (!leftLines[i]) continue;
                diffpower[i] = plants_plain_power[i] - zombies_power[i]; // 也可以用dpower, dps
                for (j = 0;j < columns;j++)
                {
                    if (plants[i][j] != 0)
                    {
                        plants_valuemap[i][j] = (double)moonlight_gain[plants[i][j] - 1] * moonlight_ratio + plants_sun[plants[i][j] - 1] * (1 - moonlight_ratio);
                        if (plants[i][j] == 1) plants_valuemap[i][j] += 17;  //TODO
                        plants_value[i] += plants_valuemap[i][j];
                    }
                }
                efficiency[i] = (double)plants_value[i] / (diffpower[i]+0.1);
            }
            //OpenCV(?)
            for (i = 0;i < rows - 1;i++)
            {
                for (j = 0;j < rows - i - 1;j++)
                {
                    if (efficiency[j] > efficiency[j + 1])
                    {
                        int _tmp = lines[j + 1];
                        lines[j + 1] = lines[j];
                        lines[j] = _tmp;
                        double _dtmp = diffpower[j + 1];
                        diffpower[j + 1] = diffpower[j];
                        diffpower[j] = _tmp;
                        _dtmp = efficiency[j + 1];
                        efficiency[j + 1] = efficiency[j];
                        efficiency[j] = _dtmp;
                    }
                }
            }
            for (i = rows-1;i >=0;i--)
            {
                if (efficiency[i] < -0.01) continue;
                if (!leftLines[lines[i]]) continue;
                if (diffpower[i] < -plants_plain_power[lines[i]] * 0.3) continue;
                int rightmost_zombie = 10;
                int leftmost_zombie = -1;
                int rm_zombie_type = 0;
                int boss_pos = -1;
                for (j = columns - 1;j >=0;j--)
                {
                    if (zombies[lines[i]][j][0] != -1)
                    {
                        rightmost_zombie = j;
                        rm_zombie_type = zombies[lines[i]][j][0];
                        break;
                    }
                }
                for (j = 0;j < columns;j++)
                {
                    if (zombies[lines[i]][j][0] != -1)
                    {
                        leftmost_zombie = j;
                        break;
                    }
                }
                for (j = 0;j < columns;j++)
                {
                    k = 0;
                    while (zombies[lines[i]][j][k] != -1)
                    {
                        if (zombies[lines[i]][j][k] == 4 || zombies[lines[i]][j][k] == 5)
                        {
                            boss_pos = j;
                        }
                        k++;
                    }
                }
                if (rightmost_zombie>=columns-1||(rm_zombie_type!=1&&rightmost_zombie >= columns - 2)) continue;
                if (leftmost_zombie <= rightmost[lines[i]] + 2 && p_totaldps[lines[i]] < 24 && (slow[lines[i]] == -1 || slow[lines[i]] == rightmost[lines[i]] - 1))
                {
                    player->PlaceZombie(3, lines[i]);
                }
                if (diffpower[i] < 420)
                    player->PlaceZombie(1, lines[i]);
                else if (diffpower[i] < 1000)
                    player->PlaceZombie(2, lines[i]);
                else if ((diffpower[i] < 1920 || (leftmost_zombie <= rightmost[lines[i]] + 3 && squashcount[lines[i]][1]==0)) && boss_pos == -1)
                {
                    player->PlaceZombie(4, lines[i]);
                    boss_pos = 10;
                }
                else if (boss_pos != -1 && sun>=450)
                    player->PlaceZombie(5, lines[i]);
            }
        }
        else // 歼灭
        {
            //游戏开始时就在这一阶段。
            for (i = 0;i < rows;i++)
            {
                if (!leftLines[i]) continue;
                diffpower[i] = p_total_dpower[i] - zombies_power[i]; // 也可以用plain, dps
                for (j = 0;j < columns;j++)
                {
                    if (plants[i][j] != 0)
                    {
                        plants_valuemap[i][j] = (double)moonlight_gain[plants[i][j] - 1] * 0.2 + plants_sun[plants[i][j] - 1] * 0.8;
                        if (plants[i][j] == 1) plants_valuemap[i][j] += 17;  //TODO
                        plants_value[i] += plants_valuemap[i][j];
                    }
                }
                efficiency[i] = (double)plants_value[i] / (diffpower[i] + 0.1);
            }
            //OpenCV 2.0(?)
            for (i = 0;i < rows - 1;i++)
            {
                for (j = 0;j < rows - i - 1;j++)
                {
                    if (efficiency[j] > efficiency[j + 1])
                    {
                        int _tmp = lines[j + 1];
                        lines[j + 1] = lines[j];
                        lines[j] = _tmp;
                        double _dtmp = diffpower[j + 1];
                        diffpower[j + 1] = diffpower[j];
                        diffpower[j] = _tmp;
                        _dtmp = efficiency[j + 1];
                        efficiency[j + 1] = efficiency[j];
                        efficiency[j] = _dtmp;
                    }
                }
            }
            for (i = rows-1;i >=0;i--)
            {
                if (efficiency[i] < -0.01) continue;
                if (!leftLines[lines[i]]) continue;
                if (diffpower[i] < -p_total_dpower[lines[i]] * 0.3) continue;
                if (p_totaldps[lines[i]] < 1)
                {
                    player->PlaceZombie(1, lines[i]);
                }
                else if (diffpower[i] < 250)
                {
                    player->PlaceZombie(1, lines[i]);
                }
                else if (diffpower[i] < 800)
                {
                    player->PlaceZombie(2, lines[i]);
                }
                else if (sun > 750)
                {
                    int rightmost_zombie = 10;
                    int leftmost_zombie = -1;
                    int rm_zombie_type = 0;
                    int boss_pos = -1;
                    for (j = columns - 1;j >= 0;j--)  //应该放到最条件判断之前的.
                    {
                        if (zombies[lines[i]][j][0] != -1)
                        {
                            rightmost_zombie = j;
                            rm_zombie_type = zombies[lines[i]][j][0];
                            break;
                        }
                    }
                    for (j = 0;j < columns;j++)
                    {
                        if (zombies[lines[i]][j][0] != -1)
                        {
                            leftmost_zombie = j;
                            break;
                        }
                    }
                    for (j = 0;j < columns;j++)
                    {
                        k = 0;
                        while (zombies[lines[i]][j][k] != -1)
                        {
                            if (zombies[lines[i]][j][k] == 4 || zombies[lines[i]][j][k] == 5)
                            {
                                boss_pos = j;
                            }
                            k++;
                        }
                    }
                    if (rightmost_zombie >= columns - 1 || (rm_zombie_type != 1 && rightmost_zombie >= columns - 2)) continue;
                    if (leftmost_zombie <= rightmost[lines[i]] + 2 && p_totaldps[lines[i]] < 24 && (slow[lines[i]] == -1 || slow[lines[i]] == rightmost[lines[i]] - 1))
                    {
                        player->PlaceZombie(3, lines[i]);
                    }
                    if (diffpower[i] < 420)
                        player->PlaceZombie(1, lines[i]);
                    else if (diffpower[i] < 1000)
                        player->PlaceZombie(2, lines[i]);
                    else if ((diffpower[i] < 1920 || (leftmost_zombie <= rightmost[lines[i]] + 3 && squashcount[lines[i]][1] == 0)) && boss_pos == -1)
                    {
                        player->PlaceZombie(4, lines[i]);
                        boss_pos = 10;
                    }
                    else if (boss_pos != -1)
                        player->PlaceZombie(5, lines[i]);
                }
            }
        }
    }
}