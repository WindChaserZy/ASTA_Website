#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
void player_ai(IPlayer * player)
{
    int Type = player->Camp->getCurrentType();//获取植物方还是僵尸方
    int** Plants = player->Camp->getCurrentPlants();//获取当前植物情况（向日葵1，冰豌豆2，豌豆射手3，坚果4，辣椒5，倭瓜6）
    int*** Zombies = player->Camp->getCurrentZombies();//获取当前僵尸情况（普通1，铁通2，撑杆跳3，路障4，伽刚特尔5）
    int rows = player->Camp->getRows();//返回有几行
    int columns = player->Camp->getColumns();//返回有几列
    int sun = player->Camp->getSun();//当前阳光数
    int time = player->getTime();//当前step
    int* LeftLines = player->Camp->getLeftLines();//各行是否攻破，1为未攻破
    int* PlantCD = player->Camp->getPlantCD();//获取当前CD

    if (Type == 0) {//当前为植物方

        //遍历各行进行防守
        for (int i = 0; i < rows; i++) {
            int zombiedefence = 0;
            int plantdamage = 0;
            int plantfront = 1;
            int zombiefront = 100;
            int timeremain = 0;
            int damage = 0;
            int zombienum = 0;
            for (int j = 0; j < columns; j++) {
                if (Zombies[i][j][0] != -1) {
                    if (j < zombiefront) zombiefront = j;
                    int k = 0;
                    while (Zombies[i][j][k] != -1) {
                        zombiedefence += zombiePH(Zombies[i][j][k]);
                        k++;
                        zombienum++;
                    }
                }
                if (j > plantfront) plantfront = j;
                if (Plants[i][j] != -1) {
                    plantdamage += PlantAttack(Plants[i][j]);
                }
            }
                damage = (zombiefront - plantfront) * 5 * plantdamage;
                if (damage > zombiedefence) break;
                else if (zombiedefence - damage > 0 && LeftLines[i] == 1 && zombiedefence - damage < (zombiefront - plantfront) * 5 * 20 && PlantCD[1] == 0 && sun >= 50 && sun<100) {
                    player->PlacePlant(6, i, plantfront - 1);
                    Plants[i][plantfront - 1] = 6;
                    sun -= 50;
                    plantfront++;
                }//阳光比较少种倭瓜
                else if (zombiedefence - damage > 0 && LeftLines[i] == 1 && zombiedefence - damage < (zombiefront - plantfront) * 5 * 20 && PlantCD[1] == 0 && sun >= 100) {
                    player->PlacePlant(3, i, plantfront-1);
                    Plants[i][plantfront - 1] = 3;
                    sun -= 100;
                    plantfront++;
                }//阳光比较多种豌豆
                else if ( zombiedefence - damage > (zombiefront - plantfront) * 5 * 40 && LeftLines[i] == 1 && PlantCD[1] == 0 && sun >= 400) {
                    player->PlacePlant(2, i, plantfront - 1);
                    Plants[i][plantfront - 1] = 2;
                    sun -= 400;
                    plantfront++;
                }//阳光更多一点种冰豌豆
                else if (zombiedefence - damage > (zombiefront - plantfront) * 5 * 60 && LeftLines[i] == 1 && zombienum >= 3 && PlantCD[5] == 0 && sun >= 125) {
                    player->PlacePlant(5, i, plantfront - 1);
                    Plants[i][plantfront - 1] = 5;
                    sun -= 125;
                    plantfront++;
                }//对面比较强放辣椒
        }

            //防守结束开始种向日葵
        for (int i = 0; i < rows; i++) {
                if (Plants[i][0] == 0 && LeftLines[i] == 1 && PlantCD[0] == 0 && sun >= 50) {
                    player->PlacePlant(1, i, 0);//在第i行种向日葵
                    Plants[i][0] = 1;
                    sun -= 50;
                }
        }
    }
    else {//当前为僵尸方
        int i = 0;
        while (LeftLines[i] == 0) {
            i++;
        }
        if (sun >= 300 && PlantCD[4] == 0) {
            player->PlaceZombie(5, i);
            sun -= 300;
        }
        if (sun >= 200 && PlantCD[3] == 0) {
            player->PlaceZombie(4, i);
            sun -= 200;
        }
        if (sun >= 75 && PlantCD[2] == 0) {
            player->PlaceZombie(3, i);
            sun -= 75;
        }
        if (sun >= 125 && PlantCD[1] == 0) {
            player->PlaceZombie(2, i);
            sun -= 125;
        }
        if (sun >= 50 && PlantCD[0] == 0) {
            player->PlaceZombie(1, i);
            sun -= 50;
        }
    }
}