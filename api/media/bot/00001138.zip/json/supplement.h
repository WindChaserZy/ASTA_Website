#include"vector"
using namespace std;
#ifndef SUPPLEMENT_H_
#define SUPPLEMENT_H_

struct DataSupplement
{
	vector<double> cellTechPoint;
};

#endif
