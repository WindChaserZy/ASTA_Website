#include<stdio.h>
int main()
{
    int offset;
    char ch;
    scanf("%d", &offset);
    scanf("%c", &ch);
    scanf("%c", &ch);
    ch += offset;
    printf("%c", ch);
    return 0;
}