#include<stdio.h>
int main()
{
    int number;
    float price;
    scanf("%d", &number);
    scanf("%f", &price);
    float total = number * price;
    int times = total / 100;
    float discount = 20 * times;
    float pay = total - discount;
    printf("%.2f %.2f", discount, pay);
    return 0;
}