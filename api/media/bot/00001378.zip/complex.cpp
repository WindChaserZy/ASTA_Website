#include<stdio.h>
int main()
{
    float a_re, a_im, b_re, b_im;
    scanf("%f%f%*[i]", &a_re, &a_im);
    scanf("%f%f%*[i]", &b_re, &b_im);
    if(a_im*b_re+a_re*b_im < 0 )
        printf("%.3f%.3f%c", a_re*b_re-a_im*b_im, a_im*b_re+a_re*b_im,'i');
    else
        printf("%.3f%c%.3f%c", a_re*b_re-a_im*b_im,'+', a_im*b_re+a_re*b_im,'i');
    return 0;
}