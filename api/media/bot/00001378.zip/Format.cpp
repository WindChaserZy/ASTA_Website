#include<stdio.h>
int main()
{
    float data[12];
    for (int i = 0; i < 12; i++)
        scanf("%f", &data[i]);
    for (int i = 0; i < 3; i++)
    {
        int tmp_1 = data[2 * i] * 1000;
        int tmp_2 = data[2 * i + 1] * 1000;
        printf("%-6.3f %-6.3f\n", tmp_1 / 1000.0, tmp_2 / 1000.0);
    }
    for (int i = 2; i < 4; i++)
        printf("%6.2f %6.2f %6.2f\n", data[3 * i], data[3 * i + 1], data[3 * i + 2]);
    return 0;
}