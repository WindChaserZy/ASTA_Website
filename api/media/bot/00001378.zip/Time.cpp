#include<stdio.h>
int main()
{
    int hour_1, minute_1, second_1;
    int hour_2, minute_2, second_2;
    int delta;
    int dhour, dminute, dsecond;
    scanf("%d:%d:%d", &hour_1, &minute_1, &second_1);
    scanf("%d:%d:%d", &hour_2, &minute_2, &second_2);
    delta = (hour_1 - hour_2) * 3600 + (minute_1 - minute_2) * 60 + (second_1 - second_2);
    if(delta < 0)
        delta *= -1;
    dhour = delta / 3600;
    dminute = (delta - 3600 * dhour) / 60;
    dsecond = (delta - 3600 * dhour - 60 * dminute);
    printf("%02d:%02d:%02d", dhour, dminute, dsecond);
    return 0;
}