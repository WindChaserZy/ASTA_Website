#include "ai.h"
#include <iostream>
int help = 0;
int offend = 0;
void updateplants(int,int,int ,int& ,int *, int **);
void player_ai(IPlayer * player) {
    int Type = player->Camp->getCurrentType(); //获取植物方还僵尸方
    int BrokenLinesScore = player->getBrokenLinesScore();
    int NotBrokenLinesNum = player->getNotBrokenLines();
    int KillPlantsScore = player->getKillPlantsScore();
    int KillZombiesScore = player->getKillZombiesScore();
    int LeftPlants = player->getLeftPlants();
    int Score = player->getScore();
    int time = player->getTime();
    int rows = player->Camp->getRows();
    int columns = player->Camp->getColumns();
    int* PlantCD = player->Camp->getPlantCD();
    int** Plants = player->Camp->getCurrentPlants();
    int*** Zombies = player->Camp->getCurrentZombies();
    int* LeftLines = player->Camp->getLeftLines();
    int Sun = player->Camp->getSun();
    if (Type == 0) {
        //当前为植物方，采取若干策略
        //int gargantuar[10];
        //int sled[10];
        //int polevault[10];
        //int bucket[10];
        //int normal[10];
        //for(int i=0;i<rows;i++)
        //{
        //    int k=0;
        //    gargantuar[i]=0;
        //    sled[i]=0;
        //    polevault[i]=0;
        //    bucket[i]=0;
        //    normal[i]=0;
        //    for(int j=0;j<columns;j++)
        //    {
        //        k=0;
        //        while(Zombies[i][j][k]!=-1)
        //        {
        //            switch(Zombies[i][j][k])
        //            {
        //                case 1:normal[i]++;break;
        //                case 2:bucket[i]++;break;
        //                case 3:polevault[i]++;break;
        //                case 4:sled[i]++;break;
        //                case 5:gargantuar[i]++;break;
        //                default:break;
        //            }
        //            k++;
        //        }
        //    }
        //}
        //int dangerous[10][2];
        //for(int i=0;i<rows;i++)
        //{
        //    dangerous[i][0]=gargantuar[i]+sled[i];
        //    dangerous[i][1]=i;
        //}
        //for(int i=rows-1;i>=0;i--)
        //{
        //    for(int j=0;j<i;j++)
        //    {
        //        if(dangerous[j][0]<dangerous[j+1][0])
        //        {
        //            int tmp[2]={dangerous[j][0],dangerous[j][1]};
        //            dangerous[j][0]=dangerous[j+1][0];
        //            dangerous[j][1]=dangerous[j+1][1];
        //            dangerous[j+1][0]=tmp[0];
        //            dangerous[j+1][1]=tmp[1];
        //        }
        //        else if(dangerous[j][0]==0&&dangerous[j+1][0]==0&&LeftLines[j]==0)
        //        {
        //            int tmp=dangerous[j][1];
        //            dangerous[j][1]=dangerous[j+1][1];
        //            dangerous[j+1][1]=tmp;
        //        }
        //    }
        //}
        //if(dangerous[0][0]!=0)
        //{
        //    int zombieplace=-1;
        //    if(dangerous[0][0]>1)
        //    {
        //        if(PlantCD[4]==0&&Sun>=125)
        //        {
        //            for(int i=0;i<columns;i++)
        //            {
        //                if(Plants[dangerous[0][1]][i]==0)
        //                {
        //                    player->PlacePlant(5,dangerous[0][1],i);
        //                    updateplants(5,dangerous[0][1],i,Sun,PlantCD,Plants);
        //                    break;
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        int plantplace=-1;
        //        for(int i=columns-1;i>=0;i--)
        //        if(Plants[dangerous[0][1]][i]!=0)
        //        {
        //            plantplace=i;
        //            break;
        //        }
        //        for(int i=0;i<columns&&zombieplace==-1;i++)
        //        {
        //            for(int j=0;Zombies[dangerous[0][1]][i][j]!=-1;j++)
        //            {
        //                if(Zombies[dangerous[0][1]][i][j]==4||Zombies[dangerous[0][1]][i][j]==5)
        //                {
        //                    zombieplace=i;
        //                    break;
        //                }
        //            }
        //        }
        //        if(PlantCD[5]==0&&Sun>=50&&zombieplace<9)
        //        {
        //            player->PlacePlant(6,dangerous[0][1],zombieplace);
        //            updateplants(6,dangerous[0][1],zombieplace,Sun,PlantCD,Plants);
        //        }
        //        else if(PlantCD[4]==0&&Sun>=125&&(plantplace>=zombieplace-1||zombieplace==0))
        //        {
        //            for(int i=0;i<columns;i++)
        //            {
        //                if(Plants[dangerous[0][1]][i]==0)
        //                {
        //                    player->PlacePlant(5,dangerous[0][1],i);
        //                    updateplants(5,dangerous[0][1],i,Sun,PlantCD,Plants);
        //                    break;
        //                }
        //            }
        //        }
        //        else
        //        {
        //            if(plantplace!=-1&&zombieplace-plantplace<=1&&Zombies[dangerous[0][1]][plantplace][0]==-1)
        //            {
        //                player->removePlant(dangerous[0][1],plantplace);
        //                updateplants(0,dangerous[0][1],plantplace,Sun,PlantCD,Plants);
        //            }
        //            int winterpeaplace=-1;
        //            for(int i=0;i<columns;i++)
        //            if(Plants[dangerous[0][1]][i]==2)
        //            {
        //                winterpeaplace=i;
        //                break;
        //            }
        //            if(winterpeaplace==-1)
        //            {
        //                if(!PlantCD[1]&&Sun>=500)
        //                {
        //                    int firstplace=0;
        //                    for(int i=0;i<columns;i++)
        //                    {
        //                        if(Zombies[dangerous[0][1]][i][0]!=-1)
        //                        {
        //                            firstplace=i;
        //                            break;
        //                        }
        //                    }
        //                    if(firstplace>5)
        //                    {
        //                        if(Plants[dangerous[0][1]][0]!=0)
        //                        {
        //                            player->removePlant(dangerous[0][1],0);
        //                            updateplants(0,dangerous[0][1],0,Sun,PlantCD,Plants);
        //                        }
        //                        player->PlacePlant(2,dangerous[0][1],0);
        //                        updateplants(2,dangerous[0][1],0,Sun,PlantCD,Plants);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
        //int linezombie[5][2];
        //for(int i=0;i<rows;i++)
        //{
        //    if(LeftLines[i]==1)
        //    {
        //        linezombie[i][0]=sled[i]+gargantuar[i]+bucket[i]+polevault[i]+normal[i];
        //        linezombie[i][1]=i;
        //    }
        //    else {
        //        linezombie[i][0]=-1;
        //    }
        //}
        //for (int i = rows - 1; i >= 0; i--)
        //{
        //    for (int j = 0; j < i; j++)
        //    {
        //        if (linezombie[j][0] < linezombie[j + 1][0])
        //        {
        //            int tmp[2] = { linezombie[j][0],linezombie[j][1] };
        //            linezombie[j][0] = linezombie[j + 1][0];
        //            linezombie[j][1] = linezombie[j + 1][1];
        //            linezombie[j + 1][0] = tmp[0];
        //            linezombie[j + 1][1] = tmp[1];
        //        }
        //    }
        //}
        //for(int count=0;linezombie[count][0]!=-1&&count<rows&&count<=0;count++)
        //{
        //    int i=linezombie[count][1];
        //    int winter=-1,pea=-1,nut=-1,sunflower=-1;
        //    for(int j=0;j<columns-1;j++)
        //    {
        //        switch(Plants[i][j])
        //        {
        //            case 1:sunflower=j;break;
        //            case 2:winter=j;break;
        //            case 3:pea=j;break;
        //            case 4:nut=j;break;
        //            default:break;
        //        }
        //    }
        //    if(linezombie[count][0]>=2)
        //    {
        //        int same=-1;
        //        for(int j=0;j<columns-1;j++)
        //        {
        //            int num=0;
        //            int k=0;
        //            while(Zombies[i][j][k]!=-1)
        //            {
        //                num++;
        //            }
        //            if(Plants[i][j]==0)
        //            {
        //                if(num>=2&&linezombie[count][0]<=4)
        //                {
        //                    if(PlantCD[5]==0&&Sun>=100)
        //                    {
        //                        player->PlacePlant(6,i,j);
        //                        updateplants(6,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                    else if(PlantCD[4]==0&&Sun>=200&&PlantCD[5]>=10)
        //                    {
        //                        player->PlacePlant(5,i,j);
        //                        updateplants(5,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                }
        //                else if(linezombie[count][0]>=4)
        //                {
        //                    if(PlantCD[4]==0&&Sun>=175)
        //                    {
        //                        player->PlacePlant(5,i,j);
        //                        updateplants(5,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                    else if(PlantCD[5]==0&&Sun>=100&&num>=2)
        //                    {
        //                        player->PlacePlant(6,i,j);
        //                        updateplants(6,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    int zombieplace=9;
        //    for(int j=columns;j>=0;j--)
        //    {
        //        if(Zombies[i][j][0]!=-1)
        //        zombieplace=j;
        //    }
        //    
        //    if (nut != -1)
        //    {
        //        if(pea==-1&&winter==-1)
        //        {
        //            bool pla=0;
        //            for(int j=0;j<nut;j++)
        //            {
        //                if(Plants[i][j]==0)
        //                {
        //                    if(PlantCD[1]==0&&Sun>=450)
        //                    {
        //                        player->PlacePlant(2,i,j);
        //                        updateplants(2,i,j,Sun,PlantCD,Plants);
        //                        pla=1;
        //                        break;
        //                    }
        //                    else if(PlantCD[2]==0&&Sun>=150)
        //                    {
        //                        player->PlacePlant(3,i,j);
        //                        updateplants(3,i,j,Sun,PlantCD,Plants);
        //                        pla=1;
        //                        break;
        //                    }
        //                }
        //            }
        //            if(!pla)
        //            {
        //                if(PlantCD[1]==0&&Sun>=450)
        //                {
        //                    player->removePlant(i,0);
        //                    player->PlacePlant(3,i,0);
        //                    updateplants(2,i,0,Sun,PlantCD,Plants);
        //                }
        //                else if(PlantCD[2]==0&&Sun>=150)
        //                {
        //                    player->removePlant(i,0);
        //                    player->PlacePlant(3,i,0);
        //                    updateplants(3,i,0,Sun,PlantCD,Plants);
        //                }
        //            }
        //        }
        //        else{
        //            for(int j=0;j<nut;j++)
        //            {
        //                if(Plants[i][j]==0)
        //                {
        //                    if(PlantCD[1]==0&&Sun>=450)
        //                    {
        //                        player->PlacePlant(2,i,j);
        //                        updateplants(2,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                    else if(PlantCD[2]==0&&Sun>=150)
        //                    {
        //                        player->PlacePlant(3,i,j);
        //                        updateplants(3,i,j,Sun,PlantCD,Plants);
        //                        break;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    else if (sunflower != -1)
        //    {
        //       if(winter!=-1||pea!=-1)
        //        {
        //            if(PlantCD[3]==0&&Sun>=100)
        //            {
        //                //if(winter<zombieplace&&pea<zombieplace)
        //                //{
        //                //    for (int j = zombieplace; j>winter && j>pea && j>sunflower&&j>=0; j--)
        //                //    {
        //                //        /*if(Plants[i][j]==0)
        //                //        {
        //                //            player->PlacePlant(4,i,j);
        //                //            updateplants(4,i,j,Sun,PlantCD,Plants);
        //                //            break;
        //                //        }*/
        //                //    }
        //                //}
        //            }
        //        }
        //        else if (zombieplace == sunflower + 1)
        //        {
        //            /*player->removePlant(i,sunflower);
        //            updateplants(0,i,sunflower,Sun,PlantCD,Plants);*/
        //        }
        //    }
        //    /*else
        //    {
        //        if(linezombie[count][0]<=1)
        //        {
        //            if(PlantCD[3]==0&&Sun>=100)
        //            {
        //                for(int j=zombieplace-1;j>=1;j--)
        //                {
        //                    if(Plants[i][j]==0)
        //                    {
        //                        player->PlacePlant(4,i,j);
        //                        updateplants(4,i,j,Sun,PlantCD,Plants);
        //                        nut=j;
        //                        break;
        //                    }
        //                }
        //                if(nut!=-1)
        //                {
        //                    if(PlantCD[0]==0&&Sun>=75)
        //                    {
        //                        for(int j=nut-1;j>=0;j--)
        //                        {
        //                            if(Plants[i][j]==0)
        //                            {
        //                                player->PlacePlant(1,i,j);
        //                                updateplants(1,i,j,Sun,PlantCD,Plants);
        //                                break;
        //                            }
        //                        }
        //                    }
        //                    if(pea==-1&&winter==-1)
        //                    {
        //                        if(Sun>=450&&PlantCD[1]==0)
        //                        {
        //                            for(int j=0;j<nut;j++)
        //                            {
        //                                if(Plants[i][j]==0)
        //                                {
        //                                    player->PlacePlant(2,i,j);
        //                                    updateplants(2,i,j,Sun,PlantCD,Plants);
        //                                    break;
        //                                }
        //                            }
        //                        }
        //                        else if(Sun>=150&&PlantCD[2]==0)
        //                        {
        //                            for(int j=0;j<nut;j++)
        //                            {
        //                                if(Plants[i][j]==0)
        //                                {
        //                                    player->PlacePlant(3,i,j);
        //                                    updateplants(3,i,j,Sun,PlantCD,Plants);
        //                                    break;
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }*/
        //}
    }
    if (Type == 1) {
        //当前为僵尸方,采取若干策略
        // 扫描当前大致情况
        int wandou[5] = {9999,9999,9999,9999,9999};
        int hanbin[5]={9999,9999,9999,9999,9999};
        int jianguo[5]={9999,9999,9999,9999,9999};
        int wogua[5]={9999,9999,9999,9999,9999};
        int xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        double weighted_average_qianqi[5]={9999,9999,9999,9999,9999};
        double weighted_average_zhongqi_xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        double weighted_average_zhongqi[5] = { 9999,9999,9999,9999,9999 };
        bool need_attack[5]={1,1,1,1,1};
        for(int i = 0; i<rows; ++i){
            if(LeftLines[i] == 0 || Zombies[i][0][0] != -1){
                need_attack[i] = false;
            }
        }
        for (int i = 0; i < rows; ++i) {
            if (!need_attack[i]) continue;
            wandou[i] = 0;
            hanbin[i] = 0;
            jianguo[i] = 0;
            wogua[i] = 0;
            xiangrikui[i] = 0;
        }
        for(int i = 0; i < rows; ++i){
            if(!need_attack[i]) continue;
            for(int j = 0; j<columns; ++j){
                if(Plants[i][j]==2) hanbin[i]++;
                if(Plants[i][j]==3) wandou[i]++;
                if(Plants[i][j]==4) jianguo[i]++;
                if(Plants[i][j]==6) wogua[i]++;
                if (Plants[i][j] == 1) xiangrikui[i]++;
            }
        }
        int min_wandou = 999, min_wandou_i=-1;
        int min_hanbin = 999, min_hanbin_i=-1;
        int min_jianguo = 999, min_jianguo_i=-1;
        int max_xiangrikui = 0, max_xiangrikui_i = -1;
        double min_weighted_average_qianqi = 999; 
        int min_weighted_average_qianqi_i = -1;
        double min_weighted_average_zhongqi_xiangrikui = 999;
        int min_weighted_average_zhongqi_xiangrikui_i = -1;
        double min_weighted_average_zhongqi = 999;
        int min_weighted_average_zhongqi_i = -1;
        for(int i = 0; i<rows; ++i){
            if(!need_attack[i])  continue;
            if(wandou[i]<min_wandou){
                min_wandou = wandou[i];
                min_wandou_i = i;
            }
            if (hanbin[i] < min_hanbin) {
                min_hanbin = hanbin[i];
                min_hanbin_i = i;
            }
            if (jianguo[i] < min_jianguo) {
                min_jianguo = jianguo[i];
                min_jianguo_i = i;
            }
            weighted_average_qianqi[i] = 1.0 * wogua[i] + 0.6 * hanbin[i] + 0.3 * jianguo[i] + 0.1 * wandou[i];
            if (weighted_average_qianqi[i] < min_weighted_average_qianqi) {
                min_weighted_average_qianqi = weighted_average_qianqi[i];
                min_weighted_average_qianqi_i = i;
            }
            weighted_average_zhongqi_xiangrikui[i] = 0.5 * wogua[i] + 0.5 * hanbin[i] + 0.3 * jianguo[i] + 0.7 * xiangrikui[i];
            if (weighted_average_zhongqi_xiangrikui[i] < min_weighted_average_zhongqi_xiangrikui) {
                min_weighted_average_zhongqi_xiangrikui = weighted_average_zhongqi_xiangrikui[i];
                min_weighted_average_zhongqi_xiangrikui_i = i;
            }
            weighted_average_zhongqi[i] = 0.5 * wogua[i] + 0.6 * hanbin[i] + 0.2 * jianguo[i] + 0.2*xiangrikui[i];
            if (weighted_average_zhongqi[i] < min_weighted_average_zhongqi) {
                min_weighted_average_zhongqi = weighted_average_zhongqi[i];
                min_weighted_average_zhongqi_i = i;
            }
            if (xiangrikui[i] >= max_xiangrikui) {
                max_xiangrikui = xiangrikui[i];
                max_xiangrikui_i = i;
            }
        }

        // 检查当前僵尸状况
        int zombies[5] = { 0,0,0,0,0 };
        int tietong[5] = { 0,0,0,0,0 };
        int chenggan[5] = { 0,0,0,0,0 };
        int xueqiao[5] = { 0,0,0,0,0 };
        int jiagang[5] = { 0,0,0,0,0 };
        double all_zombies[5] = { 0,0,0,0,0 };
        for (int i = 0; i < rows; ++i) {
            if (!need_attack[i]) continue;
            for (int j = 0; j < columns; ++j) {
                for (int k = 0; Zombies[i][j][k] != -1; ++k) {
                    if (Zombies[i][j][k] == 1) zombies[i]++;
                    if (Zombies[i][j][k] == 2) tietong[i]++;
                    if (Zombies[i][j][k] == 3) chenggan[i]++;
                    if (Zombies[i][j][k] == 4) xueqiao[i]++;
                    if (Zombies[i][j][k] == 5) jiagang[i]++;
                }
            }
            all_zombies[i] = 0.1*zombies[i] + 0.3*tietong[i] + 0.2*chenggan[i] + 0.5*xueqiao[i] + 0.9*jiagang[i];
        }
        
        // 前期策略
        int target = min_weighted_average_qianqi_i;
        if (target == -1) return;
        if (time <= 200 && target != -1) {
            if (zombies[target] == 0) {
                if (PlantCD[1] == 0 && Sun >= 200)player->PlaceZombie(1, target);
            }
            if (tietong[target] == 0 && Zombies[target][0][0] == -1) {
                if (weighted_average_qianqi[target] > 0.3) {
                    if (PlantCD[1] == 0 && Sun >= 200)player->PlaceZombie(2, target);
                }
            }
            else if (Zombies[target][columns - 1][0] == -1) {
                if (weighted_average_qianqi[target] > 0.1 && weighted_average_qianqi[target]<=0.5) {
                    if ((tietong[target] + zombies[target]) <= wandou[target] || (tietong[target] + zombies[target]) <= (hanbin[target] + 2)) {
                        if (PlantCD[0] == 0 && Sun >= 50)player->PlaceZombie(1, target);
                    }
                }
            }
        }
        //中期策略
        target = min_weighted_average_zhongqi_i;
        if (target == -1) return;
        if ((time > 200 && time <= 450) || (time >600 && time <= 750)) {
            if (Sun <= 500) {
                if (weighted_average_zhongqi[target]<0.6 && (time - offend) >= 75 && ((tietong[target] + zombies[target]) <= wandou[target] || (tietong[target] + zombies[target]) <= (hanbin[target] + 2))) {
                    player->PlaceZombie(1, target);
                    offend = time;
                }
            }
            if (help != 0) {
                if (jiagang[help] == 0 && Zombies[help][0][0] == -1) {
                    player->PlaceZombie(2, help);
                    help = 0;
                }
            }
            if (Sun >= 500) {
                if ((target - 1) >= 0 && need_attack[target]) {
                    player->PlaceZombie(1, target - 1);
                    if (Zombies[target - 1][0][0] == -1) {
                        for (int j = 0; j < columns; ++j) {
                            if (PlantCD[4] == 0) {
                                player->PlaceZombie(5, target);
                                help = target;
                            }
                        }
                    }
                }
                else {
                    player->PlaceZombie(1, target + 1);
                    if (Zombies[target + 1][0][0] == -1) {
                        for (int j = 0; j < columns; ++j) {
                            if (PlantCD[4] == 0) {
                                player->PlaceZombie(5, target);
                                help = target;
                            }
                        }
                    }
                }

            }
        }
    }
}
void updateplants(int type,int x,int y,int& a,int *b,int **c)
{
    switch(type)
    {
        case 0:c[x][y]=0;break;
        case 1:a-=50;b[0]=10;c[x][y]=1;break;
        case 2:a-=400;b[1]=30;c[x][y]=2;break;
        case 3:a-=100;b[2]=10;c[x][y]=3;break;
        case 4:a-=50;b[3]=40;c[x][y]=4;break;
        case 5:a-=125;b[4]=60;c[x][y]=5;break;
        case 6:a-=50;b[5]-=60;c[x][y]=6;break;
        default:break;
    }
}