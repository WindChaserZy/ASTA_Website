#include "ai.h"
#include<iostream>
#include<time.h>
//选手代码在下方填入
//通用变量
int step;
int** Plants;
int*** Zombies;
int* plantcd;

//植物所需变量
int sun;
int squashlist[10][2] = { {-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1} };
int* ali;
int sunflowers[5] = { 0,0,0,0,0 };
int linefire[5] = { 0,0,0,0,0 };
int linezom[5] = { 0,0,0,0,0 };
int zomhead[5] = { 10,10,10,10,10 };
int plantsdanger[5][9] = { {0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0} };

//僵尸所需变量
bool zombie_placement_done = true;
int zomtype = 0, target_line = 0;
int rand_seed;

void place_sunflower(IPlayer* p);
void more_sun(IPlayer* p);
void execute(IPlayer* p, int l);
void plant_ice(IPlayer* p, int l);
void squashclear();
void squash_execute(IPlayer* p);
void more_ice(IPlayer* p);
void rm_plant(IPlayer* p);
void player_ai(IPlayer* player) {
    //收集通用信息
    int _my_camp = player->Camp->getCurrentType();
    Plants = player->Camp->getCurrentPlants();
    Zombies = player->Camp->getCurrentZombies();
    ali = player->Camp->getLeftLines();
    step = player->getTime();

    if (_my_camp == 0)  //植物方策略
    {   //调试
        //std::cout << "step" << step << ": ";
        //system("pause");

        //获取数据
        sun = player->Camp->getSun();
        plantcd = player->Camp->getPlantCD();
        //放向日葵
        place_sunflower(player);
        //正义铲除
        rm_plant(player);
        //逐行操作
        //std::cout << "start execution. ";
        squashclear();
        for (int i = 0; i < 5; i++) {
            execute(player,i);
        }
        squash_execute(player);
        more_ice(player);
        more_sun(player);
    }
    if (_my_camp == 10)  //测试用僵尸方
    {
        if(step == 1)
            player->PlaceZombie(3,2);

    }
    if (_my_camp == 1)  //僵尸方
    {
        int moon = player->Camp->getSun();
        int mooncost[] = { 0,50,125,125,300,300 };
        int* zomcd = player->Camp->getPlantCD();
        //std::cout << "step " << step << ": ";
        //std::cout << "moon: " << moon << ": ";
        if (zombie_placement_done)  //添加放置新僵尸的计划
        {
            if (step == 1)
                rand_seed = 5;
            srand(rand_seed);
            zomtype = rand() % 5 + 1;
            if (step <= 500 && zomtype == 5)
                zomtype = 1;
            if (step <= 500 && zomtype == 4)
                zomtype = 3;
            rand_seed += step;
            srand(rand_seed);
            target_line = rand() % 5;
            rand_seed += step;
            zombie_placement_done = false;
            //std::cout << "try to place zombie" << zomtype << " at line" << target_line << " ";
        }
        if (!zombie_placement_done && moon >= mooncost[zomtype] && !zomcd[zomtype - 1])
        {
            player->PlaceZombie(zomtype, target_line);
            //std::cout << moon << ">=" << mooncost[zomtype] << ", zombie placed\n";
            zombie_placement_done = true;
        }
        //else
        //    std::cout << "\n";
    }
}
void more_sun(IPlayer* p)
{
    if (plantcd[0] == 0) {
        for (int l = 0; l < 5; l++)
        {
            if ((linefire[l] >= 20 && zomhead[l] >= 7) || (linefire[l] >= 10 && zomhead[l] == 10)) {
                for (int i = 1; i < 6; i++) {
                    if (Plants[l][i] == 0) {
                        p->PlacePlant(1,l,i);
                        plantcd[0] = 10;
                        sunflowers[l] += 1;
                        sun -= 50;
                    }
                }
            }
        }
    }
}
void place_sunflower(IPlayer* p)
{  
    for (int i = 0; i < 5; i++) {
        sunflowers[i] = 0;
        for (int j = 0; j < 6; j++) {
            if (Plants[i][j] == 1)
                sunflowers[i] += 1;
        }
    }
    for (int i = 0; i < 5; i++) {
        bool x = true;
        if (sunflowers[i]==0 && plantcd[0] == 0 && sun >= 150 && Plants[i][1]==0) {
            for (int j = 0; j < 4; j++) {
                if (Zombies[i][j][0] != -1) 
                    x = false;                
            }
            if (x) {
                p->PlacePlant(1, i, 1);
                plantcd[0] = 10;
                sun -= 50;
            }
        }
    }
}
int nuthealth[] = { 0,0,0,0,0 };
int zomdamage[] = { 0,75,75,75,4000,4000 };
void nutupdate(IPlayer* p)
{
    for (int i = 0; i < 5; i++) {
        int k = 0;
        while (Zombies[i][4][k] != -1)
        {
            nuthealth[i] -= zomdamage[Zombies[i][4][k]];
            k++;
        }
        if (nuthealth[i] <= 0) {
            nuthealth[i] = 0;
        }
        else if (Plants[i][4] == 0)
        {
            nuthealth[i] = 0;
        }
        else if (nuthealth[i] <= 500 && Zombies[i][4][0] == -1) {//坚果很残且没有僵尸，铲了
            p->removePlant(i, 4);
            nuthealth[i] = 0;
        }
    }
}
const int pp[] = { 0,0,10,1,0,0,0 };
const int zomsun[] = { 0,50,200,200,300,300 };
void squashclear()
{
    for (int i = 0; i < 10; i++) {        
        squashlist[i][0] = -1;
        squashlist[i][1] = -1;
        break;
    }
}
void squashcall(int x, int y)
{
    for (int i = 0; i < 10; i++) {
        if (squashlist[i][0] == -1) {
            squashlist[i][0] = x;
            squashlist[i][1] = y;
            break;
        }
    }
}
void squash_execute(IPlayer* p)
{
    if (sun >= 50 && plantcd[5] == 0) {//窝瓜可以放
        int t1 = 10, t2 = 10;
        for (int i = 0; i < 10; i++) {
            if (squashlist[i][0] != -1 && squashlist[i][1]<t2) {
                t1 = squashlist[i][0];
                t2 = squashlist[i][1];                
            }
        }
        if (t1 != 10 && (Plants[t1][t2] == 0 ||Zombies[t1][t2][0] == -1)) {//有目标
            p->removePlant(t1, t2);
            p->PlacePlant(6,t1, t2);
            plantcd[5] = 60;
            sun -= 50;
        }
    }
    squashclear();
}

void rm_plant(IPlayer* p)//正义铲除濒死植物
{
    for (int l = 0; l < 5; l++) {
        for (int t = 0; t < 9; t++) {//检测其右一格僵尸
            int c = 0;
            while (Zombies[l][t+1][c] != -1) {
                if (Zombies[l][t + 1][c] >= 4) {
                    plantsdanger[l][t] += 1;
                    std::cout << "(" << l << "," << t << ") danger: " << plantsdanger[l][t]<<"\n";
                }
                else if(plantsdanger[l][t]){
                    plantsdanger[l][t] = 0;
                    std::cout << "(" << l << "," << t << ") not danger. \n";
                }
                c++;
            }
            if (c == 0 && plantsdanger[l][t]) {
                plantsdanger[l][t] = 0;
                std::cout << "(" << l << "," << t << ") Not danger. \n";
            }
            if (plantsdanger[l][t] >= 4 && Plants[l][t] < 5) {
                std::cout << "(" << l << "," << t << ") remove.\n";
                p->removePlant(l, t);
            }
        }
    }

}
void execute(IPlayer* p, int l)//单行执行
{
    nutupdate(p);
    int firepower = 0;
    firepower += pp[Plants[l][0]];
    firepower += pp[Plants[l][1]];
    firepower += pp[Plants[l][2]];
    firepower += pp[Plants[l][3]];
    int zoms[10][2] = { {0,10},{0,10},{0,10},{0,10},{0,10},{0,10},{0,10},{0,10},{0,10},{0,10} };
    int barrier = 0;
    int zompower = 0;
    for (int i = 0; i < 10; i++){//记录全部僵尸
        int c = 0;
        while (Zombies[l][i][c] != -1){
            for (int j = 0; j < 10; j++) {
                if (zoms[j][0] == 0) {
                    zoms[j][0] = Zombies[l][i][c];
                    zoms[j][1] = i;
                    break;
                }
            }
            c++;
        }
    }
    for (int i = 0; i < 10; i++) {
        zompower += zomsun[zoms[i][0]];
    }
    //std::cout << "zombies documented\n";
    //system("pause");
    for (int i = 0; i < 10; i++) {
        //僵尸已到底线，危
        if (zoms[i][0] && zoms[i][1] == 0) {
            if (sun >= 125 && plantcd[4] == 0 && zoms[1][0]) {//有俩僵尸且够条件放辣椒
                p->PlacePlant(5, l, 9);
                plantcd[4] = 60;
                sun -= 125;
            }
            else if (Plants[l][0] == 0) {//要寄了
                if (sun >= 50 && plantcd[5] == 0) {//能放窝瓜
                    p->PlacePlant(6, l, 0);
                    plantcd[5] = 60;
                    sun -= 50;
                }
                else if (sun >= 125 && plantcd[4] == 0) {//没有俩僵尸但也没窝瓜
                    p->PlacePlant(5, l, 0);
                    plantcd[4] = 60;
                    sun -= 125;
                }               
            }
        }
        //僵尸逼近
        if (zoms[i][0] && zoms[i][1] == 4) {
            if (sun > 125 && plantcd[4] == 0 && zompower>300) {//攻势较强就直接辣椒
                for (int j = 9; j >= 0; j--) {
                    if (Plants[l][j] == 0) {
                        p->PlacePlant(5, l, i);
                        plantcd[4] = 60;
                        sun -= 125;
                        break;
                    }
                }
            }
            else if (i == 0 && firepower!= 0 && firepower < 5 && zompower<300 && zompower>=100) {//火力很弱但没有坦克，也不只是一个普通
                if (sun >= 100 && plantcd[3] == 0 && nuthealth[l] == 0) {//放坚果
                    p->removePlant(l, 4);
                    p->PlacePlant(4, l, 4);
                    plantcd[3] = 40;
                    sun -= 50;
                    nuthealth[l] = 4000;
                }
                else if (nuthealth[l] >= 2000 && zompower >= 100 || (firepower==2&&nuthealth[l]>=1000)) {//坚果还能扛但火力弱
                    if (sun >= 500 && plantcd[2] == 0) {//能放寒冰就放
                        plant_ice(p, l);
                        firepower += 10;
                    }
                    else if (sun >= 100 && plantcd[2] == 0 && Plants[l][2] == 0) {//不行就放豌豆
                        p->PlacePlant(3, l, 2);
                        sun -= 100;
                        plantcd[2] = 10;
                        firepower += 1;
                    }
                }
                else {
                    if (zoms[i][0] != 1)
                        squashcall(l, 4);//准备窝瓜
                    else
                        squashcall(l, 5);//如果是普通僵尸炮灰，那去砸后面的
                }
            }
            else if (i == 0 && firepower == 0) {//无火力情况
                if (zompower == 50 && sun >= 150 && plantcd[3] == 0 && plantcd[2]==0 && nuthealth[l] == 0) {//只来了一个普通
                    p->PlacePlant(4, l, 4);
                    p->PlacePlant(3, l, 0);
                    plantcd[3] = 40;
                    plantcd[2] = 10;
                    sun -= 150;
                    nuthealth[l] = 4000;
                    firepower += 1;
                }
                else
                    squashcall(l, 4);//准备窝瓜
            }
        }
        if (firepower < 2 && zoms[i][0] == 2) {//单/无豌豆行来铁桶
            if (zoms[0][1]>=6 && sun >= 500 && plantcd[1] == 0) {//能寒冰就寒冰
                plant_ice(p, l);
                firepower += 10;
            }
            else
                squashcall(l, zoms[i][1]);//准备窝瓜
        }
        if (i == 0 && zoms[i][0] && zoms[i][1] >= 8) {//僵尸在空行新入场
            if (firepower == 0 && zoms[i][0] == 1) {//来普通
                if (sun >= 100 && plantcd[2] == 0) {//放豌豆
                    p->PlacePlant(3, l, 0);
                    sun -= 100;
                    plantcd[2] = 10;
                    firepower += 1;
                }
            }
            if (firepower < 2 && zoms[i][0] == 3) {//单/无豌豆行来撑杆
                if (sun >= 500 && plantcd[1] == 0) {//有寒冰就种
                    plant_ice(p, l);
                    firepower += 10;
                }
                else if (firepower == 0 && sun >= 150 && plantcd[0] == 0 && plantcd[2] == 0 && Plants[l][8]==0 && Plants[l][9] == 0) {//没火力但能垫
                    p->PlacePlant(1, l, 8);
                    p->PlacePlant(3, l, 0);
                    plantcd[1] = 10;
                    plantcd[2] = 10;
                    sun -= 150;
                    firepower += 1;
                }
                else if (firepower == 0 && sun >= 150 && plantcd[2] == 0) {//已经有之前垫的向日葵了
                    p->PlacePlant(3, l, 0);
                    plantcd[2] = 10;
                    sun -= 100;
                    firepower += 1;
                }
                else
                    squashcall(l, zoms[i][1]);//窝瓜砸前场撑杆
            }
        }
        if (i != 0 && zoms[i][0]==3 && zoms[i][1] >= 6) {//有撑杆僵尸跟随入场
            if (zoms[0][1] >= 6 && firepower<5 && sun >= 500 && plantcd[1] == 0) {//没寒冰就加寒冰
                plant_ice(p, l);
                firepower += 10;
            }
            bool jumped = false;
            for (int j = zoms[i][1]; j < 10; j++) {
                if (Plants[l][j] || zoms[i + 1][0]) {
                    jumped = true;
                }
            }
            if (sun >= 150 && plantcd[0] == 0 && jumped == false) {//能垫就垫
                p->PlacePlant(1,l, zoms[i][1]);
            }
        }
        if (zoms[i][0] == 4 && zoms[i][1] >= 6) {//来冰车了
            if ((i != 0 && firepower < 15) || firepower < 5){//火力不够打死
                if (zoms[0][1] >= 6 && firepower < 5 && sun >= 500 && plantcd[1] == 0) {//能寒冰打死就打
                    plant_ice(p, l);
                    firepower += 10;
                }
                else if (sun >= 100 && plantcd[5] == 0) {
                    p->PlacePlant(6, l, zoms[i][1]);
                }                    
            }
        }
        if (zoms[i][0] == 5 && zoms[i][1] >= 6) {//来巨人了
            if (sun >= 100 && plantcd[5] == 0) {//窝瓜招呼
                p->PlacePlant(6, l, zoms[i][1]);
            }
            if (zoms[0][1] >= 6 && firepower < 5 && sun >= 500 && plantcd[1] == 0) {//能寒冰打死就打
                plant_ice(p, l);
                firepower += 10;
            }
            if (zoms[0][1] >= 6 && firepower == 10) {//单寒冰不够，加火力
                if (sun >= 100 && plantcd[2] == 0) {//放豌豆
                    p->PlacePlant(3, l, 0);
                    p->PlacePlant(3, l, 2);
                    sun -= 100;
                    plantcd[2] = 10;
                    firepower += 1;
                }
            }
        }
        if (step > 1000 && zoms[i][0] >= 4 && zoms[i][1] == 5) {//1000回合后如果有僵尸突脸
            if (sun > 125 && plantcd[4] == 0 && zompower >= 500) {//大波就直接辣椒
                for (int j = 9; j >= 0; j--) {
                    if (Plants[l][j] == 0) {
                        p->PlacePlant(5, l, i);
                        plantcd[4] = 60;
                        sun -= 125;
                        break;
                    }
                }
            }
        }
    }
    linefire[l] = firepower;
    linezom[l] = zompower;
    zomhead[l] = zoms[0][1];
}
void more_ice(IPlayer* p)
{
    if (sun > 900 && plantcd[1] == 0)
    {
        int minpower = 100;
        int danger = 0;
        int t = -1;
        for (int l = 0; l < 5; l++){
            if (linezom[l] > danger && zomhead[l]>=6) {
                danger = linezom[l];
                minpower = linefire[l];
                t = l;
            }
            else if(linezom[l] == danger && zomhead[l]>=6 && linefire[l]<minpower) {
                danger = linezom[l];
                minpower = linefire[l];
                t = l;
            }
        }
        if (t != -1) {
            if (Plants[t][0] == 0)
                p->PlacePlant(2, t, 0);
            else if (Plants[t][2] <= 1) {
                p->removePlant(t, 2);
                p->PlacePlant(2, t, 2);
                Plants[t][2] = 2;
            }
            else if (Plants[t][0] == 3)
            {
                p->removePlant(t, 0);
                p->PlacePlant(2, t, 0);
                Plants[t][0] = 2;
            }
            else if (Plants[t][2] == 1)
            {
                p->removePlant(t, 2);
                p->PlacePlant(2, t, 2);
                Plants[t][2] = 2;
            }
            else if(Plants[t][3] <= 1)
            {
                p->removePlant(t, 3);
                p->PlacePlant(2, t, 3);
                Plants[t][3] = 2;
            }
            else if (Plants[t][2] == 3)
            {
                p->removePlant(t, 2);
                p->PlacePlant(2, t, 2);
                Plants[t][2] = 2;
            }
            else if (Plants[t][1] == 1 && sunflowers[t] >= 2)
            {
                p->removePlant(t, 1);
                p->PlacePlant(2, t, 1);
                Plants[t][1] = 2;
            }
            else if (sun >= 2000 && Plants[t][4] != 2)
            {
                p->removePlant(t, 4);
                p->PlacePlant(2, t, 4);
                Plants[t][2] = 4;
            }
            plantcd[1] = 30;
            sun -= 400;
        }
    }
}
void plant_ice(IPlayer* p, int l)
{
    if (Plants[l][0] == 0)
        p->PlacePlant(2, l, 0);
    else if (Plants[l][2] <= 1) {
        p->removePlant(l, 2);
        p->PlacePlant(2, l, 2);
        Plants[l][2] = 2;
    }
    else if (Plants[l][0] == 1)
    {
        p->removePlant(l, 0);
        p->PlacePlant(2, l, 0);
        Plants[l][0] = 2;
    }
    else if (Plants[l][2] == 1)
    {
        p->removePlant(l, 2);
        p->PlacePlant(2, l, 2);
        Plants[l][2] = 2;
    }
    plantcd[1] = 30;
    sun -= 400;
}