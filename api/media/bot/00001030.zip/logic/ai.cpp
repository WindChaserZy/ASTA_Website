#include "ai.h"
#include <iostream>
using namespace std;
/*
要求：模仿YouHead的植物攻击模式
0列种豌豆，1列种向日葵，2列种冰豌豆，4列种坚果。
到达底线时，如果有多只僵尸放辣椒。如果有一只僵尸放倭瓜。放完之后补种向日葵。如果豌豆冷却不足，则放置一个倭瓜。
开局：
向日葵按照从上到下的顺序种植。如果前面一格有僵尸则暂时不种。
在有僵尸的行，如果此行没有豌豆则种植一个豌豆。
如果五行的豌豆都种植完毕，则在有僵尸的行种植坚果。
如果坚果种植完毕，则在有僵尸的行种植冰豌豆。
*/

enum PlantType {
	NOPLANT = 0,
	SUNFLOWER,
	WINTERPEASHOOTER,
	PEASHOOTER,
	SMALLNUT,
	PEPPER,
	SQUASH
};
enum ZombieType {
	NOZOMBIE = 0,
	NORMAL,
	BUCKET,
	POLEVAULT,
	SLED,
	GARGANTUAR
};

const int PlantSun[6] = { 50, 100, 400, 125, 50, 50 };
const int ZombieSun[5] = { 50, 125, 125, 300, 300 };

const int LineSunFlower[] = { 1 };
const int LinePeaShooter[] = { 0,2 };
const int LineSmallNut[] = { 4 };

bool plantSunFlower(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
void plantDenfece(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
void plantNut(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);
void plantLastLine(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD);

void zombie_ai(IPlayer *player);

void player_ai(IPlayer *player) {
	int CampType = player->Camp->getCurrentType();
	if (CampType == 0) {	//植物代码
		int ***Zombies = player->Camp->getCurrentZombies();
		int **Plants = player->Camp->getCurrentPlants();
		int *PlantsCD = player->Camp->getPlantCD();

		plantLastLine(player, Zombies, Plants, PlantsCD);
		plantSunFlower(player, Zombies, Plants, PlantsCD);
		plantDenfece(player, Zombies, Plants, PlantsCD);

	}
	else if (CampType == 1) {
		zombie_ai(player);
	}
}
//放置向日葵
//向日葵按照从上到下的顺序种植。如果前面一格有僵尸则暂时不种。
bool plantSunFlower(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	for (int i = 0; i < player->Camp->getRows(); i++) {
		if (Plants[i][LineSunFlower[0]] == NOPLANT && PlantsCD[SUNFLOWER - 1] == 0 && Zombies[i][LineSunFlower[0] + 1][0] == -1) {
			player->PlacePlant(SUNFLOWER, i, LineSunFlower[0]);
			return true;
		}
	}
}
//放置豌豆，坚果，冰豌豆
//在有僵尸的行，如果此行没有豌豆则种植一个豌豆。
//如果五行的豌豆都种植完毕，则在有僵尸的行种植坚果。在阳光充足时也可考虑种坚果。
//如果坚果种植完毕，则在有僵尸的行种植冰豌豆。在阳光充足时也可考虑种冰豌豆。
void plantDenfece(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	//判断当前状况
	bool ShooterFinished = false;
	bool NutFinished = false;
	bool WinterFinished = false;
	int ShooterNum = 0;
	int NutNum = 0;
	int WinterNum = 0;
	for (int i = 0; i < player->Camp->getRows(); i++) {
		if (Plants[i][LinePeaShooter[0]] == PEASHOOTER) {
			ShooterNum++;
		}
		if (Plants[i][LineSmallNut[0]] == SMALLNUT) {
			NutNum++;
		}
		if (Plants[i][LinePeaShooter[1] == WINTERPEASHOOTER]) {
			WinterNum++;
		}
	}
	ShooterFinished = (ShooterNum == 5);
	NutFinished = (NutNum == 5);
	WinterFinished = (WinterNum == 5);
	cout << "ShooterFinished: " << ShooterFinished << endl;
	//判断是否有僵尸
	for (int i = 0; i < player->Camp->getRows(); i++) {
		for (int j = 0; j < player->Camp->getColumns(); j++) {
			for (int k = 0; Zombies[i][j][k] != -1; k++) {
				if (!ShooterFinished) {
					if (Plants[i][LinePeaShooter[0]] == NOPLANT) {
						player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
					}
				}
				else if (!NutFinished) {
					if (Plants[i][LineSmallNut[0]] == NOPLANT) {
						player->PlacePlant(SMALLNUT, i, LineSmallNut[0]);
					}
				}
				else if (!WinterFinished) {
					if (Plants[i][LinePeaShooter[1]] == NOPLANT) {
						player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[1]);
					}
				}
			}
		}
		int sun = player->Camp->getSun();
		if (ShooterFinished && sun >= 250) {
			if (PlantsCD[SMALLNUT - 1] == 0 && Plants[i][LineSmallNut[0]] == NOPLANT) {
				player->PlacePlant(SMALLNUT, i, LineSmallNut[0]);
			}
		}
		if (Plants[i][LineSmallNut[0]] == SMALLNUT && sun >= 550) {
			if (PlantsCD[WINTERPEASHOOTER - 1] == 0 && Plants[i][LinePeaShooter[1]] == NOPLANT) {
				player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[1]);
			}
		}
	}
}

void plantNut(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {

}
//放置底线辣椒、倭瓜
//到达底线时，如果有多只僵尸放辣椒。如果僵尸在同一格放倭瓜。(放完之后补种向日葵。如果豌豆冷却不足，则放置一个倭瓜。)
void plantLastLine(IPlayer *player, int ***Zombies, int **Plants, int *PlantsCD) {
	for (int i = 0; i < player->Camp->getRows(); i++) {
		static int lastPutTime = 0;
		static int lastPutLine = 0;
		if (Zombies[i][0][0] != -1) {
			//僵尸已经到达底线
			//统计僵尸个数
			int zCount = 0;
			//统计最后一格僵尸个数
			int lastLineCount = 0;
			for (int j = 0; j < player->Camp->getColumns(); j++) {
				for (int k = 0; Zombies[i][j][k] != -1; k++) {
					zCount++;
					if (j == 0) {
						lastLineCount++;
					}
				}
			}
			if (PlantsCD[PEPPER - 1] == 0) {
				if (zCount > lastLineCount) {
					player->PlacePlant(PEPPER, i, 0);
					lastPutLine = i;
					lastPutTime = player->getTime();
				}
				else {
					if (lastPutLine == i && (player->getTime() - lastPutTime < 2)) {

					}
					else {
						player->PlacePlant(SQUASH, i, 0);
					}
				}
			}
			else if (PlantsCD[SQUASH - 1] == 0) {
				if (lastPutLine == i && (player->getTime() - lastPutTime < 2)) {

				}
				else {
					player->PlacePlant(SQUASH, i, 0);
				}
			}
		}

	}
}
//enum PlantType
//{
//    NOPLANT = 0,                                  //血量           阳光           冷却
//    SUNFLOWER,                                  //300            50            10/20
//    WINTERPEASHOOTER,                           //300            400           30/3
//    PEASHOOTER,                                 //300            100           10/2
//    SMALLNUT,                                   //4000           50            40
//    PEPPER,                                     //300            125           60
//    SQUASH                                      //300            50            60
//};
//
//enum ZombieType
//{
//    NOZOMBIE = 0,                                  //血量           阳光           冷却           移速
//    NORMAL,                                      //270            50             15            0.2
//    BUCKET,                                      //820            125            20            0.2
//    POLEVAULT,                                   //200            125            20            1/2.5,1/4.5
//    SLED,                                        //1600           300            25            1/3,...,1/8
//    GARGANTUAR                                   //3000           300            25            0.2
//};

enum TryZombie
{
	VacantRow = 0,
	Succeed,
	WaitCD,
	NoSun
};


const int ZombieSun2[6] = { 0,50, 125, 125, 300, 300 };

int TryPlaceZombie(IPlayer *const player, int ZombieType, int x)
{
	int *PlantCD = player->Camp->getPlantCD();
	//if (Leftlines[x]==0)return VacantRow;
	//else
	//{
	if (player->Camp->getSun() < ZombieSun2[ZombieType])return NoSun;
	else
	{
		if (PlantCD[ZombieType - 1] > 0)return WaitCD;
		else return Succeed;
	}
	//}
}



void swap(int &a, int &b)
{
	int n;
	n = a;
	a = b;
	b = n;
}

static int inta = 0;
static int intb = 0;
static int intc = 0;
static int intd = 0;
static int n = 0;

//选手代码在下方填入
void zombie_ai(IPlayer *player)
{
	int time = player->getTime();
	const int rows = player->Camp->getRows();
	const int columns = player->Camp->getColumns();
	int *PlantCD = player->Camp->getPlantCD();
	int **Plants = player->Camp->getCurrentPlants();
	int ***Zombies = player->Camp->getCurrentZombies();
	int *LeftLines = player->Camp->getLeftLines();
	int Sun = player->Camp->getSun();





	int i1, j1, k1;
	int i2, j2;
	int *bloodP = new int[rows];
	int *bloodZ = new int[rows];
	int *attackP = new int[rows];
	int *attackZ = new int[rows];
	int *order = new int[rows];
	int *parmRows = new int[rows];





	for (i1 = 0; i1 < rows; i1++)
	{
		bloodZ[i1] = 0; attackZ[i1] = 0;
		for (j1 = 0; j1 < columns; j1++)
		{
			k1 = 0;
			while (Zombies[i1][j1][k1] != -1)
			{
				if (Zombies[i1][j1][k1] == NORMAL)bloodZ[i1] += 270;
				else if (Zombies[i1][j1][k1] == POLEVAULT)bloodZ[i1] += 200;
				else if (Zombies[i1][j1][k1] == BUCKET)bloodZ[i1] += 820;
				else if (Zombies[i1][j1][k1] == SLED)bloodZ[i1] += 1600;
				else if (Zombies[i1][j1][k1] == GARGANTUAR)bloodZ[i1] += 3000;
				k1++;
			}
		}
	}


	for (i2 = 0; i2 < rows; i2++)
	{
		bloodP[i2] = 0; attackP[i2] = 0; int judgewinter = 0;
		for (j2 = 0; j2 < columns; j2++)
		{
			if (Plants[i2][j2] == NOPLANT);
			else if (Plants[i2][j2] == SMALLNUT)bloodP[i2] += 4000;
			else
			{
				bloodP[i2] += 300;
				if (Plants[i2][j2] == PEASHOOTER)attackP[i2] += 10;
				else if (Plants[i2][j2] == WINTERPEASHOOTER) { attackP[i2] += 20; judgewinter = 1; }
				else;
			}
		}
		if (judgewinter == 1)attackP[i2] = attackP[i2] * 2;
	}




	for (i2 = 0; i2 < rows; i2++)
	{
		parmRows[i2] = attackP[i2] + (bloodP[i2] / 200) + 1;
	}

	for (i1 = 0; i1 < rows; i1++)
	{
		order[i1] = i1;
	}
	for (i1 = 0; i1 < rows - 1; i1++)
	{
		k1 = i1;
		for (i2 = i1 + 1; i2 < rows; i2++)
		{
			if (parmRows[order[k1]] > parmRows[order[i2]])k1 = i2;
		}
		swap(order[k1], order[i1]);
	}

	int n2;
	if (LeftLines[order[0]] == 0)n2 = rows - 1;
	else n2 = rows - 2;

	if (time <= 400)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else if ((bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if (TryPlaceZombie(player, BUCKET, order[i1]) == Succeed)
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed)
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}

	}
	else if (time > 400 && time <= 497)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			else if ((bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[BUCKET]) > 400))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if ((TryPlaceZombie(player, NORMAL, order[i1]) == Succeed) && ((player->Camp->getSun() + 3 * (499 - time) - ZombieSun2[NORMAL]) > 400))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}
	else if (time > 497 && time <= 502)
	{
		if (time == 498)
		{
			inta = order[4];
			intb = order[3];
			intc = order[2];
			intd = order[1];

		}
		if ((TryPlaceZombie(player, GARGANTUAR, inta) == Succeed) && (n == 0 || n == 1) && LeftLines[inta] == 1)
		{
			if (bloodZ[inta] < 1600)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if (LeftLines[intb] == 0 && LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if ((TryPlaceZombie(player, GARGANTUAR, intb) == Succeed) && (n == 0 || n == 1) && LeftLines[intb] == 1)
			{
				if (bloodZ[intb] < 1600)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intc) == Succeed) && (n == 0 || n == 1) && LeftLines[intc] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intc);
					n++;

				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intd) == Succeed) && (n == 0 || n == 1) && LeftLines[intd] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intd);
					n++;

				}
			}

		}


		/*for (i1 = 0; i1 <= n2; i1++)
		{

			if (LeftLines[order[i1]] == 0)continue;
			if ((bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 3 * (501 - time) - ZombieSun2[BUCKET]) > 300))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed && ((player->Camp->getSun() + 3 * (501 - time) - ZombieSun2[NORMAL]) > 300))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}*/
		if (time == 502)
		{
			inta = 0; intb = 0; intc = 0; intd = 0;  n = 0;
		}
	}
	else if (time > 502 && time <= 850)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			if ((bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if (TryPlaceZombie(player, BUCKET, order[i1]) == Succeed)
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed)
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}
	else if (time > 850 && time <= 997)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[BUCKET]) > 400))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed && ((player->Camp->getSun() + 5 * (999 - time) - ZombieSun2[NORMAL]) > 400))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}
	else if (time > 997 && time <= 1002)
	{
		if (time == 998)
		{
			inta = order[4];
			intb = order[3];
			intc = order[2];
			intd = order[1];
		}
		if ((TryPlaceZombie(player, GARGANTUAR, inta) == Succeed) && (n == 0 || n == 1) && LeftLines[inta] == 1)
		{
			if (bloodZ[inta] < 1600)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if (LeftLines[intb] == 0 && LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if ((TryPlaceZombie(player, GARGANTUAR, intb) == Succeed) && (n == 0 || n == 1) && LeftLines[intb] == 1)
			{
				if (bloodZ[intb] < 1600)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if (LeftLines[intc] == 0 && LeftLines[intd] == 0)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intc) == Succeed) && (n == 0 || n == 1) && LeftLines[intc] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intc);
					n++;

				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intd) == Succeed) && (n == 0 || n == 1) && LeftLines[intd] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intd);
					n++;

				}

			}

		}
		if ((TryPlaceZombie(player, SLED, intc) == Succeed) && (n == 2 || n == 3) && LeftLines[intc] == 1)
		{

			player->PlaceZombie(SLED, intc);
			n++;

		}
		else if ((TryPlaceZombie(player, SLED, intd) == Succeed) && (n == 2 || n == 3) && LeftLines[intd] == 1)
		{

			player->PlaceZombie(SLED, intd);
			n++;

		}
		else if ((TryPlaceZombie(player, SLED, intb) == Succeed) && (n == 2 || n == 3) && LeftLines[intb] == 1)
		{
			if (bloodZ[intb] < 1600)
			{
				player->PlaceZombie(SLED, intb);
				n++;
			}
			else if (LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(SLED, intb);
				n++;
			}
			else if ((TryPlaceZombie(player, SLED, inta) == Succeed) && (n == 2 || n == 3) && LeftLines[inta] == 1)
			{
				if (bloodZ[inta] < 1600)
				{
					player->PlaceZombie(SLED, inta);
					n++;
				}
				else if (LeftLines[intb] == 0 && LeftLines[intd] == 0 && LeftLines[intc] == 0)
				{
					player->PlaceZombie(SLED, inta);
					n++;
				}
			}
		}


		/*for (i1 = 0; i1 <= n2; i1++)
		{

			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 5 * (1001 - time) - ZombieSun2[BUCKET]) > 300))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed && ((player->Camp->getSun() + 5 * (1001 - time) - ZombieSun2[NORMAL]) > 300))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}*/
		if (time == 1002)
		{
			inta = 0; intb = 0; intc = 0; intd = 0; n = 0;
		}
	}
	else if (time > 1002 && time <= 1400)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if (TryPlaceZombie(player, BUCKET, order[i1]) == Succeed)
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed)
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}
	else if (time > 1400 && time <= 1497)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[BUCKET]) > 400))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed && ((player->Camp->getSun() + 8 * (1499 - time) - ZombieSun2[NORMAL]) > 400))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}
	else if (time > 1497 && time <= 1502)
	{
		if (time == 1498)
		{
			inta = order[4];
			intb = order[3];
			intc = order[2];
			intd = order[1];
		}
		if ((TryPlaceZombie(player, GARGANTUAR, inta) == Succeed) && (n == 0 || n == 1) && LeftLines[inta] == 1)
		{
			if (bloodZ[inta] < 1600)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if (LeftLines[intb] == 0 && LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(GARGANTUAR, inta);
				n++;
			}
			else if ((TryPlaceZombie(player, GARGANTUAR, intb) == Succeed) && (n == 0 || n == 1) && LeftLines[intb] == 1)
			{
				if (bloodZ[intb] < 1600)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if (LeftLines[intc] == 0 && LeftLines[intd] == 0)
				{
					player->PlaceZombie(GARGANTUAR, intb);
					n++;
				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intc) == Succeed) && (n == 0 || n == 1) && LeftLines[intc] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intc);
					n++;

				}
				else if ((TryPlaceZombie(player, GARGANTUAR, intd) == Succeed) && (n == 0 || n == 1) && LeftLines[intd] == 1)
				{

					player->PlaceZombie(GARGANTUAR, intd);
					n++;

				}
			}

		}

		if ((TryPlaceZombie(player, SLED, intc) == Succeed) && (n == 2 || n == 3) && LeftLines[intc] == 1)
		{

			player->PlaceZombie(SLED, intc);
			n++;

		}
		else if ((TryPlaceZombie(player, SLED, intd) == Succeed) && (n == 2 || n == 3) && LeftLines[intd] == 1)
		{

			player->PlaceZombie(SLED, intd);
			n++;

		}
		else if ((TryPlaceZombie(player, SLED, intb) == Succeed) && (n == 2 || n == 3) && LeftLines[intb] == 1)
		{
			if (bloodZ[intb] < 1600)
			{
				player->PlaceZombie(SLED, intb);
				n++;
			}
			else if (LeftLines[intc] == 0 && LeftLines[intd] == 0)
			{
				player->PlaceZombie(SLED, intb);
				n++;
			}
			else if ((TryPlaceZombie(player, SLED, inta) == Succeed) && (n == 2 || n == 3) && LeftLines[inta] == 1)
			{
				if (bloodZ[inta] < 1600)
				{
					player->PlaceZombie(SLED, inta);
					n++;
				}
				else if (LeftLines[intb] == 0 && LeftLines[intd] == 0 && LeftLines[intc] == 0)
				{
					player->PlaceZombie(SLED, inta);
					n++;
				}
			}
		}

		/*for (i1 = 0; i1 <= n2; i1++)
		{

			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if ((TryPlaceZombie(player, BUCKET, order[i1]) == Succeed) && ((player->Camp->getSun() + 8 * (1501 - time) - ZombieSun2[BUCKET]) > 300))
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed && ((player->Camp->getSun() + 8 * (1501 - time) - ZombieSun2[NORMAL]) > 300))
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}*/
		if (time == 1502)
		{
			inta = 0; intb = 0; intc = 0; intd = 0;  n = 0;
		}
	}
	else if (time > 1502)
	{
		for (i1 = 0; i1 <= n2; i1++)
		{
			if (LeftLines[order[i1]] == 0)continue;
			if (((int)bloodZ[order[i1]] / parmRows[order[i1]]) > 50);
			else if (attackP[order[i1]] > 10 || bloodP[order[i1]] > 3000)
			{
				if (TryPlaceZombie(player, BUCKET, order[i1]) == Succeed)
					player->PlaceZombie(BUCKET, order[i1]);
				else;
			}
			else
			{
				if (TryPlaceZombie(player, NORMAL, order[i1]) == Succeed)
					player->PlaceZombie(NORMAL, order[i1]);
				else;
			}
		}
	}

}