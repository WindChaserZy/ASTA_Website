#include <vector>
#include "ai.h"


class Zombies
{
public:
	int everyRowNum[5] = { 0 };
	int everyRowZombieNum[5][6] = { 0 };
	std::vector<std::pair<int, int>> ZombieType[6];
	Zombies(int*** zombies)
	{
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (zombies[i][j][k]!=-1)
				{	
					everyRowNum[i]++;
					everyRowZombieNum[i][zombies[i][j][k]]++;
					ZombieType[zombies[i][j][k]].push_back(std::pair<int,int>(i, j));
					k++;
				}
			}
		}
	}
};


void placeSunFlower(IPlayer*player, int& sun, int CD, int **plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int j = 2; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 100 && leftLines[i] && !zombies.everyRowNum[i])
			{
				player->PlacePlant(1, i, j);
				sun -= 50;
				return;
			}
		}
	}

	for (int j = 2; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 150 && leftLines[i])
			{
				player->PlacePlant(1, i, j);
				sun -= 50;
			}
		}
	}
}

void placePeaShooter(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowZombieNum[i][1] && !CD && sun >= 150 && leftLines[i])
		{
			if (!plants[i][0])
			{
				player->PlacePlant(3, i, 0);
				placeRow[3] = i;
				sun -= 100;
				return;
			}
			if (!plants[i][1])
			{
				player->PlacePlant(3, i, 1);
				placeRow[3] = i;
				sun -= 100;
				return;
			}
		}
	}

	for (int j = 0; j < 6; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 200 && leftLines[i])
			{
				player->PlacePlant(3, i, j);
				placeRow[3] = i;
				sun -= 100;
			}
		}
	}
}


void placeIcePeaShooter(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] && !CD && sun >= 500 && leftLines[i])
		{
			if (plants[i][0] && plants[i][0] != 2)
			{
				player->removePlant(i, 0);
				player->PlacePlant(2, i, 0);
				sun -= 400;
				return;
			}
			if (plants[i][1] && plants[i][1] != 2)
			{
				player->removePlant(i, 1);
				player->PlacePlant(2, i, 1);
				sun -= 400;
				return;
			}
		}
	}

	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 500 && leftLines[i])
			{
				player->PlacePlant(3, i, j);
				sun -= 400;
				return;
			}
			if (plants[i][j] && !CD && sun >= 500 && leftLines[i])
			{
				if (plants[i][j] != 2)
				{
					player->removePlant(i, j);
					player->PlacePlant(2, i, j);
					sun -= 400;
				}
			}
		}
	}
}

void placeChili(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] >= 4 && !CD && sun >=125 && leftLines[i])
		{
			for (int j = 0; j < 10; j++)
			{
				if (!plants[i][j])
				{
					player->PlacePlant(5, i, j);
					placeRow[5] = i;
					sun -= 125;
				}
			}
		}
	}
}

void placeWogua(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 5; i > 3; i--)
	{
		if (zombies.ZombieType[i].size()!=0 && !CD && sun >= 50 && leftLines[i])
		{

			if (zombies.ZombieType[i][0].second - 1 >= 0 && !plants[zombies.ZombieType[i][0].first][zombies.ZombieType[i][0].second - 1])
			{
				player->PlacePlant(6, zombies.ZombieType[i][0].first, zombies.ZombieType[i][0].second - 1);
				placeRow[6] = i;
				sun -= 50;
			}
		}
	}
}

void placeNut(IPlayer* player, int& sun, int CD, int** plants, Zombies zombies, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] && !CD && sun >= 100 && leftLines[i])
		{
			for (int j = 6; j < 10; j++)
				if (!plants[i][j])
				{
					player->PlacePlant(4, i, j);
					placeRow[4] = i;
					sun -= 50;
					return;
				}
		}
	}

	for (int j = 6; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 150 && leftLines[i])
			{
				player->PlacePlant(4, i, j);
				sun -= 50;
			}
		}
	}
}

void placeNormalZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 50 && leftLines[i])
		{
			player->PlaceZombie(1, i);
			sun -= 50;
		}
}

void placeCaplZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 125 && leftLines[i])
		{
			player->PlaceZombie(2, i);
			sun -= 125;
		}
}

void placeStickZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 125 && leftLines[i])
		{
			player->PlaceZombie(3, i);
			sun -= 125;
		}
}

void placeCarZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300 && leftLines[i])
		{
			player->PlaceZombie(4, i);
			sun -= 300;
		}
}

void placeGangZombie(IPlayer* player, int &sun, int CD, int** plants, int* leftLines, int* placeRow)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300&& leftLines[i])
		{
			player->PlaceZombie(5, i);
			sun -= 300;
		}
}


void player_ai(IPlayer* player)
{
	auto type = player->Camp->getCurrentType();
	auto CD = player->Camp->getPlantCD();
	auto sun = player->Camp->getSun();
	Zombies zombies(player->Camp->getCurrentZombies());
	auto plants = player->Camp->getCurrentPlants();
	auto leftLines = player->Camp->getLeftLines();
	int placeRow[7] = { -1, -1, -1, -1, -1, -1 ,-1 };
	auto time = player->getTime();

	// 植物方
	if (type == 0)
	{
		placeChili(player, sun, CD[4], plants, zombies, leftLines, placeRow);
		placeWogua(player, sun, CD[5], plants, zombies, leftLines, placeRow);
		placePeaShooter(player, sun, CD[2], plants, zombies, leftLines, placeRow);
		placeSunFlower(player, sun, CD[0], plants, zombies, leftLines, placeRow);
		placeNut(player, sun, CD[3], plants, zombies, leftLines, placeRow);
		placeIcePeaShooter(player, sun, CD[1], plants, zombies, leftLines, placeRow);
	}

	// 僵尸方
	if (type == 1)
	{
		for (int i = 0; i < 5; i++)
			if (sun >= 2000 || zombies.everyRowNum[i])
			{
				placeGangZombie(player, sun, CD[4], plants, leftLines, placeRow);
				placeCarZombie(player, sun, CD[3], plants, leftLines, placeRow);
				placeCaplZombie(player, sun, CD[1], plants, leftLines, placeRow);
				placeStickZombie(player, sun, CD[2], plants, leftLines, placeRow);
				placeNormalZombie(player, sun, CD[0], plants, leftLines, placeRow);
			}
	}
}