#include "ai.h"
#include<iostream>

//int zombieCount = 3;
bool beginPlace[5] = { false,false,false,false,false };
int totalFlowerNum = 0;
int totalPeaNum = 0;
int totalNutNum = 0;
int totalPumpkinNum = 0;
bool isPea = false;
bool isNut = false;
bool isPumpkin = false;
bool isFlower = false;

void PlaceG()
{

}

void player_ai(IPlayer* player)
{

#pragma region GameStatus
    int plantNum = 0;
    bool isPlant = false;//判断场上是否有植物存在
    bool isZombie = false;//判断场上是否有僵尸存在
    bool isfull = false;//判断当前扫描地图格上是否都存在植物
    int producerow = -1;//判断生产行是第几行
    int count = 0;//控制producerow不变的量
#pragma endregion

#pragma region Interface
    int* PlantCD = player->Camp->getPlantCD();//获取当前植物CD
    int time = player->getTime();//获得当前回合数
    int rows = player->Camp->getRows();//获取当前行数
    int columns = player->Camp->getColumns();//获取当前列数
    int type = player->Camp->getCurrentType();//获得当前玩家类型

#pragma endregion

    int** plants = player->Camp->getCurrentPlants();//当前植物情况二维数组
    int*** zombies = player->Camp->getCurrentZombies();//当前僵尸情况三维数组

    //以下声明了很多个一维数组，用以计算某一行每种植物或僵尸数量，进而寻求对某一行的最优解
    int rowPlantNum[5] = { 0 };//植物总数
    int rowZombieNum[5] = { 0 };//僵尸总数
    int rowPeaNum[5] = { 0 };//豌豆射手总数
    int rowIceNum[5] = { 0 };//冰豌豆射手总数
    int rowPumpkinNum[5] = { 0 };//倭瓜总数
    int rowNutNum[5] = { 0 };//坚果总数
    int rowFlowerNum[5] = { 0 };

    for (int i = 0; i <= 5; i++) {
        PlantCD = player->Camp->getPlantCD();
    }

    //遍历植物二维数组计算每行植物数组对应的数量
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            if (plants[i][j] != 0)
            {
                rowPlantNum[i] += 1;
                plantNum++;
            }
            if (plants[i][j] != 1)//向日葵
            {
                rowFlowerNum[i] += 1;
                totalFlowerNum++;
            }
            if (plants[i][j] == 2)//冰豌豆
            {
                rowIceNum[i] += 1;
            }
            if (plants[i][j] == 3)//豌豆
            {
                rowPeaNum[i] += 1;
                totalPeaNum += 1;
            }
            if (plants[i][j] == 6)//火爆辣椒
            {
                rowPumpkinNum[i] += 1;
                totalPumpkinNum += 1;
            }
            if (plants[i][j] == 4)//坚果
            {
                rowNutNum[i] += 1;
                totalNutNum += 1;
            }
        }
    }

    for (int i = 0; i < rows; i++)//   遍历僵尸,得到各行的僵尸总数
    {
        for (int j = 0; j < columns; j++)
        {
            int k = 0;
            while (zombies[i][j][k] != -1)
            {
                rowZombieNum[i]++;
                k++;
            }

        }
    }

    //植物方操作
    if (type == 0)
    {
        int Sun = player->Camp->getSun();
        bool sunSupply = Sun > 600;
        for (int i = 0; i < rows; i++) {

            //阳光充足的情况
            if (sunSupply) {
                if (rowZombieNum[i] == 1)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];  //向日葵1，冰豆2，豌豆3，坚果墙4，辣椒5，倭瓜6
                            break;                      //  普僵1，铁桶2，撑杆3，冰车4，伽刚5
                        }
                    }                   //得到这一个僵尸的种类和位置   
                    if (zomPosition <= 4)        //僵尸较近时，用倭瓜
                    {
                        if (PlantCD[6] == 0) {
                            player->PlacePlant(6, i, zomPosition - 1);
                            player->PlacePlant(6, i, zomPosition);
                            player->PlacePlant(6, i, zomPosition - 2);
                        }
                        else {
                            player->PlacePlant(5, i, 0);
                            player->PlacePlant(5, i, 1);
                            player->PlacePlant(5, i, 2);
                        }
                    }
                    else if (zomType == 1)       //普通僵尸，用坚果墙，开始攒阳光
                    {
                        player->PlacePlant(4, i, zomPosition - 1);
                        for (int j = 0; j < zomPosition - 1; j++)
                        {
                            player->PlacePlant(1, i, j);
                        }
                    }
                    else if (zomType == 3)        //撑杆跳：用坚果墙或者向日葵垫一下,后面放冰豆
                    {

                        if (PlantCD[3] == 0) {
                            player->PlacePlant(4, i, 7);
                            player->PlacePlant(2, i, 0);
                        }
                        else
                            player->PlacePlant(1, i, 7);
                        player->PlacePlant(2, i, 0);

                    }
                    else if (zomType == 2 && !sunSupply || zomType == 4)  //雪车出现或铁桶出现（且阳光不充足），用倭瓜
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                    }
                    /* else if (zomType == 2 && sunSupply)  //铁桶出现，且阳光充足，用冰豆
                     {
                         player->PlacePlant(2, i, 0);
                         player->PlacePlant(2, i, 1);
                     }*/

                    else if (zomType == 5)   //伽刚特尔，用倭瓜和炸弹
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 1);
                        player->PlacePlant(5, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 3);
                    }
                }
                //一行的僵尸多于一个时
                else if (rowZombieNum[i] > 1)
                {
                    bool isCarOrGiant = false;    //是否有雪车和伽刚特尔
                    int* zomPosition = new int[rowZombieNum[i]];
                    int* zomType = new int[rowZombieNum[i]];
                    int a = 0;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        int k = 0;
                        while (zombies[i][j][k] != -1)
                        {
                            zomPosition[a] = k;
                            zomType[a] = zombies[i][j][k];
                            a++;
                            k++;
                        }             //得到这一行的僵尸位置及其种类
                    }

                    for (int j = 0; j < rowZombieNum[i]; j++)
                    {
                        if (zomType[j] == 4 || zomType[j] == 5)
                        {
                            isCarOrGiant = true;
                            break;
                        }
                    }  //判断本行有无雪车和伽刚
                    if (isCarOrGiant || rowZombieNum[i] > 2)
                    {
                        player->PlacePlant(5, i, 1);
                        player->PlacePlant(5, i, 2);
                        player->PlacePlant(5, i, 3);
                        player->PlacePlant(5, i, 4);
                        player->PlacePlant(5, i, 5);
                        player->PlacePlant(5, i, 6);
                        player->PlacePlant(5, i, 7);
                    }
                    //若有雪车或者伽刚，或者僵尸数大于2，放辣椒


                    else if (plants[i][0] == 3 || plants[i][0] == 2 || plants[i][1] == 3 || plants[i][0] == 2)
                    {
                        if (sunSupply)
                        {
                            player->PlacePlant(2, i, 0);
                            player->PlacePlant(2, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(3, i, 0);
                            player->PlacePlant(3, i, 0);
                        }
                    }
                    delete[]zomPosition;
                    delete[]zomType;

                }
                //放置冰豆，先把空缺填满，填满后铲掉豌豆种冰豆
                for (int j = 0; j <= 5; j++)
                {
                    if (plants[i][j] == 0) {
                        player->PlacePlant(2, i, j);
                        if (!sunSupply)
                            break;
                    }
                    else isfull = true;
                    if (j == 5) {
                        if (isfull) {
                            for (int j = 0; j <= 5; j++) {
                                if (plants[i][j] == 3) {
                                    player->removePlant(i, j);
                                    player->PlacePlant(2, i, j);
                                    if (!sunSupply)
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            //阳光不充足的情况
            else
            {
                if (rowZombieNum[i] == 1)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];  //向日葵1，冰豆2，豌豆3，坚果墙4，辣椒5，倭瓜6
                            break;                      //  普僵1，铁桶2，撑杆3，冰车4，伽刚5
                        }
                    }                   //得到这一个僵尸的种类和位置   
                    if (zomPosition <= 4)        //僵尸较近时，用倭瓜
                    {
                        if (PlantCD[6] == 0) {
                            player->PlacePlant(6, i, zomPosition - 1);
                            player->PlacePlant(6, i, zomPosition);
                            player->PlacePlant(6, i, zomPosition - 2);
                        }
                        else {
                            player->PlacePlant(5, i, 0);
                            player->PlacePlant(5, i, 1);
                            player->PlacePlant(5, i, 2);
                        }
                    }
                    else if (zomType == 1)       //普通僵尸，用坚果墙，开始攒阳光
                    {
                        player->PlacePlant(4, i, zomPosition - 1);
                        count++;
                        if (count == 1)
                            producerow = i;
                        for (int j = 0; j < zomPosition - 1; j++)
                        {
                            player->PlacePlant(1, i, j);
                        }
                    }
                    else if (zomType == 3)        //撑杆跳：用坚果墙或者向日葵垫一下,后面放豌豆
                    {
                        if (PlantCD[3] == 0) {
                            player->PlacePlant(4, i, 7);
                            player->PlacePlant(3, i, 0);
                        }
                        else
                            player->PlacePlant(1, i, 7);
                        player->PlacePlant(3, i, 0);
                    }
                    else if (zomType == 2 && !sunSupply || zomType == 4)  //雪车出现或铁桶出现（且阳光不充足），用倭瓜
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                    }
                    else if (zomType == 2 && sunSupply)  //铁桶出现，且阳光充足，用冰豆
                    {
                        player->PlacePlant(2, i, 0);
                        player->PlacePlant(2, i, 1);
                    }

                    else if (zomType == 5)   //伽刚特尔，用倭瓜和炸弹
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 1);
                        player->PlacePlant(5, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 3);
                    }

                }
                //一行的僵尸多于一个时
                else if (rowZombieNum[i] > 1)
                {
                    bool isCarOrGiant = false;    //是否有雪车和伽刚特尔
                    int* zomPosition = new int[rowZombieNum[i]];
                    int* zomType = new int[rowZombieNum[i]];
                    int a = 0;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        int k = 0;
                        while (zombies[i][j][k] != -1)
                        {
                            zomPosition[a] = k;
                            zomType[a] = zombies[i][j][k];
                            a++;
                            k++;
                        }             //得到这一行的僵尸位置及其种类
                    }

                    for (int j = 0; j < rowZombieNum[i]; j++)
                    {
                        if (zomType[j] == 4 || zomType[j] == 5)
                        {
                            isCarOrGiant = true;
                            break;
                        }
                    }  //判断本行有无雪车和伽刚
                    if (isCarOrGiant || rowZombieNum[i] > 2)
                    {
                        player->PlacePlant(5, i, 1);
                        player->PlacePlant(5, i, 2);
                        player->PlacePlant(5, i, 3);
                        player->PlacePlant(5, i, 4);
                        player->PlacePlant(5, i, 5);
                        player->PlacePlant(5, i, 6);
                        player->PlacePlant(5, i, 7);
                    }
                    //若有雪车或者伽刚，或者僵尸数大于2，放辣椒


                    else if (plants[i][0] == 3 || plants[i][0] == 2 || plants[i][1] == 3 || plants[i][0] == 2)
                    {
                        if (sunSupply)
                        {
                            player->PlacePlant(2, i, 0);
                            player->PlacePlant(2, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(3, i, 0);
                            player->PlacePlant(3, i, 0);
                        }
                    }
                    delete[]zomPosition;
                    delete[]zomType;

                }
            }
            //如不需要应急，在首行预备倭瓜，并预备坚果
            if (time >= 5) {
                if (rowZombieNum[i] == 0) {
                    {
                        player->PlacePlant(6, i, 10);
                        player->PlacePlant(6, i, 9);
                        player->PlacePlant(4, i, 8);
                    }
                }
            }
            //阳光数多于2000,开始变更阵型,逐个铲掉生产行的向日葵,然后放上冰豆,再在6或7列补上向日葵
            if (Sun > 2000) {
                for (int j = 0; j <= 7; j++) {
                    if (PlantCD[1] == 0 && totalFlowerNum >= 6) {
                        player->removePlant(producerow, j);
                        player->PlacePlant(2, producerow, j);
                        player->PlacePlant(1, i, 7);
                        player->PlacePlant(1, i, 6);
                    }
                }
            }
        }
    }


    //僵尸方操作
    if (type == 1)
    {
        int sun = player->Camp->getSun();
        int* zombieCD = player->Camp->getPlantCD();
        int sunZombie = player->Camp->getSun();
        int* leftLines = player->Camp->getLeftLines();
        
        for (int i = 0; i < rows; i++)
        {
            int j = 4 - i;
            if (sun > 850)
            {
                if (j == 4)
                {
                    beginPlace[j] = true;
                }
                if (j == 3 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 2 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 1 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 0 && leftLines[1] == 0 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
            }
            /*if (beginPlace[j] && rowZombieNum[j] < 2)
            {
                player->PlaceZombie(5, j);
            }*/
        }

        if (time == 5)
        {
            if (totalFlowerNum != 0)
            {
                isFlower = true;
            }
            if (totalNutNum != 0)
            {
                isNut = true;
            }
            if (totalPumpkinNum != 0)
            {
                isPumpkin = true;
            }
            if (totalPeaNum != 0)
            {
                isPea = true;
            }
        }
        if (time >= 6)
        {
            if (!isNut && !isPea && !isPumpkin)
            {
                if (isFlower||time == 6)
                {
                    for (int i = 0; i < rows; i++)
                    {
                        if (rowFlowerNum[i] != 0)
                        {
                            player->PlaceZombie(2, i);
                            if (i - 1 == -1 || i + 1 == 5)
                            {
                                player->PlaceZombie(1, 1);
                                player->PlaceZombie(3, 2);
                            }
                            else
                            {
                                player->PlaceZombie(1, i-1);
                                player->PlaceZombie(3, i+1);
                            }
                        }
                    }
                }
                else if(time==6)
                {
                    player->PlaceZombie(1, 1);
                    player->PlaceZombie(2, 2);
                    player->PlaceZombie(3, 3);
                }
                else
                {
                    for (int i = 0; i < 5; i++)
                    {
                        int j = 4 - i;
                        if (beginPlace[j] && rowZombieNum[j] <= 2)
                        {
                            player->PlaceZombie(5, j);
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    int j = 4 - i;
                    if (beginPlace[j] && rowZombieNum[j] <= 2)
                    {
                        player->PlaceZombie(5, j);
                    }
                }
            }
        }
    }
}

