/**
 * This file is preprocessed by an amalgamater
 * to protect its copyright
 *
 * Please do not try to parse it
 * 
 * Amalgamater is written by Futrime<https://github.com/Futrime>
 */

#include "ai.h"

/**
 * @file 2.ai.cpp
 * @author Futrime (futrime@outlook.com)
 * @brief AI Edition Two
 * @details This AI calls strong PlantExpertAgent and ZombieReflexAgent2.
 * @version 1.0.0
 * @date 2022-05-19
 *
 * @copyright Copyright (c) 2022 Futrime
 *
 */

#include <iostream>


/*** Start of inlined file: Game.cpp ***/
#ifndef __GAME_CPP__
#define __GAME_CPP__

#include <algorithm>
#include <bitset>
#include <cmath>
#include <exception>
#include <iostream>
#include <string>
#include <vector>


/*** Start of inlined file: ai.h ***/
#ifndef _FC19_AI_H_
#define _FC19_AI_H_

/*** Start of inlined file: Interface.h ***/
#ifndef INTERFACE_H_
#define INTERFACE_H_
class ICamp
{
public:
	virtual int** getCurrentPlants() = 0;
	virtual int*** getCurrentZombies() = 0;
	virtual int getSun() = 0;
	virtual int* getPlantCD() = 0;
	virtual int* getLeftLines() = 0;
	virtual int getRows() = 0;
	virtual int getColumns() = 0;
	virtual int getCurrentType() = 0;
};
class IPlayer
{
public:
	ICamp* Camp;
	virtual void PlacePlant(int type, int x, int y) = 0;
	virtual void PlaceZombie(int type, int y) = 0;
	virtual int getTime() = 0;
	virtual int getScore() = 0;
	virtual int getKillPlantsScore() = 0;
	virtual int getKillZombiesScore() = 0;
	virtual int getNotBrokenLines() = 0;
	virtual int getBrokenLinesScore() = 0;
	virtual int getLeftPlants() = 0;
	virtual void removePlant(int x, int y) = 0;
};

#endif
/*** End of inlined file: Interface.h ***/


#ifdef _MSC_VER
extern "C" _declspec(dllexport) void  player_ai(IPlayer * Player);
#endif

#ifdef __GNUC__
extern "C" void player_ai(IPlayer * _Player);
#endif

#endif
/*** End of inlined file: ai.h ***/


/*** Start of inlined file: Entity.cpp ***/
#ifndef __ENTITY_CPP__
#define __ENTITY_CPP__

#include <exception>
#include <string>


/*** Start of inlined file: Utility.cpp ***/
#ifndef __UTILITY_CPP__
#define __UTILITY_CPP__

#include <bitset>
#include <exception>
#include <iostream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

const struct
{
	int PLANT = 0;
	int ZOMBIE = 1;
} CAMP;

const struct
{
	int NOPLANT = 0;
	int SUNFLOWER = 1;
	int WINTERPEASHOOTER = 2;
	int PEASHOOTER = 3;
	int SMALLNUT = 4;
	int PEPPER = 5;
	int SQUASH = 6;
} PLANT;

const string PLANT_STRING[7] = {"NOPLANT", "SUNFLOWER", "WINTERPEASHOOTER", "PEASHOOTER", "SMALLNUT", "PEPPER", "SQUASH"};

const struct
{
	int NOZOMBIE = 0;
	int NORMAL = 1;
	int BUCKET = 2;
	int POLEVAULT = 3;
	int SLED = 4;
	int GARGANTUAR = 5;
} ZOMBIE;

const string ZOMBIE_STRING[6] = {"NOZOMBIE", "NORMAL", "BUCKET", "POLEVAULT", "SLED", "GARGANTUAR"};

const struct
{
	int SUNFLOWER = 300;
	int WINTERPEASHOOTER = 300;
	int PEASHOOTER = 300;
	int SMALLNUT = 4000;
	int PEPPER = 300;
	int SQUASH = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_HP::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_HP;

const struct
{
	int SUNFLOWER = 50;
	int WINTERPEASHOOTER = 400;
	int PEASHOOTER = 100;
	int SMALLNUT = 50;
	int PEPPER = 125;
	int SQUASH = 50;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_COST::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_COST;

const struct
{
	int WINTERPEASHOOTER = 60;
	int PEASHOOTER = 20;
	int PEPPER = 1800;
	int SQUASH = 1800;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1: // SUNFLOWER
			return 0;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4: // SMALLNUT
			return 0;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_ATK::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_ATK;

const struct
{
	int SUNFLOWER = 10;
	int WINTERPEASHOOTER = 30;
	int PEASHOOTER = 10;
	int SMALLNUT = 40;
	int PEPPER = 60;
	int SQUASH = 60;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(PLANT_CD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_CD;

const struct
{
	int WINTERPEASHOOTER = 3;
	int PEASHOOTER = 2;
	int operator[](int type) const
	{
		switch (type)
		{
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		}

		/* Check legality */
		if (type != 2 && type != 3)
		{
			throw invalid_argument("(PLANT_PERIOD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_PERIOD;

const struct
{
	int NORMAL = 270;
	int BUCKET = 550 + 270;
	int POLEVAULT = 200;
	int SLED = 1600;
	int GARGANTUAR = 3000;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOZOMBIE
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_HP::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_HP;

const struct
{
	int NORMAL = 50;
	int BUCKET = 125;
	int POLEVAULT = 125;
	int SLED = 300;
	int GARGANTUAR = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_COST::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_COST;

const struct
{
	int NORMAL = 75;
	int BUCKET = 75;
	int POLEVAULT = 75;
	int SLED = 999999;
	int GARGANTUAR = 999999;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_ATK::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_ATK;

const struct
{
	int NORMAL = 15;
	int BUCKET = 20;
	int POLEVAULT = 20;
	int SLED = 25;
	int GARGANTUAR = 25;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(ZOMBIE_CD::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_CD;

const struct
{
	double DEFAULT = 0.2;
	double POLEVAULT[2] = {0.4, 0.2222222222222222};
	double SLED[5] = {0.3333333333333333, 0.28125, 0.2291666666666667, 0.1770833333333333, 0.125};
} ZOMBIE_SPEED;

template <typename T>
class Position
{
public:
	T x, y;

	/**
	 * @brief Construct a new Position object
	 *
	 */
	Position()
	{
		this->x = -1;
		this->y = -1;
	}

	/**
	 * @brief Construct a new Position object
	 *
	 * @param x
	 * @param y
	 */
	Position(T x, T y) : x(x), y(y)
	{
	}

	friend ostream &operator<<(ostream &os, Position<T> pos)
	{
		return os << "<" << pos.x << ", " << pos.y << ">";
	}
};

class Action
{
protected:
	bitset<7> plant_switch_;
	bitset<6> zombie_switch_;
	Position<int> plant_position_[7];
	Position<int> zombie_position_[6];
	vector<Position<int>> plant_removal_;
	vector<int> plant_sequence_;
	vector<int> zombie_sequence_;

public:
	/**
	 * @brief Construct a new Action object
	 *
	 */
	Action()
	{
	}

	/**
	 * @brief Get removal actions of plant camp
	 *
	 * @return vector<Position<int>> A vector of removal actions
	 */
	vector<Position<int>> getRemovalList()
	{
		return this->plant_removal_;
	}

	/**
	 * @brief Get the target position of a slot
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return Position<int> The target position
	 */
	Position<int> getPosition(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::getPosition) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw invalid_argument("(Action::getPosition) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw invalid_argument("(Action::getPosition) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_position_[slot];
		}
		else
		{
			return this->zombie_position_[slot];
		}
	}

	/**
	 * @brief Get the placement sequence
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @return vector<int> The placement sequence, whose elements are plant/zombie types
	 */
	vector<int> getSequence(int camp)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::getSequence) Invalid camp!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_sequence_;
		}
		else
		{
			return this->zombie_sequence_;
		}
	}

	/**
	 * @brief Check if a slot is set in this action
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return true The slot is set
	 * @return false The slot is not set
	 */
	bool isSet(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(Action::isSet) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw invalid_argument("(Action::isSet) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw invalid_argument("(Action::isSet) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_switch_[slot];
		}
		else
		{
			return this->zombie_switch_[slot];
		}
	}

	/**
	 * @brief Remove a plant. Plant placement is prior to plant removal.
	 *
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 * @param force true Ignore non-fatal illegal removal
	 * @param force false Check all illegal removal
	 */
	void removePlant(int x, int y, bool force = false)
	{
		/* Check legality */
		if (x < 0 || x > 4 || y < 0 || y > 9)
		{
			throw invalid_argument("(Action::removePlant) Out of map!");
		}
		for (int i = 0; i < this->plant_removal_.size(); ++i)
		{
			if (plant_removal_[i].x == x &&
				plant_removal_[i].y == y)
			{ // if the removal has already been performed
				if (force)
				{
					return; // do not add duplicated removal
				}
				else
				{
					throw runtime_error("(Action::removePlant) Duplicated plant removal!");
				}
			}
		}

		this->plant_removal_.push_back(Position<int>(x, y));
	}

	/**
	 * @brief Place a plant. Plant placement is prior to plant removal.
	 *
	 * @param type The type of the plant, should be PLANT.X
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 * @param force true Ignore non-fatal illegal placement
	 * @param force false Check all illegal placement
	 */
	void placePlant(int type, int x, int y, bool force = false)
	{
		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw invalid_argument("(Action::placePlant) Wrong plant type!");
		}
		if (x < 0 || x > 4 || y < 0 || y > 9)
		{
			throw invalid_argument("(Action::placePlant) Out of map!");
		}
		if (this->plant_switch_[type] && !force)
		{
			throw runtime_error("(Action::placePlant) Duplicated plant placement!");
		}

		this->plant_switch_[type] = true;
		this->plant_position_[type].x = x;
		this->plant_position_[type].y = y;

		if (force)
		{
			for (auto it = this->plant_sequence_.begin(); it != this->plant_sequence_.end(); ++it)
			{
				if (*it == type)
				{
					this->plant_sequence_.erase(it); // remove previous placement
					break;
				}
			}
		}

		this->plant_sequence_.push_back(type);
	}

	/**
	 * @brief Place a zombie
	 *
	 * @param type The type of the zombie, should be ZOMBIE.x
	 * @param x The x position to place, within [0, 4]
	 * @param force true Ignore non-fatal illegal placement
	 * @param force false Check all illegal placement
	 */
	void placeZombie(int type, int x, bool force = false)
	{
		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw invalid_argument("(Action::placeZombie) Wrong zombie type!");
		}
		if (x < 0 || x > 4)
		{
			throw invalid_argument("(Action::placeZombie) Out of map!");
		}
		if (this->zombie_switch_[type] && !force)
		{
			throw runtime_error("(Action::placeZombie) Duplicated zombie placement!");
		}

		this->zombie_switch_.set(type, true);
		this->zombie_position_[type].x = x;
		this->zombie_position_[type].y = 10;

		if (force)
		{
			for (auto it = this->zombie_sequence_.begin(); it != this->zombie_sequence_.end(); ++it)
			{
				if (*it == type)
				{
					this->zombie_sequence_.erase(it); // remove previous placement
					break;
				}
			}
		}

		this->zombie_sequence_.push_back(type);
	}

	/**
	 * @brief Merge an action of plant camp and an action of zombie camp
	 *
	 * @param action_plant An action of plant camp
	 * @param action_zombie An action of zombie camp
	 * @return Action
	 */
	static Action merge(Action action_plant, Action action_zombie)
	{
		Action result;

		vector<int> sequence_plant = action_plant.getSequence(CAMP.PLANT);
		vector<Position<int>> removal_list = action_plant.getRemovalList();
		vector<int> sequence_zombie = action_zombie.getSequence(CAMP.ZOMBIE);

		for (auto it = sequence_plant.begin(); it != sequence_plant.end(); ++it)
		{
			Position<int> pos = action_plant.getPosition(CAMP.PLANT, *it);
			result.placePlant(*it, pos.x, pos.y);
		}

		for (auto it = removal_list.begin(); it != removal_list.end(); ++it)
		{
			result.removePlant(it->x, it->y);
		}

		for (auto it = sequence_zombie.begin(); it != sequence_zombie.end(); ++it)
		{
			int x = action_zombie.getPosition(CAMP.ZOMBIE, *it).x;
			result.placeZombie(*it, x);
		}

		return result;
	}
};

int generateID()
{
	static int id = 0;
	++id;
	return id;
}

#endif
/*** End of inlined file: Utility.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class Entity
{
protected:
	int spawn_time_;
	int type_;
	int hp_;
	int id_;
	Position<int> position_;

public:
	/**
	 * @brief Construct a new Entity object
	 *
	 * @param spawn_time The spawning time of the entity
	 * @param type The type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 * @param position The position of the entity
	 */
	Entity(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get the spawning time of the entity
	 *
	 * @return int The spawning time
	 */
	int getSpawnTime();

	/**
	 * @brief Get the type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 *
	 * @return int The type of the entity, fitting PLANT.X or ZOMBIE.X
	 */
	int getType();

	/**
	 * @brief Get the health of the entity
	 *
	 * @return int The health of the entity, >= 0
	 */
	virtual int getHealth();

	/**
	 * @brief Reduce the health of the entity
	 *
	 * @param value The number of health to reduce
	 * @return int The health left
	 */
	int reduceHealth(int value);

	/**
	 * @brief Get the position of the entity
	 *
	 * @return Position<int> The position of the entity
	 */
	Position<int> getPosition();

	/**
	 * @brief Get the id of the entity
	 *
	 * @return int The id
	 */
	int getID();
};

class Plant : public Entity
{
protected:
	int last_attack_time_ = -999999;

public:
	/**
	 * @brief Construct a new Plant object
	 *
	 */
	Plant();

	/**
	 * @brief Construct a new Plant object
	 *
	 * @param spawn_time The spawing time of the plant
	 * @param type The type of the plant
	 * @param position The position of the plant
	 */
	Plant(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get last attack time
	 *
	 * @return int Last attack time
	 */
	int getLastAttackTime();

	/**
	 * @brief Set last attack time
	 *
	 * @param time Last attack time
	 */
	void setLastAttackTime(int time);

	/**
	 * @brief Print a plant object
	 *
	 * @param oss The output stream
	 * @param plant The plant
	 * @return ostream& The result output stream
	 */
	friend ostream &operator<<(ostream &oss, Plant plant);
};

class Zombie : public Entity
{
protected:
	Position<double> position_real_;
	int state_ = 0; // Polevault and Sled's state
	int frozen_state_ = 0;
	int time_;

public:
	/**
	 * @brief Construct a new Zombie object
	 *
	 */
	Zombie();

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<double> position);

	/**
	 * @brief Get the health of the zombie
	 *
	 * @return int The health of the zombie, >= 0
	 */
	int getHealth();

	/**
	 * @brief Set the current time for calculating health
	 *
	 * @param time The current time
	 */
	void setNowTime(int time);

	/**
	 * @brief Get the position of the zombie
	 *
	 * @return Position<int> The position of the zombie
	 */
	Position<int> getPosition();

	/**
	 * @brief Get the real position of the zombie
	 *
	 * @return Position<double> The real position of the zombie
	 */
	Position<double> getRealPosition();

	/**
	 * @brief Set the real position of the zombie
	 *
	 * @param position The real position of the zombie
	 */
	void setRealPosition(Position<double> position);

	/**
	 * @brief Get the state of the zombie
	 *
	 * @return int The state number
	 */
	int getState();

	/**
	 * @brief Set the state of the zombie
	 *
	 * @param state The state number
	 */
	void setState(int state);

	/**
	 * @brief Get if the zombie is frozen
	 *
	 * @return int The ticks from unfreezing
	 */
	int getFrozenState();

	/**
	 * @brief Set if the zombie is frozen
	 *
	 * @param state int The ticks from unfreezing
	 */
	void setFrozenState(int state);

	/**
	 * @brief Print a zombie object
	 *
	 * @param oss The output stream
	 * @param plant The zombie
	 * @return ostream& The result output stream
	 */
	friend ostream &operator<<(ostream &oss, Zombie zombie);
};

/****************
 * Definitions
 ****************/

Entity::Entity(int spawn_time, int type, Position<int> position)
	: spawn_time_(spawn_time), type_(type), position_(position), id_(generateID())
{
	/* Check legality */
	if (spawn_time < 0)
	{
		throw invalid_argument("(Entity::Entity) Invalid spawn time!");
	}
}

int Entity::getSpawnTime()
{
	return this->spawn_time_;
}

int Entity::getType()
{
	return this->type_;
}

int Entity::getHealth()
{
	return this->hp_;
}

int Entity::reduceHealth(int value)
{
	/* Check legality */
	if (value < 0)
	{
		throw invalid_argument("(Entity::reduceHealth) Invalid value!");
	}

	this->hp_ -= value;
	return this->hp_;
}

Position<int> Entity::getPosition()
{
	return this->position_;
}

int Entity::getID()
{
	return this->id_;
}

Plant::Plant() : Plant(0, PLANT.NOPLANT, Position<int>())
{
}

Plant::Plant(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position)
{
	/* Check legality */
	if (type < 0 || type > 6)
	{
		throw invalid_argument("(Plant::Plant) Invalid type!");
	}

	this->hp_ = PLANT_HP[type];
}

int Plant::getLastAttackTime()
{
	return this->last_attack_time_;
}

void Plant::setLastAttackTime(int time)
{
	/* Check legality */
	if (time < 0)
	{
		throw invalid_argument("(Plant::setLastAttackTime) Invalid time!");
	}

	this->last_attack_time_ = time;
}

ostream &operator<<(ostream &oss, Plant plant)
{
	oss << "Plant(type=" << PLANT_STRING[plant.getType()]
		<< ", position=" << plant.getPosition()
		<< ", health=" << plant.getHealth()
		<< ", spawn_time=" << plant.getSpawnTime()
		<< ")";
	return oss;
}

Zombie::Zombie() : Zombie(0, ZOMBIE.NOZOMBIE, Position<double>())
{
}

Zombie::Zombie(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position), position_real_(position.x, position.y), time_(spawn_time)
{
	/* Check legality */
	if (type < 0 || type > 5)
	{
		throw invalid_argument("(Zombie::Zombie) Invalid type!");
	}

	this->hp_ = ZOMBIE_HP[type];
}

Zombie::Zombie(int spawn_time, int type, Position<double> position)
	: Entity(spawn_time, type, Position<int>(static_cast<int>(floor(position.x + 0.001)), static_cast<int>(floor(position.y + 0.001)))), position_real_(position.x, position.y), time_(spawn_time)
{
	/* Check legality */
	if (type < 0 || type > 5)
	{
		throw invalid_argument("(Zombie::Zombie) Invalid type!");
	}

	this->hp_ = ZOMBIE_HP[type];
}

int Zombie::getHealth()
{
	return this->hp_ + static_cast<int>(ZOMBIE_HP[this->type_] * (max(1.0, this->time_ / 1000.0) - 1.0));
	// doubt: what the fuck is the algorithm of Game.exe!
}

void Zombie::setNowTime(int time)
{
	/* Check legality */
	if (time < 0)
	{
		throw invalid_argument("(Zombie::setNowTime) Invalid time!");
	}

	this->time_ = time;
}

ostream &operator<<(ostream &oss, Zombie zombie)
{
	oss << "Zombie(type=" << ZOMBIE_STRING[zombie.getType()]
		<< ", position=" << zombie.getRealPosition()
		<< ", health=" << zombie.getHealth()
		<< ", spawn_time=" << zombie.getSpawnTime()
		<< ")";
	return oss;
}

Position<int> Zombie::getPosition()
{
	Position<int> pos(this->position_);
	if (pos.y == 10)
	{ // doubt: how to solve this problem?
		pos.y = 9;
	}
	else if (pos.y == 9 && this->type_ == ZOMBIE.POLEVAULT && this->state_ == 1)
	{
		pos.y = 8;
	}
	return pos;
}

Position<double> Zombie::getRealPosition()
{
	return this->position_real_;
}

void Zombie::setRealPosition(Position<double> position)
{
	int x = static_cast<int>(floor(position.x + 0.001));
	int y = static_cast<int>(floor(position.y + 0.001));

	/* Check legality */
	if (x < 0 || x > 4 || y < -1 || y > 10) // -1 for polevault
	{
		throw invalid_argument("(Zombie::setRealPosition) Out of map!");
	}

	this->position_.x = x;
	this->position_.y = y;
	this->position_real_.x = position.x;
	this->position_real_.y = position.y;
}

int Zombie::getState()
{
	return this->state_;
}

void Zombie::setState(int state)
{
	this->state_ = state;
}

int Zombie::getFrozenState()
{
	return this->frozen_state_;
}

void Zombie::setFrozenState(int state)
{
	/* Check legality */
	if (state < 0)
	{
		throw invalid_argument("(Zombie::setFrozenState) Invalid frozen state!");
	}

	this->frozen_state_ = state;
}

#endif
/*** End of inlined file: Entity.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class GameState
{
protected:
	int inference_state_ = 0; // 0: normal 1: inaccurate 2: invalid
	bool debug_mode_ = false;
	ostream *os = nullptr;

	/* Global Information */
	IPlayer *player_ = nullptr;
	int time_ = 0;
	bitset<5> broken_lines_;
	int score_base_ = 0;

	/* Camp Information */
	int camp_;
	int other_camp_;
	vector<Plant> plant_;
	vector<Zombie> zombie_;
	int sun_plant_ = 400;
	int sun_zombie_ = 299; // at tick 0
	int cd_plant_[7] = {0};
	int cd_zombie_[6] = {0};
	int score_plant_ = 0;
	int score_zombie_ = 0;

public:
	/**
	 * @brief Construct a new Game State object
	 *
	 * @param camp The current camp
	 */
	GameState(int camp);

	/**
	 * @brief Destroy the Game State object
	 *
	 */
	~GameState();

	/**
	 * @brief Get the battlefront of a line
	 *
	 * @param x The line
	 * @return int The y position of the battlefront, 10 if no zombie on this row
	 */
	int getBattlefront(int x);

	/**
	 * @brief Get the broken lines
	 *
	 * @return bitset<5> True if broken
	 */
	bitset<5> getBrokenLines();

	/**
	 * @brief Get the current camp
	 *
	 * @return int The current camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getCamp();

	/**
	 * @brief Get the left cooldown time of a slot
	 *
	 * @param camp The camp
	 * @param slot The slot
	 * @return int The left cooldown time
	 */
	int getCD(int camp, int slot);

	/**
	 * @brief Get the zombie appeared earliest whose y position >= col
	 *
	 * @param row The row to query
	 * @param col The col
	 * @return Zombie The zombie, Zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 10)) if no zombie
	 */
	Zombie getEarliestZombie(int row, int col = 0);

	/**
	 * @brief Get the zombie whose y position >= col and closest to the house
	 *
	 * @param row The row to query
	 * @param col The col
	 * @return Zombie The zombie, Zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 10)) if no zombie
	 */
	Zombie getFirstZombie(int row, int col = 0);

	/**
	 * @brief Get the inference state
	 *
	 * @return 0 The inference algorithm is working properly
	 * @return 1 The inference algorithm is not working properly
	 * @return 2 The inference algorithm is collapsed
	 */
	int getInferenceState();

	/**
	 * @brief Get the other camp
	 *
	 * @return int The other camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getOtherCamp();

	/**
	 * @brief Get the plant at the position
	 *
	 * @param x The x position
	 * @param y The y position
	 * @return Plant The plant
	 */
	Plant getPlant(int x, int y);

	/**
	 * @brief Get plants fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The plant type, -1 for all (optional)
	 * @return vector<Plant>
	 */
	vector<Plant> getPlantList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Get the IPlayer handler
	 *
	 * @return IPlayer* The handler
	 */
	IPlayer *getPlayer();

	/**
	 * @brief Get the score
	 *
	 * @param camp The camp
	 * @return int The score of the camp
	 */
	int getScore(int camp);

	/**
	 * @brief Get the sun count
	 *
	 * @param camp The camp
	 * @return int The sun count of the camp
	 */
	int getSun(int camp);

	/**
	 * @brief Get the time
	 *
	 * @return int The time
	 */
	int getTime();

	/**
	 * @brief Get zombies fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The zombie type, -1 for all (optional)
	 * @return vector<Zombie>
	 */
	vector<Zombie> getZombieList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Set the debug mode
	 *
	 * @param mode true Debug mode on
	 * @param mode false Debug mode off
	 * @param os ostream * The ostream to print errors
	 */
	void setDebugMode(bool mode, ostream *os = &cerr);

	/**
	 * @brief Convert the game state to a std::vector
	 *
	 * @return vector<double> The std::vector
	 */
	vector<double> to_vector();

	/**
	 * @brief Generate a predicted state after applying an action
	 *
	 * @param action The action to apply
	 * @return GameState* The predicted state
	 */
	GameState *generateSuccessor(Action action);

	/**
	 * @brief Infer the next state
	 *
	 */
	void infer();

	/**
	 * @brief Infer the next state according to an action
	 *
	 * @param action The action
	 */
	void infer(Action action);

	/**
	 * @brief Update the state
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Print the game state
	 *
	 * @param os The ostream
	 * @param game_state The game state
	 * @return ostream& The result ostream
	 */
	friend ostream &operator<<(ostream &os, GameState *game_state);
};

class History
{
protected:
	vector<GameState> history_;

public:
	/**
	 * @brief Construct a new History object
	 *
	 */
	History();

	/**
	 * @brief Insert a game state to the history
	 *
	 * @param game_state The game state
	 */
	void insert(GameState *game_state);

	/**
	 * @brief Get a game state
	 *
	 * @param time The time of the game state
	 * @return GameState* The game state
	 */
	GameState *operator[](int time);

	/**
	 * @brief Get the unique identifier of the history object
	 *
	 * @return unsigned long long The identifier
	 */
	unsigned long long getIdentifier();
};

class Game
{
protected:
	IPlayer *player_;
	GameState *game_state_;

public:
	/**
	 * @brief Construct a new Game object
	 *
	 * @param player The IPlayer object
	 */
	Game(IPlayer *player);

	/**
	 * @brief Destroy the Game object
	 *
	 */
	~Game();

	/**
	 * @brief Get the current state
	 *
	 * @return GameState* The current state
	 */
	GameState *getGameState();

	/**
	 * @brief Update the game environment
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Apply an action
	 *
	 * @param action The action to apply
	 * @param force true Apply the action and resolve conflicts automatically
	 * @param force false Apply the action and check conflicts
	 */
	void applyAction(Action action, bool force = false);
};

/****************
 * Definitions
 ****************/

GameState::GameState(int camp) : camp_(camp), other_camp_(1 - camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::GameState) Invalid camp!");
	}
}

GameState::~GameState()
{
}

IPlayer *GameState::getPlayer()
{
	return this->player_;
}

int GameState::getTime()
{
	return this->time_;
}

bitset<5> GameState::getBrokenLines()
{
	return this->broken_lines_;
}

int GameState::getCamp()
{
	return this->camp_;
}

int GameState::getOtherCamp()
{
	return this->other_camp_;
}

Plant GameState::getPlant(int x, int y)
{
	/* Check legality */
	if (x < 0 || x > 4 || y < 0 || y > 10)
	{
		throw invalid_argument("(GameState::getPlant) Out of map!");
	}

	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x == iter->getPosition().x &&
			y == iter->getPosition().y)
		{
			return *iter;
		}
	}

	return Plant(); // if there exists no plant
}

vector<Plant> GameState::getPlantList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 10)
	{
		throw invalid_argument("(GameState::getPlantList) Out of map!");
	}
	if (type < -1 || type > 6)
	{
		throw invalid_argument("(GameState::getPlantList) Invalid type!");
	}

	vector<Plant> result;
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

vector<Zombie> GameState::getZombieList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 10)
	{
		throw invalid_argument("(GameState::getZombieList) Out of map!");
	}
	if (type < -1 || type > 5)
	{
		throw invalid_argument("(GameState::getZombieList) Invalid type!");
	}

	vector<Zombie> result;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

Zombie GameState::getFirstZombie(int row, int col)
{
	vector<Zombie> possible_zombie_list = this->getZombieList(row);
	Zombie first_zombie(0, ZOMBIE.NOZOMBIE, Position<double>(row, 999999));
	for (vector<Zombie>::iterator it = possible_zombie_list.begin();
		 it != possible_zombie_list.end();
		 ++it)
	{
		if (it->getPosition().y < col)
		{
			continue;
		}
		if (abs(it->getRealPosition().y - first_zombie.getRealPosition().y) < 0.001)
		{ // to avoid floating point comparison error
			if (it->getSpawnTime() < first_zombie.getSpawnTime())
			{
				first_zombie = *it;
			}
		}
		else if (it->getRealPosition().y < first_zombie.getRealPosition().y)
		{
			first_zombie = *it;
		}
	}
	return first_zombie;
}

Zombie GameState::getEarliestZombie(int row, int col)
{
	vector<Zombie> possible_zombie_list = this->getZombieList(row);
	Zombie earliest_zombie(this->getTime(), ZOMBIE.NOZOMBIE, Position<double>(row, 10));
	for (vector<Zombie>::iterator it = possible_zombie_list.begin();
		 it != possible_zombie_list.end();
		 ++it)
	{
		if (it->getPosition().y < col)
		{
			continue;
		}
		if (it->getSpawnTime() <= earliest_zombie.getSpawnTime())
		{
			earliest_zombie = *it;
		}
	}
	return earliest_zombie;
}

int GameState::getSun(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::getCD) Invalid camp!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->sun_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->sun_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getCD(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw invalid_argument("(GameState::getCD) Invalid camp!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw invalid_argument("(GameState::getCD) Invalid slot!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw invalid_argument("(GameState::getCD) Invalid slot!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->cd_plant_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->cd_zombie_[slot];
	}

	return 0; // to avoid compilation warning
}

int GameState::getScore(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		if (camp < 0 || camp > 1)
		{
			throw invalid_argument("(GameState::getScore) Invalid camp!");
		}
	}

	if (camp == CAMP.PLANT)
	{
		return this->score_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->score_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getBattlefront(int x)
{
	/* Check legality */
	if (x < 0 || x > 4)
	{
		throw invalid_argument("(GameState::getBattlefront) Out of map!");
	}

	int battle_front = 10;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (iter->getPosition().x == x)
		{
			battle_front = min(battle_front, iter->getPosition().y);
		}
	}
	return battle_front;
}

int GameState::getInferenceState()
{
	return this->inference_state_;
}

void GameState::setDebugMode(bool mode, ostream *os)
{
	this->debug_mode_ = mode;
	this->os = os;
}

void GameState::update(IPlayer *player)
{
	this->player_ = player;

	if (player->getTime() == 1)
	{
		this->score_base_ = player->getScore();
	}

	if (this->inference_state_ != 2)
	{
		try
		{
			this->infer();

			/* Check if the platform does not support static variables */
			if (this->time_ != player->getTime())
			{
				throw runtime_error("(GameState::update) Time error!");
			}

			/* Update according to player */
			/* Update plant list */
			int **raw_plant_map = player->Camp->getCurrentPlants();
			for (int x = 0; x <= 4; ++x)
			{
				for (int y = 0; y <= 9; ++y)
				{
					if (this->getPlant(x, y).getType() != raw_plant_map[x][y])
					{ // if the plant is removed or placed or changed
						if (this->getPlant(x, y).getType() != PLANT.NOPLANT)
						{ // if removed or changed
							for (vector<Plant>::iterator it = this->plant_.begin();
								 it != this->plant_.end();
								 ++it)
							{
								if (it->getPosition().x == x &&
									it->getPosition().y == y)
								{
									this->plant_.erase(it); // remove the plant from plant list
									break;
								}
							}
						}
						if (raw_plant_map[x][y] != PLANT.NOPLANT)
						{                                                 // if placed or changed
							this->plant_.push_back(Plant(this->time_ - 1, // place at last tick
														 raw_plant_map[x][y],
														 Position<int>(x, y)));
							this->cd_plant_[raw_plant_map[x][y]] = PLANT_CD[raw_plant_map[x][y]] - 1; // CD has already gone one tick
							this->sun_plant_ -= PLANT_COST[raw_plant_map[x][y]];
						}
					}
				}
			}

			/* Update zombie list */
			int ***raw_zombie_map = player->Camp->getCurrentZombies();
			for (int x = 0; x <= 4; ++x)
			{
				int zombie_cnt = 0;
				for (int z = 0; raw_zombie_map[x][9][z] != -1; ++z)
				{
					++zombie_cnt;
				}
				if (zombie_cnt > this->getZombieList(x, 9).size() + this->getZombieList(x, 10).size())
				{ // after inference, all zombies' y position will < 10
					for (size_t z = this->getZombieList(x, 9).size(); z < zombie_cnt; ++z)
					{
						this->zombie_.push_back(Zombie(
							this->time_ - 1, // place at last tick
							raw_zombie_map[x][9][z],
							Position<double>(x, 10)));
						this->cd_zombie_[raw_zombie_map[x][9][z]] = ZOMBIE_CD[raw_zombie_map[x][9][z]] - 1; // CD has already gone one tick;
						this->sun_zombie_ -= ZOMBIE_COST[raw_zombie_map[x][9][z]];
					}
				}
			}

			/* Perform zombie boost again */
			if (this->time_ % 500 == 0)
			{ // trigger zombie boost
				for (int i = 1; i <= 5; ++i)
				{
					this->cd_zombie_[i] = 0;
				}
			}

			/* Check accuracy */
			if (this->inference_state_ == 0)
			{
				for (int i = 1; i <= 4; ++i)
				{
					if (this->broken_lines_[i] != (this->player_->Camp->getLeftLines()[i] == 0))
					{
						this->inference_state_ = 1;
					}
				}
				if (this->camp_ == CAMP.PLANT)
				{
					if (this->score_plant_ != this->player_->getScore() - this->score_base_ ||
						this->sun_plant_ != this->player_->Camp->getSun())
					{
						this->inference_state_ = 1;
					}
					for (int i = 1; i <= 6; ++i)
					{
						if (this->cd_plant_[i] != this->player_->Camp->getPlantCD()[i - 1])
						{
							this->inference_state_ = 1;
						}
					}
				}
				else
				{
					if (this->score_zombie_ != this->player_->getScore() - this->score_base_ ||
						this->sun_zombie_ != this->player_->Camp->getSun())
					{
						this->inference_state_ = 1;
					}
					for (int i = 1; i <= 5; ++i)
					{
						if (this->cd_zombie_[i] != this->player_->Camp->getPlantCD()[i - 1])
						{
							this->inference_state_ = 1;
						}
					}
				}

				if (this->inference_state_ == 1 && this->debug_mode_)
				{
					*(this->os) << "******** " << this->time_ << " ********" << endl;
					*(this->os) << this;
					*(this->os) << "Real sun: " << this->player_->Camp->getSun() << endl;
					*(this->os) << "Real CD: [0, ";
					for (int i = 0; i < ((this->camp_ == CAMP.PLANT) ? 6 : 5); ++i)
					{
						*(this->os) << this->player_->Camp->getPlantCD()[i] << ", ";
					}
					*(this->os) << "]" << endl;
					*(this->os) << "Real score: " << this->player_->getScore() - this->score_base_ << endl;
					*(this->os) << "[WARNING]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> Inference algorithm is not working properly! Trying to correct..." << endl
								<< endl;
				}
			}
		}
		catch (const exception &e)
		{
			this->inference_state_ = 2; // the inference algorithm is collapsed
			if (this->debug_mode_)
			{
				*(this->os) << "******** " << this->player_->getTime() << " ********" << endl;
				*(this->os) << this;
				*(this->os) << "[ERROR]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> " << e.what() << endl;
				*(this->os) << "[INFO]<CAMP " << ((this->camp_ == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << this->time_ << "> Disabling inference algorithm..." << endl
							<< endl;
			}
		}
	}

	/* Error correction */
	if (this->inference_state_ == 1 || this->inference_state_ == 2)
	{
		for (int i = 0; i <= 4; ++i)
		{
			this->broken_lines_[i] = (this->player_->Camp->getLeftLines()[i] == 0);
		}

		if (this->camp_ == CAMP.PLANT)
		{
			this->sun_plant_ = this->player_->Camp->getSun();
			if (this->sun_zombie_ < 0)
			{
				this->sun_zombie_ += 900; // to avoid error in inference
			}
			this->score_plant_ = this->player_->getScore() - this->score_base_;
			for (int i = 1; i <= 6; ++i)
			{
				this->cd_plant_[i] = this->player_->Camp->getPlantCD()[i - 1];
			}
			for (int i = 0; i <= 5; ++i)
			{
				this->cd_zombie_[i] = 0;
			}
		}
		else
		{
			this->sun_zombie_ = this->player_->Camp->getSun();
			if (this->sun_plant_ < 0)
			{
				this->sun_plant_ += 775; // to avoid error in inference
			}
			this->score_zombie_ = this->player_->getScore() - this->score_base_;
			for (int i = 1; i <= 5; ++i)
			{
				this->cd_zombie_[i] = this->player_->Camp->getPlantCD()[i - 1];
			}
			for (int i = 0; i <= 6; ++i)
			{
				this->cd_plant_[i] = 0;
			}
		}
	}

	if (this->inference_state_ == 2)
	{
		this->time_ = this->player_->getTime();
		this->plant_.clear();
		this->zombie_.clear();
		for (int x = 0; x <= 4; ++x)
		{
			for (int y = 0; y <= 9; ++y)
			{
				int plant_type = this->player_->Camp->getCurrentPlants()[x][y];
				this->plant_.push_back(Plant(this->time_, plant_type, Position<int>(x, y)));
			}
		}
		for (int x = 0; x <= 4; ++x)
		{
			for (int y = 0; y <= 9; ++y)
			{
				for (int z = 0; this->player_->Camp->getCurrentZombies()[x][y][z] != -1; ++z)
				{
					this->zombie_.push_back(Zombie(this->time_, this->player_->Camp->getCurrentZombies()[x][y][z], Position<double>(x, y + 0.04)));
				}
			}
		}
		if (this->camp_ == CAMP.PLANT)
		{
			this->sun_zombie_ = 1000;              // heuristic
			this->score_zombie_ = 4 * this->time_; // heuristic
		}
		else
		{
			this->sun_plant_ = 1000;              // heuristic
			this->score_plant_ = 3 * this->time_; // heuristic
		}
	}
}

vector<double> GameState::to_vector()
{
	vector<double> result;
	result.push_back(this->time_ / 2000.0);
	result.push_back(this->sun_plant_ / 1000.0);
	result.push_back(this->sun_zombie_ / 1000.0);
	for (int i = 1; i <= 6; ++i)
	{
		result.push_back(static_cast<double>(this->cd_plant_[i]) / PLANT_CD[i]);
	}
	for (int i = 1; i <= 5; ++i)
	{
		result.push_back(static_cast<double>(this->cd_zombie_[i]) / ZOMBIE_CD[i]);
	}
	for (int x = 0; x <= 4; ++x)
	{
		for (int y = 0; y <= 9; ++y)
		{
			int plant_type = this->getPlant(x, y).getType();
			result.push_back((plant_type >> 2) & 1);
			result.push_back((plant_type >> 1) & 1);
			result.push_back(plant_type & 1);
		}
	}
	for (int x = 0; x <= 4; ++x)
	{
		vector<Zombie> zombie_list = this->getZombieList(x);
		for (int i = 0; i < 5; ++i)
		{
			if (i >= zombie_list.size())
			{
				for (int j = 0; j < 5; ++j)
				{
					result.push_back(0);
				}
				continue;
			}
			Zombie zombie = zombie_list.at(i);
			int zombie_type = zombie.getType();
			result.push_back((zombie_type >> 2) & 1);
			result.push_back((zombie_type >> 1) & 1);
			result.push_back(zombie_type & 1);
			result.push_back(static_cast<double>(zombie.getHealth()) / ZOMBIE_HP[zombie_type]);
			result.push_back(zombie.getRealPosition().y / 10);
		}
	}
	return result;
}

GameState *GameState::generateSuccessor(Action action)
{
	GameState *gs = new GameState(*this);
	gs->infer(action);
	return gs;
}

void GameState::infer()
{
	/* Update zombies' time property */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		it->setNowTime(this->time_); // because this->time_ is the time of last tick
	}

	/* Perform plant attack and sun production */
	for (vector<Plant>::iterator it = this->plant_.begin();
		 it != this->plant_.end();
		 ++it)
	{
		Position<int> pos = it->getPosition();
		if (it->getType() == PLANT.PEPPER)
		{
			for (vector<Zombie>::iterator it1 = this->zombie_.begin();
				 it1 != this->zombie_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x)
				{
					it1->reduceHealth(1800);
				}
			}
			it->reduceHealth(300); // pepper will kill itself
		}
		else if (it->getType() == PLANT.SQUASH)
		{
			for (vector<Zombie>::iterator it1 = this->zombie_.begin();
				 it1 != this->zombie_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					it1->getPosition().y == pos.y)
				{
					it1->reduceHealth(1800);
					it->reduceHealth(300); // squash will kill itself
				}
			}
		}
		else if (it->getType() == PLANT.PEASHOOTER)
		{
			Zombie target = this->getFirstZombie(pos.x, pos.y);
			Zombie earliest = this->getEarliestZombie(pos.x, pos.y);
			int reference_time = max(earliest.getSpawnTime(), it->getSpawnTime());
			if (((this->time_ - it->getLastAttackTime() > 3) && ((this->time_ - reference_time) % 3 == 1)) ||
				(this->time_ - it->getLastAttackTime() == 3))
			{
				for (vector<Zombie>::iterator it1 = this->zombie_.begin();
					 it1 != this->zombie_.end();
					 ++it1)
				{
					if (it1->getID() == target.getID())
					{
						it1->reduceHealth(20);
						it->setLastAttackTime(this->time_);
					}
				}
			}
		}
		else if (it->getType() == PLANT.WINTERPEASHOOTER)
		{
			Zombie target = this->getFirstZombie(pos.x, pos.y);
			Zombie earliest = this->getEarliestZombie(pos.x, pos.y);
			int reference_time = max(earliest.getSpawnTime(), it->getSpawnTime());
			if (((this->time_ - it->getLastAttackTime() > 4) && ((this->time_ - reference_time) % 4 == 1)) ||
				(this->time_ - it->getLastAttackTime() == 4))
			{
				for (vector<Zombie>::iterator it1 = this->zombie_.begin();
					 it1 != this->zombie_.end();
					 ++it1)
				{
					if (it1->getID() == target.getID() ||
					(it1->getPosition().x == target.getPosition().x && it1->getPosition().y == target.getPosition().y))
					{
						it1->reduceHealth(60);
						it1->setFrozenState(10); // freeze the zombie for 10 sec
						it->setLastAttackTime(this->time_);
					}
				}
			}
		}
		else if (it->getType() == PLANT.SUNFLOWER)
		{
			if ((this->getTime() - it->getSpawnTime()) % 21 == 1)
			{
				this->sun_plant_ += 25;
			}
		}
	}

	/* Remove dead zombies */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();)
	{
		if (it->getHealth() <= 0)
		{
			this->score_plant_ += ZOMBIE_COST[it->getType()]; // zombies' death contributes to plant camp's score
			it = this->zombie_.erase(it);
		}
		else
		{
			++it;
		}
	}

	/* Perform zombie attack */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		Position<int> pos = it->getPosition();
		if (it->getType() == ZOMBIE.NORMAL ||
			it->getType() == ZOMBIE.BUCKET ||
			it->getType() == ZOMBIE.POLEVAULT)
		{
			for (vector<Plant>::iterator it1 = this->plant_.begin();
				 it1 != this->plant_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					it1->getPosition().y == pos.y)
				{
					if (it->getFrozenState() == 0)
					{
						it1->reduceHealth(static_cast<int>(
							75 * max(1.0, this->time_ / 1000.0))); // zombies' ATK will increase after tick 1000
					}
					else
					{
						it1->reduceHealth(static_cast<int>(
							37.5 * max(1.0, this->time_ / 1000.0))); // zombies' ATK will increase after tick 1000
					}
				}
			}
		}
		else if (it->getType() == ZOMBIE.SLED ||
				 it->getType() == ZOMBIE.GARGANTUAR)
		{
			for (vector<Plant>::iterator it1 = this->plant_.begin();
				 it1 != this->plant_.end();
				 ++it1)
			{
				if (it1->getPosition().x == pos.x &&
					(it1->getPosition().y == pos.y))
				{
					it1->reduceHealth(999999);
				}
			}
		}
	}

	/* Remove dead plants */
	for (vector<Plant>::iterator it = this->plant_.begin();
		 it != this->plant_.end();)
	{
		if (it->getHealth() <= 0)
		{
			this->score_zombie_ += PLANT_COST[it->getType()]; // plants' death contributes to zombie camp's score
			this->sun_zombie_ += PLANT_COST[it->getType()] / 5 +
								 static_cast<int>(
									 sqrt(PLANT_HP[it->getType()]));
			it = this->plant_.erase(it);
		}
		else
		{
			++it;
		}
	}

	/* Perform zombie movement */
	for (vector<Zombie>::iterator it = this->zombie_.begin();
		 it != this->zombie_.end();
		 ++it)
	{
		Position<double> pos_real = it->getRealPosition();
		Position<int> pos = it->getPosition();
		if (it->getType() == ZOMBIE.NORMAL ||
			it->getType() == ZOMBIE.BUCKET)
		{
			if (this->getPlant(pos.x, pos.y).getType() == PLANT.NOPLANT)
			{ // if there's no plant, the zombie can move

				if (it->getFrozenState())
				{ // if the zombie is frozen, its speed cuts to half
					pos_real.y -= ZOMBIE_SPEED.DEFAULT * 0.5;
				}
				else
				{ // if the zombie is not frozen
					pos_real.y -= ZOMBIE_SPEED.DEFAULT;
				}
			}
		}
		else if (it->getType() == ZOMBIE.POLEVAULT)
		{
			if (this->getPlant(pos.x, pos.y).getType() == PLANT.NOPLANT)
			{ // if there's no plant, the zombie can move normally
				if (it->getFrozenState())
				{ // if the zombie is frozen, its speed cuts to half
					pos_real.y -= ZOMBIE_SPEED.POLEVAULT[it->getState()] * 0.5;
				}
				else
				{ // if the zombie is not frozen
					pos_real.y -= ZOMBIE_SPEED.POLEVAULT[it->getState()];
				}
			}
			else if (it->getState() == 0)
			{ // if there's plant and the zombie is not skipped, the zombie will skip the plant
				pos_real.y -= 1;
				it->setState(1); // set the zombie as skipped state
			}
		}
		else if (it->getType() == ZOMBIE.SLED)
		{
			int y = (pos_real.y + 0.001 > 10) ? 10 : pos.y; // to correct the speed
			if (it->getFrozenState())
			{ // if the zombie is frozen, its speed cuts to half
				pos_real.y -= ZOMBIE_SPEED.SLED[min(10 - y, 4)] * 0.5;
			}
			else
			{ // if the zombie is not frozen
				pos_real.y -= ZOMBIE_SPEED.SLED[min(10 - y, 4)];
			}
		}
		else if (it->getType() == ZOMBIE.GARGANTUAR)
		{
			if (it->getFrozenState())
			{ // if the zombie is frozen, its speed cuts to half
				pos_real.y -= ZOMBIE_SPEED.DEFAULT * 0.5;
			}
			else
			{ // if the zombie is not frozen
				pos_real.y -= ZOMBIE_SPEED.DEFAULT;
			}
		}

		it->setRealPosition(pos_real);

		/* Update frozen state */
		if (it->getFrozenState() > 0)
		{                                                 // if the zombie is frozen
			it->setFrozenState(it->getFrozenState() - 1); // reduce remaining frozen time
		}

		/* Update broken lines */
		if (pos_real.y < -0.001 && !this->broken_lines_[pos.x]) // doubt: what is the condition?
		{
			this->broken_lines_.set(pos.x);
			this->score_zombie_ += 3000 - this->time_; // doubt: which tick to calculate?
		}
	}

	/* Remove entities in broken rows */
	for (int row = 0; row <= 4; ++row)
	{
		if (this->broken_lines_[row])
		{
			for (vector<Plant>::iterator it = this->plant_.begin();
				 it != this->plant_.end();)
			{ // remove plants in the broken line
				if (it->getPosition().x == row)
				{
					it = this->plant_.erase(it);
				}
				else
				{
					++it;
				}
			}
			for (vector<Zombie>::iterator it = this->zombie_.begin();
				 it != this->zombie_.end();)
			{ // remove zombies in the broken line
				if (it->getPosition().x == row)
				{
					it = this->zombie_.erase(it);
				}
				else
				{
					++it;
				}
			}
		}
	}

	/* Perform CD reduction */
	for (int i = 1; i <= 6; ++i)
	{ // reduce plant CDs
		this->cd_plant_[i] = max(0, this->cd_plant_[i] - 1);
	}

	for (int i = 1; i <= 5; ++i)
	{ // reduce zombie CDs
		this->cd_zombie_[i] = max(0, this->cd_zombie_[i] - 1);
	}

	/* Perform zombie camp's sun increase */
	this->sun_zombie_ += this->time_ / 200 + 1;

	/* Perform zombie boost */
	if (this->time_ % 500 == 499)
	{ // trigger zombie boost
		for (int i = 1; i <= 5; ++i)
		{
			this->cd_zombie_[i] = 0;
		}
		this->sun_zombie_ += 200;
	}

	++this->time_;
}

void GameState::infer(Action action)
{
	int camp = this->getCamp();

	/* Plant removal */
	for (int i = 0; i < action.getRemovalList().size(); ++i)
	{
		Position<int> removal = action.getRemovalList().at(i);

		/* Check legality */
		if (this->getPlant(removal.x, removal.y).getType() == PLANT.NOPLANT)
		{
			throw runtime_error("(GameState::infer) Plant removal on empty place!");
		}

		for (vector<Plant>::iterator it = this->plant_.begin();
			 it != this->plant_.end();)
		{ // remove a plant
			if (it->getPosition().x == removal.x &&
				it->getPosition().y == removal.y)
			{
				it = this->plant_.erase(it);
			}
			else
			{
				++it;
			}
		}
	}

	/* Plant placement */
	int sun_consumption = 0;
	for (int slot = 1; slot <= 6; ++slot)
	{
		if (action.isSet(CAMP.PLANT, slot))
		{
			if (this->getBrokenLines()[action.getPosition(CAMP.PLANT, slot).x])
			{
				throw runtime_error("(GameState::infer) Plant placement in broken line!");
			}
			if (this->getCD(CAMP.PLANT, slot) > 0)
			{
				throw runtime_error("(GameState::infer) Plant cooldown unfinished!");
			}
			sun_consumption += PLANT_COST[slot];
		}
	}
	if (sun_consumption > this->getSun(CAMP.PLANT))
	{
		throw runtime_error("(GameState::infer) Plant sun insufficient!");
	}

	for (int slot = 1; slot <= 6; ++slot)
	{
		if (action.isSet(CAMP.PLANT, slot))
		{
			Position<int> position = action.getPosition(CAMP.PLANT, slot);

			for (vector<Plant>::iterator it = this->plant_.begin();
				 it != this->plant_.end();)
			{ // remove a plant
				if (it->getPosition().x == position.x &&
					it->getPosition().y == position.y)
				{
					it = this->plant_.erase(it);
				}
				else
				{
					++it;
				}
			}

			this->plant_.push_back(Plant(
				this->time_,
				slot,
				position));
			this->cd_plant_[slot] = PLANT_CD[slot] - 1; // CD has already gone one tick
		}
	}

	this->sun_plant_ -= sun_consumption;

	/* Zombie placement */
	sun_consumption = 0;
	for (int slot = 1; slot <= 5; ++slot)
	{
		if (action.isSet(CAMP.ZOMBIE, slot))
		{
			if (this->getBrokenLines()[action.getPosition(CAMP.ZOMBIE, slot).x])
			{
				throw runtime_error("(GameState::infer) Zombie placement in broken line!");
			}
			if (this->getCD(CAMP.ZOMBIE, slot) > 0)
			{
				throw runtime_error("(GameState::infer) Zombie cooldown unfinished!");
			}
			sun_consumption += ZOMBIE_COST[slot];
		}
	}
	if (sun_consumption > this->getSun(CAMP.ZOMBIE))
	{
		throw runtime_error("(GameState::infer) Zombie sun insufficient!");
	}

	for (int slot = 1; slot <= 5; ++slot)
	{
		if (action.isSet(CAMP.ZOMBIE, slot))
		{
			this->zombie_.push_back(
				Zombie(
					this->time_,
					slot,
					action.getPosition(CAMP.ZOMBIE, slot)));
			this->cd_zombie_[slot] = ZOMBIE_CD[slot] - 1; // CD has already gone one tick
		}
	}

	this->sun_zombie_ -= sun_consumption;

	this->infer();
}

ostream &operator<<(ostream &os, GameState *game_state)
{
	os << "GameState(time_="
	   << game_state->time_
	   << ",\n          broken_lines_="
	   << game_state->broken_lines_
	   << ",\n          camp_="
	   << game_state->camp_
	   << ",\n          other_camp_="
	   << game_state->other_camp_
	   << ",\n          sun_plant_="
	   << game_state->sun_plant_
	   << ",\n          sun_zombie_="
	   << game_state->sun_zombie_
	   << ",\n          cd_plant_=[";
	for (int i = 0; i < 7; ++i)
	{
		os << game_state->cd_plant_[i] << ", ";
	}
	os << "],\n          cd_zombie_=[";
	for (int i = 0; i < 6; ++i)
	{
		os << game_state->cd_zombie_[i] << ", ";
	}
	os << "],\n          score_plant_="
	   << game_state->score_plant_
	   << ",\n          score_zombie_="
	   << game_state->score_zombie_
	   << ",\n          )\n";

	return os;
}

History::History() : history_(2001, GameState(0))
{
}

void History::insert(GameState *game_state)
{
	int time = game_state->getTime();

	/* Check legality */
	if (time < 0 || time > 2000)
	{
		throw invalid_argument("(History::insert) Invalid game state time!");
	}

	this->history_.at(time) = *game_state;
}

GameState *History::operator[](int time)
{
	/* Check legality */
	if (time < 0 || time > 2000)
	{
		throw invalid_argument("(History::[]) Invalid game state time!");
	}

	return &(this->history_.at(time));
}

unsigned long long History::getIdentifier()
{
	unsigned long long result = 0;
	unsigned long long hash = 19260817;
	for (int i = 0; i <= 2000; ++i)
	{
		GameState &gs = this->history_.at(i);
		if (gs.getTime() == 0)
		{
			continue;
		}

		result = result * hash + gs.getTime();
		result = result * hash + gs.getBrokenLines().to_ullong();
		result = result * hash + gs.getCamp();
		result = result * hash + gs.getTime();
		result = result * hash + gs.getScore(CAMP.PLANT);
		result = result * hash + gs.getScore(CAMP.ZOMBIE);
		result = result * hash + gs.getSun(CAMP.PLANT);
		result = result * hash + gs.getSun(CAMP.ZOMBIE);
		for (int i = 1; i <= 6; ++i)
		{
			result = result * hash + gs.getCD(CAMP.PLANT, i);
		}
		for (int i = 1; i <= 5; ++i)
		{
			result = result * hash + gs.getCD(CAMP.ZOMBIE, i);
		}
		vector<Plant> plant_list = gs.getPlantList();
		for (auto it = plant_list.begin(); it != plant_list.end(); ++it)
		{
			result = result * hash + it->getType();
			result = result * hash + it->getHealth();
			result = result * hash + it->getID();
			result = result * hash + it->getSpawnTime();
			result = result * hash + it->getPosition().x;
			result = result * hash + it->getPosition().y;
			result = result * hash + it->getLastAttackTime();
		}
		vector<Zombie> zombie_list = gs.getZombieList();
		for (auto it = zombie_list.begin(); it != zombie_list.end(); ++it)
		{
			result = result * hash + it->getFrozenState();
			result = result * hash + it->getHealth();
			result = result * hash + it->getID();
			result = result * hash + it->getPosition().x;
			result = result * hash + it->getPosition().y;
			result = result * hash + it->getSpawnTime();
			result = result * hash + it->getState();
			result = result * hash + it->getType();
		}
	}

	return result;
}

Game::Game(IPlayer *player)
{
	this->player_ = player;
	this->game_state_ = new GameState(player->Camp->getCurrentType());
}

Game::~Game()
{
}

GameState *Game::getGameState()
{
	return this->game_state_;
}

void Game::update(IPlayer *player)
{
	this->player_ = player;
	this->game_state_->update(player);
}

void Game::applyAction(Action action, bool force)
{
	int camp = this->game_state_->getCamp();
	if (camp == CAMP.PLANT)
	{
		if (!force)
		{
			/* Check legality */
			for (int slot = 1; slot <= 5; ++slot)
			{
				if (action.isSet(CAMP.ZOMBIE, slot))
				{
					throw runtime_error("(Game::applyAction) No access to zombie action!");
				}
			}
		}

		/* Plant removal */
		for (int i = 0; i < action.getRemovalList().size(); ++i)
		{
			Position<int> removal = action.getRemovalList().at(i);

			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getPlant(removal.x, removal.y).getType() == PLANT.NOPLANT)
				{
					throw runtime_error("(Game::applyAction) Plant removal on empty place!");
				}
			}

			this->player_->removePlant(removal.x, removal.y);
		}

		/* Plant placement */
		int remaining_sun = this->game_state_->getSun(CAMP.PLANT);
		vector<int> sequence = action.getSequence(CAMP.PLANT);
		for (auto it = sequence.begin(); it != sequence.end(); ++it)
		{
			Position<int> pos = action.getPosition(CAMP.PLANT, *it);
			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getBrokenLines()[pos.x])
				{
					throw runtime_error("(Game::applyAction) Plant placement in broken line!");
				}
				if (this->game_state_->getCD(CAMP.PLANT, *it) > 0)
				{
					throw runtime_error("(Game::applyAction) Plant cooldown unfinished!");
				}
				if (PLANT_COST[*it] > remaining_sun)
				{
					throw runtime_error("(Game::applyAction) Plant sun insufficient!");
				}
			}
			this->player_->removePlant(pos.x, pos.y);
			this->player_->PlacePlant(*it, pos.x, pos.y);
			remaining_sun -= PLANT_COST[*it];
		}
	}
	else if (camp == CAMP.ZOMBIE)
	{
		/* Check legality */
		if (!force)
		{
			for (int slot = 1; slot <= 6; ++slot)
			{
				if (action.isSet(CAMP.PLANT, slot))
				{
					throw runtime_error("(Game::applyAction) No access to plant action!");
				}
			}
		}

		/* Zombie placement */
		int remaining_sun = this->game_state_->getSun(CAMP.ZOMBIE);
		vector<int> sequence = action.getSequence(CAMP.ZOMBIE);
		for (auto it = sequence.begin(); it != sequence.end(); ++it)
		{
			int x = action.getPosition(CAMP.ZOMBIE, *it).x;
			if (!force)
			{
				/* Check legality */
				if (this->game_state_->getBrokenLines()[action.getPosition(CAMP.ZOMBIE, *it).x])
				{
					throw runtime_error("(Game::applyAction) Zombie placement in broken line!");
				}
				if (this->game_state_->getCD(CAMP.ZOMBIE, *it) > 0)
				{
					throw runtime_error("(Game::applyAction) Zombie cooldown unfinished!");
				}
				if (ZOMBIE_COST[*it] > remaining_sun)
				{
					throw runtime_error("(Game::applyAction) Zombie sun insufficient!");
				}
			}
			this->player_->PlaceZombie(*it, x);
			remaining_sun -= ZOMBIE_COST[*it];
		}
	}
}

class Agent
{
public:
	/**
	 * @brief Get the action the agent performs
	 *
	 * @param game_state A game state
	 * @return Action The action
	 */
	virtual Action getAction(GameState *game_state) = 0;

	/**
	 * @brief Judge if the agent is available under the game state
	 *
	 * @param game_state A game state
	 * @return true The agent is available
	 * @return false The agent is not available
	 */
	virtual bool isAvailable(GameState *game_state)
	{
		return true;
	}
};

#endif
/*** End of inlined file: Game.cpp ***/


/*** Start of inlined file: PlantStrongExpertAgent.cpp ***/
#include <chrono>
// #include "Debug.cpp"

/*** Start of inlined file: Math.cpp ***/
#ifndef __MATH_CPP__
#define __MATH_CPP__

#include <algorithm>
#include <cmath>
#include <exception>
#include <numeric>
#include <ios>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

using namespace std;

/**
 * @brief Math vector
 *
 * @tparam T The item type of the Vector object
 */
template <typename T>
class Vector
{
private:
	vector<T> data_;

public:
	/**
	 * @brief Construct a new Vector object filled with copies of the element
	 *
	 * @param n The size of the vector
	 * @param el The element
	 */
	Vector(size_t n, const T el);

	/**
	 * @brief Construct a new Vector object from a C++ vector
	 *
	 * @param v The vector
	 */
	Vector(const vector<T> &v);

	/**
	 * @brief Dot multiply another vector
	 *
	 * @tparam T1 The typename of elements of the other vector
	 * @param other The other vector
	 * @return const T The product
	 */
	template <typename T1>
	const T operator*(const Vector<T1> &other) const;

	/**
	 * @brief Add another vector
	 *
	 * @tparam T1 The typename of elements of the other vector
	 * @param other The other vector
	 * @return const Vector<T> The result vector
	 */
	template <typename T1>
	const Vector<T> operator+(const Vector<T1> &other) const;

	/**
	 * @brief Access an element of the vector
	 *
	 * @param pos The position of the element
	 * @return T The element
	 */
	T &operator[](size_t pos);

	/**
	 * @brief Get an element of the constant vector
	 *
	 * @param pos The position of the element
	 * @return const T The element
	 */
	const T operator[](size_t pos) const;

	/**
	 * @brief Get the modulo of the vector
	 *
	 * @return const T The modulo of the vector
	 */
	const T mod() const;

	/**
	 * @brief Get the dimension of the vector
	 *
	 * @return const size_t The dimension of the vector
	 */
	const size_t dim() const;

	/**
	 * @brief Convert the Vector object to a C++ vector
	 *
	 * @return const vector<T> A vector
	 */
	const vector<T> &to_vector() const;

	/**
	 * @brief Convert the Vector object to a string
	 *
	 * @return const string A string
	 */
	const string to_string() const;
};

/**
 * @brief Math matrix
 *
 * @tparam T The item type of the Matrix object
 */
template <typename T>
class Matrix
{
private:
	vector<vector<T>> data_;

public:
	/**
	 * @brief Construct a new Matrix object filled with copies of the element
	 *
	 * @param row The number of rows of the matrix
	 * @param column The number of columns of the matrix
	 * @param el The element
	 */
	Matrix(size_t row, size_t column, const T el);

	/**
	 * @brief Construct a new Matrix object from a C++ vector containing C++ vectors
	 *
	 * @param v The vector
	 */
	Matrix(const vector<vector<T>> &v);

	/**
	 * @brief Dot multiply another matrix
	 *
	 * @tparam T1 The typename of elements of the other matrix
	 * @param other The other matrix
	 * @return const Matrix<T> The matrix product
	 */
	template <typename T1>
	const Matrix<T> operator*(const Matrix<T1> &other) const;

	/**
	 * @brief Dot multiply a vector
	 *
	 * @tparam T1 The typename of elements of the vector
	 * @param other The vector
	 * @return const Vector<T> The result vector
	 */
	template <typename T1>
	const Vector<T> operator*(const Vector<T1> &other) const;

	/**
	 * @brief Add another matrix
	 *
	 * @tparam T1 The typename of elements of the other matrix
	 * @param other The other matrix
	 * @return const matrix<T> The result matrix
	 */
	template <typename T1>
	const Matrix<T> operator+(const Matrix<T1> &other) const;

	/**
	 * @brief Add a vector by broadcasting
	 *
	 * @tparam T1 The typename of elements of the vector
	 * @param other The vector
	 * @return const matrix<T> The result matrix
	 */
	template <typename T1>
	const Matrix<T> operator+(const Vector<T1> &other) const;

	/**
	 * @brief Access a row of the matrix
	 *
	 * @param row The row number
	 * @return vector<T> The row vector
	 */
	vector<T> &operator[](size_t row);

	/**
	 * @brief Get a row of the constant matrix
	 *
	 * @param row The row number
	 * @return const vector<T> The row vector
	 */
	const vector<T> operator[](size_t row) const;

	class DimensionType
	{
	public:
		size_t x;
		size_t y;

		/**
		 * @brief Get a dimension
		 *
		 * @param n The dimension number
		 * @return const size_t The dimension
		 */
		inline const size_t operator[](size_t n) const
		{
			/* Check legality */
			if (n > 1)
			{
				throw invalid_argument("(Matrix::DimensionType::operator[]) Invalid dimension number!");
			}

			switch (n)
			{
			case 0:
				return this->x;
				break;
			case 1:
				return this->y;
				break;
			default:
				break;
			}
		}
	};

	/**
	 * @brief Get the dimensions of the matrix
	 *
	 * @return const Matrix::DimensionType The dimensions of the matrix
	 */
	const Matrix<T>::DimensionType dim() const;

	/**
	 * @brief Get the transpose of the matrix
	 *
	 * @return const Matrix<T> The transpose
	 */
	const Matrix<T> t() const;

	/**
	 * @brief Convert the Matrix object to a C++ vector containing C++ vectors
	 *
	 * @return const vector<vector<T>> A C++ vector containing C++ vectors
	 */
	const vector<vector<T>> &to_vector() const;

	/**
	 * @brief Convert the Matrix object to a string
	 *
	 * @return const string A string
	 */
	const string to_string() const;

	/**
	 * @brief Generate a unit matrix
	 *
	 * @param n The rank of the unit matrix
	 * @return const Matrix<T> The unit matrix
	 */
	static const Matrix<T> eye(size_t n);
};

template <typename T>
Vector<T>::Vector(size_t n, const T el)
{
	/* Check legality */
	if (n == 0)
	{
		throw invalid_argument("(Vector<T>::Vector) Zero size not allowed!");
	}

	this->data_.resize(n, el);
}

template <typename T>
Vector<T>::Vector(const vector<T> &v) : data_(v)
{
	/* Check legality */
	if (v.empty())
	{
		throw invalid_argument("(Vector<T>::Vector) Zero size not allowed!");
	}
}

template <typename T>
template <typename T1>
const T Vector<T>::operator*(const Vector<T1> &other) const
{
	/* Check legality */
	if (this->data_.size() != other.data_.size())
	{
		throw invalid_argument("(Vector<T>::operator*) Vector dimensions not matched!");
	}

	return inner_product(this->data_.begin(), this->data_.end(), other.data_.begin(), T());
}

template <typename T>
template <typename T1>
const Vector<T> Vector<T>::operator+(const Vector<T1> &other) const
{
	/* Check legality */
	if (this->data_.size() != other.data_.size())
	{
		throw invalid_argument("(Vector<T>::operator+) Vector dimensions not matched!");
	}

	Vector<T> tmp(this->data_.size(), T());
	for (size_t i = 0; i < tmp.dim(); ++i)
	{
		tmp[i] = this->data_.at(i) + static_cast<T>(other.data_.at(i));
	}

	return tmp;
}

template <typename T>
T &Vector<T>::operator[](size_t pos)
{
	/* Check legality */
	if (pos >= this->data_.size())
	{
		throw out_of_range("(Vector<T>::operator[]) Subscript out of range!");
	}

	return this->data_.at(pos);
}

template <typename T>
const T Vector<T>::operator[](size_t pos) const
{
	/* Check legality */
	if (pos >= this->data_.size())
	{
		throw out_of_range("(Vector<T>::operator[]) Subscript out of range!");
	}

	return this->data_.at(pos);
}

template <typename T>
const T Vector<T>::mod() const
{
	T tmp = inner_product(this->data_.begin(), this->data_.end(), this->data_.begin(), T());
	return static_cast<T>(tmp);
}

template <typename T>
const size_t Vector<T>::dim() const
{
	return this->data_.size();
}

template <typename T>
const vector<T> &Vector<T>::to_vector() const
{
	return this->data_;
}

template <typename T>
const string Vector<T>::to_string() const
{
	ostringstream oss;
	oss << "Vector([";
	for (size_t i = 0; i < this->data_.size(); ++i)
	{
		oss << this->data_.at(i);
		if (i != this->data_.size() - 1)
		{
			oss << ", ";
		}
	}
	oss << "])";
	return oss.str();
}

template <typename T>
Matrix<T>::Matrix(size_t row, size_t column, const T el)
{
	/* Check legality */
	if (row == 0 || column == 0)
	{
		throw invalid_argument("(Matrix<T>::Matrix) Zero size not allowed!");
	}

	this->data_.resize(row, vector<T>(column, el));
}

template <typename T>
Matrix<T>::Matrix(const vector<vector<T>> &v)
{
	/* Check legality */
	if (v.empty() || v.at(0).empty())
	{
		throw invalid_argument("(Matrix<T>::Matrix) Zero size not allowed!");
	}
	for (size_t i = 0; i < v.size(); ++i)
	{
		if (v.at(i).size() != v.at(0).size())
		{
			throw invalid_argument("(Matrix<T>::Matrix) Inconsistent number of columns!");
		}
	}

	this->data_ = v;
}

template <typename T>
template <typename T1>
const Matrix<T> Matrix<T>::operator*(const Matrix<T1> &other) const
{
	/* Check legality */
	if (this->data_.at(0).size() != other.data_.size())
	{
		throw invalid_argument("(Matrix<T>::operator*) Matrix dimensions not matched!");
	}

	Matrix<T> tmp(this->data_.size(), other.data_.at(0).size(), T());
	for (size_t x = 0; x < this->data_.size(); ++x)
	{
		for (size_t y = 0; y < other.data_.at(0).size(); ++y)
		{
			for (size_t k = 0; k < other.data_.size(); ++k)
			{
				tmp[x][y] += this->data_.at(x).at(k) * other.data_.at(k).at(y);
			}
		}
	}

	return tmp;
}

template <typename T>
template <typename T1>
const Vector<T> Matrix<T>::operator*(const Vector<T1> &other) const
{
	/* Check legality */
	if (this->data_.at(0).size() != other.dim())
	{
		throw invalid_argument("(Matrix<T>::operator*) Matrix and Vector dimensions not matched!");
	}

	Vector<T> tmp(this->data_.size(), T());
	for (size_t x = 0; x < this->data_.size(); ++x)
	{
		for (size_t y = 0; y < other.dim(); ++y)
		{
			tmp[x] += this->data_.at(x).at(y) * other[y];
		}
	}

	return tmp;
}

template <typename T>
template <typename T1>
const Matrix<T> Matrix<T>::operator+(const Matrix<T1> &other) const
{
	/* Check legality */
	if (this->data_.size() != other.data_.size() ||
		this->data_.at(0).size() != other.data_.at(0).size())
	{
		throw invalid_argument("(Matrix<T>::operator+) Matrix dimensions not matched!");
	}

	Matrix<T> tmp(this->data_.size(), this->data_.at(0).size(), T());
	for (size_t x = 0; x < this->data_.size(); ++x)
	{
		for (size_t y = 0; y < this->data_.at(0).size(); ++y)
		{
			tmp[x][y] = this->data_[x][y] + other.data_[x][y];
		}
	}

	return tmp;
}

template <typename T>
template <typename T1>
const Matrix<T> Matrix<T>::operator+(const Vector<T1> &other) const
{
	/* Check legality */
	if (this->data_.size() != other.dim())
	{
		throw invalid_argument("(Matrix<T>::operator*) Matrix and Vector dimensions not matched!");
	}

	Matrix<T> tmp(this->data_.size(), this->data_.at(0).size(), T());
	for (size_t x = 0; x < this->data_.size(); ++x)
	{
		for (size_t y = 0; y < this->data_.at(0).size(); ++y)
		{
			tmp[x][y] = this->data_.at(x).at(y) + other[x];
		}
	}

	return tmp;
}

template <typename T>
vector<T> &Matrix<T>::operator[](size_t row)
{
	/* Check legality */
	if (row >= this->data_.size())
	{
		throw out_of_range("(Matrix<T>::operator[]) Subscript out of range!");
	}

	return this->data_.at(row);
}

template <typename T>
const vector<T> Matrix<T>::operator[](size_t row) const
{
	/* Check legality */
	if (row >= this->data_.size())
	{
		throw out_of_range("(Matrix<T>::operator[]) Subscript out of range!");
	}

	return this->data_.at(row);
}

template <typename T>
const typename Matrix<T>::DimensionType Matrix<T>::dim() const
{
	Matrix<T>::DimensionType tmp;
	tmp.x = this->data_.size();
	tmp.y = this->data_.at(0).size();
	return tmp;
}

template <typename T>
const Matrix<T> Matrix<T>::t() const
{
	Matrix<T> tmp(this->data_.at(0).size(), this->data_.size(), T());
	for (size_t i = 0; i < this->data_.size(); ++i)
	{
		for (size_t j = 0; j < this->data_.at(0).size(); ++j)
		{
			tmp[j][i] = this->data_.at(i).at(j);
		}
	}

	return Matrix<T>(tmp);
}

template <typename T>
const vector<vector<T>> &Matrix<T>::to_vector() const
{
	return this->data_;
}

template <typename T>
const string Matrix<T>::to_string() const
{
	ostringstream oss;
	oss << "Matrix([";
	for (size_t i = 0; i < this->data_.size(); ++i)
	{
		if (i != 0)
		{
			oss << "        ";
		}
		oss << "[";
		for (size_t j = 0; j < this->data_.at(0).size(); ++j)
		{
			oss << this->data_.at(i).at(j);
			if (j != this->data_.at(0).size() - 1)
			{
				oss << ", ";
			}
		}
		oss << "]";
		if (i != this->data_.size() - 1)
		{
			oss << ",\n";
		}
	}
	oss << "])";

	return oss.str();
}

template <typename T>
const Matrix<T> Matrix<T>::eye(size_t n)
{
	static_assert(is_integral<T>::value || is_floating_point<T>::value, "(Matrix<T>::eye) Unsupported type!");
	Matrix<T> tmp(n, n, T());
	for (size_t i = 0; i < n; ++i)
	{
		tmp[i][i] = static_cast<T>(1);
	}
	return tmp;
}

/**
 * @brief Deeplearning related algorithms
 *
 * @tparam T The typename of Vector elements
 */
template <typename T>
class DL
{
public:
	/**
	 * @brief Flatten a matrix to a vector
	 *
	 */
	class Flatten2D
	{
	public:
		const Vector<T> operator()(const Matrix<T> &input) const;
	};

	/**
	 * @brief Linear transformation
	 *
	 */
	class Linear
	{
	private:
		Matrix<T> weight_;
		Vector<T> bias_;

	public:
		/**
		 * @brief Construct a new Linear transformation object
		 *
		 * @param weight The weight
		 * @param bias The bias
		 */
		Linear(const Matrix<T> &weight, const Vector<T> &bias);
		const Vector<T> operator()(const Vector<T> &input) const;
		const Matrix<T> operator()(const Matrix<T> &input) const;
	};

	/**
	 * @brief 1D convolution transformation
	 *
	 */
	class Conv1D
	{
	private:

	};

	/**
	 * @brief The rectified linear unit function
	 *
	 */
	class ReLU
	{
	public:
		const Vector<T> operator()(const Vector<T> &input) const;
		const Matrix<T> operator()(const Matrix<T> &input) const;
	};

	/**
	 * @brief The sigmoid function
	 *
	 */
	class Sigmoid
	{
		static_assert(is_integral<T>::value || is_floating_point<T>::value, "(DL<T>::Sigmoid) Unsupported type!");

	public:
		const Vector<T> operator()(const Vector<T> &input) const;
		const Matrix<T> operator()(const Matrix<T> &input) const;
	};

	/**
	 * @brief Softmax function
	 *
	 */
	class Softmax
	{
	public:
		const Vector<T> operator()(const Vector<T> &input) const;
		const Matrix<T> operator()(const Matrix<T> &input) const;
	};

	/**
	 * @brief Hyperbolic tangent function
	 *
	 */
	class Tanh
	{
		static_assert(is_integral<T>::value || is_floating_point<T>::value, "(DL<T>::Tanh) Unsupported type!");

	public:
		const Vector<T> operator()(const Vector<T> &input) const;
		const Matrix<T> operator()(const Matrix<T> &input) const;
	};
};

template <typename T>
const Vector<T> DL<T>::Flatten2D::operator()(const Matrix<T> &input) const
{
	Vector<T> tmp(input.dim().x * input.dim().y, T());
	for (size_t i = 0; i < input.dim().x; ++i)
	{
		for (size_t j = 0; j < input.dim().y; ++j)
		{
			tmp[i * input.dim().y + j] = input[i][j];
		}
	}
	return tmp;
}

template <typename T>
DL<T>::Linear::Linear(const Matrix<T> &weight, const Vector<T> &bias)
	: weight_(weight), bias_(bias)
{
	/* Check legality */
	if (weight.dim().x != bias.dim())
	{
		throw invalid_argument("(DL<T>::Linear::Linear) Weight and bias dimensions not matched!");
	}
}

template <typename T>
const Vector<T> DL<T>::Linear::operator()(const Vector<T> &input) const
{
	return this->weight_ * input + this->bias_;
}

template <typename T>
const Matrix<T> DL<T>::Linear::operator()(const Matrix<T> &input) const
{
	return this->weight_ * input + this->bias_;
}

template <typename T>
const Vector<T> DL<T>::ReLU::operator()(const Vector<T> &input) const
{
	Vector<T> result(input.dim(), T());
	for (size_t i = 0; i < input.dim(); ++i)
	{
		result[i] = max(T(), input[i]);
	}
	return result;
}

template <typename T>
const Vector<T> DL<T>::Sigmoid::operator()(const Vector<T> &input) const
{
	Vector<T> result(input.dim(), T());
	for (size_t i = 0; i < input.dim(); ++i)
	{
		result[i] = static_cast<T>(1 / (1 + exp(-input[i])));
	}
	return result;
}

template <typename T>
const Vector<T> DL<T>::Softmax::operator()(const Vector<T> &input) const
{
	T sum = T();
	for (size_t i = 0; i < input.dim(); ++i)
	{
		sum += static_cast<T>(exp(input[i]));
	}
	Vector<T> tmp(input.dim(), T());
	for (size_t i = 0; i < input.dim(); ++i)
	{
		tmp[i] = static_cast<T>(exp(input[i]) / sum);
	}
	return tmp;
}

template <typename T>
const Vector<T> DL<T>::Tanh::operator()(const Vector<T> &input) const
{
	Vector<T> result(input.dim(), T());
	for (size_t i = 0; i < input.dim(); ++i)
	{
		const T &x = input[i];
		result[i] = static_cast<T>((exp(x) - exp(-x)) / (exp(x) + exp(-x)));
	}
	return result;
}

#endif
/*** End of inlined file: Math.cpp ***/


#include <ctime>
#include <cstdlib>
#include <cmath>
#include <cstring>

using namespace std;

namespace legacy_ai_plant
{
#define TRUE 1
#define FALSE 0
	static int peashooter_no_cd_step = 0;
	static int judge_peashooter_cd_time = 0;

	constexpr int ZOMBIE_KIND = 5;
	constexpr int PLANT_KIND = 6;
	constexpr int TOTAL_TIME = 2000;
	constexpr int COLUMN = 10;
	constexpr int ROW = 5;

	GameState *game_state;
	Action *action;

	enum PlantType
	{
		NOPLANT = 0,
		SUNFLOWER,
		WINTERPEASHOOTER,
		PEASHOOTER,
		SMALLNUT,
		PEPPER,
		SQUASH
	};

	enum ZombieType
	{
		NOZOMBIE = 0,
		NORMAL,
		BUCKET,
		POLEVAULT,
		SLED,
		GARGANTUAR
	};

	typedef struct pos_and_value
	{
		int pos[2];
		double value;
	} pos_and_value;

	class value_plant_func
	{
	public:
		double noplant;
		pos_and_value sunflower;
		pos_and_value peashooter;
		pos_and_value winterpeashooter;
		pos_and_value smallnut;
		pos_and_value pepper;
		pos_and_value squash;
		int generating_row;
		IPlayer *player;
		// double value[PLANT_KIND + 1];
		// int choice[PLANT_KIND + 1] = {this->noplant, this->sunflower, this->peashooter, this->winterpeashooter, this->smallnut, this->pepper, this->squash};

		int NotBrokenLinesNum;
		int KillZombiesScore;
		int LeftPlants;
		int Score;
		int time;
		int *PlaceCD;
		int **Plants;
		int ***Zombies;
		int *LeftLines;
		int Sun;
		int zombie_nums;
		int opponent_sun;

		value_plant_func(int NotBrokenLinesNum,
						 int KillZombiesScore,
						 int Score,
						 int time,
						 int *PlaceCD,
						 int **Plants,
						 int ***Zombies,
						 int *LeftLines,
						 int Sun, IPlayer *player)
		{
			this->NotBrokenLinesNum = NotBrokenLinesNum;
			this->KillZombiesScore = KillZombiesScore;
			this->Score = Score;
			this->time = time;
			this->PlaceCD = PlaceCD;
			this->Plants = Plants;
			this->Zombies = Zombies;
			this->LeftLines = LeftLines;
			this->Sun = Sun;
			this->player = player;
			this->generating_row = 5;
			this->opponent_sun = game_state->getSun(CAMP.ZOMBIE);
		}
		int **sum_plants_per_row()
		{ // [rows,plants_kind] = num_per_row
			int **plants_num_format = (int **)malloc(ROW * sizeof(int *));
			for (int i = 0; i < ROW; i++)
			{
				plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND);
				memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int));
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					switch (this->Plants[i][j])
					{
					case SUNFLOWER:
						plants_num_format[i][SUNFLOWER]++;
						break;
					case WINTERPEASHOOTER:
						plants_num_format[i][WINTERPEASHOOTER]++;
						break;
					case PEASHOOTER:
						plants_num_format[i][PEASHOOTER]++;
						break;
					case SMALLNUT:
						plants_num_format[i][SMALLNUT]++;
						break;
					case PEPPER:
						plants_num_format[i][PEPPER]++;
						break;
					case SQUASH:
						plants_num_format[i][SQUASH]++;
						break;
					}
				}
			}
			return plants_num_format;
		}
		bool judge_Lines_not_have_zombies(int row)
		{
			int flag = 0;
			for (int j = 0; j < row; j++)
			{
				int k = 0;
				while (Zombies[row][j][k] != -1)
				{
					k++;
					flag = 1;
				}
			}
			if (flag == 1)
				return false;
			else
				return true;
		}
		double have_pole(int row)
		{
			for (int i = 0; i < game_state->getZombieList(row, -1, POLEVAULT).size(); i++)
			{
				return ((game_state->getZombieList(row, -1, POLEVAULT))[i].getPosition()).y;
			}
			return 0;
		}
		void beginning_experts_operation()
		{
			if (this->time > 1)
			{
				double farthest_plants[ROW] = {0, 0, 0, 0, 0};
				int nearest_zombies[ROW] = {9, 9, 9, 9, 9};
				for (int i = 0; i < ROW; i++)
					for (int j = 0; j < COLUMN; j++)
					{
						if (Plants[i][j] != NOPLANT)
						{
							farthest_plants[i] = j;
						}
					}
				for (int i = 0; i < ROW; i++)
					for (int j = COLUMN - 1; j >= 0; j--)
					{
						vector<Zombie> Z = game_state->getZombieList(i, j);
						for (int k = Z.size() - 1; k >= 0; k--)
							nearest_zombies[i] = (int)floor(Z[k].getPosition().y + 0.001);
					}
				// how to put pepper;
				int aborted_action_flag = 0;
				if (PlaceCD[PEPPER - 1] == 0)
				{
					if (game_state->getZombieList(-1, -1, GARGANTUAR).size() > 0 && Sun >= 125)
					{
						int x = game_state->getZombieList(-1, -1, GARGANTUAR)[0].getPosition().x;
						for (int j = COLUMN - 1; j >= 0; j--)
							if (Plants[x][j] == NOPLANT)
							{
								player->PlacePlant(PEPPER, x, j);
								break;
							}
					}
					else if (game_state->getZombieList(-1, -1, GARGANTUAR).size() > 0 && Sun < 125)
					{
						aborted_action_flag = 1;
					}
					int flag = 0;
					for (int i = 0; i < ROW; i++)
						if (game_state->getZombieList(i, -1, POLEVAULT).size() > 0 && game_state->getZombieList(i, -1, BUCKET).size() > 0 && Sun >= 125)
						{
							for (int j = COLUMN - 1; j >= 0; j--)
								if (Plants[i][j] == NOPLANT)
								{
									player->PlacePlant(PEPPER, i, j);
									flag = 1;
									break;
								}
							if (flag == 1)
								break;
						}
						else if (game_state->getZombieList(i, -1, POLEVAULT).size() > 0 && game_state->getZombieList(i, -1, BUCKET).size() > 0 && Sun < 125)
						{
							aborted_action_flag = 1;
						}

					int dangerous_flag0 = -1, dangerous_lim0 = 4;
					int dangerous_flag1 = -1, dangerous_lim1 = 5;

					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j <= dangerous_lim0; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								dangerous_flag0 = i;
								k++;
							}
						}
					}
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j <= dangerous_lim1; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								dangerous_flag1 = i;
								k++;
							}
						}
					}
					if (dangerous_flag1 < 0)
					{
						for (int i = 0; i < ROW; i++)
						{
							if (game_state->getZombieList(i, -1, BUCKET).size() > 0 &&
								game_state->getZombieList(i, -1, POLEVAULT).size() > 0)
							{
								player->PlacePlant(PEPPER, i, 9);
								break;
							}
						}
					}
					if (dangerous_flag0 >= 0)
					{
						// int urgent_row = dangerous_flag;

						int sunflower_or_noplant_col[5] = {0};
						for (int i = 0; i < ROW; i++)
							for (int j = 0; j < COLUMN; j++)
							{
								if (Plants[i][j] == NOPLANT || Plants[i][j] == SUNFLOWER)
								{
									sunflower_or_noplant_col[i] = j;
									break;
								}
							}
						double broken_time0[5] = {1000, 1000, 1000, 1000, 1000};
						GameState new_game_state = *game_state;
						double cnt_of_zombie[5];
						for (int i = 0; i < ROW; i++)
							cnt_of_zombie[i] = double(new_game_state.getZombieList(i, -1, -1).size());
						// 100
						for (int step = 0; step < 40; step++)
						{
							// if (new_game_state.getCD(new_game_state.getCamp(), SQUASH) == 0 && new_game_state.getBrokenLines()[i] == false)
							// {
							//     action0.removePlant(i, sunflower_or_noplant_col[i]);
							//     action0.placePlant(SQUASH, i, sunflower_or_noplant_col[i]);
							// }
							new_game_state.infer();
							for (int i = 0; i < ROW; i++)
								if (new_game_state.getBrokenLines()[i] == true && broken_time0[i] > 200 && cnt_of_zombie[i] > 0)
								{
									broken_time0[i] = step / pow(cnt_of_zombie[i], 1.1);
								}
						}

						int *rank_pepper = rank(broken_time0, 5);
						// for (int i = 0; i < ROW; i++)
						//     cout << (broken_time0[i]) << " ";
						// cout << endl;

						int whether_have_broken_occasion = 0;
						for (int i = 0; i < ROW; i++)
						{
							if (broken_time0[i] < 500)
							{
								whether_have_broken_occasion = 1;
								break;
							}
						}
						if (new_game_state.getBrokenLines()[rank_pepper[4]] == true && this->Sun >= 125)
						{
							// printf("\n");
							for (int j = COLUMN - 1; j >= 0; j--)
								if (Plants[rank_pepper[4]][j] == NOPLANT)
								{
									player->PlacePlant(PEPPER, rank_pepper[4], j);
									break;
								}
						}
						else if (whether_have_broken_occasion && this->Sun < 125)
						{
							// printf("!!!!!\n");
							aborted_action_flag = 1;
						}
					}
				}
				// how to put smallnut
				double broken_time[5] = {1000.0, 1000.0, 1000.0, 1000.0, 1000.0};
				double broken_true_time[5] = {1000.0, 1000.0, 1000.0, 1000.0, 1000.0};

				for (int i = 0; i < ROW; i++)
				{
					if (LeftLines[i] == 0)
						broken_time[i] = 10000;
				}
				judge_whether_need_to_put_small_nut(broken_time, broken_true_time);
				int small_nut_cd = PlaceCD[SMALLNUT - 1];
				int *rank0 = rank(broken_time, 5);
				int *rank1 = rank(broken_true_time, 5);

				// for (int i = 0; i < ROW; i++)
				// {
				//     printf("%lf ", broken_time[i]);
				// }
				// printf("\n");

				// for (int i = 0; i < ROW; i++)
				// {
				//     printf("%lf ", broken_true_time[i]);
				// }
				// printf("\n\n");
				int urgency_flag0 = -1; // flag0、1都为-1 :全都不被攻破；flag0>0 flag1==-1：存在被攻破的行，且坚果CD较小；flag0，flag1>0 坚果CD大，不足以补充上来
				int urgency_flag1 = -1;
				int urgency_flag2 = -1;

				int i = ROW - 1;
				for (; i >= 0; i--)
				{
					int have_gargantuar_or_sled_flag = 0;
					int small_nut_flag = 1;
					int have_not_skipped_pole_flag = 0;
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[rank0[i]][j][k] != -1)
						{
							if (Zombies[rank0[i]][j][k] == GARGANTUAR || Zombies[rank0[i]][j][k] == SLED)
							{
								have_gargantuar_or_sled_flag = 1;
								break;
							}
							if (Zombies[rank0[i]][j][k] == POLEVAULT)
							{
								if (game_state->getZombieList(rank0[i], j, POLEVAULT)[0].getState() == 0)
								{
									have_gargantuar_or_sled_flag = 1;
									break;
								}
							}
							k++;
						}
						if (Plants[rank0[i]][j] == SMALLNUT)
						{
							small_nut_flag = 0;
						}
					}
					if (have_gargantuar_or_sled_flag == 0 && small_nut_flag == 1 && have_not_skipped_pole_flag == 0)
						break;
				}
				if (broken_true_time[i] < 999)
				{
					urgency_flag0 = rank0[i];
				}
				if (broken_true_time[ROW - 1] < 999)
				{
					urgency_flag2 = rank1[ROW - 1];
				}
				if (small_nut_cd > broken_true_time[i] - 4)
				{
					urgency_flag1 = urgency_flag0 = rank0[i];
				}
				if (urgency_flag1 == -1 && urgency_flag0 > -1 && PlaceCD[SMALLNUT - 1] == 0 && Sun >= 50)
				{
					double y = have_pole(urgency_flag0);
					if (y > 1.1 && small_nut_cd > 0 && whether_far_from_sled_and_gargun(urgency_flag0, floor(y) - 1))
					{
						player->PlacePlant(SUNFLOWER, urgency_flag0, floor(y) - 1);
					}
					int farthest_peashooter = 0;
					for (int j = 0; j < COLUMN; j++)
					{
						if (Plants[urgency_flag0][j] == PEASHOOTER)
							farthest_peashooter = j;
					}
					if (farthest_peashooter < nearest_zombies[urgency_flag0] - 1)
					{
						for (int j = nearest_zombies[urgency_flag0]; j >= max(farthest_peashooter, 0); j--)
						{
							if (Plants[urgency_flag0][j - 1] == NOPLANT && whether_far_from_sled_and_gargun(urgency_flag0, j - 1))
							{
								player->PlacePlant(SMALLNUT, urgency_flag0, j - 1);
								break;
							}

							else if (Plants[urgency_flag0][j - 1] == SUNFLOWER && whether_far_from_sled_and_gargun(urgency_flag0, j - 1))
							{
								player->removePlant(urgency_flag0, j);
								player->PlacePlant(SMALLNUT, urgency_flag0, j - 1);
								break;
							}
						}
					}
					else
					{
						if (Plants[urgency_flag0][nearest_zombies[urgency_flag0] - 1] == NOPLANT && whether_far_from_sled_and_gargun(urgency_flag0, nearest_zombies[urgency_flag0] - 1))
						{
							player->PlacePlant(SMALLNUT, urgency_flag0, nearest_zombies[urgency_flag0] - 1);
						}

						else if (whether_far_from_sled_and_gargun(urgency_flag0, nearest_zombies[urgency_flag0] - 1) &&
								 Plants[urgency_flag0][nearest_zombies[urgency_flag0] - 1] != SMALLNUT && Plants[urgency_flag0][nearest_zombies[urgency_flag0] - 1] != SQUASH &&
								 Plants[urgency_flag0][nearest_zombies[urgency_flag0] - 1] != PEASHOOTER)
						{
							player->removePlant(urgency_flag0, nearest_zombies[urgency_flag0] - 1);
							player->PlacePlant(SMALLNUT, urgency_flag0, nearest_zombies[urgency_flag0] - 1);
						}
					}
				}
				// printf("%d %d %d\n", urgency_flag0, urgency_flag1,urgency_flag2);
				if (time > 11 && urgency_flag1 == -1 && urgency_flag0 == -1 && small_nut_cd == 0)
				{
					int whether_have_small_nut[5] = {0};
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
							if (Plants[i][j] == SMALLNUT)
							{
								whether_have_small_nut[i] += 1;
							}
					}
					for (int i = 0; i < ROW; i++)
					{
						if (whether_have_small_nut[i] <= 1 && whether_far_from_sled_and_gargun(i, nearest_zombies[i] - 1))
							player->PlacePlant(SMALLNUT, i, nearest_zombies[i] - 1);
					}
				}
				// how to put squash;
				if (PlaceCD[SQUASH - 1] == 0 && time > 11 && Sun >= 50)
				{
					if ((game_state->getZombieList(-1, -1, SLED)).size() != 0)
					{
						Zombie z = game_state->getZombieList(-1, -1, SLED)[0];
						int plant_x = z.getPosition().x;
						int plant_y = floor(z.getPosition().y) - 1 < 0 ? 0 : floor(z.getPosition().y) - 1;
						if (Plants[plant_x][plant_y] == NOPLANT || Plants[plant_x][plant_y] == SUNFLOWER || Plants[plant_x][plant_y] == PEASHOOTER || Plants[plant_x][plant_y] == SMALLNUT)
						{
							player->removePlant(plant_x, plant_y);
							player->PlacePlant(SQUASH, plant_x, plant_y);
						}
					}
					if ((game_state->getZombieList(-1, -1, GARGANTUAR)).size() != 0)
					{
						Zombie z = game_state->getZombieList(-1, -1, GARGANTUAR)[0];
						int plant_x = z.getPosition().x;
						int plant_y = floor(z.getPosition().y) - 1 < 0 ? 0 : floor(z.getPosition().y) - 1;
						if (Plants[plant_x][plant_y] == NOPLANT || Plants[plant_x][plant_y] == SUNFLOWER || Plants[plant_x][plant_y] == PEASHOOTER || Plants[plant_x][plant_y] == SMALLNUT)
						{
							player->removePlant(plant_x, plant_y);
							player->PlacePlant(SQUASH, plant_x, plant_y);
						}
					}
					if (urgency_flag2 > -1)
					{
						// printf("hh\n");
						if (Plants[urgency_flag2][nearest_zombies[urgency_flag2] - 1] == NOPLANT)
							player->PlacePlant(SQUASH, urgency_flag2, nearest_zombies[urgency_flag2] - 1);
						else
						{
							int j = nearest_zombies[urgency_flag2] - 1;
							for (; j >= 0; j--)
								if (Plants[urgency_flag2][j] == SUNFLOWER && game_state->getPlantList(-1, -1, SUNFLOWER).size() > 4)
								{

									player->removePlant(urgency_flag2, j);
									player->PlacePlant(SQUASH, urgency_flag2, j);
									break;
								}
								else if (Plants[urgency_flag2][j] == NOPLANT)
								{
									player->PlacePlant(SQUASH, urgency_flag2, j);
									break;
								}
							if (j == -1)
							{
								j = nearest_zombies[urgency_flag2] - 1;
								for (; j >= 0; j--)
									if (Plants[urgency_flag2][j] == SUNFLOWER)
									{
										player->removePlant(urgency_flag2, j);
										player->PlacePlant(SQUASH, urgency_flag2, j);
										break;
									}
							}
						}
					}
				}
				// how to put sunflower
				int sunflower_num = (game_state->getPlantList(-1, -1, SUNFLOWER)).size();
				int aborted_normal_sunflower_plant_flag = 0;
				if (PlaceCD[SUNFLOWER - 1] == 0 && time > 2) //极限操作and绊撑杆跳 触发条件:有豌豆射手或有撑杆跳
				{
					double score[5] = {1000, 1000, 1000, 1000, 1000};
					if (game_state->getZombieList(-1, -1, POLEVAULT).size() > 0)
					{
						vector<Zombie> Z = game_state->getZombieList(-1, -1, POLEVAULT);
						for (int i = 0; i < Z.size(); i++)
						{
							if (Z[i].getState() == 0)
							{ //未跳过
								int x = Z[i].getPosition().x;
								int y = Z[i].getPosition().y;
								player->PlacePlant(SUNFLOWER, x, y - 1);
								aborted_normal_sunflower_plant_flag = 1;
								break;
							}
						}
					}

					for (int i = 0; i < ROW; i++)
					{
						if (game_state->getBrokenLines()[i] == false)
						{
							int flag = 0;
							for (int j = 0; j < COLUMN; j++)
							{
								if (Plants[i][j] == PEASHOOTER)
									flag = 1;
							}
							if (flag == 1)
							{
								int col = 0;
								for (; col < COLUMN; col++)
								{
									if (Plants[i][col] == NOPLANT)
										break;
								}
								int before_broken_flag = 0;
								int after_broken_flag = 0;

								GameState new_game_state0 = *game_state;
								GameState new_game_state1 = *game_state;

								for (int step = 0; step < 26; step++)
								{
									Action action0;

									if (new_game_state0.getSun(CAMP.PLANT) >= 50 && new_game_state0.getCD(CAMP.PLANT, PLANT.SUNFLOWER) >= 50)
										action0.placePlant(SUNFLOWER, i, col);
									new_game_state0.infer(action0);
									new_game_state1.infer();
									if ((new_game_state1.getBrokenLines())[i] == TRUE)
									{
										before_broken_flag = 1;
									}
								}
								if ((new_game_state0.getBrokenLines())[i] == FALSE)
								{
									after_broken_flag = 1;
								}
								if (before_broken_flag == 1 && after_broken_flag == 1)
								{
									player->PlacePlant(SUNFLOWER, i, col);
									aborted_normal_sunflower_plant_flag = 1;

									break;
								}
							}
						}
					}
				}
				// (time >= 7 || (game_state->getZombieList().size() > 0 && time > 2)) &&
				if ((aborted_action_flag == 0 || (aborted_action_flag == 1 && sunflower_num <= 2)) && aborted_normal_sunflower_plant_flag == 0)
					this->value_sunflower_beginning();
				// how to put peashooter
				if (aborted_action_flag == 0)
				{
					if ((time > 10 || (game_state->getZombieList().size() > 0 && time > 3)) && ((peashooter_no_cd_step > 4) || (game_state->getZombieList().size() > 0)))
					{
						int whether_have_zombie[5] = {0};
						for (int i = 0; i < ROW; i++)
						{
							if ((game_state->getZombieList(i, -1, -1)).size() > 0)
							{
								whether_have_zombie[i] = 1;
							}
						}
						int whether_be_placed_fully_in_column0 = 0;
						int left_lines = 0;
						for (int i = 0; i < ROW; i++)
						{
							if (Plants[i][0] != NOPLANT)
							{
								whether_be_placed_fully_in_column0++;
							}
							{
								if (LeftLines[i] == 1)
								{
									left_lines++;
								}
							}
						}
						double score[5] = {-1, -1, -1, -1, -1};
						double score0[5] = {-1, -1, -1, -1, -1};

						if (PlaceCD[PEASHOOTER - 1] == 0)
						{
							for (int i = 0; i < ROW; i++)
							{
								if (game_state->getBrokenLines()[i] == false)
								{
									int have_gargantuar_or_sled_flag0 = 0;
									for (int j = 0; j < COLUMN; j++)
									{
										int k = 0;
										while (Zombies[rank0[i]][j][k] != -1)
										{
											if (Zombies[rank0[i]][j][k] == GARGANTUAR || Zombies[rank0[i]][j][k] == SLED)
											{
												have_gargantuar_or_sled_flag0 = 1;
												break;
											}
											k++;
										}
									}

									if (have_gargantuar_or_sled_flag0 == 1)
									{
										score[i] = 1000;
										continue;
									}
									if (whether_have_zombie[i] == 0)
									{
										score[i] = 500;
										continue;
									}
									else if (whether_have_zombie[i] == 1)
									{
										// action0.removePlant(i, Plants[i][0] != NOPLANT ? (Plants[i][2] != NOPLANT ? 3 : 2) : 0);

										GameState new_game_state = *game_state;
										for (int step = 0; step < 75; step++)
										{
											new_game_state.infer();
											if ((new_game_state.getBrokenLines())[i] == TRUE)
											{
												score0[i] = step;
												break;
											}
										}
										for (int step = 0; step < 75; step++)
										{
											Action action0;
											if (new_game_state.getCD(game_state->getCamp(), PEASHOOTER) && new_game_state.getSun(CAMP.PLANT) >= 100)
												action0.placePlant(PEASHOOTER, i, Plants[i][0] != NOPLANT ? (Plants[i][2] != NOPLANT ? 3 : 2) : 0);
											new_game_state.infer(action0);
											if ((new_game_state.getBrokenLines())[i] == TRUE)
											{
												score[i] = step;
												break;
											}
										}
										if (score[i] < 0 && (score0[i] >= 0 && score0[i] < 200)) //原来被攻破，放了之后不被攻破
										{
											score[i] = -100;
										}
										if ((score[i] < 0 || abs(score[i] - 500) < 1) && score0[i] < 0) //原来不被攻破，惩罚
										{
											score[i] = 700;
										}
										if ((score[i] >= 0 && score[i] < 200) && (score0[i] >= 0 && score0[i] < 200))
										{
											score[i] = 18000;
										}
										if (LeftLines[i] == 0)
										{
											score[i] = 10000;
										}
									}
								}
								else
								{
									score[i] = 1000000;
								}
							}
							int *rank_row = rank(score, 5);
							// for (int i = 0; i < ROW; i++)
							// {
							//     printf("%lf ", score[i]);
							// }
							if (score[4] < 200)
							{
								int i = 4;
								for (; i >= 0; i--)
								{
									//

									if (game_state->getZombieList(rank_row[i], -1, BUCKET).size() == 0 && game_state->getZombieList(rank_row[i], -1, SLED).size() == 0 && game_state->getZombieList(rank_row[i], -1, GARGANTUAR).size() == 0)
									{
										player->PlacePlant(PEASHOOTER, rank_row[i], Plants[rank_row[i]][0] != NOPLANT ? (Plants[rank_row[i]][2] != NOPLANT ? 3 : 2) : 0);
										// if (rank_row[i] == 4)
										// {
										//     for (int i = 0; i < ROW; i++)
										//         printf("%lf ", score[i]);
										//     printf("\n");
										// }
										break;
									}
								}
								if (i == -1)
								{
									player->PlacePlant(PEASHOOTER, rank_row[4], Plants[rank_row[4]][0] != NOPLANT ? (Plants[rank_row[4]][2] != NOPLANT ? 3 : 2) : 0);
								}
								// printf("hh");
							}
							else
							{
								this->value_peashooter();
							}
							judge_peashooter_cd_time++;
						}
						else if (PlaceCD[PEASHOOTER - 1] == 1)
						{
							judge_peashooter_cd_time = 0;
						}
					}
				}
				if (PlaceCD[PEASHOOTER - 1] == 0)
				{
					peashooter_no_cd_step++;
				}
				else
				{
					peashooter_no_cd_step = 0;
				}
			}
		}
		void judge_whether_need_to_put_small_nut(double broken_time[], double broken_true_time[])
		{
			GameState new_game_state = *game_state;
			double times = 0;

			// double zombie_type_cost[6] = {0, 1, 0.5, 1.5, 0.2, 0.2}; //普僵为基准1
			// for (int i = 0; i < 100; i++)
			// {
			//     new_game_state.infer();
			//     vector<Zombie> detailed_zombie = new_game_state.getZombieList();
			//     for (int k = 0; k < detailed_zombie.size(); k++)
			//         if ((detailed_zombie[k].getPosition()).y < 1.6)
			//         {
			//             if (broken_time[(detailed_zombie[k].getPosition()).x] > 100)
			//             {
			//                 broken_time[(detailed_zombie[k].getPosition()).x] = i * (zombie_type_cost[detailed_zombie[k].getType()]);
			//                 broken_true_time[(detailed_zombie[k].getPosition()).x] = i;
			//             }
			//         }
			// }

			double zombie_type_cost[6] = {0.01, 1, 2, 1.2, 10, 5}; //普僵为基准1
			int cnt_of_zombie[5];
			// int cnt_of_zombie_reaching[5] = {0};

			for (int i = 0; i < ROW; i++)
			{
				vector<Zombie> Z = new_game_state.getZombieList(i, -1, -1);
				for (int k = 0; k < Z.size(); k++)
					cnt_of_zombie[i] += zombie_type_cost[Z[k].getType()];
			}

			for (int step = 0; step < 100; step++)
			{
				new_game_state.infer();
				for (int i = 0; i < ROW; i++)
				{
					if (new_game_state.getBrokenLines()[i] == true)
					{
						if (broken_true_time[i] > 100)
						{
							broken_true_time[i] = broken_time[i] = step;
						}
						// cnt_of_zombie_reaching[i] += 1;
					}
				}
			}
			for (int i = 0; i < ROW; i++)
			{
				// broken_time[i] = 100 / broken_time[i];

				if (cnt_of_zombie[i] > 0)
				{
					broken_time[i] /= cnt_of_zombie[i];
				}
			}
		}
		bool whether_far_from_sled_and_gargun(int row, int col)
		{

			if (game_state->getZombieList(row, col, GARGANTUAR).size() == 0 && game_state->getZombieList(row, col + 1, GARGANTUAR).size() == 0 &&
				game_state->getZombieList(row, col, SLED).size() == 0 && game_state->getZombieList(row, col + 1, SLED).size() == 0)
				return true;
			else
				return false;
		}
		void GameState_2_400()
		{
			if (this->time > 2 && this->time < 100)
			{
				int alarming_flag = -1;
				for (int i = 0; i < ROW; i++)
				{
					if (i != this->generating_row)
					{
						if (time < 160)
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (this->Zombies[i][j][k] != -1)
								{
									if (j <= 3)
										alarming_flag = i;
									if (this->Sun >= 70)
										switch (this->Zombies[i][j][k])
										{
										case POLEVAULT:
										case SLED:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										case BUCKET:
											if (this->PlaceCD[SQUASH] == 0)
												this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											else if (j <= 5)
												this->player->PlacePlant(PEPPER, i, (j - 1 < 0 ? 0 : j - 1));
											this->player->PlacePlant(SMALLNUT, i, (j - 2 < 0 ? 0 : j - 2));
											break;
										case GARGANTUAR:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											if (j < 4)
												this->player->PlacePlant(PEPPER, i, 8);
											break;
										case NORMAL:
											this->player->PlacePlant(PEASHOOTER, i, 0);
											break;
										}
									k++;
								}
							}
					}
					else
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (this->Zombies[this->generating_row][j][k] != -1)
							{
								if (this->Sun >= 70)
									switch (this->Zombies[this->generating_row][j][k])
									{
									case POLEVAULT:
									case BUCKET:
									case SLED:
										this->player->PlacePlant(SQUASH, this->generating_row, 5);
										break;
									case GARGANTUAR:
										this->player->PlacePlant(SQUASH, this->generating_row, (j - 1 < 0 ? 0 : j - 1));
										if (j < 4)
											this->player->PlacePlant(PEPPER, this->generating_row, 8);
										break;
									case NORMAL:
										this->player->PlacePlant(SMALLNUT, this->generating_row, (j - 2 < 0 ? 1 : j - 2));
										break;
									}
								if (j < (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 + 1 && this->PlaceCD[SQUASH - 1] != 0)
								{
									this->player->PlacePlant(PEPPER, i, 8);
								}
								k++;
							}
						}
				}
				// int num = 0, pos = 0;
				// for (int i = 0; i < COLUMN; i++)
				// {
				//     if (Plants[this->generating_row][i] == SUNFLOWER)
				//     {
				//         num++;
				//     }
				//     if (Plants[this->generating_row][i] != NOPLANT)
				//     {
				//         pos = i;
				//     }
				// }
				// if (num < 5)
				// {
				//     this->player->PlacePlant(SUNFLOWER, this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1);
				// }
				int line_not_have_zombie = 0;
				int flag = 0;
				int i = 4;
				for (; i >= 0; i--)
				{
					if (i != this->generating_row)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								flag = 1;
								k++;
							}
						}
					if (Plants[i][2] == SUNFLOWER)
						flag = 1;
					if (flag == 0)
					{
						line_not_have_zombie = i;
						break;
					}
				}
				if (i == -1)
					this->player->PlacePlant(SUNFLOWER, line_not_have_zombie, 3);
				else
				{
					this->player->PlacePlant(SUNFLOWER, line_not_have_zombie, 2);
				}
				if (alarming_flag != -1)
				{
					if (this->PlaceCD[SQUASH - 1] == 0)
					{
						this->player->removePlant(alarming_flag, 1);
						this->player->PlacePlant(SQUASH, alarming_flag, 1);
					}
					else
						this->player->PlacePlant(PEPPER, alarming_flag, COLUMN - 1);
				}
			}
		}
		bool judge_situation_stable()
		{
			if (time > 70 && time < 250)
			{
				double Zombie_cost[6] = {0, -2, -6, -4, 12, 6};
				double Plant_cost[7] = {0, 0.2, 4, 1, 1, 3, 0};
				int rate = 1 + (time - 70) / 1000;
				for (int i = 0; i < ROW; i++)
				{
					Plant_cost[i] *= rate;
				}
				int score = 0;
				int safe_lim = 4;
				for (int j = 0; j <= safe_lim; j++)
				{
					if (game_state->getZombieList(-1, j, -1).size() > 0)
						return false;
				}
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						score += Plant_cost[Plants[i][j]];
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							score += Zombie_cost[Zombies[i][j][k]];
							k++;
						}
					}
				}
				if (score > 0)
					return true;
				else
					return false;
			}
			else
				return false;
		}
		void GameState_50_200()
		{
			if (this->time > 50 && this->time < 200)
			{
				// if (this->Sun >= 400)
				// this->player->PlacePlant(WINTERPEASHOOTER, this->generating_row, 0);
			}
		}
		void value_peashooter_origin()
		{
			if (this->time > 10)
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					double **loss = (double **)malloc(ROW * sizeof(double *));
					for (int i = 0; i < ROW; i++)
					{
						loss[i] = (double *)malloc(COLUMN * sizeof(double));
						memset(loss[i], 0, COLUMN * sizeof(double));
					}
					double max = -10000, max_index[2] = {0, 0};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							if (this->Plants[i][j] != NOPLANT)
								loss[i][j] = -10000;
							else
							{
								//对行的参数
								double row = (i == this->generating_row ? -10 : 0);
								loss[i][j] += row;

								//对列的参数
								// double column = (25);
								// loss[i][j] += column * exp(-column) - 10;

								//对僵尸参数
								double zombie[ZOMBIE_KIND] = {6, -10, -2, -40, -20};
								for (int column0 = 0; j < COLUMN; j++)
								{
									int k = 0;
									while (Zombies[i][column0][k] != -1)
									{
										loss[i][j] += zombie[Zombies[i][column0][k] - 1] / (+COLUMN - j);
										k++;
									}
								}

								//对植物参数
								double plant[PLANT_KIND] = {2, 0, -2, 5, 2, 0};
								for (int column0 = 0; j < COLUMN; j++)
								{
									if (this->Plants[i][column0] != NOPLANT)
										loss[i][j] += plant[this->Plants[i][column0]] * (1 + (column0 - COLUMN / 2) / 40);
								}

								//对时间的参数
								double time_rate = 30;
								loss[i][j] += time_rate * (1 / (1 + exp((+this->time - TOTAL_TIME / 5) / 600)) - 0.5);
							}
							if (max < loss[i][j])
							{
								max_index[0] = i;
								max_index[1] = j;
							}
						}
					this->peashooter.pos[0] = max_index[0];
					this->peashooter.pos[1] = max_index[1];
					this->peashooter.value = max;
				}
		}
		bool have_type_of_zombies(int *zombie, int type)
		{
			int k = 0;
			while (zombie[k] != -1)
			{
				if (zombie[k] == type)
					return true;
				k++;
			}
			return false;
		}
		int search_for_nearest_zombie(int ***zombie, int row, int column)
		{
			int nearest = 100;
			for (int j = 0; j < COLUMN; j++)
			{
				int k = 0;
				while (Zombies[row][j][k] != -1)
				{
					if (nearest > j - column)
						nearest = j - column;
					k++;
				}
			}
			return nearest;
		}
		void judge_Lines_not_broken(double *final_choice)
		{
			for (int i = 0; i < ROW; i++)
			{
				if (this->LeftLines[i] == 0)
				{
					final_choice[i] = -100000;
				}
			}
		}
		void value_peashooter0()
		{
			if (this->time > 30)
			{
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					for (int i = 0; i < ROW; i++)
					{
						if (LeftLines[i] == 1)
						{
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (Zombies[i][j][k] != -1)
								{
									k++;
								}
								if (k == 1 && Zombies[i][j][0] == NORMAL && j >= COLUMN - 2)
								{
									this->player->PlacePlant(PEASHOOTER, i, 0);
								}
								else if (k > 0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) && Sun < 400 && time < 500 && j < 5)
								{
									int start = 0;
									while (Plants[i][start] != NOPLANT)
									{
										start++;
									}
									if (search_for_nearest_zombie(Zombies, i, start) >= 1)
									{
										player->PlacePlant(PEASHOOTER, i, start);
									}
								}
							}
						}
					}
				}
			}
		}
		void value_peashooter()
		{
			int num_of_peashooter = 0;
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == PEASHOOTER)
						num_of_peashooter++;
				}
			if (time > 3)
			{
				double score[5] = {0, 0, 0, 0, 0};
				double plant_cost[7] = {0.2, 2, -8, -6, 15, 10, 0};
				if (this->time < 80)
				{
					plant_cost[SMALLNUT] = -5;
					plant_cost[SUNFLOWER] = -5;
				}
				judge_Lines_not_broken(score);

				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						double distance_cost = 1;
						switch (Plants[i][j])
						{
						case SUNFLOWER:
							distance_cost *= 1 + j / 100;
						}
						score[i] += plant_cost[Plants[i][j]] * distance_cost;
					}
				}

				double zombie_cost[5] = {15, 5, 5, -20, -20};
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 1;
							switch (Zombies[i][j][k])
							{
							case NORMAL:
								distance_cost = j / 8;
							}
							score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost;
							k++;
						}
					}
				}
				int *serial_num = rank(score, ROW);
				// if (time < 50)
				// {
				//     for (int i = 0; i < ROW; i++)
				//         printf("%lf ", score[i]);
				//     for (int i = 0; i < ROW; i++)
				//         printf("%d ", serial_num[i]);
				//     printf("\n");
				// }
				int i = 0;
				for (; i < 10; i++)
				{
					if (Plants[serial_num[0]][i] == NOPLANT)
						break;
				}
				if (i <= 3)
				{
					if (whether_far_from_sled_and_gargun(serial_num[0], i))
					{
						player->PlacePlant(PEASHOOTER, serial_num[0], i);
						// printf("ok");
					}
				}
				free(serial_num);
			}
		}
		int *rank(double *array, int len)
		{
			double max = array[0];
			int *serial_num = (int *)malloc(len * sizeof(int));
			for (int i = 0; i < len; i++)
			{
				serial_num[i] = i;
			}
			for (int i = 0; i < len - 1; i++)
			{
				for (int j = 0; j < len - 1; j++)
				{
					if (array[j] <= array[j + 1])
					{
						double swap = array[j];
						array[j] = array[j + 1];
						array[j + 1] = swap;
						int serial_swap = serial_num[j];
						serial_num[j] = serial_num[j + 1];
						serial_num[j + 1] = serial_swap;
					}
				}
			}
			return serial_num;
		}
		void value_sunflower()
		{
			int sunflower_num = 0;
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == SUNFLOWER)
					{
						sunflower_num++;
					}
				}
			double b = -((this->time - 1000) / 2000) * 5 + 1;
			if (this->time > 9 && sunflower_num < 13 + (b < 0 ? 0 : b) && this->Sun < 5500)
				if (this->PlaceCD[SUNFLOWER - 1] == 0)
				{
					double score[5] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[i][j] == SUNFLOWER)
								score[i] -= 120;
							if (Plants[i][j] == PEASHOOTER)
								score[i] += 50 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == WINTERPEASHOOTER)
								score[i] += 100 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == SMALLNUT)
								score[i] += 100 * (-0.01 * (j - 5) * (j - 5) + 1);
						}
					}
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								if (Zombies[i][j][k] == NORMAL)
									score[i] -= 10 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == BUCKET)
									score[i] -= 50 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == POLEVAULT)
									score[i] -= 30 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == GARGANTUAR)
									score[i] -= 100 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == SLED)
									score[i] -= 80 * (1 / (0.1 + j));
								k++;
							}
						}

					// int sunflower_num_in_generating_row = 0;
					// for (int j = 0; j < COLUMN; j++)
					// {
					//     if (Plants[this->generating_row][j] == SUNFLOWER)
					//         sunflower_num_in_generating_row++;
					// }
					// score[this->generating_row] += 100 * (1 / (sunflower_num_in_generating_row + 2));

					int *serial_num = rank(score, ROW);
					int j = 0;
					while ((Plants[serial_num[0]][j + 2] != NOPLANT) && j < 7)
					{
						j++;
						if ((time > 900 && Plants[serial_num[0]][j + 2] == SMALLNUT))
							break;
					}
					if (j < 7)
						if (whether_far_from_sled_and_gargun(serial_num[0], j + 2))
						{
							player->removePlant(serial_num[0], j + 2);
							player->PlacePlant(SUNFLOWER, serial_num[0], j + 2);
						}
					free(serial_num);
				}
		}
		void value_sunflower_beginning()
		{
			int sunflower_num = 0;
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == SUNFLOWER)
					{
						sunflower_num++;
					}
				}
			double b = -0.01 * (this->time - 300) * (this->time - 300) / 10000 + 1;
			if (this->time > 1 && sunflower_num < 11 + (b < 0 ? 0 : b) && this->Sun < 2500)
				if (this->PlaceCD[SUNFLOWER - 1] == 0 && Sun > 40)
				{
					double score[5] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[i][j] == SUNFLOWER)
								score[i] -= 100;
							if (Plants[i][j] == PEASHOOTER)
								score[i] += 80 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == WINTERPEASHOOTER)
								score[i] += 200 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == SMALLNUT)
								score[i] += 100 * (-0.04 * (j - 5) * (j - 5) + 1);
							if (Plants[i][j] == SQUASH)
							{
								score[i] += 100;
							}
						}
					}
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								if (Zombies[i][j][k] == NORMAL && Plants[i][j] != SMALLNUT)

									score[i] -= (64 / (pow(double(time), 0.5))) * (10 / (0.2 + j));
								if (Zombies[i][j][k] == NORMAL && Plants[i][j] == SMALLNUT)
									score[i] -= (36 / (pow(double(time), 0.5))) * (10 / (0.2 + j));

								if (Zombies[i][j][k] == BUCKET && Plants[i][j] != SMALLNUT)
									score[i] -= (400 / (pow(double(time), 0.5))) * (10 / (0.2 + j));

								if (Zombies[i][j][k] == BUCKET && Plants[i][j] == SMALLNUT)
									score[i] -= (100 / (pow(double(time), 0.5))) * (10 / (0.2 + j));

								if (Zombies[i][j][k] == POLEVAULT)
									score[i] -= ((200 / (pow(double(time), 0.5))) * (10 / (0.2 + j)));
								if (Zombies[i][j][k] == GARGANTUAR)
									score[i] -= 1000 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == SLED)
									score[i] -= 800 * (1 / (0.1 + j));
								k++;
							}
						}

					// int sunflower_num_in_generating_row = 0;
					// for (int j = 0; j < COLUMN; j++)
					// {
					//     if (Plants[this->generating_row][j] == SUNFLOWER)
					//         sunflower_num_in_generating_row++;
					// }
					// score[this->generating_row] += 100 * (1 / (sunflower_num_in_generating_row + 2));

					int *serial_num = rank(score, ROW);
					int i = 0;
					int j = 0;
					//  int j = 0;
					//                     while (Plants[serial_num[0]][j + 1] != NOPLANT && j < 7)
					//                     {
					//                         j++;
					//                     }
					//                     if (j < 7)
					//                         if (game_state->getZombieList(serial_num[0], j, -1).size() == 0 && game_state->getZombieList(serial_num[0], j + 1, -1).size() == 0 && (game_state->getZombieList(serial_num[0], j + 2, -1).size() == 0 || Plants[serial_num[0]][j + 2] == SMALLNUT))
					//                             player->PlacePlant(SUNFLOWER, serial_num[0], j + 1);
					for (; i < ROW; i++)
					{
						if (game_state->getBrokenLines()[serial_num[i]] == false)
						{
							GameState new_game_state = *game_state;
							Action action0;
							while (Plants[serial_num[i]][j + 1] != NOPLANT && j < 7)
							{
								j++;
							}
							if (j < 7)
							{
								if (game_state->getZombieList(serial_num[i], j, -1).size() == 0 && game_state->getZombieList(serial_num[i], j + 1, -1).size() == 0 && (game_state->getZombieList(serial_num[i], j + 2, -1).size() == 0 || Plants[serial_num[i]][j + 2] == SMALLNUT))
									action0.placePlant(SUNFLOWER, serial_num[i], j + 1);
								else
									continue;
								new_game_state.infer(action0);
								int be_eaten_flag = 0;
								for (int step = 0; step < 40; step++)
								{
									if (new_game_state.getPlant(serial_num[i], j + 1).getType() == NOPLANT)
									{
										be_eaten_flag = 1;
										break;
									}
									new_game_state.infer();
								}
								if (be_eaten_flag == 0)
								{
									player->PlacePlant(SUNFLOWER, serial_num[i], j + 1);
									break;
								}
							}
							j = 0;
						}
					}
					free(serial_num);
				}
		}
		void value_smallmnut()
		{
			if (this->PlaceCD[SMALLNUT - 1] == 0)

			{
				double score[ROW] = {0, 0, 0, 0, 0};
				judge_Lines_not_broken(score);

				// value plants
				double plants_score[7] = {0.4, 5, 10, 20, -300, -2, 0};
				if (time < 200)
				{
					plants_score[PEASHOOTER] = -5;
				}
				int small_nut_num_per_row[5] = {0, 0, 0, 0, 0};
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						double distance_cost = 1;
						switch (Plants[i][j])
						{
						case SUNFLOWER:
							distance_cost = 1.5 - 0.05 * j;
							break;
						case PEASHOOTER:
							distance_cost = 2 - 0.09 * j;
							break;
						case WINTERPEASHOOTER:
							distance_cost = 2 - 0.1 * j;
							break;
						case SMALLNUT:
							small_nut_num_per_row[i]++;
						}
						score[i] += plants_score[Plants[i][j]] * distance_cost;
					}
				}

				// value zombies;
				double zombie_cost[5] = {2.0, 12, 9, -1000, -2000};
				int nearest_zombie_per_row[5] = {7, 7, 7, 7, 7};
				for (int i = 0; i < ROW; i++)
				{
					for (int j = COLUMN - 1; j >= 0; j--)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 1;
							switch (Zombies[i][j][k])
							{
							case NORMAL:
								distance_cost = 1.2 - 0.02 * (j);
								break;
							case POLEVAULT:
								distance_cost = 1.1 - 0.01 * j;
								break;
							case BUCKET:
								distance_cost = 1.3 - 0.04 * j;
								break;
							}
							score[i] += zombie_cost[(Zombies[i][j][k] - 1)] * distance_cost;
							k++;
							nearest_zombie_per_row[i] = j;
						}
					}
				}
				// for(int i=0;i< ROW; i++){
				//     score[i] += this->time/2;
				// }
				int *serial_num = rank(score, ROW);
				// for (int i = 0; i < ROW; i++)
				// {
				//     int j = 0;

				// if (Plants[serial_num[i]][nearest_zombie_per_row[serial_num[i]] - 1])
				int j = COLUMN - 3;
				int small_nut_num[5] = {0, 0, 0, 0, 0};
				for (int i = 0; i < ROW; i++)
					for (int j = 0; j < COLUMN; j++)
					{
						if (Plants[i][j] == SMALLNUT)
						{
							small_nut_num[i]++;
						}
					}
				if (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT)
				{
					for (; j >= 2; j--)
					{
						if (Plants[serial_num[0]][j] == NOPLANT)
							break;
					}
					if (j != -1)
					{
						if (small_nut_num[serial_num[0]] < 1 && whether_far_from_sled_and_gargun(serial_num[0], j))
							player->PlacePlant(SMALLNUT, serial_num[0], j);
					}
				}
				else
				{
					if (small_nut_num[serial_num[0]] < 1 && whether_far_from_sled_and_gargun(serial_num[0], (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 0 : (nearest_zombie_per_row[serial_num[0]] - 1)))
						player->PlacePlant(SMALLNUT, serial_num[0], (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 0 : (nearest_zombie_per_row[serial_num[0]] - 1));
				}
				// }
				free(serial_num);
			}
		}
		void value_winterpeashooter()
		{
			if (this->PlaceCD[WINTERPEASHOOTER - 1] == 0)
			{
				if (this->time > 40)
				{
					double score[5] = {0.0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);

					// value plant;
					double plant_cost[7] = {1, 2.5, -8, -4, -10, 6, 0};
					if (time > 400)
					{
						plant_cost[SMALLNUT] = 2;
					}
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							score[i] += plant_cost[Plants[i][j]];
						}
					}

					double zombie_cost[5] = {5, 20, 10, 2, 0};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								score[i] += zombie_cost[Zombies[i][j][k] - 1];
								k++;
							}
						}
					int *serial_num = rank(score, ROW);
					if (this->time < 200)
					{
						int j = 0;

						while (Plants[serial_num[0]][j] != NOPLANT && j < 8)
						{
							j++;
						}

						if (j < 6)
						{
							if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) ||
								  have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR)))
								if (search_for_nearest_zombie(Zombies, serial_num[0], j) >= 1)
								{
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j);
								}
						}
					}
					else
					{
						int limit = ((this->time) / 600) + 3;
						for (int i = 0; i < limit; i++)
						{
							if ((Plants[serial_num[0]][i] == PEASHOOTER && this->time > 450) || (Plants[serial_num[0]][i] == SMALLNUT && this->time > 1000) || (Plants[serial_num[0]][i] == SUNFLOWER))
							{
								if (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun > 400)
								{
									player->removePlant(serial_num[0], i);
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
									break;
								}
							}
							else if (this->Sun > 400 && Plants[serial_num[0]][i] == NOPLANT)
							{
								if (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) ||
									  have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR)))
								{
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
									break;
								}
							}
						}
						// printf("%d:hh ",time);
					}
					free(serial_num);
				}
			}
		}

		void value_squash()
		{
			if (this->PlaceCD[SQUASH - 1] == 0)
			{
				double score[5] = {0, 0, 0, 0, 0};

				double plant_cost[7] = {0, 5, 20, 3, -10, -100, -200};

				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						double distance_cost = 0.2 + 0.08 * j;
						score[i] += plant_cost[Plants[i][j]] * distance_cost;
					}
				}

				double zombie_cost[5] = {-5, 10, 2, 100, 200};
				for (int i = 0; i < ROW; i++)
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 11 / (j + 1);
							score[i] += zombie_cost[Zombies[i][j][k] - 1] * distance_cost;
							k++;
						}
					}
				int *serial_num = rank(score, ROW);

				int nearest_zombie = 8;
				for (int j = COLUMN - 1; j >= 0; j--)
				{
					int k = 0;
					while (Zombies[serial_num[0]][j][k] != -1)
					{
						nearest_zombie = j;
						k++;
					}
				}
				if (nearest_zombie - 1 >= 0)
				{
					if (Plants[serial_num[0]][nearest_zombie - 1] == NOPLANT)
					{
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
					else if (Plants[serial_num[0]][nearest_zombie - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 1] != SQUASH && Plants[serial_num[0]][nearest_zombie - 1] != SMALLNUT && Plants[serial_num[0]][nearest_zombie - 1] != NOPLANT && time > 400 && this->Sun > 50)
					{
						player->removePlant(serial_num[0], nearest_zombie - 1);
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
					else if (Plants[serial_num[0]][nearest_zombie] == SMALLNUT && time > 1000)
					{
						player->removePlant(serial_num[0], nearest_zombie);
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie);
					}
					else if (Plants[serial_num[0]][nearest_zombie] == NOPLANT)
					{
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie);
					}
				}
				else
				{
					for (int j = COLUMN - 1; j >= 0; j--)
					{
						if (Plants[serial_num[0]][j] != NOPLANT && j >= 6)
						{
							player->PlacePlant(SQUASH, serial_num[0], j);
						}
					}
				}
				int flag = 0;

				for (int i = 0; i < ROW; i++)
					if (Sun > 4000 && game_state->getPlantList(-1, -1, SUNFLOWER).size() >= 20000 / Sun && time > 650 && (Plants[serial_num[i]][nearest_zombie] == SUNFLOWER || Plants[serial_num[i]][nearest_zombie] == SMALLNUT))
					{
						player->removePlant(serial_num[i], nearest_zombie);
						player->PlacePlant(SQUASH, serial_num[i], nearest_zombie);
						flag = 1;
						break;
					}
				if (flag == 0)
				{
					for (int i = 0; i < ROW; i++)
						if (Sun > 4000 && game_state->getPlantList(-1, -1, SUNFLOWER).size() >= 20000 / Sun && time > 1050 && (Plants[serial_num[i]][nearest_zombie - 2] == SUNFLOWER || Plants[serial_num[i]][nearest_zombie - 2] == SMALLNUT))
						{
							player->removePlant(serial_num[i], nearest_zombie - 2);
							player->PlacePlant(SQUASH, serial_num[i], nearest_zombie - 2);
							break;
						}
				}

				free(serial_num);
			}
		}
		void value_pepper()
		{
			if (time > 170 && this->PlaceCD[PEPPER - 1] == 0 && this->PlaceCD[SQUASH - 1] != 0)
			{
				double score[ROW] = {0, 0, 0, 0, 0};
				int warning_flag[5] = {0, 0, 0, 0, 0};
				int have_zombies[5] = {0, 0, 0, 0, 0};
				double zombie_cost[5] = {1, 10, 5, 20, 80};
				if (time > 1000)
				{
					for (int i = 0; i < ROW; i++)
					{
						zombie_cost[i] /= ((time) / 800.0);
					}
				}
				// for (int i = 0; i < ROW; i++)
				// {
				//     for (int j = 0; j < COLUMN; j++)
				//     {
				//         int k = 0;
				//         while (Zombies[i][j][k] != -1)
				//         {
				//             double distance_cost = 10 / (0.2 + j);
				//             score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 1];
				//             have_zombies[i] = 1;
				//             if (j <= 3)
				//                 warning_flag[i] = 1;
				//             k++;
				//         }
				//     }
				// }
				int broken_time0[5] = {1000, 1000, 1000, 1000, 1000};
				GameState new_game_state = *game_state;
				int cnt_of_zombie[5];
				for (int i = 0; i < ROW; i++)
					cnt_of_zombie[i] = new_game_state.getZombieList(i, -1, -1).size();

				for (int step = 0; step < 24; step++)
				{
					// if (new_game_state.getCD(new_game_state.getCamp(), SQUASH) == 0 && new_game_state.getBrokenLines()[i] == false)
					// {
					//     action0.removePlant(i, sunflower_or_noplant_col[i]);
					//     action0.placePlant(SQUASH, i, sunflower_or_noplant_col[i]);
					// }
					new_game_state.infer();
					for (int i = 0; i < ROW; i++)
						if (new_game_state.getBrokenLines()[i] == true && broken_time0[i] > 200 && cnt_of_zombie[i] > 0)
						{
							broken_time0[i] = step / cnt_of_zombie[i];
						}
				}

				// for (int i = 0; i < ROW; i++)
				// {
				//     for (int j = 0; j < COLUMN; j++)
				//     {
				//         int k = 0;
				//         while (Zombies[i][j][k] != -1)
				//         {
				//             double distance_cost = 10 / (0.2 + j);
				//             score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 1];
				//             have_zombies[i] = 1;
				//             if (j <= 4)
				//                 warning_flag[i] = 1;
				//             k++;
				//         }
				//     }
				// }

				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 10 / (0.2 + j);
							score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 1];
							have_zombies[i] = 1;
							if (broken_time0[i] < 100)
								warning_flag[i] = 1;
							k++;
						}
					}
				}
				double plant_cost[7] = {0, 0, -10, -3, -1, -80, -80};
				if (time > 1000)
				{
					plant_cost[SQUASH] = -10;
				}
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						score[i] += plant_cost[Plants[i][j]];
					}
				}

				double time_cost = 10 * (1 / (1 + exp((time - 1000) / 500)));

				int *serial_num = rank(score, ROW);
				int deal_with_warning_flag = 0;

				for (int i = 0; i < ROW; i++)
				{
					if (warning_flag[serial_num[i]] == 1)
					{ //加入detect wrong
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[i]][j] == NOPLANT)
							{
								player->PlacePlant(PEPPER, serial_num[i], j);
								flag = 1;
								deal_with_warning_flag = 1;
							}
							if (flag == 1)
								break;
						}
						break;
					}
				}
				if (deal_with_warning_flag == 0)
				{
					if (score[0] >= 0)
					{
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[0]][j] == NOPLANT && have_zombies[serial_num[0]] == 1)
							{
								player->PlacePlant(PEPPER, serial_num[0], j);
								flag = 1;
							}
							if (flag == 1)
								break;
						}
					}
				}

				// for (int i = 0; i < ROW; i++)
				// {
				//     printf("%lf ", score[i]);
				// }
				// printf("\n");
				free(serial_num);
			}
		}
		void eliminate_plants()
		{
			// for (int i = 0; i < ROW; i++)
			// {
			//     for (int j = 1; j < COLUMN; j++)
			//     {
			//         int k = 0;
			//         while (Zombies[i][j][k] != -1)
			//         {
			//             if ((Zombies[i][j][k] == SLED || Zombies[i][j][k] == GARGANTUAR) &&
			//                 (Plants[i][j - 1] != NOPLANT && Plants[i][j - 1] != PEPPER && Plants[i][j - 1] != SQUASH))
			//                 this->player->removePlant(i, j - 1);
			//             k++;
			//         }
			//     }
			// }
			// int farthest_plants[5] = {0};
			// for (int i = 0; i < ROW; i++)
			// {
			//     for (int j = 0; j < COLUMN; j++)
			//     {
			//         if ()
			//         {
			//             farthest_plants[i] = j;
			//         }
			//     }
			// }
			GameState new_game_state = *game_state;
			new_game_state.infer();
			// new_game_state.infer();

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] != NOPLANT && Plants[i][j] != SQUASH && Plants[i][j] != PEPPER)
					{
						if (new_game_state.getZombieList(i, j, GARGANTUAR).size() > 0 || new_game_state.getZombieList(i, j, SLED).size() > 0)
							this->player->removePlant(i, j);
						// printf("remove %d\n", Plants[i][j]);
					}
				}
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();
			new_game_state.infer();

			GameState step5_game_state = new_game_state;
			int whether_be_broken[5] = {0, 0, 0, 0, 0};
			if (time < 200)
				for (int step = 0; step <= 60; step++)
				{
					step5_game_state.infer();
					for (int i = 0; i < ROW; i++)
						if (step5_game_state.getBrokenLines()[i] == true && whether_be_broken[i] == 0)
						{
							whether_be_broken[i] = step;
						}
				}

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if ((whether_be_broken[i] > 0 || time > 300) && new_game_state.getPlant(i, j).getType() != Plants[i][j] && Plants[i][j] != NOPLANT && Plants[i][j] != SQUASH && Plants[i][j] != PEPPER)
					{
						this->player->removePlant(i, j);
						// printf("remove %d step: %d\n", Plants[i][j], time);
					}
				}

			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					Plant P = game_state->getPlant(i, j);
					if (P.getType() == SMALLNUT && P.getHealth() < 200)
					{
						player->removePlant(i, j);
					}
				}
		}
		void value()
		{ //加入time_cost;!!!!!
			this->value_peashooter();
			this->value_sunflower();
			if (this->time < 650)
				this->value_smallmnut();
			this->value_winterpeashooter();
			this->value_squash();
			this->value_pepper();
			// double max = -100000;
			// double value[7] = {this->noplant, this->sunflower.value, this->winterpeashooter.value, this->peashooter.value, this->smallnut.value, this->squash.value, this->pepper.value};
			// this->player->PlacePlant(PEASHOOTER, this->peashooter.pos[0], this->peashooter.pos[1]);
		}
		void make_decision()
		{
			int Agent_in_use = 0;
			if (time > 250 || judge_situation_stable() || Sun > 420)
			{
				Agent_in_use = 1;
				// if (time < 150)
				//     printf("%d : changed", time);
			}
			if (Agent_in_use == 0)
				this->beginning_experts_operation();
			else
				this->value();
			if (this->time > 10)
				eliminate_plants();
		}
	};
	void entry()
	{
		IPlayer *player = game_state->getPlayer();

		int NotBrokenLinesNum = player->getNotBrokenLines();
		int KillZombiesScore = player->getKillZombiesScore();
		int LeftPlants = player->getLeftPlants();
		int Score = player->getScore();
		int time0 = player->getTime();
		int rows = player->Camp->getRows();
		int columns = player->Camp->getColumns();
		int *PlaceCD = player->Camp->getPlantCD();
		int **Plants = player->Camp->getCurrentPlants();
		int ***Zombies = player->Camp->getCurrentZombies();
		int *LeftLines = player->Camp->getLeftLines();
		int Sun = player->Camp->getSun();

		value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player);
		value.make_decision();
		// printf("Plants: %d\n", Score);
	}

}
using namespace std::chrono;
class PlantLegacyAgent
{
public:
	Action getAction(GameState *game_state)
	{
		Action action;
		//获取系统的当前时间
		//将获取的时间转换成time_t类型
		auto start = system_clock::now();
		// do something...

		legacy_ai_plant::action = new Action();
		legacy_ai_plant::game_state = game_state;
		legacy_ai_plant::entry();
		action = *legacy_ai_plant::action;
		delete legacy_ai_plant::action;
		auto end = system_clock::now();
		auto duration = duration_cast<microseconds>(end - start);
		// cout  << duration.count() << endl ;

		return action;
	}
};

static PlantLegacyAgent agent_plant;
/*** End of inlined file: PlantStrongExpertAgent.cpp ***/


/*** Start of inlined file: ZombieReflexAgent2.cpp ***/
#include <algorithm>
#include <vector>

class ZombieAgent
{
protected:
	const double SCORE_TABLE_PLANT[7][10] = { // [slot][y], for tick < 1000
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
		{1350, 1200, 1050, 900, 750, 600, 450, 300, 150, 0},
		{297, 264, 231, 198, 165, 132, 99, 66, 33, 0},
		{1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1800, 1800, 1800, 1800, 1800, 1800, 1800, 2400, 3000, 3600}};

	const double SCORE_TABLE_PLANT1[7][10] = { // [slot][y], for tick > 1000
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1350, 1200, 1050, 900, 750, 600, 450, 300, 150, 0},
		{297, 264, 231, 198, 165, 132, 99, 66, 33, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800}};

	bool canPlaceZombie(int x, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.ZOMBIE) < ZOMBIE_COST[slot] ||
			gs->getCD(CAMP.ZOMBIE, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	double getDifficultyScore(GameState *game_state, int row, int mode = 0)
	{
		double score = 0.0;
		vector<Plant> plant_list = game_state->getPlantList(row);
		for (vector<Plant>::iterator it = plant_list.begin();
			 it != plant_list.end();
			 ++it)
		{
			if (mode == 0)
			{
				score += SCORE_TABLE_PLANT[it->getType()][it->getPosition().y];
			}
			if (mode == 1)
			{
				score += SCORE_TABLE_PLANT1[it->getType()][it->getPosition().y];
			}
		}
		return score;
	}

	vector<int> getWeakestRows(GameState *game_state, int mode = 0)
	{
		/* Get available rows and sort by difficulty score */
		vector<pair<int, double>> difficulty_score;
		for (int i = 0; i <= 4; ++i)
		{
			if (!game_state->getBrokenLines()[i])
			{
				difficulty_score.push_back(pair<int, double>(i, this->getDifficultyScore(game_state, i, mode)));
			}
		}
		auto cmp = [](pair<int, double> a, pair<int, double> b)
		{ return a.second < b.second; };
		sort(difficulty_score.begin(), difficulty_score.end(), cmp);
		vector<int> weakest_rows;
		for (auto it = difficulty_score.begin(); it != difficulty_score.end(); ++it)
		{
			weakest_rows.push_back(it->first);
		}
		return weakest_rows;
	}

	bool judgeEarlyStage(GameState *gs)
	{
		if (gs->getTime() < 15 &&
			gs->getPlantList().size() == 0)
		{
			return false;
		}
		for (int i = 4; i >= 0; --i)
		{
			if (gs->getBrokenLines()[i])
			{
				continue;
			}
			if (!gs->getPlantList(i, -1, PLANT.WINTERPEASHOOTER).empty())
			{
				continue;
			}
			if (gs->getPlantList(i, -1, PLANT.PEASHOOTER).size() >= 2 &&
				!gs->getPlantList(i, -1, PLANT.SMALLNUT).empty())
			{
				continue;
			}
			return true;
		}
		return false;
	}

public:
	Action getAction(GameState *game_state)
	{
		Action action;

		for (int i = 4; i >= 0; --i)
		{
			if (game_state->getPlant(i, 9).getType() == PLANT.SQUASH &&
				canPlaceZombie(i, ZOMBIE.NORMAL, game_state))
			{
				action.placeZombie(ZOMBIE.NORMAL, i);
				return action;
			}
		}

		if ((game_state->getTime() < 500 && judgeEarlyStage(game_state)) &&
			game_state->getSun(CAMP.ZOMBIE) >= 125)
		{
			vector<int> weakest_rows = getWeakestRows(game_state);
			for (auto it = weakest_rows.begin(); it != weakest_rows.end(); ++it)
			{
				int row = *it;
				if (canPlaceZombie(row, ZOMBIE.NORMAL, game_state) &&
					game_state->getZombieList(row).empty() &&
					game_state->getPlantList(row, -1, PLANT.WINTERPEASHOOTER).empty() &&
					!game_state->getPlantList(row, -1, PLANT.SQUASH).empty())
				{
					Plant squash = game_state->getPlantList(row, -1, PLANT.SQUASH).back();
					int y = squash.getPosition().y;
					bool has_smallnut = false;
					for (int i = y + 1; i <= 9; ++i)
					{
						if (game_state->getPlant(row, i).getType() == PLANT.SMALLNUT)
						{
							has_smallnut = true;
							break;
						}
					}
					if (!has_smallnut)
					{
						action.placeZombie(ZOMBIE.NORMAL, row);
						return action;
					}
				}

				if (canPlaceZombie(row, ZOMBIE.BUCKET, game_state) &&

					((game_state->getZombieList(row).empty() &&
					  game_state->getCD(CAMP.PLANT, PLANT.PEPPER) <= 50) ||
					 (!game_state->getZombieList(row).empty() &&
					  game_state->getCD(CAMP.PLANT, PLANT.PEPPER) > 50)) &&

					game_state->getPlantList(row, -1, PLANT.SQUASH).empty() &&
					game_state->getPlantList(row, -1, PLANT.WINTERPEASHOOTER).empty())
				{
					action.placeZombie(ZOMBIE.BUCKET, row);
					return action;
				}

				if (canPlaceZombie(row, ZOMBIE.NORMAL, game_state) &&
					game_state->getZombieList(row).empty() &&
					game_state->getPlantList(row, -1, PLANT.SQUASH).empty() &&
					game_state->getPlantList(row, -1, PLANT.SMALLNUT).empty() &&
					game_state->getPlantList(row, -1, PLANT.WINTERPEASHOOTER).empty())
				{
					action.placeZombie(ZOMBIE.NORMAL, row);
					return action;
				}
			}
		}

		if ((game_state->getTime() >= 1497 ||
			 (game_state->getPlantList(-1, -1, PLANT.SUNFLOWER).size() <= 1 &&
			  game_state->getSun(CAMP.PLANT) <= 75)) &&
			game_state->getTime() < 1940)
		{
			if (game_state->getSun(CAMP.ZOMBIE) < 600)
			{
				return action;
			}

			vector<int> target_rows = getWeakestRows(game_state, 1);

			if (target_rows.size() >= 2)
			{
				for (int i = 0; i < 3; ++i)
				{
					int row = target_rows.at(min((game_state->getTime()) % 2, static_cast<int>(target_rows.size() - 1)));
					if (i == 0 && canPlaceZombie(row, ZOMBIE.SLED, game_state))
					{
						action.placeZombie(ZOMBIE.SLED, row);
						return action;
					}
					if (i == 1 && canPlaceZombie(row, ZOMBIE.GARGANTUAR, game_state))
					{
						action.placeZombie(ZOMBIE.GARGANTUAR, row);
						return action;
					}
					if (i == 2 && canPlaceZombie(row, ZOMBIE.BUCKET, game_state))
					{
						action.placeZombie(ZOMBIE.BUCKET, row);
						action.placeZombie(ZOMBIE.NORMAL, row);
						return action;
					}
				}
			}
			else
			{
				for (int i = 0; i < 3; ++i)
				{
					int row = target_rows.at(0);
					if (i == 0 && canPlaceZombie(row, ZOMBIE.GARGANTUAR, game_state))
					{
						action.placeZombie(ZOMBIE.GARGANTUAR, row);
						return action;
					}
					if (i == 2 && canPlaceZombie(row, ZOMBIE.BUCKET, game_state))
					{
						action.placeZombie(ZOMBIE.BUCKET, row);
						action.placeZombie(ZOMBIE.NORMAL, row);
						return action;
					}
				}
			}
		}

		return action;
	}
};

static ZombieAgent agent_zombie;
/*** End of inlined file: ZombieReflexAgent2.cpp ***/


/*** Start of inlined file: PlantLieFlatAgent.cpp ***/
class PlantLieFlatAgent
{
protected:
	bool canPlacePlant(int x, int y, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.PLANT) < PLANT_COST[slot] ||
			gs->getCD(CAMP.PLANT, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		Action action;

		int row1 = __LINE__ % 3;
		int row2 = row1 + 2;

		if (game_state->getPlant(row1, 0).getType() != PLANT.WINTERPEASHOOTER &&
			game_state->getPlant(row1, 0).getType() != PLANT.NOPLANT)
		{
			action.removePlant(row1, 0);
		}
		if (game_state->getPlant(row2, 0).getType() != PLANT.WINTERPEASHOOTER &&
			game_state->getPlant(row2, 0).getType() != PLANT.NOPLANT)
		{
			action.removePlant(row2, 0);
		}

		if (game_state->getZombieList(row1).size() != 0)
		{
			Position<int> pos = game_state->getZombieList(row1).at(game_state->getZombieList(row1).size() - 1).getPosition();
			int x = pos.x, y = pos.y;
			for (int slot_index = 0; slot_index < 4; ++slot_index)
			{
				const int slot_queue[4] = {4, 3, 1, 6};
				int slot = slot_queue[slot_index];
				if (canPlacePlant(x, y, slot, game_state) &&
					game_state->getPlant(x, y).getType() == PLANT.NOPLANT)
				{
					action.placePlant(slot, x, y);
					return action;
				}
			}
		}

		if (canPlacePlant(row2, 9, PLANT.PEPPER, game_state))
		{
			action.placePlant(PLANT.PEPPER, row2, 9);
			return action;
		}

		for (int x = 0; x <= 4; ++x)
		{
			for (int y_index = 0; y_index <= 9; ++y_index)
			{
				const int y_queue[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
				int y = y_queue[y_index];
				if (canPlacePlant(x, y, PLANT.SUNFLOWER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.SUNFLOWER &&
					x != row1 && x != row2)
				{
					action.placePlant(PLANT.SUNFLOWER, x, y);
					return action;
				}
				if (canPlacePlant(x, y, PLANT.WINTERPEASHOOTER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.WINTERPEASHOOTER &&
					x == row2 &&
					y <= 4 &&
					game_state->getSun(CAMP.PLANT) >= 450)
				{
					action.placePlant(PLANT.WINTERPEASHOOTER, x, y);
					return action;
				}
				if (canPlacePlant(x, y, PLANT.WINTERPEASHOOTER, game_state) &&
					game_state->getPlant(x, y).getType() != PLANT.WINTERPEASHOOTER &&
					x == row1 &&
					game_state->getSun(CAMP.PLANT) >= 450 &&
					game_state->getPlantList(row2, -1, PLANT.WINTERPEASHOOTER).size() == 4)
				{
					action.placePlant(PLANT.WINTERPEASHOOTER, x, y);
					return action;
				}
			}
		}

		return action;
	}
};

static PlantLieFlatAgent agent_plant_lie_flat;
/*** End of inlined file: PlantLieFlatAgent.cpp ***/


/*** Start of inlined file: ZombieLieFlatAgent.cpp ***/
class ZombieLieFlatAgent
{
protected:
	bool canPlaceZombie(int x, int slot, GameState *gs)
	{
		if (gs->getBrokenLines()[x] ||
			gs->getSun(CAMP.ZOMBIE) < ZOMBIE_COST[slot] ||
			gs->getCD(CAMP.ZOMBIE, slot) != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		vector<int> target_rows;
		for (int i = 0; i <= 4; ++i)
		{
			if (game_state->getPlant(i, 0).getType() != PLANT.SUNFLOWER)
			{
				target_rows.push_back(i);
			}
		}

		if (game_state->getTime() >= 290)
		{
			if (canPlaceZombie(target_rows.at(0), ZOMBIE.GARGANTUAR, game_state))
			{
				GameState gs = *game_state;
				Action action1;
				action1.placeZombie(ZOMBIE.GARGANTUAR, target_rows.at(0));
				gs.infer(action1);
				for (int i = 0; i < 100; ++i)
				{
					gs.infer();
				}

				if (!gs.getBrokenLines()[target_rows.at(0)])
				{
					return action1;
				}
			}

			if (canPlaceZombie(target_rows.at(0), ZOMBIE.SLED, game_state))
			{
				GameState gs = *game_state;
				Action action1;
				action1.placeZombie(ZOMBIE.SLED, target_rows.at(0));
				gs.infer(action1);
				for (int i = 0; i < 200; ++i)
				{
					gs.infer();
				}

				if (!gs.getBrokenLines()[target_rows.at(0)])
				{
					return action1;
				}
			}

			for (int slot = 1; slot <= 3; ++slot)
			{
				if (canPlaceZombie(target_rows.at(1), slot, game_state) &&
					game_state->getSun(CAMP.ZOMBIE) - ZOMBIE_COST[slot] >= 600)
				{
					GameState gs = *game_state;
					Action action1;
					action1.placeZombie(slot, target_rows.at(1));
					gs.infer(action1);
					for (int i = 0; i < 100; ++i)
					{
						gs.infer();
					}

					if (!gs.getBrokenLines()[target_rows.at(1)])
					{
						return action1;
					}
				}
			}
		}

		return Action();
	}
};

static ZombieLieFlatAgent agent_zombie_lie_flat;
/*** End of inlined file: ZombieLieFlatAgent.cpp ***/

using namespace std;

void player_ai(IPlayer *player)
{
	static Game *game = new Game(player);
	static History *history = new History();
	static bool lie_flat_mode = false;

	const vector<unsigned long long> LIE_FLAT_CODE = {};

	/* Start a new game when the camp swapped */
	if (player->Camp->getCurrentType() != game->getGameState()->getCamp())
	{
		delete game;
		delete history;
		game = new Game(player);
		history = new History();
	}

	game->getGameState()->setDebugMode(false);

	try
	{
		game->update(player);
		history->insert(game->getGameState());

		if (game->getGameState()->getTime() == 50 && !lie_flat_mode)
		{
			auto code = history->getIdentifier();
			// cout << code << endl;
			for (auto it = LIE_FLAT_CODE.begin(); it != LIE_FLAT_CODE.end(); ++it)
			{
				if (*it == code)
				{
					lie_flat_mode = true;
					break;
				}
			}
		}

		Action action;
		if (lie_flat_mode)
		{
			if (game->getGameState()->getCamp() == CAMP.PLANT)
			{
				action = agent_plant_lie_flat.getAction(game->getGameState());
			}
			else if (game->getGameState()->getCamp() == CAMP.ZOMBIE)
			{
				action = agent_zombie_lie_flat.getAction(game->getGameState());
			}
		}
		else
		{
			if (game->getGameState()->getCamp() == CAMP.PLANT)
			{
				action = agent_plant.getAction(game->getGameState());
			}
			else if (game->getGameState()->getCamp() == CAMP.ZOMBIE)
			{
				action = agent_zombie.getAction(game->getGameState());
			}
		}

		game->applyAction(action, true);
	}
	catch (const exception &e)
	{
		// cerr << "******** " << game->getGameState()->getTime() << " ********" << endl;
		// cerr << "[ERROR]<CAMP " << ((game->getGameState()->getCamp() == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << game->getGameState()->getTime() << "> " << e.what() << endl
		//      << endl;
	}
}
