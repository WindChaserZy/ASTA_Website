// 这里是提交版本
// 时间戳 04/24 23:06

#include "ai.h"
#include <iostream>
int help = 0;
int offend = 0;
bool had_xueqiao[5] = {0};
bool detect_guaorjiao[5] = { 0 };
int had_jiagang[5] = { 0 };
int lajiao[5] = { 0 };
int all_xueqiao[5] = { 0 };
bool filledd = 0;
int selecteded[3];
void updateplants(int,int,int ,int& ,int *, int **);

int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}

void player_ai(IPlayer * player) {
    int Type = player->Camp->getCurrentType(); //获取植物方还僵尸方
    int BrokenLinesScore = player->getBrokenLinesScore();
    int NotBrokenLinesNum = player->getNotBrokenLines();
    int KillPlantsScore = player->getKillPlantsScore();
    int KillZombiesScore = player->getKillZombiesScore();
    int LeftPlants = player->getLeftPlants();
    int Score = player->getScore();
    int time = player->getTime();
    int rows = player->Camp->getRows();
    int columns = player->Camp->getColumns();
    int* PlantCD = player->Camp->getPlantCD();
    int** Plants = player->Camp->getCurrentPlants();
    int*** Zombies = player->Camp->getCurrentZombies();
    int* LeftLines = player->Camp->getLeftLines();
    int Sun = player->Camp->getSun();
    if (Type == 0) {
        //当前为植物方，采取若干策略   
        //v2.13
        //need to work 2 road and this will be a v3.0
        if (time == 1)
        {
            selecteded[0] = -1;
            selecteded[1] = -1;
            selecteded[2] = -1;
        }
        int gargantuar[10] = { 0 };
        int sled[10] = { 0 };
        int polevault[10] = { 0 };
        int bucket[10] = { 0 };
        int normal[10] = { 0 };
        int zombienum[5] = { 0 };
        int zombieplace[5] = { 0 };
        int dangerplace[5] = { 0 };
        int numplace[5] = { 0 };
        int bucketplace[5] = { 0 };
        int poleplace[5] = { 0 };
        for (int i = 0; i < rows; i++)
        {
            int k = 0;
            gargantuar[i] = 0;
            sled[i] = 0;
            polevault[i] = 0;
            bucket[i] = 0;
            normal[i] = 0;
            zombienum[i] = 0;
            zombieplace[i] = 10;
            dangerplace[i] = 11;
            numplace[i] = -1;
            poleplace[i] = -1;
            bucketplace[i] = -1;
            for (int j = 0; j < columns; j++)
            {
                k = 0;
                while (Zombies[i][j][k] != -1)
                {
                    switch (Zombies[i][j][k])
                    {
                    case 1:normal[i]++; break;
                    case 2:bucket[i]++;
                        if (bucketplace[i] == -1)
                        {
                            bucketplace[i] = j;
                        }
                        break;
                    case 3:polevault[i]++;
                        if (poleplace[i] == -1)
                        {
                            poleplace[i] = j;
                        }
                        break;
                    case 4: {
                        sled[i]++;
                        if (dangerplace[i] == 11)
                        {
                            dangerplace[i] = j;
                        }
                        break;
                    }
                    case 5: {
                        gargantuar[i]++;
                        if (dangerplace[i] == 11)
                        {
                            dangerplace[i] = j;
                        }
                        break;
                    }
                    default:break;
                    }
                    k++;
                    zombienum[i]++;
                }
                if (k >= 3 && numplace[i] == -1)
                {
                    numplace[i] = j;
                }
                if (zombieplace[i] == 10 && Zombies[i][j][0] != -1)
                {
                    zombieplace[i] = j;
                }
            }
        }
        for (int i = 0; i < 3; i++)
        {
            if (selecteded[i] >= 0 && selecteded[i] != 6)
            {
                if (LeftLines[selecteded[i]] == 0)
                    selecteded[i] = 6;
            }
            if (selecteded[i] == -1)
            {
                int min = -1;
                int minnum = 20;
                for (int j = 0; j < rows; j++)
                {
                    if (zombienum[j] < minnum && zombieplace[j] >= 4)
                    {
                        bool yess = 1;
                        for (int ii = 0; ii < i; ii++)
                        {
                            if (j == selecteded[ii])
                            {
                                yess = 0;
                                break;
                            }
                        }
                        if (yess == 1)
                        {
                            minnum = zombienum[j];
                            min = j;
                        }
                    }
                }
                if (min != -1)
                {
                    if (Sun >= 150 && PlantCD[0] == 0 && PlantCD[2] == 0)//
                    {
                        int j = 0;
                        for (; j < 5 && j < zombieplace[min]; j++)
                        {
                            if (Plants[min][j] == 0)
                            {
                                player->PlacePlant(3, min, j);
                                updateplants(3, min, j, Sun, PlantCD, Plants);
                                break;
                            }
                        }
                        for (; j < 5 && j < zombieplace[min]; j++)
                        {
                            if (Plants[min][j] == 0)
                            {
                                player->PlacePlant(1, min, j);
                                updateplants(1, min, j, Sun, PlantCD, Plants);
                                break;
                            }
                        }
                        selecteded[i] = min;
                        if (polevault[min] != 0)
                        {
                            for (int j = poleplace[min]; j >= 0; j--)
                            {
                                if (Plants[min][j] == 0)
                                {
                                    if (PlantCD[5] == 0 && Sun >= 100)
                                    {
                                        player->PlacePlant(6, min, j);
                                        updateplants(6, min, j, Sun, PlantCD, Plants);
                                    }
                                    break;
                                }
                            }
                        }
                        if (bucket[min] != 0)
                        {
                            for (int j = bucketplace[min]; j >= 0; j--)
                            {
                                if (Plants[min][j] == 0)
                                {
                                    if (PlantCD[5] == 0 && Sun >= 100)
                                    {
                                        player->PlacePlant(6, min, j);
                                        updateplants(6, min, j, Sun, PlantCD, Plants);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            else
                if (selecteded[i] < 6)
                {
                    int cur_row = selecteded[i];
                    if (sled[cur_row] + gargantuar[cur_row] > 0)
                    {
                        int dangerpoint = dangerplace[cur_row];
                        if (PlantCD[5] == 0 && Sun >= 50 &&( Plants[cur_row][dangerpoint] == 0||(dangerpoint-1>=0&&(Plants[cur_row][dangerpoint-1]==0||Plants[cur_row][dangerpoint-1]==1))))
                        {
                            if(dangerpoint-1>=0&&(Plants[cur_row][dangerpoint-1]==0||Plants[cur_row][dangerpoint-1]==1))
                            {
                                if(Plants[cur_row][dangerpoint-1]==1)
                                {
                                    player->removePlant(cur_row,dangerpoint-1);
                                }
                                player->PlacePlant(6, cur_row, dangerpoint-1);
                                updateplants(6, cur_row, dangerpoint-1, Sun, PlantCD, Plants);
                            }
                            else{
                                player->PlacePlant(6, cur_row, dangerpoint);
                                updateplants(6, cur_row, dangerpoint, Sun, PlantCD, Plants);
                            }
                        }
                        else if (PlantCD[4] == 0 && Sun >= 150 && PlantCD[5] < 60 && ((dangerpoint - 1 >= 0 && Plants[cur_row][dangerpoint - 1])))
                        {
                            for (int i = columns - 1; i >= 0; i--)
                            {
                                if (Plants[cur_row][i] == 0)
                                {
                                    player->PlacePlant(5, cur_row, dangerpoint);
                                    updateplants(5, cur_row, dangerpoint, Sun, PlantCD, Plants);
                                    break;
                                }
                            }
                        }
                    }
                    bool okeyy = 0;//have changed
                    if (numplace[cur_row] != -1)
                    {
                        if (Plants[cur_row][numplace[cur_row]] == 0)
                        {
                            if (PlantCD[5] == 0 && Sun >= 100)
                            {
                                player->PlacePlant(6, cur_row, numplace[cur_row]);
                                updateplants(6, cur_row, numplace[cur_row], Sun, PlantCD, Plants);
                                okeyy = 1;
                            }
                        }
                    }
                    if (okeyy == 0)
                    {
                        if (zombienum[cur_row] >= 3 && (Plants[cur_row][zombieplace[cur_row]] != 0 && Plants[cur_row][zombieplace[cur_row]] != 4) && PlantCD[4] == 0 && Sun >= 175 && PlantCD[5] < 60)
                        {
                            for (int j = 0; j < columns; j++)
                            {
                                if (Plants[cur_row][j] == 0)
                                {
                                    player->PlacePlant(5, cur_row, j);
                                    updateplants(5, cur_row, j, Sun, PlantCD, Plants);
                                    break;
                                }
                            }
                        }
                    }
                    if(zombieplace[cur_row]==0)
                    {
                        if(PlantCD[4]==0&&Plants[cur_row][0]==0&&Sun>=150)
                        {
                            player->PlacePlant(5,cur_row,0);
                            updateplants(5,cur_row,0,Sun,PlantCD,Plants);
                        }
                    }
                    else if(zombieplace[cur_row]<=4&&(Plants[cur_row][zombieplace[cur_row]-1]==1||Plants[cur_row][zombieplace[cur_row]-1]==2||Plants[cur_row][zombieplace[cur_row]-1]==3))
                    {
                        if(PlantCD[5]==0&&Sun>=100&&Plants[cur_row][zombieplace[cur_row]]==0)
                        {
                            player->PlacePlant(6,cur_row,zombieplace[cur_row]);
                            updateplants(6,cur_row,zombieplace[cur_row],Sun,PlantCD,Plants);
                        }
                    }
                    bool pea = 0, sunflower = 0, nut = 0;
                    for (int j = 0; j < 5; j++)
                    {
                        if (Plants[cur_row][j] == 1)
                            sunflower = 1;
                        else if (Plants[cur_row][j] == 2 || Plants[cur_row][j] == 3)
                            pea = 1;
                    }
                    for (int j = 5; j < columns; j++)
                    {
                        if (Plants[cur_row][j] == 4)
                            nut = 1;
                    }
                    if (!nut && zombieplace[cur_row] == 5 || zombieplace[cur_row] == 6)
                    {
                        for (int j = 5; j < columns; j++)
                        {
                            if (Plants[cur_row][j] == 0)
                            {
                                if (Sun >= 100 && PlantCD[3] == 0)
                                {
                                    player->PlacePlant(4, cur_row, j);
                                    updateplants(4, cur_row, j, Sun, PlantCD, Plants);
                                    break;
                                }
                                else break;
                            }
                        }
                    }
                    else if(!nut&&zombieplace[cur_row]<=4)
                    {
                        int tmpp=zombieplace[cur_row];
                        if(Plants[tmpp]==0&&PlantCD[3] == 0 && Sun >= 50&&pea==1)
                        {
                            player->PlacePlant(4, cur_row, tmpp);
                            updateplants(4, cur_row, tmpp, Sun, PlantCD, Plants);
                        }
                    }
                    if (!pea)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (Plants[cur_row][j] == 0)
                            {
                                if (Sun >= 450 && PlantCD[1] == 0)
                                {
                                    player->PlacePlant(2, cur_row, j);
                                    updateplants(2, cur_row, j, Sun, PlantCD, Plants);
                                    break;
                                }
                                else if (Sun >= 150 && PlantCD[2] == 0)
                                {
                                    player->PlacePlant(3, cur_row, j);
                                    updateplants(3, cur_row, j, Sun, PlantCD, Plants);
                                    break;
                                }
                                else break;
                            }
                        }
                    }
                    if (!sunflower)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (Plants[cur_row][j] == 0)
                            {
                                if (Sun >= 50 && PlantCD[0] == 0)
                                {
                                    player->PlacePlant(1, cur_row, j);
                                    updateplants(1, cur_row, j, Sun, PlantCD, Plants);
                                    break;
                                }
                                else break;
                            }
                        }
                    }
                }
        }
        int sfnum[5] = { 0 }, peanum[5] = { 0 },winternum[5]={0}, nutnum[5] = { 0 }, wgnum[5] = { 0 };
        if (time >= 100)
        {
            for (int i = 0; i < 3; i++)
            {
                if (selecteded[i] != -1 && selecteded[i] != 6)
                {
                    int cur_row = selecteded[i];
                    for (int j = 0; j < columns - 1; j++)
                    {
                        if (Plants[cur_row][j] == 1)
                        {
                            sfnum[cur_row]++;
                        }
                        else if (Plants[cur_row][j] == 2 || Plants[cur_row][j] == 3)
                        {
                            peanum[cur_row]++;
                            if(Plants[cur_row][j] == 2)
                            winternum[cur_row]++;
                        }
                    }
                    for (int j = 5; j < columns; j++)
                    {
                        if (Plants[cur_row][j] == 4)
                            nutnum[cur_row]++;
                        else if (Plants[cur_row][j] == 6)
                            wgnum[cur_row]++;
                    }
                }
            }
            int workline = -1;
            int maxzom = 0;
            for (int i = 0; i < 3; i++)
            {
                if (selecteded[i] != -1 && selecteded[i] != 6)
                {
                    int xianzai = selecteded[i];
                    if (zombienum[xianzai] >= maxzom)
                    {
                        workline = xianzai;
                        maxzom = zombienum[xianzai];
                    }
                }
            }
            if (maxzom <= 1)
            {
                int peatmppp=9;
                int wintertmp=9;
                bool choide=0;
                for(int i=0;i<3;i++)
                {
                    int tmpp=selecteded[i];
                    if(tmpp!=-1&&tmpp!=6)
                    {
                        if(peanum[tmpp]<peatmppp)
                        {
                            choide=1;
                            workline=tmpp;
                            peatmppp=peanum[tmpp];
                            wintertmp=winternum[tmpp];
                        }
                        else if(peanum[tmpp]==peatmppp&&winternum[tmpp]<wintertmp)
                        {
                            workline=tmpp;
                            peatmppp=peanum[tmpp];
                            wintertmp=winternum[tmpp];
                        }
                    }
                }

                if(choide==0)
                workline = selecteded[(int)time % 3];
            }
            //std::cout << workline << " | " << selecteded[0] <<'|'<<zombienum[0]<<" | "<<zombienum[2] << std::endl;
            if (workline != -1&&workline!=6)
            {
                if (peanum[workline] < 3 && PlantCD[2] == 0 && Sun >= 150)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        if (Plants[workline][i] == 0)
                        {
                            player->PlacePlant(3, workline, i);
                            updateplants(3, workline, i, Sun, PlantCD, Plants);
                            break;
                        }
                    }
                }
                else if (peanum[workline] >= 3 && PlantCD[1] == 0 && Sun >= 450)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        if (Plants[workline][i] == 3 || Plants[workline][i] == 0)
                        {
                            if (Plants[workline][i] == 3)
                            {
                                player->removePlant(workline, i);
                            }
                            player->PlacePlant(2, workline, i);
                            updateplants(2, workline, i, Sun, PlantCD, Plants);
                            break;
                        }
                    }
                }
                if (sfnum[workline] < 2 && PlantCD[0] == 0 && Sun >= 50)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        if (Plants[workline][i] == 0)
                        {
                            player->PlacePlant(1, workline, i);
                            updateplants(1, workline, i, Sun, PlantCD, Plants);
                            break;
                        }
                    }
                }
                if (nutnum[workline] < 2 && PlantCD[3] == 0 && Sun >= 100&&Plants[workline][columns-1]!=4)
                {
                    if(zombieplace[workline]>5)
                    {
                        for (int i = columns - 1; i >= 5; i--)
                        {
                            if (Plants[workline][i] == 0)
                            {
                                player->PlacePlant(4, workline, i);
                                updateplants(4, workline, i, Sun, PlantCD, Plants);
                                break;
                            }
                        }
                    }
                    else {
                        int tmpp=zombieplace[workline];
                        if(Plants[workline][tmpp]==0&&sled[workline]==0&&gargantuar[workline]==0)
                        {
                                player->PlacePlant(4, workline, tmpp);
                                updateplants(4, workline, tmpp, Sun, PlantCD, Plants);
                        }
                    }
                }
                if (nutnum[workline] >= 2 && Sun >= 75 && PlantCD[0] == 0 && sfnum[workline] <= 2&&peanum[workline]>=2)
                {
                    for (int i = 0; i < columns; i++)
                    {
                        if (Plants[workline][i] == 4)
                        {
                            player->removePlant(workline, i);
                            player->PlacePlant(1, workline, i);
                            updateplants(1, workline, i, Sun, PlantCD, Plants);
                            break;
                        }
                    }
                }
                if (Sun >= 800 && sfnum[workline] >= 3 && PlantCD[1] == 0)
                {
                    for (int i = 0; i < columns; i++)
                    {
                        if (Plants[workline][i] == 1 || Plants[workline][i] == 0)
                        {
                            if (Plants[workline][i] == 1)
                                player->removePlant(workline, i);
                            player->PlacePlant(2, workline, i);
                            updateplants(2, workline, i, Sun, PlantCD, Plants);
                            break;
                        }
                    }
                }
                if (Sun >= 175 && PlantCD[5] == 0 && PlantCD[4] <= 5 && wgnum[workline] == 0)
                {
                    bool nplace = 0;
                    int nuuplace=10;
                    for (int i = columns - 1; i > 5; i--)
                    {
                        if (Plants[workline][i] == 4)
                        {
                            nplace = 1;
                            nuuplace=i;
                            break;
                        }
                    }
                    if(nplace==1&&nuuplace>=2)
                    {
                        for(int i=nuuplace-2;i>5;i--)
                        {
                            if(Plants[workline][i]==0||Plants[workline][i]==4)
                            {
                                if(Plants[workline][i]==4)
                                player->removePlant(workline,i);
                                player->PlacePlant(6,workline,i);
                                updateplants(6,workline,i,Sun,PlantCD,Plants);
                                break;
                            }
                        }
                    }
                }
            }
            int i = time % 3;

            int cur_row = selecteded[i];
            if (selecteded[i] == -1 || selecteded[i] == 6)
                return;
            if (peanum[cur_row] == 3 && Sun >= 500 && PlantCD[1] == 0)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (Plants[cur_row][j] == 0)
                    {
                        player->PlacePlant(2, workline, j);
                        updateplants(2, workline, j, Sun, PlantCD, Plants);
                        break;
                    }
                }
            }
            if (nutnum[cur_row] == 2 && Sun >= 75 && PlantCD[0] == 0)
            {
                for (int i = 0; i < columns; i++)
                {
                    if (Plants[cur_row][i] == 4)
                    {
                        player->removePlant(cur_row, i);
                        player->PlacePlant(1, cur_row, i);
                        updateplants(1, cur_row, i, Sun, PlantCD, Plants);
                        break;
                    }
                }
            }
        }
    }


    // ======================================================================
    // ======================================================================


    if (Type == 1) {
        //当前为僵尸方,采取若干策略
        // v4.7 04/24 11:59 TODO：前期的多线性性
        
        // 扫描当前植物情况
        int wandou[5] = {9999,9999,9999,9999,9999};
        int hanbin[5]={9999,9999,9999,9999,9999};
        int jianguo[5]={9999,9999,9999,9999,9999};
        int wogua[5]={9999,9999,9999,9999,9999};
        int xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        int all_plants[5] = { 9999,9999,9999,9999,9999 };
        double weighted_average_qianqi[5]={9999,9999,9999,9999,9999};
        double weighted_average_zhongqi_xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        double weighted_average_zhongqi[5] = { 9999,9999,9999,9999,9999 };
        bool need_attack[5]={1,1,1,1,1};
        for(int i = 0; i<rows; ++i){
           if(LeftLines[i] == 0 || Zombies[i][0][0] != -1){
               need_attack[i] = false;
           }
        }
        for (int i = 0; i < rows; ++i) {
           if (!need_attack[i]) continue;
           wandou[i] = 0;
           hanbin[i] = 0;
           jianguo[i] = 0;
           wogua[i] = 0;
           xiangrikui[i] = 0;
           all_plants[i] = 0;
        }
        for(int i = 0; i < rows; ++i){
           if(!need_attack[i]) continue;
           for(int j = 0; j<columns; ++j){
               if(Plants[i][j]==2) hanbin[i]++;
               if(Plants[i][j]==3) wandou[i]++;
               if(Plants[i][j]==4) jianguo[i]++;
               if(Plants[i][j]==6) wogua[i]++;
               if (Plants[i][j] == 1) xiangrikui[i]++;
               if (Plants[i][j] == 5) lajiao[i]++;
           }
           all_plants[i] = wandou[i] + hanbin[i] + jianguo[i] + wogua[i] + xiangrikui[i];
        }
        int min_wandou = 999, min_wandou_i=-1;
        int min_hanbin = 999, min_hanbin_i=-1;
        int min_jianguo = 999, min_jianguo_i=-1;
        int max_xiangrikui = 0, max_xiangrikui_i = -1;
        
        for(int i = 0; i<rows; ++i){
           if(!need_attack[i])  continue;
           if(wandou[i]<min_wandou){
               min_wandou = wandou[i];
               min_wandou_i = i;
           }
           if (hanbin[i] < min_hanbin) {
               min_hanbin = hanbin[i];
               min_hanbin_i = i;
           }
           if (jianguo[i] < min_jianguo) {
               min_jianguo = jianguo[i];
               min_jianguo_i = i;
           }
           if (xiangrikui[i] >= max_xiangrikui) {
               max_xiangrikui = xiangrikui[i];
               max_xiangrikui_i = i;
           }
        }

        // 检查当前僵尸状况
        int zombies[5] = { 0,0,0,0,0 };
        int tietong[5] = { 0,0,0,0,0 };
        int chenggan[5] = { 0,0,0,0,0 };
        int xueqiao[5] = { 0,0,0,0,0 };
        int jiagang[5] = { 0,0,0,0,0 };
        double all_zombies[5] = { 0,0,0,0,0 };
        for (int i = 0; i < rows; ++i) {
           if (!need_attack[i]) continue;
           for (int j = 0; j < columns; ++j) {
               for (int k = 0; Zombies[i][j][k] != -1; ++k) {
                   if (Zombies[i][j][k] == 1) zombies[i]++;
                   if (Zombies[i][j][k] == 2) tietong[i]++;
                   if (Zombies[i][j][k] == 3) chenggan[i]++;
                   if (Zombies[i][j][k] == 4) {
                       xueqiao[i]++; all_xueqiao[i]++;
                   }
                   if (Zombies[i][j][k] == 5) jiagang[i]++;
               }
           }
           all_zombies[i] = 0.2 * zombies[i] + 0.5 * tietong[i] + 0.3 * chenggan[i] + 0.6 * xueqiao[i] + 1.0 * jiagang[i];
        }

        // 对场上情况将进行估计
        double min_weighted_average_qianqi = 999;
        int min_weighted_average_qianqi_i = -1;
        double min_weighted_average_zhongqi_xiangrikui = 999;
        int min_weighted_average_zhongqi_xiangrikui_i = -1;
        double min_weighted_average_zhongqi = 999;
        int min_weighted_average_zhongqi_i = -1;
        for (int i = 0; i < rows; ++i) {
           // warning：当前估值函数，以及后续采用的阈值为大致估计，需结合实战回访重新制定
           weighted_average_qianqi[i] = 1.0 * wogua[i] + 0.6 * hanbin[i] + 0.3 * jianguo[i] + 0.1 * wandou[i] + 0.1*lajiao[i];
           if (all_plants[i] == 0 && all_zombies[i] > 0) weighted_average_qianqi[i] = 9999;
           if (weighted_average_qianqi[i] <= min_weighted_average_qianqi) {
               min_weighted_average_qianqi = weighted_average_qianqi[i];
               min_weighted_average_qianqi_i = i;
           }
           weighted_average_zhongqi_xiangrikui[i] = 0.3 * wogua[i] + 0.7 * hanbin[i] + 0.3 * jianguo[i] + 0.7 * xiangrikui[i]+0.15*lajiao[i];
           if (weighted_average_zhongqi_xiangrikui[i] < min_weighted_average_zhongqi_xiangrikui) {
               min_weighted_average_zhongqi_xiangrikui = weighted_average_zhongqi_xiangrikui[i];
               min_weighted_average_zhongqi_xiangrikui_i = i;
           }
           weighted_average_zhongqi[i] = 0.3 * wogua[i] + 1.0 * hanbin[i] + 0.3 * jianguo[i]+0.15*lajiao[i];
           if (weighted_average_zhongqi[i] < min_weighted_average_zhongqi) {
               min_weighted_average_zhongqi = weighted_average_zhongqi[i];
               min_weighted_average_zhongqi_i = i;
           }
        }
        
        int target = -1;
        
        // 前期策略（单线程版本，warning：需升级至双线程版本）  回合<=200 或者 威胁<0.4
        target = min_weighted_average_qianqi_i;
        if (target == -1) return;
        if ((time <= 200 && weighted_average_qianqi[target] < 0.8) || (time > 200 && weighted_average_qianqi[target] < 0.4)){
            if (Zombies[target][columns - 1][0] == -1) { // 根据场上情况放置僵尸，以攻击力植物为导向，针对主要进攻行
                int flag_i = -1;
                for (int i = 0; i < rows; ++i) {
                    if (all_plants[i] == (xiangrikui[i] + wogua[i]) && all_plants[target] >0) {
                        target = i;
                        flag_i = i;
                        break;
                    }
                }
                if (flag_i != -1) {
                    if(all_zombies[target] <= wogua[target] && Zombies[target][columns-1][0]==-1)player->PlaceZombie(1, target);
                }
                else {
                    if (weighted_average_qianqi[target] == 0 && all_zombies[target] == 0) {
                        player->PlaceZombie(1, target);
                    }
                    else {
                        if (hanbin[target] == 0) {
                            if (jianguo[target] > 0 && hanbin[target] == 0 && weighted_average_qianqi[target] < 0.5) player->PlaceZombie(3, target);
                            if ((2 * tietong[target] + zombies[target] + 1 * chenggan[target]) <= wandou[target]) {
                                if ((weighted_average_qianqi[target] + 0.6) > all_zombies[target]) {
                                    player->PlaceZombie(2, target);
                                }
                                else {
                                    player->PlaceZombie(1, target);
                                }
                            }
                        }
                        else {
                            if ((2 * tietong[target] + zombies[target]) <= (hanbin[target] + 2 + 2 * jianguo[target])) {
                                if (PlantCD[1] == 0) {
                                    player->PlaceZombie(2, target);
                                }
                            }
                        }
                    }
                }
            }
           
        }


        if(weighted_average_qianqi[target] > 0.4){ // 威胁>0.4

            // 中期策略（400-499（可能）空档期，用以积累阳光)  time 200-800
            if(((time>200 && time <= 800) && !(time>400 && time <= 499 && Sun<500)) || (time<=200 && weighted_average_qianqi[target]>0.8)){
                target = min_weighted_average_zhongqi_i;
                if (weighted_average_qianqi[target] < 0.6) { // 风险较小的情况下用普通僵尸/铁桶僵尸尝试攻击，沿用前期策略
                    if (Zombies[target][columns - 1][0] == -1) { // 根据场上情况放置僵尸，以攻击力植物为导向，针对主要进攻行
                        if (weighted_average_qianqi[target] == 0 && all_zombies[target] == 0) {
                            if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(1, target);
                        }
                        else {
                            if (hanbin[target] == 0) {
                                if (jianguo[target] > 0) 
                                    if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(3, target);
                                if ((2 * tietong[target] + zombies[target] + 1 * chenggan[target]) <= wandou[target]) {
                                    if ((weighted_average_qianqi[target]+0.6) > all_zombies[target] ) {
                                        if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(2, target);
                                    }
                                    else {
                                        if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(1, target);
                                    }
                                }
                            }
                            else {
                                if ((2 * tietong[target] + zombies[target]) <= (hanbin[target] + 2 + 2 * jianguo[target])) {
                                    if (PlantCD[1] == 0) {
                                        if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(2, target);
                                    }
                                }
                            }
                        }
                    }
                } 
                else { // 风险较大的情况
                    /*if (Plants[target][columns - 1] == 6 || Plants[target][columns - 2] == 6) {
                        if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(3, target);
                    }*/
                    if (hanbin[target] == 0) {
                        if (weighted_average_zhongqi[target] <= 1) {
                            if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(5, target);
                        }
                        else {
                            if (Sun >= 600 && PlantCD[3] == 0 && PlantCD[4] == 0) {
                                if (Zombies[target][columns - 1][0] == -1) {
                                    player->PlaceZombie(4, target);
                                    offend = time;
                                }
                            }
                            if (PlantCD[3] >= 4 && Zombies[target][9][0] == -1) {
                                if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                    if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(5, target);
                            }
                        }
                        
                    }
                    else {
                        if (Sun >= 600 && PlantCD[3] == 0 && PlantCD[4] == 0) {
                            if (Zombies[target][columns - 1][0] == -1) {
                                player->PlaceZombie(4, target);
                                offend = time;
                            }
                        }
                        if (PlantCD[3] >= 4 && Zombies[target][9][0] == -1) {
                            if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(5, target);
                        }
                    }
                }
            }
            bool too_strong = false;
            // 中后期 800 - 1200 回合 以及 500 - 599回合（向日葵为导向的攻击模式）
            target = min_weighted_average_zhongqi_xiangrikui_i;
            if (target == -1) return;
            if ((time > 800 && time <= 1200) || (time>500 && time <=599)) {
               // std::cout << time << "\n";
                if (weighted_average_zhongqi[target] > 3.5) {
                    too_strong = true;
                }
                else {
                    for (int j = 0; j < columns; ++j) {
                        if (Plants[target][j] == 5 || Plants[target][j] == 6) {
                            detect_guaorjiao[target] = true;
                            break;
                        }
                    }
                    if (weighted_average_qianqi[target] < 0.6) { // 风险较小的情况下用普通僵尸/铁桶僵尸尝试攻击，沿用前期策略
                        if (Zombies[target][columns - 1][0] == -1) { // 根据场上情况放置僵尸，以攻击力植物为导向，针对主要进攻行
                            if (weighted_average_qianqi[target] == 0 && all_zombies[target] == 0) {
                                player->PlaceZombie(1, target);
                            }
                            else {
                                if (hanbin[target] == 0) {
                                    if (jianguo[target] > 0) player->PlaceZombie(3, target);
                                    if ((2 * tietong[target] + zombies[target] + 1 * chenggan[target]) <= wandou[target]) {
                                        if (weighted_average_qianqi[target] > all_zombies[target]) {
                                            player->PlaceZombie(2, target);
                                        }
                                        else {
                                            player->PlaceZombie(1, target);
                                        }
                                    }
                                }
                                else {
                                    if ((2 * tietong[target] + zombies[target]) <= (hanbin[target] + 2 + 2 * jianguo[target])) {
                                        if (PlantCD[1] == 0) {
                                            player->PlaceZombie(2, target);
                                        }
                                        else {
                                            player->PlaceZombie(1, target);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else { // 风险较大的情况
                        if (Plants[target][columns - 1] == 6 || Plants[target][columns - 2] == 6) {
                            if(hanbin[target] == 0)
                            if (Zombies[target][columns - 1][0] == -1) {
                                player->PlaceZombie(3, target);
                            }
                        }
                        else {
                            if (tietong[target] == 0 && (offend - time) > 15)
                                if (Zombies[target][columns - 1][0] == -1) {
                                    player->PlaceZombie(2, target);
                                    offend = time;
                                }
                            if (tietong[target] > 0 && (offend - time) > 2)
                                if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(3, target);
                        }
                        if (weighted_average_zhongqi[target] <= 0.8) {
                            if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7)) 
                                if (Zombies[target][columns - 1][0] == -1 )player->PlaceZombie(5, target);
                        }
                        else {
                            if (Sun >= 600 && PlantCD[3] == 0 && PlantCD[4] == 0) {
                                if (Zombies[target][columns - 1][0] == -1 )
                                {
                                    player->PlaceZombie(4, target);
                                    offend = time;
                                }
                            }
                            if (PlantCD[3] >= 3 && Zombies[target][9][0] == -1) {
                                if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                    if (Zombies[target][columns - 1][0] == -1) {
                                        player->PlaceZombie(5, target);
                                    }
                                if (Zombies[target][columns - 1][0] == -1 && hanbin[target] < 3)player->PlaceZombie(2, target);
                            }
                        }
                    }
                }
            }
            // 中后期 time>1200（寒冰射手为导向的攻击模式）
            target = min_hanbin_i;
            if (too_strong) target = min_weighted_average_zhongqi_xiangrikui_i;
            if (target == -1) return;
            if (time > 1200 || too_strong) {
                if (hanbin[target] > 4) {
                    if(time >=1500 && time < 1800)
                        if (Sun >= 800 || (Sun<800&&PlantCD[1] != 0)) {
                            if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(2,target);
                            if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(3, target);
                            if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(4, target);
                            if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(5, target);
                        }
                }
                else {
                    for (int j = 0; j < columns; ++j) {
                        if (Plants[target][j] == 5 || Plants[target][j] == 6) {
                            detect_guaorjiao[target] = true;
                            break;
                        }
                    }
                    if (weighted_average_qianqi[target] < 0.6) { // 风险较小的情况下用普通僵尸/铁桶僵尸尝试攻击，沿用前期策略
                        if (Zombies[target][columns - 1][0] == -1) { // 根据场上情况放置僵尸，以攻击力植物为导向，针对主要进攻行
                            if (weighted_average_qianqi[target] == 0 && all_zombies[target] == 0) {
                                player->PlaceZombie(1, target);
                            }
                            else {
                                if (hanbin[target] == 0) {
                                    if (jianguo[target] > 0) player->PlaceZombie(3, target);
                                    if ((2 * tietong[target] + zombies[target] + 1 * chenggan[target]) <= wandou[target]) {
                                        if (weighted_average_qianqi[target] > all_zombies[target]) {
                                            player->PlaceZombie(2, target);
                                        }
                                        else {
                                            player->PlaceZombie(1, target);
                                        }
                                    }
                                }
                                else {
                                    if ((2 * tietong[target] + zombies[target]) <= (hanbin[target] + 2 + 2 * jianguo[target])) {
                                        if (PlantCD[1] == 0) {
                                            player->PlaceZombie(2, target);
                                        }
                                        else {
                                            player->PlaceZombie(1, target);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else { // 风险较大的情况
                        if (Plants[target][columns - 1] == 6 ) {
                            if (Zombies[target][columns - 1][0] == -1) {
                                player->PlaceZombie(3, target);
                            }
                        }
                        else if(Plants[target][columns-2] == 6) {
                            if (tietong[target] == 0 && (offend - time) > 15)
                                if (Zombies[target][columns - 1][0] == -1) {
                                    player->PlaceZombie(2, target);
                                    offend = time;
                                }
                            if (tietong[target] > 0 && (offend - time) > 2)
                                if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(3, target);
                        }
                        if (weighted_average_zhongqi[target] <= 0.8) {
                            if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                if (Zombies[target][columns - 1][0] == -1 )player->PlaceZombie(5, target);
                        }
                        else {
                            if (Sun >= 600 && PlantCD[3] == 0 && PlantCD[4] == 0 ) {
                                if (Plants[target][columns - 1] != 4 && Plants[target][columns - 2] != 4)player->PlaceZombie(2, target);
                                if (Zombies[target][columns - 1][0] == -1)  {
                                    player->PlaceZombie(4, target);
                                    offend = time;
                                }
                            }
                            if (PlantCD[3] >= 3 && Zombies[target][9][0] == -1) {
                                if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))
                                    if (Zombies[target][columns - 1][0] == -1)player->PlaceZombie(5, target);
                                if (Zombies[target][columns - 1][0] == -1 && hanbin[target] < 3)player->PlaceZombie(2, target);
                            }
                        }
                    }
                }
            }
        }    
    }
}
void updateplants(int type,int x,int y,int& a,int *b,int **c)
{
    switch(type)
    {
        case 0:c[x][y]=0;break;
        case 1:a-=50;b[0]=10;c[x][y]=1;break;
        case 2:a-=400;b[1]=30;c[x][y]=2;break;
        case 3:a-=100;b[2]=10;c[x][y]=3;break;
        case 4:a-=50;b[3]=40;c[x][y]=4;break;
        case 5:a-=125;b[4]=60;c[x][y]=5;break;
        case 6:a-=50;b[5]-=60;c[x][y]=6;break;
        default:break;
    }
}

