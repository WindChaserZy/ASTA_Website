#include "ai.h"
#include <iostream>
#include <stdlib.h>
#include <cstring>
#include <vector>
#include <queue>
#include <time.h>

using namespace std;
#define ZOMBIE_KIND 5
#define PLANT_KIND 6
#define TOTAL_TIME 2000
#define COLUMN 10
#define ROW 5
enum ZombieType
{
    NOZOMBIE = 0,
    NORMAL,
    BUCKET,
    POLEVAULT,
    SLED,
    GARGANTUAR
};
void player_ai(IPlayer *player)
{
    int Type = player->Camp->getCurrentType();
    //植 物 种 类 2

    if (Type == 0)
    { //植物方
    }
    if (Type == 1)
    {
        //僵尸方
        int BrokenLinesScore = player->getBrokenLinesScore();
        int KillPlantsScore = player->getKillPlantsScore();
        int Score = player->getScore();
        int time0 = player->getTime();
        int rows = player->Camp->getRows();
        int columns = player->Camp->getColumns();
        int *PlaceCD = player->Camp->getPlantCD();
        int **Plants = player->Camp->getCurrentPlants();
        int ***Zombies = player->Camp->getCurrentZombies();
        int *LeftLines = player->Camp->getLeftLines();
        int Sun = player->Camp->getSun();

        srand(player->getTime() + time(NULL));
        double possibility[7] = {0, 0, 0, 0, 0, 0};
        int now_step = time0;
        possibility[0] = 0.05 + now_step / 4000.0;
        possibility[1] = 0.3 - (now_step / 16000.0) * (rand() / 65535.0) + possibility[0];
        possibility[2] = 0.07 - (now_step / 16000.0) + possibility[1];
        possibility[3] = 0.13 - (now_step / 16000.0) + possibility[2];
        possibility[4] = 0.15 - (now_step / 16000.0) + possibility[3];
        possibility[5] = 0.15 - (now_step / 50000.0) + possibility[4];
        possibility[6] = 1;
        double plant_cost[7] = {2, 2, -8, -6, -15, -10, 0};
        double score[5] = {0};
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                score[i] += plant_cost[Plants[i][j]];
            }
        }
        int row[5] = {0, 1, 2, 3, 4};
        for (int i = 0; i < 4; i++)
        {
            if(LeftLines[i]==0){
                score[i]=-10000;
                break;
            }
            for (int j = 0; j < 4; j++)
                if (score[j] < score[j + 1])
                {
                    double swap = score[j];
                    score[j] = score[j + 1];
                    score[j + 1] = swap;
                    int row_swap = row[j];
                    row[j] = row[j + 1];
                    row[j + 1] = row_swap;
                }
        }
        double random = (rand() / 65535.0) * 2;
        // for (int i = 0; i < 7; i++)
        // {
        //     printf("%lf ", possibility[i]);
        // }
        if (player->getTime() < 290)
        {
            if (random > possibility[0] && random < possibility[1])
            {
                player->PlaceZombie(NORMAL, row[rand() % 3]);
            }
            if (random > possibility[1] && random < possibility[2])
            {
                player->PlaceZombie(POLEVAULT, row[rand() % 2]);
            }
            if (random > possibility[2] && random < possibility[3])
            {
                player->PlaceZombie(BUCKET, row[rand() % 5]);
            }
        }
        if (time0 > 1496)
        {
            if (random > possibility[1] && random < possibility[2])
            {
                player->PlaceZombie(NORMAL, rand() % 5);
            }
            if (random > possibility[4] && random < possibility[5])
            {
                player->PlaceZombie(SLED, rand() % 5);
            }
            if (random > possibility[5] && random < possibility[6])
            {
                player->PlaceZombie(GARGANTUAR, rand() % 5);
            }
        }
    }
}