#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
// ֲ�����
static int phealth[10] = { 0,300,300,300,300,300,4000 };
static int pcost[10] = { 0,50,100,400,125,50,50 };
static int pcd[10] = { 0,10,10,30,60,60,40 };

// ��ʬ����
static int zhealth[10] = { 0,270,820,200,1600,3000 };
static int zhealth0[10] = { 0,270,820,200,1600,3000 };
static int zcost[10] = { 0,50,125,125,300,300 };
static int zattack[10] = { 0,75,75,75,8000,8000 };
static int zattack0[10] = { 0,75,75,75,8000,8000 };
static double zspeed[10] = { 0,0.2,0.2,0.4,0.33333,0.2 };
static int zcd[10] = { 0,15,20,20,25,25 };

struct plant {
    int type; // 1-6
    int health;
    int state; // �㶹0-2 ����0-3��0ʱ�������ã�
};

struct zombie {
    int type; // 1-5
    int health;
    double x;
    int debuff; // 0-10
    int state; // �Ÿ�0 1��0ʱδ����
};

//ȫ�ּ�¼����

static plant p[5][10];
static zombie z[5][10][100];

//ģ�⺯��

static int work(plant* a,zombie b[][100],int Step) {
    int result=10;
    for (int i = 0; i < 10; i++) {    
        if (b[i][0].type) {
            result = i;
            break;
        }
    }
    for (int k = 1; k <= Step; k++) {
        for (int i = 0; i < 10; i++) {
            if (a[i].type == 6) {
                if (b[i][0].type) {
                    for (int j = 0; j < 100; j++) {
                        if (!b[i][j].type) break;
                        b[i][j].health -= 1800;
                    }
                    a[i].type = 0;
                }  
            }
            if (a[i].type == 5) {
                for (int m = 0; m < 10; m++) {
                    for (int j = 0; j < 100; j++) {
                        if (!b[m][j].type) break;
                        b[m][j].health -= 1800;
                    }
                }
                a[i].type = 0;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                for (int j = 0; j < p; j++) {
                    if (b[i][j].health <= 0) {
                        b[i][j].type = 0;
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j+1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                int p2 = 0;
                if(i) while (b[i-1][p2].type) p2++;
                if (a[i].type) {
                    for (int j = 0; j < p; j++) {
                        if (b[i][j].debuff) a[i].health -= zattack[b[i][j].type] / 2;
                        else a[i].health -= zattack[b[i][j].type];
                        if (b[i][j].debuff) b[i][j].debuff--;
                        if (b[i][j].type == 3&& b[i][j].state == 0) {
                            if (!i) return -1;
                            else {
                                b[i][j].state = 1;
                                b[i][j].x -= 1;
                                b[i - 1][p2] = b[i][j];
                                p2++;
                            }
                            b[i][j].type = 0;
                        }
                    }
                }
                else {
                    for (int j = 0; j < p; j++) {
                        double Speed = zspeed[b[i][j].type];
                        if (b[i][j].type == 3 && b[i][j].state == 1) Speed = 0.22222;
                        if (b[i][j].type == 4 && i < 6) Speed = 0.125;
                        if (b[i][j].type == 4 && i >= 6) Speed = 0.06944*i-0.29164;
                        if (b[i][j].debuff) b[i][j].x -= Speed / 2;
                        else b[i][j].x -= Speed;
                        if (b[i][j].debuff) b[i][j].debuff--;
                        if (b[i][j].x<0) return -1;
                        if (((int)b[i][j].x) < i) {
                            b[i - 1][p2] = b[i][j];
                            p2++;
                            b[i][j].type = 0;
                        }
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j + 1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type&& i<result) {
                result = i;
                break;
            }
        }
        for (int i = 0; i < 10; i++) if (a[i].health <= 0) a[i].type = 0;
        for (int i = 0; i < 10; i++) {
            if (a[i].type == 2) {
                if (a[i].state == 0) {
                    for (int j = i; j < 10; j++) {
                        if (b[j][0].type) {
                            double minn = 10;
                            int temp=0;
                            int p = 0;
                            while (b[j][p].type) p++;
                            for (int m = 0; m < p; m++) {
                                if (b[j][m].x < minn) {
                                    minn = b[j][m].x;
                                    temp = m;
                                }
                            }
                            b[j][temp].health -= 60;
                            b[j][temp].debuff = 10;
                            break;
                        }
                    }
                }
                a[i].state = (a[i].state + 1) % 4;
            }
            if (a[i].type == 3) {
                if (a[i].state == 0) {
                    for (int j = i; j < 10; j++) {
                        if (b[j][0].type) {
                            double minn = 10;
                            int temp = 0;
                            int p = 0;
                            while (b[j][p].type) p++;
                            for (int m = 0; m < p; m++) {
                                if (b[j][m].x < minn) {
                                    minn = b[j][m].x;
                                    temp = m;
                                }
                            }
                            b[j][temp].health -= 20;
                            break;
                        }
                    }
                }
                a[i].state = (a[i].state + 1) % 3;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                for (int j = 0; j < p; j++) {
                    if (b[i][j].health <= 0) {
                        b[i][j].type = 0;
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j + 1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

void player_ai(IPlayer* player) {
    
    int Type = player->Camp->getCurrentType();

    if (Type == 0) {
        int NotBrokenLinesNum = player->getNotBrokenLines();
        int KillZombiesScore = player->getKillZombiesScore();
        int time = player->getTime();
        int* LeftLines = player->Camp->getLeftLines();
        int Sun = player->Camp->getSun();
        int* CD = player->Camp->getPlantCD();
        int** Plants = player->Camp->getCurrentPlants();
        int*** Zombies = player->Camp->getCurrentZombies();

        // ����ȫ������

        if (time > 1000) {
            for (int i = 1; i <= 5; i++) {
                zhealth[i] = (int)(zhealth0[i] * (time / 1000.0));
                zattack[i] = (int)(zattack0[i] * (time / 1000.0));
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                work(p[i], z[i], 1);
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                int flag = 0;
                for (int j = 0; j < 10; j++) {
                    if (Zombies[i][j][0] != -1) flag = 1;
                    if(p[i][j].type && !Plants[i][j]) p[i][j].type = 0;
                    else if (p[i][j].type != Plants[i][j]) {
                        p[i][j].type = Plants[i][j];
                        p[i][j].health = phealth[Plants[i][j]];
                        p[i][j].state = 0;
                    }
                }
                if (!flag) for (int j = 0; j < 10; j++) {
                    for (int r = 0; r < 100; r++) {
                        if (!z[i][j][r].type) break;
                        z[i][j][r].type = 0;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                if (Zombies[i][9][0] != -1) {
                    for (int m = 1; m <= 5; m++) {
                        int sum1 = 0, sum2 = 0;
                        for (int r = 0; Zombies[i][9][r] != -1; r++) {
                            if (Zombies[i][9][r] == m) sum1++;
                        }
                        for (int r = 0; z[i][9][r].type; r++) {
                            if (z[i][9][r].type == m) sum2++;
                        }
                        if (sum1 > sum2) {
                            int p = 0;
                            while (z[i][9][p].type) p++;
                            for (int t = 1; t <= sum1 - sum2; t++) {
                                z[i][9][p].type = m;
                                z[i][9][p].health = zhealth[m];
                                z[i][9][p].debuff = 0;
                                z[i][9][p].x = 10;
                                z[i][9][p].state = 0;
                                p++;
                            }
                        }
                    }
                }
            }
        }

        // Movement

        plant p1[5][10] = { 0 };
        zombie z1[5][10][100] = { 0 };
        int result[5] = { 0 };
        int front[5] = { 0 };
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                for (int j = 0; j < 10; j++) p1[i][j] = p[i][j];
                for (int j = 0; j < 10; j++) {
                    for (int r = 0; r < 100; r++) {
                        if (!z[i][j][r].type) break;
                        z1[i][j][r] = z[i][j][r];
                    }
                }
                result[i] = work(p1[i], z1[i], 200);
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type) front[i] = j;
                }
            }
        }
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                if (result[i] < front[i]) sum++;
            }
        }
        if (sum == 0) {
            int flag1 = 1;
            for (int i = 0; i < 5; i++) {
                if (result[i] != 10) flag1 = 0;
            }
            int temp = 0;
            if (flag1) {
                int minn = 10;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3|| p[i][j].type == 4) s++;
                        if (p[i][j].type == 2) s+=2;
                    }
                    if (LeftLines[i] && s < minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            else {
                int minn = 10;
                for (int i = 0; i < 5; i++) {
                    if (LeftLines[i] && result[i] < minn) {
                        minn = result[i];
                        temp = i;
                    }
                }
            }
            if (Sun >= 525 && !CD[2] && time > 100) { //���㶹
                for (int j = 0; j < 6; j++) {
                    if (p[temp][j].type != 2&& j!=1) {
                        if(p[temp][j].type) player->removePlant(temp, j);
                        player->PlacePlant(2, temp, j);
                        break;
                    }
                }
            }
            if (Sun >= 50 && !CD[1]) { //���տ�
                for (int i = 4; i >=0 ; i--) {
                    if (result[i] >= 8 && p[i][1].type != 1 && time > 30) {
                        player->removePlant(i, 1);
                        player->PlacePlant(1, i, 1);
                        break;
                    }
                    if (result[i] >= 2 && !p[i][1].type) player->PlacePlant(1, i, 1);
                }
                for (int i = 4; i >= 0; i--) {
                    if (result[i] >= 3 && !p[i][2].type) player->PlacePlant(1, i, 2);
                }
            }
            if (Sun >= 225 && !CD[3] && time>60) { //�㶹
                for (int j = 0; j < 7; j++) {
                    if (!p[temp][j].type && j != 1) {
                        player->PlacePlant(3, temp, j);
                        break;
                    }
                }
            }
            if (Sun >= 225 && !CD[4] && time > 100) { //���
                for (int j = 6; j < 8; j++) {
                    if (!p[temp][j].type) {
                        player->PlacePlant(4, temp, j);
                        break;
                    }
                }
            }
        }
        else {
            for (int i = 0; i < 5; i++) {
                int temp = 0;
                int minn = 10;
                for (int i = 0; i < 5; i++) {
                    if (LeftLines[i] && result[i] < minn) {
                        minn = result[i];
                        temp = i;
                    }
                }
                if (result[temp] >= front[temp]) break;
                plant p2[10] = { 0 };
                if (Sun >= 100 && !CD[3]) { //�㶹
                    plant p3[10] = { 0 };
                    zombie z3[10][100] = { 0 };
                    for (int j = 0; j < 7; j++) {
                        if (!p2[j].type) {
                            player->PlacePlant(3, temp, j);
                            p2[j].type = 3;
                            p2[j].health = phealth[p2[j].type];
                            p2[j].state = 0;
                            break;
                        }
                    }
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    result[temp] = work(p3, z3, 200);
                    if (result[temp] >= front[temp]) continue;
                }
                if (Sun >= 50 && !CD[4]) { //���
                    plant p3[10] = { 0 };
                    zombie z3[10][100] = { 0 };
                    int f = 6;
                    for (int j = 0; j < 7; j++) {
                        if (z[temp][j][0].type) {
                            f = j;
                            break;
                        }
                    }
                    if (!p2[f].type) {
                        player->PlacePlant(4, temp, f);
                        p2[f].type = 4;
                        p2[f].health = phealth[p2[f].type];
                        p2[f].state = 0;
                    }
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    result[temp] = work(p3, z3, 200);
                    if (result[temp] >= front[temp]) continue;
                }
                if (Sun >= 575 && !CD[2]) { //���㶹
                    plant p3[10] = { 0 };
                    zombie z3[10][100] = { 0 };
                    for (int j = 0; j < 5; j++) {
                        if (p2[j].type!=2) {
                            player->removePlant(temp, j);
                            player->PlacePlant(2, temp, j);
                            p2[j].type = 2;
                            p2[j].health = phealth[p2[j].type];
                            p2[j].state = 0;
                            break;
                        }
                    }
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    result[temp] = work(p3, z3, 200);
                    if (result[temp] >= front[temp]) continue;
                }
                if (Sun >= 50 && !CD[6]) { //����
                    plant p3[10] = { 0 };
                    zombie z3[10][100] = { 0 };
                    int maxn = 0, te=0;
                    for (int j = 0; j < 10; j++) {
                        int s = 0;
                        for (int r = 0; r < 100; r++) {
                            if (z[temp][j][r].type) s += z[temp][j][r].health;
                        }
                        if (s > maxn) maxn = s, te = j;
                    }
                    
                    player->PlacePlant(6, temp, te);
                    p2[te].type = 6;
                    p2[te].health = phealth[p2[te].type];
                    p2[te].state = 0;
                    
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    result[temp] = work(p3, z3, 200);
                    if (result[temp] >= front[temp]) continue;
                }
                if (Sun >= 125 && !CD[5]) { //����
                    plant p3[10] = { 0 };
                    zombie z3[10][100] = { 0 };
                    for (int j = 0; j < 10; j++) {
                        if (!p2[j].type) {
                            player->PlacePlant(5, temp, j);
                            p2[j].type = 5;
                            p2[j].health = phealth[p2[j].type];
                            p2[j].state = 0;
                        }
                    }
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    result[temp] = work(p3, z3, 200);
                    if (result[temp] >= front[temp]) continue;
                }
            }
        }
    }

    if (Type == 1) {
        int BrokenLinesScore = player->getBrokenLinesScore();
        int KillPlantsScore = player->getKillPlantsScore();
        int time = player->getTime();
        int* LeftLines = player->Camp->getLeftLines();
        int Sun = player->Camp->getSun();
        int* CD = player->Camp->getPlantCD();
        int** Plants = player->Camp->getCurrentPlants();
        int*** Zombies = player->Camp->getCurrentZombies();

        // ����ȫ������

        if (time > 1000) {
            for (int i = 1; i <= 5; i++) {
                zhealth[i] = (int)(zhealth0[i] * (time / 1000.0));
                zattack[i] = (int)(zattack0[i] * (time / 1000.0));
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                work(p[i], z[i], 1);
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                int flag = 0;
                for (int j = 0; j < 10; j++) {
                    if (Zombies[i][j][0] != -1) flag = 1;
                    if(p[i][j].type && !Plants[i][j]) p[i][j].type = 0;
                    else if (p[i][j].type != Plants[i][j]) {
                        p[i][j].type = Plants[i][j];
                        p[i][j].health = phealth[Plants[i][j]];
                        p[i][j].state = 0;
                    }
                }
                if (!flag) for (int j = 0; j < 10; j++) {
                    for (int r = 0; r < 100; r++) {
                        if (!z[i][j][r].type) break;
                        z[i][j][r].type = 0;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                if (Zombies[i][9][0] != -1) {
                    for (int m = 1; m <= 5; m++) {
                        int sum1 = 0, sum2 = 0;
                        for (int r = 0; Zombies[i][9][r] != -1; r++) {
                            if (Zombies[i][9][r] == m) sum1++;
                        }
                        for (int r = 0; z[i][9][r].type; r++) {
                            if (z[i][9][r].type == m) sum2++;
                        }
                        if (sum1 > sum2) {
                            int p = 0;
                            while (z[i][9][p].type) p++;
                            for (int t = 1; t <= sum1 - sum2; t++) {
                                z[i][9][p].type = m;
                                z[i][9][p].health = zhealth[m];
                                z[i][9][p].debuff = 0;
                                z[i][9][p].x = 10;
                                z[i][9][p].state = 0;
                                p++;
                            }
                        }
                    }
                }
            }
        }
        
        // Movement
        if (time == 491) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(4, temp);
            player->PlaceZombie(3, temp);
        }
        if (time == 501) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(2, temp);
        }
        if (time == 991) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
        }
        if (time == 1001) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(4, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1491) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(4, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
        }
        if (time == 1501) {
            int temp = 0;
            int minn = 10;
            for (int i = 0; i < 5; i++) {
                int s = 0;
                for (int j = 0; j < 10; j++) {
                    if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                    if (p[i][j].type == 2) s += 3;
                }
                if (LeftLines[i] && s < minn) {
                    minn = s;
                    temp = i;
                }
            }
            player->PlaceZombie(5, temp);
            player->PlaceZombie(4, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
    }
}
