#include "ai.h"
#include<iostream>

bool beginPlace[5] = { false,false,false,false,false };
int totalFlowerNum = 0;
int totalPeaNum = 0;
int totalNutNum = 0;
int totalPumpkinNum = 0;

int nutRow = -1;
int pumpkinRow = -1;

int rowBegin[5] = { 0 };

bool isPea = false;
bool isNut = false;
bool isPumpkin = false;
bool isFlower = false;

bool sameRow = false;

int place1[5] = { 0 };

int currentTime1 = 0;

int status = 0;

void player_ai(IPlayer* player)
{
    int rows = player->Camp->getRows();//获取当前行数
    int columns = player->Camp->getColumns();//获取当前列数
    int* leftLines = player->Camp->getLeftLines();
    int leftRows = 0;
    int totalIceNum = 0;
    for (int i = 0; i < rows; i++)
    {
        if (leftLines[i] != 0)
        {
            leftRows += 1;
        }
    }
#pragma region GameStatus
    int plantNum = 0;
#pragma endregion

#pragma region Interface

    int time = player->getTime();//获得当前回合数
    int type = player->Camp->getCurrentType();//获得当前玩家类型

#pragma endregion

    int** plants = player->Camp->getCurrentPlants();//当前植物情况二维数组
    int*** zombies = player->Camp->getCurrentZombies();//当前僵尸情况三维数组

    //以下声明了很多个一维数组，用以计算某一行每种植物或僵尸数量，进而寻求对某一行的最优解
    int rowPlantNum[5] = { 0 };//植物总数
    int rowZombieNum[5] = { 0 };//僵尸总数

    int rowPeaNum[5] = { 0 };//豌豆射手总数

    int rowIceNum[5] = { 0 };//冰豌豆射手行数
    int columnIceNum[10] = { 0 };//冰豌豆射手列数

    int rowPumpkinNum[5] = { 0 };//倭瓜行数
    int columnPumpkinNum[10] = { 0 };//倭瓜列数

    int rowNutNum[5] = { 0 };//坚果总数

    int rowFlowerNum[5] = { 0 };//向日葵行数
    int columnFlowerNum[10] = { 0 };//向日葵列数

    int totalFlowerNum = 0;//向日葵总数

    bool plantIce = false;


    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            if (plants[i][j] != 0)
            {
                rowPlantNum[i] += 1;
                plantNum++;
            }
            if (plants[i][j] == 1)//向日葵
            {
                rowFlowerNum[i] += 1;
                totalFlowerNum++;
            }
            if (plants[i][j] == 2)//冰豌豆
            {
                rowIceNum[i] += 1;
                totalIceNum += 1;
            }
            if (plants[i][j] == 3)//豌豆
            {
                rowPeaNum[i] += 1;
                totalPeaNum += 1;
            }
            if (plants[i][j] == 6)//火爆辣椒
            {
                rowPumpkinNum[i] += 1;
                totalPumpkinNum += 1;
            }
            if (plants[i][j] == 4)//坚果
            {
                rowNutNum[i] += 1;
                totalNutNum += 1;
            }
        }
    }
    //先列后行遍历
    for (int i = 0; i < columns; i++)
    {
        for (int j = 0; j < rows; j++)
        {
            if (plants[j][i] == 1)//向日葵
            {
                columnFlowerNum[i] += 1;
            }
            if (plants[j][i] == 2)//冰豌豆
            {
                columnIceNum[i] += 1;

            }
            if (plants[j][i] == 6)//倭瓜
            {
                columnPumpkinNum[i] += 1;
            }
        }
    }

    for (int i = 0; i < rows; i++)//   遍历僵尸,得到各行的僵尸总数
    {
        for (int j = 0; j < columns; j++)
        {
            int k = 0;
            while (zombies[i][j][k] != -1)
            {
                rowZombieNum[i]++;
                k++;
            }
        }
    }

    if (type == 0)
    {
        int Sun = player->Camp->getSun();
        bool sunSupply = Sun > 600;
        int* PlantCD = player->Camp->getPlantCD();

        for (int i = 0; i <= 5; i++) 
        {
            PlantCD = player->Camp->getPlantCD();
        }
        for (int i = 0; i < rows; i++)
        {
            if(Sun<=800)
            {
                if(time>=8)
                {
                    if (columnFlowerNum[1] < leftRows)
                    {
                        if (plants[i][1] != 1)
                        {
                            player->removePlant(i, 1);
                            player->PlacePlant(1, i, 1);
                        }
                    }
                    else if (columnFlowerNum[5] < leftRows)
                    {
                        if (plants[i][5] != 1)
                        {
                            player->removePlant(i, 5);
                            player->PlacePlant(1, i, 5);
                        }
                    }
                    else if (columnFlowerNum[6] < leftRows)
                    {
                        if (plants[i][6] != 1)
                        {
                            player->removePlant(i, 6);
                            player->PlacePlant(1, i, 6);
                        }
                    }
                }

                if (rowZombieNum[i] == 1)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];
                            break;                      
                        }
                    }   
                    if (zomType == 3)
                    {
                        if (PlantCD[1] == 0) 
                        {
                            player->PlacePlant(1, i, 5);
                            player->PlacePlant(3, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(4, i, 5);
                            player->PlacePlant(3, i, 0);
                        }
                    }
                    else if (zomType == 1)
                    {
                        player->PlacePlant(4, i, zomPosition - 1);
                        player->PlacePlant(3, i, 0);
                    }

                    else if (zomType == 2 || zomType == 4)
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                    }
                    else if (zomType == 5)
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 1);
                        player->PlacePlant(5, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 3);
                    }
                }

                int zomPosition = -1;
                int zomType = -1;
                for (int j = columns - 1; j >= 0; j--)
                {
                    if (zombies[i][j][0] != -1)
                    {
                        zomPosition = j;
                        zomType = zombies[i][j][0];
                        break;
                    }
                }
                if (zomPosition <= 5)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];
                            break;
                        }
                    }
                    if (zomType == 5 || zomType == 4)
                    {
                        if (PlantCD[6] == 0)
                        {
                            player->PlacePlant(6, i, zomPosition);
                        }
                        else
                        {
                            player->PlacePlant(5, i, zomPosition);
                        }
                    }

                    else if (zomType != 5 && zomType != 4 && zomPosition <= 3)
                    {
                        if (rowZombieNum[i] >= 2)
                        {
                            player->PlacePlant(5, i, 3);
                        }
                        else
                        {
                            player->PlacePlant(6, i, 3);
                        }
                    }
                }
            }
            else if (Sun > 800 && Sun <= 1600)
            {
                int zomPosition = -1;
                int zomType = -1;
                for (int j = columns - 1; j >= 0; j--)
                {
                    if (zombies[i][j][0] != -1)
                    {
                        zomPosition = j;
                        zomType = zombies[i][j][0];
                        break;
                    }
                }
                if (zomPosition <= 5)
                {
                    if (zomType == 5 || zomType == 4)
                    {
                        if (PlantCD[6] == 0)
                        {
                            player->PlacePlant(6, i, zomPosition);
                        }
                        else
                        {
                            player->PlacePlant(5, i, zomPosition);
                        }
                    }

                    else if (zomType != 5 && zomType != 4 && zomPosition <= 3)
                    {
                        if (rowZombieNum[i] >= 2)
                        {
                            player->PlacePlant(5, i, 3);
                        }
                        else
                        {
                            player->PlacePlant(6, i, 3);
                        }
                    }
                }

                if (leftLines[i] != 0)
                {
                    if (columnIceNum[0] < leftRows)
                    {
                        if (plants[i][0] != 2 && PlantCD[2] == 0)
                        {
                            player->removePlant(i, 0);
                            player->PlacePlant(2, i, 0);
                        }
                    }
                    else if (columnIceNum[2] < leftRows)
                    {
                        if (plants[i][2] != 2 && PlantCD[2] == 0 && !plantIce)
                        {
                            player->removePlant(i, 2);
                            player->PlacePlant(2, i, 2);
                            plantIce = true;
                        }
                    }
                    else if (columnIceNum[3] < leftRows && PlantCD[2] == 0 && !plantIce)
                    {
                        if (plants[i][3] != 2)
                        {
                            player->removePlant(i, 3);
                            player->PlacePlant(2, i, 3);
                            plantIce = true;
                        }
                    }
                    else if (columnIceNum[4] < leftRows && PlantCD[2] == 0 && !plantIce)
                    {
                        if (plants[i][4] != 2)
                        {
                            player->removePlant(i, 4);
                            player->PlacePlant(2, i, 4);
                            plantIce = true;
                        }
                    }
                }
            }
			else if (Sun > 1600)
				{
				int zomPosition = -1;
				int zomType = -1;
				for (int j = columns - 1; j >= 0; j--)
				{
					if (zombies[i][j][0] != -1)
					{
						zomPosition = j;
						zomType = zombies[i][j][0];
						break;
					}
				}
				if (zomPosition <= 5)
				{
					if (zomType == 5 || zomType == 4)
					{
						if (PlantCD[6] == 0)
						{
							player->PlacePlant(6, i, zomPosition);
						}
						else
						{
							player->PlacePlant(5, i, zomPosition);
						}
					}

					else if (zomType != 5 && zomType != 4 && zomPosition <= 3)
					{
						if (rowZombieNum[i] >= 2)
						{
							player->PlacePlant(5, i, 3);
						}
						else
						{
							player->PlacePlant(6, i, 3);
						}
					}
				}
				if (columnPumpkinNum[5] < leftRows)
				{
					if (plants[i][5] != 6 && PlantCD[6] == 0)
					{
						player->removePlant(i, 5);
						player->PlacePlant(6, i, 5);
					}
				}
				else if (columnPumpkinNum[6] < leftRows)
				{
					if (plants[i][6] != 6 && PlantCD[6] == 0)
					{
						player->removePlant(i, 6);
						player->PlacePlant(6, i, 6);
					}
				}
		    }

			if (time >= 70)
			{
				if (rowZombieNum[i] == 0)
				{
					if (columnPumpkinNum[7] < leftRows)
					{
						if (plants[i][7] != 6)
						{
							player->removePlant(i, 7);
							player->PlacePlant(6, i, 7);
						}
					}
					else if (columnPumpkinNum[8] < leftRows)
					{
						if (plants[i][8] != 6)
						{
							player->removePlant(i, 8);
							player->PlacePlant(6, i, 8);
						}
					}
					else if (columnPumpkinNum[9] < leftRows)
					{
						if (plants[i][9] != 6)
						{
							player->removePlant(i, 9);
							player->PlacePlant(6, i, 9);
						}
					}
				}
			}            
        }
    }

    if (type == 1)
    {   
        int sun = player->Camp->getSun();
        int* zombieCD = player->Camp->getPlantCD();

        for (int i = 0; i < rows; i++)
        {
            int j = 4 - i;
            if (sun > 850)
            {
                if (j == 4)
                {
                    beginPlace[j] = true;
                }
                if (j == 3 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 2 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 1 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 0 && leftLines[1] == 0 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
            }
        }
        if (time == 5)
        {
            if (totalFlowerNum != 0)
            {
                isFlower = true;
            }
            if (totalNutNum != 0)
            {
                isNut = true;
            }
            if (totalPumpkinNum != 0)
            {
                isPumpkin = true;
            }
            if (totalPeaNum != 0)
            {
                isPea = true;
            }
        }

        else if (time == 6)
        {
            if (!isNut && !isPea && !isPumpkin)
            {
                //摆放了向日葵
                if (isFlower)
                {
                    for (int i = 0; i < rows; i++)
                    {
                        if (rowFlowerNum[i] != 0)
                        {
                            player->PlaceZombie(2, i);
                            if (i - 1 == -1 || i + 1 == 5)
                            {
                                player->PlaceZombie(1, 1);
                                player->PlaceZombie(3, 2);
                            }
                            else
                            {
                                player->PlaceZombie(1, i - 1);
                                player->PlaceZombie(3, i + 1);
                            }
                        }
                    }
                }
                else
                {
                    player->PlaceZombie(1, 3);
                    player->PlaceZombie(2, 2);
                    player->PlaceZombie(3, 1);                
                }
            }
            else
            {
                if (isPea && !isNut && !isPumpkin)//仅有豌豆射手的情况
                {
                    for (int i = 0; i < rows; i++)
                    {
                        if (rowPeaNum[i] != 0)
                        {
                            player->PlaceZombie(2, i);
                            if (i - 1 == -1 || i + 1 == 5)
                            {
                                player->PlaceZombie(1, 1);
                                player->PlaceZombie(3, 2);
                            }
                            else
                            {
                                player->PlaceZombie(1, i - 1);
                                player->PlaceZombie(3, i + 1);
                            }
                        }
                    }
                }

                else if (isNut || isPumpkin)//仅有坚果或仅有倭瓜或仅有坚果和倭瓜
                {
					for (int i = 0; i < rows; i++)
					{
						if (rowNutNum[i] == 0 && rowPumpkinNum[i] == 0)
						{
                            if (rowPeaNum != 0)
                            {
                                player->PlaceZombie(2, i);
                                rowBegin[i] += 1;
                            }
                            else
                            {
                                if (zombieCD[1] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(1, i);
                                    rowBegin[i] += 1;
                                }
                                else if (zombieCD[2] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(2, i);
                                    rowBegin[i] += 1;
                                }
                                else if (zombieCD[3] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(3, i);
                                    rowBegin[i] += 1;
                                }
                            }
						}
					}
                }
            }
        }

        else if (time > 6)
        {    
            for(int i = 0;i<rows;i++)
            {
                if (rowPeaNum[i] == 0 && rowNutNum[i] == 0 && rowPumpkinNum[i] == 0&&rowIceNum[i]==0&&rowZombieNum[i] == 0)
                {
                    player->PlaceZombie(1, i);
                }
            }
			for (int i = 0; i < 5; i++)
			{
				int j = 4 - i;
				if (beginPlace[j] && rowIceNum[j] <= 1)
				{
					if (rowZombieNum[j] <= 1)
					{
						player->PlaceZombie(5, j);
					}
				}
				else if (beginPlace[j] && rowIceNum[j] > 1)
				{
					if (rowZombieNum[j] <= 2)
					{
						player->PlaceZombie(5, j);
					}
				}
			}
        }
    }
}
