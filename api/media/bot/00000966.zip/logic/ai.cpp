#include "ai.h"
#include"stdio.h"
#include <ctime>
#include <cstdlib>
#define ROW 5
#define COLUMN 10
#define SHOOTCD 3
#define SUNCD 21
#define FILE stdout
//坐标点类
static struct Point {
    int x;
    int y;
    Point() {
        x = -1;
        y = -1;
    }
    Point(int x, int y) {
        this->x = x;
        this->y = y;
    }
};
//遍历得到植物的个数(在原地图上获得信息)
int SearchForPlantSum(int type, int** plants) {
    int ans = 0;
    for(int i=0;i<ROW;i++)
        for (int j = 0; j < COLUMN; j++) {
            if (plants[i][j] == type) {
                ans++;
            }
        }
    return ans;
}
//植物/僵尸阳光常数组
const int PLANTSUN[] = {0,50,400,100,50,125,50};//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
const int ZOMBIESUN[] = { 0,50,125,125,300,300 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//CD常数组
const int PLANTSCD[] = { 0,10,30,10,40,60,60 };//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
const int ZOMBIESCD[] = { 0,15,20,20,25,25 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//CD维护数组
int PlantsCD[] = { 0,0,0,0,0,0,0 };//从0~6依次为空,太阳花,冰豌豆射手,豌豆射手,坚果墙,火爆辣椒,倭瓜
int ZombiesCD[] = { 0,0,0,0,0,0 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//僵尸速度数组
double ZOMBIESVELOCITYTRUE[] = { 0,0.2,0.2,1 / 2.5,1 / 3.0,0.2 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
double ZOMBIESVELOCITYFALSE[] = { 0,0.2,0.2,1 / 4.5,1 / 8.0,0.2 };//从0~5依次为空,普通僵尸,铁桶僵尸,撑杆跳僵尸,雪橇车僵尸,伽刚特尔
//冰车速度数组(从0开始是刚出现之前的回合,数组第15元素包括之后都为V=0.125)
double SlEDVELOITYTRUE[] = { 0.33333,0.28127,0.28125,0.28125,0.22917,0.22917,0.22916,0.22917,0.17708,0.17709,0.17708,0.17708,0.17709,0.17708,0.125 };

//植物类
static struct Plant
{
    Point pos;
    int type;
    int blood;
    int shootCD;
    int attack;
    int winter;
    //构造函数
    Plant() {
        Point _pos;
        _pos.x = -1;
        _pos.y = -1;
        this->pos = _pos;
        this->type = 0;
        this->blood = 0;
    }
    //初始化
    void init(int type,int x,int y) {
        pos.x = x;
        pos.y = y;
        shootCD = 1;
        attack = 0;
        this->type = type;
        blood = 300;
        winter = 0;
        //寒冰射手
        if (type == 2) {
            this->attack = 60;
            this->winter = 1;
        }//豌豆射手
        else if (type == 3) {
            this->attack = 20;
        }//坚果
        else if (type == 4) {
            this->blood = 4000;
        }//火爆辣椒
        else if (type == 5) {
            this->attack = 1800;
        }//倭瓜
        else if (type == 6) {
            this->attack = 1800;
        }//什么都没有
        else if (type == 0) {
            blood = 0;
            shootCD = 0;
        }
    }
    //检测是否有植物或者植物血量为0消失(如果有植物返回1否则返回0)
    int ifHavePlant() {
        if (this->type == 0 || this->blood <= 0)
            return 0;
        return 1;
    }
    //检测植物是否死亡(死亡返回1，未死亡返回0)
    int ifPlantDead() {
        return blood <= 0;
    }
};

//僵尸基础信息

//僵尸类
static struct Zombie 
{
    /*僵尸具体信息*/
    Point pos;//位置
    double detailPos;//浮点位置
    int type;//僵尸种类
    int blood;//血量
    int flag;//用于撑杆跳等僵尸的判据(True代表没有跳,False代表跳过了)
    int winterstep;//僵尸的减速剩余回合
    double velocity;//僵尸速度
    int Step;//已经到第几阶段(冰车僵尸使用)
/*操作*/
    //构造函数
    Zombie() {
        Point _pos;
        _pos.x = -1;
        _pos.y = -1;
        this->pos = _pos;
        this->type = 0;
        this->blood = 0;
    }
    //初始化(僵尸刚出现)
    int init(int type, int row) {
        pos.x = row;
        pos.y = COLUMN - 1;
        detailPos = COLUMN;
        this->type = type;
        flag = 1;//未完成动作
        winterstep = 0;//未被减速
        Step = 0;//第0阶段
        if (type == 1)/* 普通僵尸 */{
            velocity = 0.2;
            blood = 270;
            detailPos -= velocity;
        }//铁桶僵尸
        if (type == 2) {
            velocity = 0.2;
            blood = 550 + 270;
            detailPos -= velocity;
        }//撑杆跳僵尸
        if (type == 3) {
            velocity = 0.4;
            blood = 200;
            detailPos -= velocity;
        }//冰车僵尸
        if (type == 4) {
            velocity = 0.4;
            blood = 1600;
            detailPos -= velocity;
        }//巨人僵尸
        if (type == 5) {
            velocity = 0.2;
            blood = 3000;
            detailPos -= velocity;
        }
    }
    //检查是否有僵尸(有僵尸返回1 无僵尸返回0)
    int ifHaveZombie() {
        return type != 0;
    }
    //处理僵尸血量减少(仍然存活返回1否则返回0)
    int bloodDecrease(int deltablood) {
        blood -= deltablood;
        if (blood > 0)return 1;
        else return 0;
    }
    //处理撑杆跳僵尸的跳跃(跳跃返回1 未跳跃或者早跳跃完成返回0)
    //只处理僵尸的跳跃不处理攻击
    int polevaultJump() {
        if (flag != 0) {
            flag = 0;
            pos.x -= 1;
            detailPos -= 1;
            return 1;
        }
        return 0;
    }
    //处理冰车僵尸前4格的速度变化

    //处理僵尸的正常&减速1STEP移动(包括各种运动)

    //接受是否受伤是否减速，并对僵尸更新(血量and运动)

};
//僵尸CD初始化

//植物统计库类(植物的库统计)
static struct Plants {
    int plants[ROW][COLUMN];//植物地图
    int sum;//该植物总数
    Plant plantsmap[ROW][COLUMN];//详细数据植物地图
    Plant* sunFlowers;//向日葵表
    int SumOfSunFlower;//向日葵数目
    Plant* winterPeaShooters;//寒冰射手表
    int SumOfWinterPeaShooters;//寒冰射手数目
    Plant* peaShooters;//豌豆射手表
    int SumOfPeaShooters;//豌豆射手数目
    Plant* smallNuts;//坚果表
    int SumOfSmallNuts;//坚果数目
    Plant* peppers;//火爆辣椒表
    int SumOfPeppers;//火爆辣椒数目
    Plant* squashs;//倭瓜表
    int SumOfSquashs;//倭瓜数目
    //默认构造函数
    Plants() {
        sum = 0;
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++) {
                plants[i][j] = 0;
                plantsmap[i][j].pos.x = i;
                plantsmap[i][j].pos.y = j;
            }
        sunFlowers = new Plant[50];
        SumOfSunFlower = 0;
        winterPeaShooters = new Plant[50];
        SumOfWinterPeaShooters = 0;
        peaShooters = new Plant[50];
        SumOfPeaShooters = 0;
        smallNuts = new Plant[50];
        SumOfSmallNuts = 0;
        peppers = new Plant[50];
        SumOfPeppers = 0;
        squashs = new Plant[50];
        SumOfSquashs = 0;
    }
    //析构函数(释放各个指针分配的内存)
    ~Plants() {
        delete[]sunFlowers;
        delete[]winterPeaShooters;
        delete[]peaShooters;
        delete[]smallNuts;
        delete[]peppers;
        delete[]squashs;
    }
    //更新植物地图
    void RenewPlantMap(int** newplants) {
        //植物死亡(血量小于等于0)
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++) {
                if (plantsmap[i][j].ifPlantDead())
                    plantsmap[i][j].init(0, i, j);
            }
        //更新新植物
        for(int i=0;i<ROW;i++)
            for (int j = 0; j < COLUMN; j++) {
                plants[i][j] = newplants[i][j];
                if (!plantsmap[i][j].ifHavePlant())
                    plantsmap[i][j].init(newplants[i][j], i, j);
            }
    }
    //输出植物地图
    void PrintPlantMap() {
        fprintf(FILE,"***********************\n");
        for (int i = 0; i < ROW; i++) {
            fprintf(FILE,"* ");
            for (int j = 0; j < COLUMN; j++) {
                fprintf(FILE, "%d ", plantsmap[i][j].type);
            }
            printf("*\n");
        }
        fprintf(FILE, "***********************\n");
    }
    //输出植物血量地图
    void PrintPlantBloodMap() {
        fprintf(FILE, "*******************************************\n");
        for (int i = 0; i < ROW; i++) {
            fprintf(FILE, "* ");
            for (int j = 0; j < COLUMN; j++) {
                fprintf(FILE, "%3.d ", plantsmap[i][j].blood);
            }
            printf("*\n");
        }
        fprintf(FILE, "*******************************************\n");
    }
    //更新各植物表
    void renewPlantList() {

    }
};
//僵尸统计库类(单一僵尸的库统计)
static struct Zombies {
/*数据*/
    int zombies[ROW][COLUMN][100];//僵尸地图
    int sum;//僵尸总数
    Zombie zombiesmap[ROW][COLUMN][100];//僵尸详细数据地图
    Zombie* normals;//普通僵尸
    int sumNormals;//普通僵尸的数量
    Zombie* buckets;//铁桶僵尸
    int sumBuckets;//铁桶僵尸的数量
    Zombie* polevaults;//撑杆跳僵尸
    int sumPolevaults;//撑杆跳僵尸的数量
    Zombie* sleds;//冰车僵尸
    int sumSleds;//冰车僵尸的数量
    Zombies* gargantuars;//巨人僵尸
    int sumGargantuars;//巨人僵尸的数量
/*操作*/
    //构造函数(僵尸地图初始化，总数归零，详细地图初始化，给各个指针分配内存)
    Zombies() {
        //僵尸地图初始化
        for (int i = 0; i < ROW; i++)
            for (int j = 0; j < COLUMN; j++)
                for (int k = 0; k < 100; k++)
                    zombiesmap[i][j][k].init(0, i);
        //总数归零
        sum = 0;
        sumNormals = 0;
        sumBuckets = 0;
        sumPolevaults = 0;
        sumSleds = 0;
        sumGargantuars = 0;
        //分配内存

    }
    //析构函数(释放各个指针分配的内存)

    //注意更新相关的数量参数(包括总数和各自的参数)
    //添加一个满血的普通僵尸(刚出现)
    void addNormal(int row) {

    }
    //添加一个满血的铁桶僵尸(刚出现)

    //添加一个满血的撑杆跳僵尸(刚出现)

    //添加一个满血的冰车僵尸(刚出现)

    //添加一个满血的巨人僵尸(刚出现)

    //删除所有血量小于等于0的僵尸


};
//火力处理装置
//处理植物攻击僵尸，僵尸干掉植物这两件事
void fireProcessing(Plants& classplant, Zombies& classZombies) {
    //处理豌豆射手

}

//植物统计数组(分别为向日葵，寒冰射手，豌豆射手，坚果墙，辣椒，倭瓜)

//植物查找
//某点是否有向日葵(x,y)
int ifPointSunFlower(int** plant, int x, int y) {
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    return plant[x][y] == 1;
}
//某行向日葵查找row
int ifRowSunFlower(int** plant, int row) {
    if (row<0 || row>ROW)
        return 0;
    for (int j = 0; j < COLUMN; j++)
        if (plant[row][j] == 1)
            return 1;
    return 0;
}
//某点僵尸查找(返回统计数量的数组)
int* SearchForPointZombies(int*** Zombies, int x, int y) {
    int* ans = new int[6];
    for (int i = 0; i < 6; i++)
        ans[i] = 0;
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COLUMN; j++) {
            int k = 0;
            while (Zombies[i][j][k] != -1 && Zombies[i][j][k] != 0) {
                ans[Zombies[i][j][k]]++;
                k++;
            }
        }
    return ans;
}
//释放查找指针
void EndSearch(int* p) {
    delete[]p;
}
//检查此格是否有僵尸(返回0/1)
int ifPointZombies(int***Zombies,int x, int y) {
    int* p = SearchForPointZombies(Zombies, x, y);
    int ans = 0;
    for (int i = 1; i < 6; i++) {
        if (p[i] != 0) {
            ans = 1;
            break;
        }
    }
    EndSearch(p);
    return ans;
}
//检查此行是否有僵尸(返回0/1)
int ifRowZombles(int*** Zombies, int Row) {
    int ans = 0;
    for (int i = 0; i <COLUMN; i++) {
        if (ifPointZombies(Zombies, Row, i)) {
            ans = 1;
            break;
        }
    }
    return ans;
}
//寻找种向日葵的合适地点(返回坐标)
Point FindPlaceForSunFlower(int** Plants, int*** Zombies) {
    for (int i = 0; i < ROW; i++) {
        if (Plants[i][3] == 0 && !ifRowZombles(Zombies, i)) {
            return Point(i, 3);
        }
    }
    return Point(-1, -1);
}
//倭瓜防御一行(返回是否成功)
Point DefenseBySquash(int** Plants, int x, int y) {
    while (y >= 0) {
        if (Plants[x][y] == 0) {
            return Point(x, y);
        }
        y--;
    }
    return  Point(-1, -1);
}

//检查向日葵CD
int SunFlowerCD(int* CD) {
    return CD[0] < 1;
}
//检查寒冰射手CD
int WinterPeachShooterCD(int* CD) {
    return CD[1] < 1;
}
//检查豌豆射手CD
int PeachShooterCD(int* CD) {
    return CD[2] < 1;
}
//检查坚果墙CD
int SmallNutCD(int* CD) {
    return CD[3] < 1;
}
//检查火爆辣椒CD
int PepperCD(int* CD) {
    return CD[4] < 1;
}
//检查倭瓜CD
int SquashCD(int* CD) {
    return CD[5] < 1;
}

//种植部分已经检查CD，植物种植位置是否合法(溢出边界or有植物)
//种植倭瓜
int PlantSquash(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SquashCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(6, x, y);
    return 1;
}
//种植向日葵
int PlantSunFlower(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >=ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SunFlowerCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(1, x, y);
    return 1;
}
//种植寒冰射手
int PlantWinterPeachShooter(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!WinterPeachShooterCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(2, x, y);
    return 1;
}
//种植豌豆射手
int PlantPeachShooter(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!PeachShooterCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(3, x, y);
    return 1;
}
//种植坚果墙
int PlantSmallNut(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!SmallNutCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(4, x, y);
    return 1;
}
//种植火爆辣椒
int PlantPepper(IPlayer* player, int** Plant, Point a) {
    int x = a.x;
    int y = a.y;
    if (x < 0 || x >= ROW)
        return 0;
    if (y < 0 || y >= COLUMN)
        return 0;
    if (Plant[x][y] != 0)
        return 0;
    if (!PepperCD(player->Camp->getPlantCD()))
        return 0;
    player->PlacePlant(5, x, y);
    return 1;
}



//僵尸
//普通僵尸CD检查(CD为0返回1，否则为0)
int NormalCD(int* CD) {
    return CD[0] < 1;
}
//铁桶僵尸CD检查(CD为0返回1，否则为0)
int BucketCD(int* CD) {
    return CD[1] < 1;
}
//撑杆跳僵尸CD检查(CD为0返回1，否则为0)
int PolevaultCD(int* CD) {
    return CD[2] < 1;
}
//冰车僵尸CD检查(CD为0返回1，否则为0)
int SledCD(int* CD) {
    return CD[3] < 1;
}
//巨人僵尸CD检查(CD为0返回1，否则为0)
int GargantuarCD(int* CD) {
    return CD[4] < 1;
}

//放置普通僵尸
//放置部分已经检查CD，僵尸放置位置是否合法(溢出边界)
int SetNormal(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!NormalCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(1,Row);
    return 1;
}
//放置铁桶僵尸
int SetBucket(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!BucketCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(2, Row);
}
//放置撑杆跳僵尸
int SetPolevault(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!PolevaultCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(3, Row);
    return 1;
}
//放置冰车僵尸
int SetSled(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!SledCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(4, Row);
}
//放置巨人僵尸
int SetGargantuar(IPlayer* player, int Row) {
    if (Row < 0 || Row >= ROW)
        return 0;
    if (!GargantuarCD(player->Camp->getPlantCD()))
        return 0;
    player->PlaceZombie(5, Row);
}

//检测
//检测各行向日葵数目
void CheckSunFlower(int**Plants, int* Ans) {
    for (int i = 0; i < ROW; i++) {
        Ans[i] = 0;
        for (int j = 0; j < COLUMN; j++) {
            if (Plants[i][j] == 1)
                Ans[i]++;
        }
    }
}
//检测各行倭瓜数目
void CheckSquash(int** Plants, int* Ans) {
    for (int i = 0; i < ROW; i++) {
        Ans[i] = 0;
        for (int j = 0; j < COLUMN; j++) {
            if (Plants[i][j] == 6)
                Ans[i]++;
        }
    }
}


//对于僵尸的防御1(一次性防御)(并标记)(返回需要的阳光)

//防御能耗的概念(我下一个僵尸他需要完成防御的最少能耗和CD)

//

//僵尸策略1(1<=STEP<=50)(小费速攻策略)
//策略基本数据记录 
int attackRow1[] = { 0,0,0,0,0 };
//仅仅使用普通僵尸和撑杆跳进行进攻
void lowCostAttack(IPlayer* player) {
    //僵尸方
    int Step = player->getTime();//回合数
    int Sun = player->Camp->getSun();//月光数
    int Row = player->Camp->getRows();//行数
    int Column = player->Camp->getColumns();//列数
    int** Plants = player->Camp->getCurrentPlants();//植物数组
    int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
    int* CD = player->Camp->getPlantCD();//僵尸CD
    
    //检测是否处于前期策略(1<=STEP<=50)
    if (Step <= 1 || Step>70)
        return;
    //STEP=2放置撑杆跳/普通僵尸
    //根据不重复行原则和撑杆跳进攻向日葵原则
    if (Step == 2) {
        int row = 0;
        //检测有向日葵的地方
        //可能需要完善向日葵很前不进攻的特殊情况
        while (row < ROW) {
            if (ifRowSunFlower(Plants, row))
                break;
            row++;
        }
        //如果有向日葵，在有向日葵的地方放撑杆跳不然随机放
        if (row == ROW) {
            srand(time(0));
            int setrow = rand() % ROW;
            SetPolevault(player, setrow);
            attackRow1[setrow] = 1;
            printf("STEP:%d\n", Step);
            printf("Polevault:Row:%d\n", setrow);
        }
        else {
            SetPolevault(player, row);
            attackRow1[row] = 1;
            printf("STEP:%d\n", Step);
            printf("Polevault:Row:%d\n", row);
        }
         //在无僵尸的行放一个普通僵尸
        for (int row = 0,basic=rand()%ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Normal:Row:%d\n", setrow);
                SetNormal(player, setrow);
                attackRow1[setrow] = 1;
                break;
            }
        }
        return;
    }
    /*测试*/
    /*测试*/
    //只要CD好就放普通僵尸
    if (NormalCD(CD)&&Sun>=50) {
        for (int row = 0,basic = rand() % ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Normal:Row:%d\n", setrow);
                printf("%d\n",SetNormal(player, setrow));
                attackRow1[setrow] = 1;
                Sun -= 50;
                break;
            }
        }
    }
    //只要CD好就放撑杆跳僵尸
    if (PolevaultCD(CD)&&Sun>=75) {
        for (int row = 0, basic = rand() % ROW; row < ROW; row++) {
            int setrow = (row + basic) % ROW;
            if (attackRow1[setrow] == 0) {
                printf("STEP:%d\n", Step);
                printf("Polevault:Row:%d\n", setrow);
                printf("%d\n",SetPolevault(player, setrow));
                attackRow1[setrow] = 1;
                Sun -= 75;
                break;
            }
        }
    }
}
Plants PlantsGarden;
//选手代码在下方填入
void player_ai(IPlayer* player) {
    int Type = player->Camp->getCurrentType();
    if (Type == 0) {
        //植物方
        int Step = player->getTime();//回合数
        int Sun = player->Camp->getSun();//阳光
        int Row = player->Camp->getRows();//行数
        int Column = player->Camp->getColumns();//列数
        int** _Plants = player->Camp->getCurrentPlants();//植物数组
        int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
        int* CD = player->Camp->getPlantCD();//返回植物的CD
        if (Step <= 60) {
            
        }

    }
    
    if (Type == 1) {
        //僵尸方
        int Sun = player->Camp->getSun();//月光数
        int Row = player->Camp->getRows();//行数
        int Column = player->Camp->getColumns();//列数
        int** Plants = player->Camp->getCurrentPlants();//植物数组
        int*** Zombies = player->Camp->getCurrentZombies();//僵尸数组
        int* CD = player->Camp->getPlantCD();//僵尸CD
        int Step = player->getTime();//回合数
        /*测试*/
        if (Step == 2) {
            player->PlaceZombie(3, 1);
        }
        /*测试*/
    }
}