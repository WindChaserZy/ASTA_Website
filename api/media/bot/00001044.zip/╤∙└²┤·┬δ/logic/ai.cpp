#include "ai.h"
#include <iostream>


float zombiePH(int m_type,int steps) {
    float PH=0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270;
            break;
        case 2:PH = 820;
            break;
        case 3: PH = 200;
            break;
        case 4:PH = 1600;
            break;
        case 5:PH = 3000;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270 * steps / 1000;
            break;
        case 2:PH = 820 * steps / 1000;
            break;
        case 3: PH = 500 * steps / 1000;
            break;
        case 4:PH = 1350 * steps / 1000;
            break;
        case 5:PH = 3000 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return PH;
   
}

float zombiespeed(int m_type, int steps) {
    float speed = 0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: speed = 0;
            break;
        case 1:speed = 0.2;
            break;
        case 2:speed = 0.4;
            break;
        case 3: speed = 0.222;
            break;
        case 4:speed = 0.333;
            break;
        case 5:speed = 0.2;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: speed = 0 * steps / 1000;
            break;
        case 1:speed = 0.2 * steps / 1000;
            break;
        case 2:speed = 0.4 * steps / 1000;
            break;
        case 3: speed = 0.222 * steps / 1000;
            break;
        case 4:speed = 0.333 * steps / 1000;
            break;
        case 5:speed = 0.2 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return speed;
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 20;
        break;
    case 3:return 10;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}


void player_ai(IPlayer* player)
{

    if (Type == 0) {//当前为植物方


    }
    else {//当前为僵尸方
        
    }
}
