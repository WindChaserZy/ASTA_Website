#include "ai.h"
#include <random>
#include <iostream>
#include <time.h>

//#define DEBUG
#define SETSEED
/*			普僵	(270)	铁桶(550+270)	撑杆跳(200)	雪橇车(1600)	伽刚特尔(3000)
向日葵(300)	-/3.6		-/3.6			-/3.6		-/1			-/1
豌豆(300)	28/3.6		82/3.6			20/3.6		160/1		300/1
冰豌豆(300)	15/3.6		41/3.6			10/3.6		80/1		150/1
辣椒	(300)	1/-			1/-				1/			1/1			2/1
倭瓜	(300)	1/-			1/-				1/			1/1			2/1
坚果墙(4000)	-/53.3		-/53.3			-/53.3		-/1			-/1

坚果摆在哪一列？4
向日葵种植数量？4
何时种植冰豌豆？

开局种4个

普僵：在左侧放置豌豆
铁桶：在第4格放坚果
撑杆：在撑杆所在的格子放置向日葵
雪橇车：如果有倭瓜在其前一格放倭瓜，如没有则放置辣椒
伽刚特尔：在其所在格放置倭瓜和辣椒（优先级高于雪橇车）


冷却时间主要按月光考虑，次要按CD计算

*/
enum PlantType {
	NOPLANT = 0,
	SUNFLOWER,
	WINTERPEASHOOTER,
	PEASHOOTER,
	SMALLNUT,
	PEPPER,
	SQUASH
};
enum ZombieType {
	NOZOMBIE = 0,
	NORMAL,
	BUCKET,
	POLEVAULT,
	SLED,
	GARGANTUAR
};
enum TryPlant {
	SUCCEED = 0,
	WAITCD,
	NOSPACE,
	INVALIDTYPE,
	NEEDSUN
};
using namespace std;
const int PlantSun[6] = { 50, 100, 400, 125, 50, 50 };
const int ZombieSun[5] = { 50, 125, 125, 300, 300 };

const int LineSunFlower[] = {2,3,5,6};
const int LinePeaShooter[] = { 0,1,4 };
const int LineSmallNut[] = { 7 };

int TryPlacePlant(IPlayer *const player, int PlantType, int x, int y);
bool isSafeToPlant(int ***Zombies, int x, int y);
int TryToRemoveAndPlacePlant(IPlayer *const player, int PlantType, int x, int y);
void zombie_ai(IPlayer *player);
//选手代码在下方填入
void player_ai(IPlayer *player) {
	//	//both
	int CampType = player->Camp->getCurrentType();
	static bool isInitalized = false;
	const int Rows = player->Camp->getRows();
	const int Columns = player->Camp->getColumns();
	if (CampType == 0) {
		//		//Plants
		//		/*
		//		需要解决的问题：
		//		根据重要程度决策。例如离底线较近的僵尸需要优先考虑，防御较少的行优先考虑。
		// 		当僵尸接近底线时，考虑使用倭瓜和辣椒。
		//		寒冰射手。大后期需要用来拖慢速度。
		//		阳光冗余。阳光堆积太多，可以适当种一些豌豆、坚果和向日葵。
		// 		   当阳光够多时，把后排的豌豆逐渐升级为冰豌豆，
		//		向日葵被打后立即补种，结果又被吃掉(get)
		//		僵尸累积起来之后，可以考虑放置一个倭瓜。
		//		一行的僵尸如果数量够多，则考虑放置一个辣椒。
		//		及时止损：当植物快被摧毁时，及时铲除。(铲除后避免再次放置)，后侧的植物都是如此。
		// 		   如果在右侧有向日葵，受到僵尸攻击时，将其清除。
		// 
		//		植物被僵尸推掉之后会给僵尸大量阳光，重点是冰豌豆和坚果。
		// 		  
		//		
		//
		// 		
		// 
		//		阳光仍有盈余。考虑除去一些向日葵，改种射手。
		// 		   可以考虑囤倭瓜？
		//		后期僵尸增强，无法守住防线。
		//		阳光较多时，除去向日葵，改种射手；阳光较少时，增种向日葵？
		//		考虑舍弃一行？n
		// 
		//	问题：僵尸均匀放置，会有一些行守不住。
		//	向日葵优先放在有豌豆的地方和无僵尸的地方
		//		*/
		//
		int ***Zombies = player->Camp->getCurrentZombies();
		int **Plants = player->Camp->getCurrentPlants();
		int *PlantsCD = player->Camp->getPlantCD();
		bool isGiant = false;
		bool isSled = false;
		int containsZombie[5] = {0,0,0,0,0};
		//根据僵尸做出决策
		for (int j = 0; j < Columns; j++)
			for (int i = 0; i < Rows; i++)
				//如果僵尸靠近底线，则使用倭瓜和辣椒
				for (int k = 0; k < 2 && Zombies[i][j][k] != -1; k++) {
					containsZombie[i] += 1;

					if (j == 0) {
						if (TryToRemoveAndPlacePlant(player, SQUASH, i, 0) == SUCCEED) {

						}
						else if (TryToRemoveAndPlacePlant(player, PEPPER, i, 0) == SUCCEED) {

						}
						else {
							isGiant = false;
							isSled = false;
							for (int m = 0; m < k; m++) {
								if (Zombies[i][j][m] == GARGANTUAR) {
									isGiant = true;
								}
								else if (Zombies[i][j][m] == SLED) {
									isSled = true;
								}
							}
							if (isSled || isGiant) {
								player->removePlant(i, 0);
							}
							else {
								TryPlacePlant(player, SMALLNUT, i, 0);
							}
						}
					}
					switch (Zombies[i][j][0])
					{
					case NORMAL:		//普僵
						if (Plants[i][LinePeaShooter[0]] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
						}
						if (j < 5) {
							if (TryPlacePlant(player, SMALLNUT, i, j) == WAITCD || TryPlacePlant(player, SMALLNUT, i, j) == NEEDSUN) {
								if (Plants[i][LinePeaShooter[0]] != PEASHOOTER && Plants[i][LinePeaShooter[0]] != WINTERPEASHOOTER) {
									player->removePlant(i, LinePeaShooter[0]);
								}
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
							}
						}
						break;
					case BUCKET:		//铁桶
						if (Plants[i][LinePeaShooter[1]] == NOPLANT) {
							if (TryPlacePlant(player, SQUASH, i, j) == WAITCD) {
								player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
							}
						}
						else if (Plants[i][LinePeaShooter[2]] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, LinePeaShooter[2]);
						}
						else if (Plants[i][j] == NOPLANT) {
							player->PlacePlant(SMALLNUT, i, j);
						}
						else{
							if (player->Camp->getSun() > 700)
							{
								TryToRemoveAndPlacePlant(player, WINTERPEASHOOTER, i, LinePeaShooter[0]);
							}
						}

						break;
					case POLEVAULT:		//撑杆
						if (Plants[i][LinePeaShooter[1]] == NOPLANT) {
							player->PlacePlant(PEASHOOTER, i, LinePeaShooter[1]);
						}
						if (TryPlacePlant(player, SMALLNUT, i, j) == WAITCD || TryPlacePlant(player, SMALLNUT, i, j) == NEEDSUN) {
							if (Plants[i][LinePeaShooter[0]] != PEASHOOTER && Plants[i][LinePeaShooter[0]] != WINTERPEASHOOTER) {
								player->removePlant(i, LinePeaShooter[0]);
							}
							player->PlacePlant(PEASHOOTER, i, LinePeaShooter[0]);
						}

						break;
					case SLED:		//雪橇车
						if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED) {

						}
						else if (TryPlacePlant(player, PEPPER, i, j) == SUCCEED)
						{

						}
						else {
							TryPlacePlant(player, PEASHOOTER, i, LinePeaShooter[0]);
						}
						break;
					case GARGANTUAR:		//伽刚特尔
						if (TryPlacePlant(player, SQUASH, i, j) == SUCCEED &&
							TryPlacePlant(player, PEPPER, i, j) == SUCCEED) {

						}
						else {
							TryPlacePlant(player, WINTERPEASHOOTER, i, LinePeaShooter[0]);
						}
						break;
					default:
						break;
					}
					//适时放置倭瓜
					if (PlantsCD[SQUASH] <= 0) {
						if (k > 3) {	//如果有3个以上的僵尸
							TryPlacePlant(player, SQUASH, i, j);
						}
					}

					//如果同一格内有僵尸，则铲除除坚果，辣椒，倭瓜以外的植物
					/*if (Plants[i][j - 1] == PEASHOOTER || Plants[i][j - 1] == WINTERPEASHOOTER || Plants[i][j - 1] == SUNFLOWER) {
						player->removePlant(i, j - 1);
					}*/
					//如果有巨人或者雪橇车，则铲除其前方一格的植物
					if (j > 0) {	//如果不是底线，即其前方还有一格
						if (Zombies[i][j][k] == GARGANTUAR || Zombies[i][j][k] == SLED) {
							if (Plants[i][j - 1] != PEPPER && Plants[i][j - 1] != SQUASH) {
								player->removePlant(i, j - 1);
							}
						}
					}
				}
				//放置辣椒
		for (int i = 0; i < Rows; i++) {
			if (containsZombie[i] > 3) {
				
				player->PlacePlant(PEPPER, i, 8);
			}
		}
		//种植5个向日葵
		int i, m;

		for (m = 0, i = 5; m < 4 && i == 5;) {
			//如果没有僵尸，优先种植此行
			for (i = 0; 
				i < 5 
				&& (
					Plants[i][LineSunFlower[m]] != NOPLANT 
					|| (
						Plants[i][LineSunFlower[m]] == NOPLANT 
						&& containsZombie[i]
						)
					); 
				i++
			);
			//如果有射手，优先种植此行
			/*if (i == 5) {
				cout << "i = 5, reset i = 0" << endl;
				for (i = 0;
					i < 5
					&& (
						Plants[i][LineSunFlower[m]] != NOPLANT
						|| (
							Plants[i][LineSunFlower[m]] == NOPLANT
							&& (
								Plants[i][LinePeaShooter[0]] == NOPLANT
								&& Plants[i][LinePeaShooter[1]] == NOPLANT
								)
							)
						);
					i++
				);
			}*/
			if (i == 5) {
				m++;
			}
		}
		//cout << "m = " << m << ", i = " << i << ", NoPlant? " << (Plants[i][LineSunFlower[m]] == NOPLANT) << ", Contains Zombie? " << containsZombie[i] << endl;
		if (m < 2 && i < 5) {
			if (Zombies[i][LineSunFlower[m]][0] == -1 && isSafeToPlant(Zombies, i, LineSunFlower[m])) {
				player->PlacePlant(SUNFLOWER, i, LineSunFlower[m]);
			}
		}
		//阳光较多时
		//种植坚果
		if (player->Camp->getSun() > 400) {
			for (i = 0; i < 5 && Plants[i][LineSmallNut[0]] != NOPLANT; i++);
			if (i < 5 && isSafeToPlant(Zombies, i, LineSmallNut[0])) {
				player->PlacePlant(SMALLNUT, i, LineSmallNut[0]);
			}
		}
		////种植向日葵
		//if (player->Camp->getSun() > 300) {
		//	for (i = 0; i < 5 && Plants[i][LineSunFlower[1]] != NOPLANT; i++);
		//	if (i < 5 && isSafeToPlant(Zombies, i, LineSunFlower[1])) {
		//		player->PlacePlant(SUNFLOWER, i, LineSunFlower[1]);
		//	}
		//}
		//种植冰豌豆
		if (player->Camp->getSun() > 800) {
			for (int j = 0; j < 3; j++) {
				for (i = 0; i < 5 && Plants[i][LinePeaShooter[j]] == WINTERPEASHOOTER; i++);
				if (i < 5 && isSafeToPlant(Zombies, i, LinePeaShooter[j])) {	//如果符合种植条件
					if (Plants[i][LinePeaShooter[j]] != NOPLANT) {
						player->removePlant(i, LinePeaShooter[j]);
					}
					player->PlacePlant(WINTERPEASHOOTER, i, LinePeaShooter[j]);
					cout << "Place WinterPeaShooter: " << i << ", " << j << endl;
					j = 3;
				}
				else {		//如果不符合种植条件

				}
			}


		}
	}

	if (CampType == 1) {
		//Zombie
        zombie_ai(player);
	}
}
//void Zombie_ai2(IPlayer *player) {
//    static int *ZombieTypes;
//    static int *lines;
//    static int ZombieIndex = 0;
//    static int LineIndex = 0;
//    if (!isInitalized) {
//        ZombieIndex = 0;
//        LineIndex = 0;
//        ZombieTypes = new int[2000];
//        lines = new int[2000];
//        time_t t;
//        unsigned int seed = (unsigned)time(&t);
//        srand(seed); //1650425929
//        isInitalized = true;
//#ifdef SETSEED
//        cout << "Initialized! seed: " << seed << endl;
//#endif // DEBUG
//
//        for (int i = 0; i < 2000; i++) {
//            ZombieTypes[i] = i % 3;
//            lines[i] = rand() % 5;
//        }
//}
//    /*随机化策略：
//        随机生成僵尸，用于训练和调试植物
//        具体内容：随机抽取僵尸种类，若可以放置则放置，若不能放置，则等待放置条件成立后再放置
//        如果找到符合条件的，则抽取行数，并放置僵尸。
//    */
//    int *ZombieCD = player->Camp->getPlantCD();
//    int ZombieType = 0;
//    int line = 0;
//    if (ZombieTypes != NULL) {
//        ZombieType = ZombieTypes[ZombieIndex];
//    }
//    else {
//#ifdef DEBUG
//
//        cout << "ZombieTypes is NULL! " << endl;
//#endif // DEBUG
//    }
//
//    if (lines != NULL) {
//        line = lines[LineIndex];
//    }
//    else
//    {
//#ifdef DEBUG
//
//        cout << "lines is NULL" << endl;
//#endif // DEBUG
//    }
//#ifdef DEBUG
//    cout << "index: " << LineIndex << endl;
//    cout << "Zombie Type: " << ZombieType << endl;
//    cout << "line: " << line << endl;
//    cout << "Sun:" << player->Camp->getSun() << endl;
//#endif // DEBUG
//    if (player->Camp->getSun() > ZombieSun[ZombieType]) {
//        int i;
//        for (i = 0; i < 5 && ZombieCD[(ZombieType + i) % 5] > 0; i++);
//        if (i < 5) {
//            if (player->Camp->getLeftLines()[line]) {
//                player->PlaceZombie((ZombieType + i) % 5 + 1, line);
//                ZombieIndex++;
//#ifdef DEBUG
//
//                cout << "Place Zombie: " << (ZombieType + i) % 5 + 1 << endl;
//#endif // DEBUG
//
//            }
//            else {
//#ifdef DEBUG
//
//                cout << "The line has been destroyed! line: " << line << endl;
//#endif // DEBUG
//            }
//        }
//        else {
//#ifdef DEBUG
//
//            cout << "The zombie is not cooled down! CD: " << ZombieCD[ZombieType] << endl;
//#endif // DEBUG
//
//        }
//    }
//    else {
//#ifdef DEBUG
//
//        cout << "Sun is not enough! Sun needed: " << ZombieSun[ZombieType] << endl;
//#endif // DEBUG
//    }
//    LineIndex++;
//    if (LineIndex == 2000) {
//#ifdef DEBUG
//        cout << "random is ended!" << endl;
//#endif
//        delete[] ZombieTypes;
//        delete[] lines;
//        ZombieTypes = NULL;
//        lines = NULL;
//        ZombieIndex = 0;
//        LineIndex = 0;
//        isInitalized = false;
//    }
//}
//返回三种状态，
int TryPlacePlant(IPlayer *const player, int PlantType, int x, int y) {
	if (PlantType < 1) {
#ifdef DEBUG
		cout << "Invalid PlantType! " << endl;
#endif // DEBUG
		return INVALIDTYPE;
	}
	if (player->Camp->getPlantCD()[PlantType - 1] > 0) {
		return WAITCD;
	}
	if (player->Camp->getCurrentPlants()[x][y] != NOPLANT) {
		return NOSPACE;
	}
	else if (player->Camp->getSun() < PlantSun[PlantType - 1]) {
		return NEEDSUN;
	}
	else
	{
		player->PlacePlant(PlantType, x, y);
		return SUCCEED;
	}
}
int TryToRemoveAndPlacePlant(IPlayer *const player, int PlantType, int x, int y) {
	if (PlantType < 1) {
#ifdef DEBUG
		cout << "Invalid PlantType! " << endl;
#endif // DEBUG
		return INVALIDTYPE;
	}
	if (player->Camp->getPlantCD()[PlantType - 1] > 0) {
		return WAITCD;
	}
	if (player->Camp->getCurrentPlants()[x][y] != NOPLANT) {
		if (player->Camp->getCurrentPlants()[x][y] != PlantType) {
			player->removePlant(x, y);
			player->PlacePlant(PlantType, x, y);
		}
		return SUCCEED;
	}
	else if (player->Camp->getSun() < PlantSun[PlantType - 1]) {
		return NEEDSUN;
	}
	else
	{
		player->PlacePlant(PlantType, x, y);
		return SUCCEED;
	}
}
//如果植物前方没有僵尸，则返回true
bool isSafeToPlant(int ***Zombies, int x, int y) {
	for (int k = 0; Zombies[x][y][k] != -1; k++) {
		if (Zombies[x][y + 1][k] == GARGANTUAR || Zombies[x][y + 1][k] == SLED) {
			return false;
		}
	}
	return true;
}

enum TryZombie
{
    VacantRow = 0,
    Succeed,
    WaitCD,
    NoSun
};


const int PlantSun2[7] = { 0,50, 400, 100, 50, 125, 50 };
const int ZombieSun2[6] = { 0,50, 125, 125, 300, 300 };

int TryPlaceZombie(IPlayer *const player, int ZombieType, int x, int *Leftlines)
{
    if (Leftlines[x] == 0)return VacantRow;
    else
    {
        if (player->Camp->getSun() < ZombieSun2[ZombieType])return NoSun;
        else
        {
            if (player->Camp->getPlantCD()[ZombieType - 1] > 0)return WaitCD;
            else return Succeed;
        }
    }
}

static int SquashUsed = 0;
static int SquashTime = 0;
static int Squash = 0;

void swap(int &a, int &b)
{
    int n;
    n = a;
    a = b;
    b = n;
}


//选手代码在下方填入
void zombie_ai(IPlayer *player)
{
    int time = player->getTime();
    const int rows = player->Camp->getRows();
    const int columns = player->Camp->getColumns();
    //int * PlantCD = player->Camp->getPlantCD () ;
    int **Plants = player->Camp->getCurrentPlants();
    int ***Zombies = player->Camp->getCurrentZombies();
    int *LeftLines = player->Camp->getLeftLines();
    int Sun = player->Camp->getSun();


    if (time - SquashTime == 60)SquashUsed = 0;


    int i1, j1, k1;
    int i2, j2;
    int *bloodP = new int[rows];
    int *bloodZ = new int[rows];
    int *attack = new int[rows];
    int *order = new int[rows];



    int squash = 0;

    for (i2 = 0; i2 < rows; i2++)
    {
        bloodP[i2] = 0; attack[i2] = 0;
        for (j2 = 0; j2 < columns; j2++)
        {
            if (Plants[i2][j2] == NOPLANT);
            else if (Plants[i2][j2] == SMALLNUT)bloodP[i2] += 4000;
            else
            {
                bloodP[i2] += 300;
                if (Plants[i2][j2] == PEASHOOTER)attack[i2] += 10;
                else if (Plants[i2][j2] == WINTERPEASHOOTER)attack[i2] += 20;
                else if (Plants[i2][j2] == SQUASH)
                {
                    attack += 1800;
                    squash++;
                }
            }
        }
    }


    for (i1 = 0; i1 < rows; i1++)
    {
        bloodZ[i1] = 0;
        for (j1 = 0; j1 < columns; j1++)
        {
            k1 = 0;
            while (Zombies[i1][j1][k1] != -1)
            {
                if (Zombies[i1][j1][k1] == NORMAL || Zombies[i1][j1][k1] == POLEVAULT)bloodZ[i1] += 1;
                else if (Zombies[i1][j1][k1] == BUCKET)bloodZ[i1] += 10;
                else if (Zombies[i1][j1][k1] == SLED)bloodZ[i1] += 100;
                else if (Zombies[i1][j1][k1] == GARGANTUAR)bloodZ[i1] += 1000;
            }
        }
    }

    if (squash == Squash - 1)Squash--;
    else if (squash == Squash + 1)
    {
        SquashUsed = 1;
        SquashTime = time;
        Squash++;
    }

    for (i1 = 0; i1 < rows; i1++)
    {
        order[i1] = i1;
    }
    for (i1 = 0; i1 < rows - 1; i1++)
    {
        k1 = i1;
        for (i2 = i1 + 1; i2 < rows; i2++)
        {
            if (bloodP[order[k1]] < bloodP[order[i2]])k1 = i2;
        }
        swap(order[k1], order[i1]);
    }


    if (SquashUsed == 1)
    {
        if (Sun >= 650)
        {
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] >= 100);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, GARGANTUAR, order[0], LeftLines) == 1)
                        player->PlaceZombie(GARGANTUAR, order[0]);
                    else;
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] >= 100);
                else if (attack[order[1]] < 1800)
                {
                    if (attack[order[1]] >= 20 && bloodP[order[1]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[1], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[1]);
                        else
                        {
                            if (TryPlaceZombie(player, SLED, order[1], LeftLines) == 1 && bloodZ[order[0]] >= 100)
                                player->PlaceZombie(SLED, order[1]);
                            else;
                        };
                    }
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[1]);
                        else;
                    }
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] >= 100);
                else if (attack[order[2]] < 1800)
                {
                    if (attack[order[2]] >= 20 && bloodP[order[2]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[2], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[2]);
                        else
                        {
                            if (TryPlaceZombie(player, SLED, order[2], LeftLines) == 1 && (bloodZ[order[0]] >= 100 || bloodZ[order[1]] >= 100))
                                player->PlaceZombie(SLED, order[2]);
                            else;
                        };
                    }
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[2]);
                        else;
                    }
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] >= 10);
                else if (attack[order[3]] < 1800)
                {

                    if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                        player->PlaceZombie(BUCKET, order[3]);
                    else;

                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] >= 3);
                else if (attack[order[4]] < 1800)
                {

                    if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                        player->PlaceZombie(BUCKET, order[4]);
                    else
                    {
                        if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[4]);
                        else;
                    };

                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
        }
        else if (Sun < 650 && Sun>400)
        {
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] >= 100);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, GARGANTUAR, order[0], LeftLines) == 1)
                        player->PlaceZombie(GARGANTUAR, order[0]);
                    else;
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] >= 100);
                else if (attack[order[1]] < 1800)
                {
                    if (attack[order[1]] >= 20 && bloodP[order[1]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[1], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[1]);
                        else;
                    }
                    else
                    {
                        if (bloodZ[order[1]] >= 10)
                        {
                            if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                                player->PlaceZombie(NORMAL, order[1]);
                            else;
                        }
                        else if (bloodZ[order[1]] <= 2)
                        {
                            if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                                player->PlaceZombie(BUCKET, order[1]);

                        }
                        else;
                    }
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] > 10);
                else if (attack[order[2]] < 1800)
                {
                    if (attack[order[2]] >= 20 && bloodP[order[2]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[2], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[2]);
                        else;
                    }
                    else
                    {
                        if (bloodZ[order[2]] == 10)
                        {
                            if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                                player->PlaceZombie(NORMAL, order[2]);
                            else;
                        }
                        else if (bloodZ[order[2]] <= 1)
                        {
                            if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                                player->PlaceZombie(BUCKET, order[2]);

                        }
                        else;
                    }
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] > 10);
                else if (attack[order[4]] < 1800)
                {

                    if (bloodZ[order[4]] == 10)
                    {
                        if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[4]);
                        else;
                    }
                    else if (bloodZ[order[4]] <= 1)
                    {
                        if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[4]);

                    }
                    else;

                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] > 10);
                else if (attack[order[3]] < 1800)
                {

                    if (bloodZ[order[3]] == 10)
                    {
                        if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[3]);
                        else;
                    }
                    else if (bloodZ[order[3]] <= 1)
                    {
                        if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[3]);

                    }
                    else;

                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
        }
        else if (Sun <= 400)
        {
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] >= 3);
                else if (attack[order[4]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[4]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[4], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[4]);
                        }
                    };
                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] >= 3);
                else if (attack[order[3]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[3]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[3], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[3]);
                        }
                    };
                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] >= 10);
                else if (attack[order[2]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[2]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[2], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[2]);
                        }
                    };
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] > 10);
                else if (attack[order[1]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[1]);
                        else;
                    };
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] > 10);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[0], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[0]);
                        else;
                    };
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
        }
    }


    if (SquashUsed == 0)
    {
        if (Sun >= 650)
        {
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] >= 100);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, GARGANTUAR, order[0], LeftLines) == 1)
                        player->PlaceZombie(GARGANTUAR, order[0]);
                    else;
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] >= 100);
                else if (attack[order[1]] < 1800)
                {
                    if (attack[order[1]] >= 20 && bloodP[order[1]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[1], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[1]);
                        else
                        {
                            if (TryPlaceZombie(player, SLED, order[1], LeftLines) == 1 && bloodZ[order[0]] >= 100)
                                player->PlaceZombie(SLED, order[1]);
                            else;
                        };
                    }
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[1]);
                        else;
                    }
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] >= 100);
                else if (attack[order[2]] < 1800)
                {
                    if (attack[order[2]] >= 20 && bloodP[order[2]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[2], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[2]);
                        else
                        {
                            if (TryPlaceZombie(player, SLED, order[2], LeftLines) == 1 && (bloodZ[order[0]] >= 100 || bloodZ[order[1]] >= 100))
                                player->PlaceZombie(SLED, order[2]);
                            else;
                        };
                    }
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[2]);
                        else;
                    }
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] >= 10);
                else if (attack[order[3]] < 1800)
                {

                    if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                        player->PlaceZombie(BUCKET, order[3]);
                    else;

                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] >= 3);
                else if (attack[order[4]] < 1800)
                {

                    if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                        player->PlaceZombie(BUCKET, order[4]);
                    else
                    {
                        if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[4]);
                        else;
                    };

                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
        }
        else if (Sun < 650 && Sun>400)
        {
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] >= 100);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, GARGANTUAR, order[0], LeftLines) == 1)
                        player->PlaceZombie(GARGANTUAR, order[0]);
                    else;
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] >= 100);
                else if (attack[order[1]] < 1800)
                {
                    if (attack[order[1]] >= 20 && bloodP[order[1]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[1], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[1]);
                        else;
                    }
                    else
                    {
                        if (bloodZ[order[1]] >= 10)
                        {
                            if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                                player->PlaceZombie(NORMAL, order[1]);
                            else;
                        }
                        else if (bloodZ[order[1]] <= 2)
                        {
                            if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                                player->PlaceZombie(BUCKET, order[1]);

                        }
                        else;
                    }
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] > 10);
                else if (attack[order[2]] < 1800)
                {
                    if (attack[order[2]] >= 20 && bloodP[order[2]] > 4000)
                    {
                        if (TryPlaceZombie(player, GARGANTUAR, order[2], LeftLines) == 1)
                            player->PlaceZombie(GARGANTUAR, order[2]);
                        else;
                    }
                    else
                    {
                        if (bloodZ[order[2]] == 10)
                        {
                            if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                                player->PlaceZombie(NORMAL, order[2]);
                            else;
                        }
                        else if (bloodZ[order[2]] <= 1)
                        {
                            if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                                player->PlaceZombie(BUCKET, order[2]);

                        }
                        else;
                    }
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] > 10);
                else if (attack[order[4]] < 1800)
                {

                    if (bloodZ[order[4]] == 10)
                    {
                        if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[4]);
                        else;
                    }
                    else if (bloodZ[order[4]] <= 1)
                    {
                        if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[4]);

                    }
                    else;

                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] > 10);
                else if (attack[order[3]] < 1800)
                {

                    if (bloodZ[order[3]] == 10)
                    {
                        if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                            player->PlaceZombie(NORMAL, order[3]);
                        else;
                    }
                    else if (bloodZ[order[3]] <= 1)
                    {
                        if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[3]);

                    }
                    else;

                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
        }
        else if (Sun <= 400)
        {
            if (LeftLines[order[4]] == 1)
            {
                if (bloodZ[order[4]] >= 3);
                else if (attack[order[4]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[4], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[4]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[4], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[4]);
                        }
                    };
                }
                else if (attack[order[4]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[4], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[4]);
                    else;
                }
            }
            if (LeftLines[order[3]] == 1)
            {
                if (bloodZ[order[3]] >= 3);
                else if (attack[order[3]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[3], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[3]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[3], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[3]);
                        }
                    };
                }
                else if (attack[order[3]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[3], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[3]);
                    else;
                }
            }
            if (LeftLines[order[2]] == 1)
            {
                if (bloodZ[order[2]] >= 10);
                else if (attack[order[2]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[2], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[2]);
                        else
                        {
                            if (TryPlaceZombie(player, POLEVAULT, order[2], LeftLines) == 1)
                                player->PlaceZombie(POLEVAULT, order[2]);
                        }
                    };
                }
                else if (attack[order[2]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[2], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[2]);
                    else;
                }
            }
            if (LeftLines[order[1]] == 1)
            {
                if (bloodZ[order[1]] > 10);
                else if (attack[order[1]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[1], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[1]);
                        else;
                    };
                }
                else if (attack[order[1]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[1], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[1]);
                    else;
                }
            }
            if (LeftLines[order[0]] == 1)
            {
                if (bloodZ[order[0]] > 10);
                else if (attack[order[0]] < 1800)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else
                    {
                        if (TryPlaceZombie(player, BUCKET, order[0], LeftLines) == 1)
                            player->PlaceZombie(BUCKET, order[0]);
                        else;
                    };
                }
                else if (attack[order[0]] == 0)
                {
                    if (TryPlaceZombie(player, NORMAL, order[0], LeftLines) == 1)
                        player->PlaceZombie(NORMAL, order[0]);
                    else;
                }
            }
        }
    }
}