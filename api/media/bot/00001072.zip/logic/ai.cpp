
#include "ai.h"

#include <iostream>

#include <stdlib.h>

#include <math.h>

#include <cstring>

#include <vector>

#include <queue>

using namespace std;
#define ZOMBIE_KIND 5

#define PLANT_KIND 6

#define TOTAL_TIME 2000

#define COLUMN 10

#define ROW 5

#define _includeaih enum PlantType { NOPLANT = 0, SUNFLOWER, WINTERPEASHOOTER, 
#define _includeiostream PEASHOOTER, SMALLNUT, PEPPER, SQUASH }; enum ZombieType { 
#define _includestdlibh NOZOMBIE = 0, NORMAL, BUCKET, POLEVAULT, SLED, GARGANTUAR 
#define _includemathh }; const int plantCost[7] = {0, 50, 400, 
#define _includecstring 100, 50, 125, 50}; const int plantCd[7] = 
#define _includevector {0, 10, 30, 10, 40, 60, 60}; const 
#define _includequeue int zombieCost[6] = {0, 50, 125, 125, 300, 
#define _usingnamespacestd 300}; const int zombieCd[6] = {0, 15, 20, 
#define _defineZOMBIEKIND5 20, 25, 25}; const int plantHp[7] = {0, 
#define _definePLANTKIND6 300, 300, 300, 4000, 0, 0}; const int 
#define _defineTOTALTIME2000 plantDps[7] = {0, 0, 20, 10, 0, 0, 
#define _defineCOLUMN10 0}; int zombieHp[6] = {0, 270, 820, 200, 
#define _defineROW5 1600, 3000}; struct Sunflower { int row, column, 
#define _FILEfile cd; Sunflower(int Row, int Column) { cd = 
#define _errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw 24; row = Row, column = Column; } 
#define _enumPlantTypeNOPLANT0 }; int *zombieNum(int ***zombies) { int cnt[7] = 
#define _SUNFLOWER {}, *p = cnt; for (int i = 
#define _WINTERPEASHOOTER 0; i < 5; i++) for (int j 
#define _PEASHOOTER = 0; j < 10; j++) for (int 
#define _SMALLNUT k = 0; k < 10; k++) { 
#define _PEPPER if (zombies[i][j][k] = -1) break; else cnt[zombies[i][j][k]]++; } 
#define _SQUASHenumZombieTypeNOZOMBIE0 return p; } int *zombieNum(int zombies[5][10][10]) { int 
#define _NORMAL cnt[7] = {}, *p = cnt; for (int 
#define _BUCKET i = 0; i < 5; i++) for 
#define _POLEVAULT (int j = 0; j < 10; j++) 
#define _SLED for (int k = 0; k < 10; 
#define _GARGANTUAR k++) { if (zombies[i][j][k] = -1) break; else 
#define _zrfscodestarts cnt[zombies[i][j][k]]++; } return p; } struct Zombie { 
#define _constintplantCost70504001005012550 int num; int hp; int coX, coY; Zombie(int 
#define _constintplantCd70103010406060 Num, int row) { coX = row, coY 
#define _constintzombieCost6050125125300300 = 9; hp = zombieHp[Num]; num = Num; 
#define _constintzombieCd601520202525 } }; struct Plant { int num; int 
#define _constintplantHp70300300300400000 hp; int coX, coY; int dps; Plant(int Num, 
#define _constintplantDps7002010000 int row, int col) { num = Num; 
#define _intzombieHp6027082020016003000 coX = row, coY = col; hp = 
#define _structSunflowerintrowcolumncd plantHp[Num]; dps = plantDps[Num]; } }; struct Actionlist 
#define _SunflowerintRowintColumncd24 { int plantPlace[5][10] = {}, zombiePlace[5] = {}; 
#define _rowRowcolumnColumn int plantRemove[5][10] = {}; }; class Game { 
#define _intzombieNumintzombiesintcnt7pcnt public: int time, sun, moon; int plants[5][10], zombies[5][10][10]; 
#define _forinti0i5i int cdPlant[7], cdZombie[6]; int dps[5]; int flagPlant[7], flagZombie[6]; 
#define _forintj0j10j int flagShovel[5][10]; int zombieCostPerRow[5]; vector<Sunflower> sunFlowers; vector<Plant> vectorPlants; 
#define _forintk0k10kifzombiesijk1 vector<Zombie> vectorZombies; void plantremove(int i, int j, IPlayer 
#define _break *player) { player->removePlant(i, j); flagShovel[i][j] = 1; } 
#define _else void maintain(IPlayer *player) { time++; int **Plants = 
#define _cntzombiesijkreturnp player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); moon += int(time 
#define _zombies / 200.0) + 1; for (int i = 
#define _intzombieNumintzombies51010intcnt7pcnt 0; i < 5; i++) for (int j 
#define _forinti0i5i_ = 0; j < 10; j++) { if 
#define _forintj0j10j_ (plants[i][j] > Plants[i][j] && plants[i][j] != PEPPER && 
#define _forintk0k10kifzombiesijk1_ plants[i][j] != SQUASH) { if (flagShovel[i][j] == 1) 
#define _break_ { flagShovel[i][j] = 0; } else { int 
#define _else_ num = plants[i][j]; moon += plantCost[num] / 5 
#define _cntzombiesijkreturnpstructZombieintnum + int(sqrt(plantHp[num])); dps[i] -= plantDps[num]; if (num == 
#define _inthp 1) { for (int k = 0; k 
#define _intcoXcoY < sunFlowers.size(); k++) if (sunFlowers[k].row == i && 
#define _ZombieintNumintrowcoXrowcoY9 sunFlowers[k].column == j) { sunFlowers.erase(sunFlowers.begin() + k); break; 
#define _hpzombieHpNum } } } } else if (plants[i][j] < 
#define _numNumintspeedstructPlantintnum Plants[i][j]) { int num = Plants[i][j]; sun -= 
#define _inthp_ plantCost[num]; dps[i] += plantDps[num]; cdPlant[num] = plantCd[num]; flagPlant[num] 
#define _intcoXcoY_ = 0; if (num == 1) { sun 
#define _intdps += 25; sunFlowers.push_back(Sunflower(i, j)); } vectorPlants.push_back(Plant(Plants[i][j], i, j)); 
#define _PlantintNumintrowintcolnumNum } plants[i][j] = Plants[i][j]; int flag = 0; 
#define _coXrowcoYcol for (int k = 0; k < vectorPlants.size(); 
#define _hpplantHpNum k++) { if (vectorPlants[k].coX == i && vectorPlants[k].coY 
#define _dpsplantDpsNum == j) { if (vectorPlants[k].num != Plants[i][j]) { 
#define _structActionlistintplantPlace510zombiePlace5 vectorPlants.erase(vectorPlants.begin() + k); k--; if (Plants[i][j] != 0) 
#define _intplantRemove510classGamepublic vectorPlants.push_back(Plant(Plants[i][j], i, j)); } flag = 1; break; 
#define _inttimesunmoon } } if (flag == 0 && Plants[i][j] 
#define _intplants510zombies51010 != 0) vectorPlants.push_back(Plant(Plants[i][j], i, j)); } int *z 
#define _intcdPlant7cdZombie6tick = zombieNum(zombies), *Z = zombieNum(Zombies); for (int i 
#define _intdps5dps = 0; i < 5; i++) { int 
#define _intflagPlant7flagZombie610 rowZombie[6] = {}, RowZombie[6] = {}; for (int 
#define _intflagShovel51010 j = 0; j < 10; j++) for 
#define _intzombieCostPerRow5 (int k = 0; k < 10; k++) 
#define _vectorSunflowersunFlowers { if (zombies[i][j][k] = -1) break; else rowZombie[zombies[i][j][k]]++; 
#define _vectorPlantvectorPlants } for (int j = 0; j < 
#define _vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij 10; j++) for (int k = 0; k 
#define _flagShovelij1voidmaintainIPlayerplayertime < 10; k++) { if (Zombies[i][j][k] = -1) 
#define _intPlantsplayerCampgetCurrentPlantscurrentPlants break; else RowZombie[Zombies[i][j][k]]++; ; } for (int j 
#define _intZombiesplayerCampgetCurrentZombiescurrentZombies = 0; j < 6; j++) if (RowZombie[j] 
#define _mooninttime20001 > rowZombie[j]) zombieCostPerRow[i] += zombieCost[j]; } for (int 
#define _forinti0i5i__ i = 0; i < 7; i++) { 
#define _forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij if (z[i] < Z[i]) { } else if 
#define _moonplantCostnum5intsqrtplantHpnum (z[i] > Z[i]) { moon -= zombieCost[i]; cdZombie[i] 
#define _dpsiplantDpsnum = zombieCd[i]; flagZombie[i] = 0; } } for 
#define _ifnum1forintk0ksunFlowerssizek (int i = 0; i < 5; i++) 
#define _ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink { for (int j = 0; j < 
#define _break__ 10; j++) { int k = 0; while 
#define _elseifplantsijPlantsijintnumPlantsij (Zombies[i][j][k] != -1) { zombies[i][j][k] = Zombies[i][j][k]; k++; 
#define _sunplantCostnum } } } vector<int> have_erased; for (int i 
#define _dpsiplantDpsnum_ = 0; i < vectorZombies.size(); i++) { int 
#define _cdPlantnumplantCdnum have_erased_flag = 0; for (int z = 0; 
#define _flagPlantnum0 z < have_erased.size(); z += 2) { if 
#define _ifnum1sun25 (vectorZombies[i].coX == have_erased[z] && vectorZombies[i].coY == have_erased[z + 
#define _sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij 1]) { have_erased_flag = 1; break; } } 
#define _intflag0 if (Plants[vectorZombies[i].coX][vectorZombies[i].coY] != SMALLNUT || have_erased_flag == 1) 
#define _forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink { continue; } else { int num = 
#define _k vectorZombies[i].num; int original_num_of_this_kind = 0, now_num_of_this_kind = 0; 
#define _ifPlantsij0 int k = 0; while (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1) 
#define _vectorPlantspushbackPlantPlantsijijflag1 { if (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num) { original_num_of_this_kind++; } 
#define _break___ k++; } k = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != 
#define _ifflag0Plantsij0 -1) { if (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num) { now_num_of_this_kind++; 
#define _vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies } k++; } if (original_num_of_this_kind - now_num_of_this_kind > 
#define _forinti0i5iintrowZombie6RowZombie6 0) { vector<int> serialNum; for (int j = 
#define _forintj0j10j__ 0; j < vectorZombies.size(); j++) { if (vectorZombies[j].num 
#define _forintk0k10kifzombiesijk1__ == num && vectorZombies[i].coY == vectorZombies[j].coY && vectorZombies[i].coX 
#define _break____ == vectorZombies[j].coX) { serialNum.push_back(j); } } if (now_num_of_this_kind 
#define _else__ == 0) { for (int i = serialNum.size() 
#define _rowZombiezombiesijkforintj0j10j - 1; i >= 0; i--) { vectorZombies.erase(serialNum[i] 
#define _forintk0k10kifZombiesijk1 + vectorZombies.begin()); } } if (original_num_of_this_kind - now_num_of_this_kind 
#define _break_____ == 1) { int small_hp = 5000, small_hp_num 
#define _else___ = 0; for (int k = 0; k 
#define _RowZombieZombiesijk < serialNum.size(); k++) { if (small_hp > vectorZombies[serialNum[k]].hp) 
#define _forintj0j6j { small_hp = vectorZombies[serialNum[k]].hp; small_hp_num = k; } 
#define _ifRowZombiejrowZombiej } vectorZombies.erase(small_hp_num + vectorZombies.begin()); } have_erased.push_back(vectorZombies[i].coX); have_erased.push_back(vectorZombies[i].coY); } 
#define _zombieCostPerRowizombieCostjforinti0i7iifziZi } } for (int i = 0; i 
#define _zombiedie < vectorZombies.size(); i++) { int num = vectorZombies[i].num; 
#define _elseifziZimoonzombieCosti int k = 0; int flag_self = 0; 
#define _cdZombieizombieCdi int flag_near = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1) 
#define _flagZombiei0 { if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { break; } 
#define _zombieplaced else { flag_self = 1; } } k 
#define _forinti0i5iforintj0j10jintk0 = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY - 1][k] != -1) 
#define _whileZombiesijk1zombiesijkZombiesijk { if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { vectorZombies[i].coY--; } 
#define _k_ else { flag_near = 1; } } if 
#define _vectorinthaveerased (flag_self == 1 && flag_near == 1) { 
#define _forinti0ivectorZombiessizeiinthaveerasedflag0 vectorZombies.erase(vectorZombies.begin() + i); i--; } } for (int 
#define _forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1 i = 0; i < 7; i++) { 
#define _breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum if (cdPlant[i] > 0) cdPlant[i]--; if (cdPlant[i] == 
#define _intoriginalnumofthiskind0nownumofthiskind0 0) flagPlant[i] = 1; } for (int i 
#define _intk0 = 0; i < 6; i++) { if 
#define _whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0 (cdZombie[i] > 0) cdZombie[i]--; if (cdZombie[i] == 0) 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum flagZombie[i] = 1; } for (int i = 
#define _forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj 0; i < sunFlowers.size(); i++) { if (sunFlowers[i].cd 
#define _ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin > 0) sunFlowers[i].cd--; if (sunFlowers[i].cd == 0) { 
#define _iforiginalnumofthiskindnownumofthiskind1 sun += 25; sunFlowers[i].cd = 24; } } 
#define _findthesmallesthp } Game() { time = 0; sun = 
#define _intsmallhp5000smallhpnum0 400, moon = 300; for (int i = 
#define _forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp 0; i < 5; i++) for (int j 
#define _smallhpnumk = 0; j < 10; j++) plants[i][j] = 
#define _vectorZombieserasesmallhpnumvectorZombiesbegin 0, flagShovel[i][j] = 0; for (int i = 
#define _haveerasedpushbackvectorZombiesicoX 0; i < 5; i++) for (int j 
#define _haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum = 0; j < 10; j++) for (int 
#define _intk0_ k = 0; k < 10; k++) zombies[i][j][k] 
#define _intflagself0 = 0; for (int i = 0; i 
#define _intflagnear0 < 5; i++) dps[i] = 0, zombieCostPerRow[i] = 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1 0; for (int i = 0; i < 
#define _k0 7; i++) cdPlant[i] = 0, flagPlant[i] = 1; 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1 for (int i = 0; i < 6; 
#define _ifflagself1flagnear1vectorZombieserasevectorZombiesbegini i++) cdZombie[i] = 0, flagZombie[i] = 1; } 
#define _iforinti0i7iifcdPlanti0 Game tranState(Actionlist q, IPlayer *player); }; Game Game::tranState(Actionlist 
#define _cdPlanti q, IPlayer *player) { Game newGame; { newGame.time 
#define _ifcdPlanti0 = this->time, newGame.sun = this->sun, newGame.moon = this->moon; 
#define _flagPlanti1 for (int i = 0; i < 5; 
#define _forinti0i6iifcdZombiei0 i++) for (int j = 0; j < 
#define _cdZombiei 10; j++) newGame.plants[i][j] = this->plants[i][j], flagShovel[i][j] = this->flagShovel[i][j]; 
#define _ifcdZombiei0 for (int i = 0; i < 5; 
#define _flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0 i++) for (int j = 0; j < 
#define _sunFlowersicd 10; j++) for (int k = 0; k 
#define _ifsunFlowersicd0sun25 < 10; k++) newGame.zombies[i][j][k] = this->zombies[i][j][k]; for (int 
#define _sunFlowersicd24ticktick i = 0; i < 7; i++) newGame.cdPlant[i] 
#define _Gametime0 = this->cdPlant[i], newGame.flagPlant[i] = this->flagPlant[i]; for (int i 
#define _sun400moon300 = 0; i < 6; i++) newGame.cdZombie[i] = 
#define _forinti0i5i___ this->cdZombie[i], newGame.flagZombie[i] = this->flagZombie[i]; for (int i = 
#define _forintj0j10j___ 0; i < 5; i++) newGame.dps[i] = this->dps[i], 
#define _plantsij0flagShovelij0 newGame.zombieCostPerRow[i] = this->zombieCostPerRow[i]; } for (int i = 
#define _forinti0i5i____ 0; i < 5; i++) for (int j 
#define _forintj0j10j____ = 0; j < 10; j++) { if 
#define _forintk0k10k (q.plantPlace[i][j] > 0) { int num = q.plantPlace[i][j]; 
#define _zombiesijk0 newGame.sun -= plantCost[num]; newGame.cdPlant[num] = plantCd[num]; newGame.flagPlant[num] = 
#define _forinti0i5i_____ 0; newGame.dps[i] += plantDps[num]; newGame.plants[i][j] = num; } 
#define _dpsi0zombieCostPerRowi0 if (q.zombiePlace[i] > 0) { int num = 
#define _forinti0i7i q.zombiePlace[i]; newGame.moon -= zombieCost[num]; newGame.cdZombie[num] = zombieCd[num]; newGame.flagZombie[num] 
#define _cdPlanti0flagPlanti1 = 0; } } newGame.maintain(player); return newGame; } 
#define _forinti0i6i class Zombies_num { public: int normal; int bucket; 
#define _cdZombiei0flagZombiei1 int polevault; int sled; int gargantuar; int total_num; 
#define _initialize Zombies_num() { this->normal = this->bucket = this->polevault = 
#define _GametranStateActionlistqIPlayerplayerq this->sled = this->gargantuar = this->total_num = 0; } 
#define _globalstatus void compute_num(int ***zombies, int rows, int columns) { 
#define _GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon int num = 0; for (int i = 
#define _forinti0i5i______ 0; i < rows; i++) { for (int 
#define _forintj0j10j_____ j = 0; j < columns; j++) { 
#define _newGameplantsijthisplantsijflagShovelijthisflagShovelij int k = 0; while (zombies[i][j][k] != -1) 
#define _forinti0i5i_______ { switch (zombies[i][j][k]) { case NORMAL: this->normal++; break; 
#define _forintj0j10j______ case BUCKET: this->bucket++; break; case POLEVAULT: this->polevault++; break; 
#define _forintk0k10k_ case SLED: this->sled++; break; case GARGANTUAR: this->gargantuar++; break; 
#define _newGamezombiesijkthiszombiesijk } num++; k++; } } } } }; 
#define _forinti0i7i_ class Plants_num { public: int sunflower; int winterpeashooter; 
#define _newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti int peashooter; int smallnut; int pepper; int squash; 
#define _forinti0i6i_ Plants_num() { this->sunflower = this->winterpeashooter = this->peashooter = 
#define _newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei this->smallnut = this->pepper = this->squash = 0; } 
#define _forinti0i5i________ void compute_num(int **plants, int rows, int columns) { 
#define _newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame for (int i = 0; i < rows; 
#define _forinti0i5i_________ i++) for (int j = 0; j < 
#define _forintj0j10jifqplantPlaceij0intnumqplantPlaceij columns; j++) { switch (plants[i][j]) { case SUNFLOWER: 
#define _newGamesunplantCostnum this->sunflower++; break; case WINTERPEASHOOTER: this->winterpeashooter++; break; case PEASHOOTER: 
#define _newGamecdPlantnumplantCdnum this->peashooter++; break; case SMALLNUT: this->smallnut++; break; case PEPPER: 
#define _newGameflagPlantnum0 this->pepper++; break; case SQUASH: this->squash++; break; } } 
#define _newGamedpsiplantDpsnum } }; int calculate_zombie_nums(int ***zombies, int rows, int 
#define _newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei columns) { int num = 0; for (int 
#define _newGamemoonzombieCostnum i = 0; i < rows; i++) { 
#define _newGamecdZombienumzombieCdnum for (int j = 0; j < columns; 
#define _newGameflagZombienum0 j++) { int k = 0; while (zombies[i][j][k] 
#define _newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic != -1) { num++; k++; } } } 
#define _intnormal return num; } int choose_Lines_not_Broken(int *Left_lines, int **plants, 
#define _intbucket int column) { for (int i = 0; 
#define _intpolevault ; i++) { if (Left_lines[i] == 1 && 
#define _intsled plants[i][column] == NOPLANT) return i; } return rand() 
#define _intgargantuar % ROW; } typedef struct pos_and_value { int 
#define _inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0 pos[2]; double value; } pos_and_value; class value_plant_func { 
#define _forinti0irowsiforintj0jcolumnsjintk0 public: double noplant; pos_and_value sunflower; pos_and_value peashooter; pos_and_value 
#define _whilezombiesijk1switchzombiesijkcaseNORMAL winterpeashooter; pos_and_value smallnut; pos_and_value pepper; pos_and_value squash; int 
#define _thisnormal generating_row; IPlayer *player; Game game; int NotBrokenLinesNum; int 
#define _break______ KillZombiesScore; int LeftPlants; int Score; int time; int 
#define _caseBUCKET *PlaceCD; int **Plants; int ***Zombies; int *LeftLines; int 
#define _thisbucket Sun; int zombie_nums; value_plant_func(int NotBrokenLinesNum, int KillZombiesScore, int 
#define _break_______ Score, int time, int *PlaceCD, int **Plants, int 
#define _casePOLEVAULT ***Zombies, int *LeftLines, int Sun, IPlayer *player, Game 
#define _thispolevault game) { this->NotBrokenLinesNum = NotBrokenLinesNum; this->KillZombiesScore = KillZombiesScore; 
#define _break________ this->Score = Score; this->time = time; this->PlaceCD = 
#define _caseSLED PlaceCD; this->Plants = Plants; this->Zombies = Zombies; this->LeftLines 
#define _thissled = LeftLines; this->Sun = Sun; this->player = player; 
#define _break_________ this->generating_row = 1; this->game = game; } int 
#define _caseGARGANTUAR **sum_plants_per_row() { int **plants_num_format = (int **)malloc(ROW * 
#define _thisgargantuar sizeof(int *)); for (int i = 0; i 
#define _breaknum < ROW; i++) { plants_num_format[i] = (int *)malloc(sizeof(int) 
#define _kclassPlantsnumpublic * PLANT_KIND); memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int)); } 
#define _intsunflower for (int i = 0; i < ROW; 
#define _intwinterpeashooter i++) { for (int j = 0; j 
#define _intpeashooter < COLUMN; j++) { switch (this->Plants[i][j]) { case 
#define _intsmallnut SUNFLOWER: plants_num_format[i][SUNFLOWER]++; break; case WINTERPEASHOOTER: plants_num_format[i][WINTERPEASHOOTER]++; break; case 
#define _intpepper PEASHOOTER: plants_num_format[i][PEASHOOTER]++; break; case SMALLNUT: plants_num_format[i][SMALLNUT]++; break; case 
#define _intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi PEPPER: plants_num_format[i][PEPPER]++; break; case SQUASH: plants_num_format[i][SQUASH]++; break; } 
#define _forintj0jcolumnsjswitchplantsijcaseSUNFLOWER } } return plants_num_format; } void beginning_operation() { 
#define _thissunflower if (this->time == 3) { this->player->PlacePlant(SUNFLOWER, this->generating_row, 1); 
#define _break__________ } } void GameState_2_400() { if (this->time > 
#define _caseWINTERPEASHOOTER 2 && this->time < 150) { int alarming_flag 
#define _thiswinterpeashooter = -1; for (int i = 0; i 
#define _break___________ < ROW; i++) { if (i != this->generating_row) 
#define _casePEASHOOTER { if (time < 30) for (int j 
#define _thispeashooter = 0; j < COLUMN; j++) { int 
#define _break____________ k = 0; while (this->Zombies[i][j][k] != -1) { 
#define _caseSMALLNUT if (j < 3) alarming_flag = i; if 
#define _thissmallnut (this->Sun >= 70) switch (this->Zombies[i][j][k]) { case POLEVAULT: 
#define _break_____________ case SLED: this->player->PlacePlant(SQUASH, i, (j - 1 < 
#define _casePEPPER 0 ? 0 : j - 1)); break; 
#define _thispepper case BUCKET: if (this->PlaceCD[SQUASH] == 0) this->player->PlacePlant(SQUASH, i, 
#define _break______________ (j - 1 < 0 ? 0 : 
#define _caseSQUASH j - 1)); else if (j <= 5) 
#define _thissquash this->player->PlacePlant(PEPPER, i, (j - 1 < 0 ? 
#define _breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0 0 : j - 1)); break; case GARGANTUAR: 
#define _forinti0irowsiforintj0jcolumnsjintk0_ this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 
#define _whilezombiesijk1num 0 : j - 1)); if (j < 
#define _kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT 4) this->player->PlacePlant(PEPPER, i, 8); break; case NORMAL: this->player->PlacePlant(PEASHOOTER, 
#define _returnireturnrandROWtypedefstructposandvalueintpos2 i, 0); this->player->PlacePlant(SMALLNUT, i, (j - 1 < 
#define _doublevalue 0 ? 0 : j - 1)); break; 
#define _posandvalueclassvalueplantfuncpublic } k++; } } } else for (int 
#define _doublenoplant j = 0; j < COLUMN; j++) { 
#define _posandvaluesunflower int k = 0; while (this->Zombies[this->generating_row][j][k] != -1) 
#define _posandvaluepeashooter { if (this->Sun >= 70) switch (this->Zombies[this->generating_row][j][k]) { 
#define _posandvaluewinterpeashooter case POLEVAULT: case BUCKET: case SLED: this->player->PlacePlant(SQUASH, this->generating_row, 
#define _posandvaluesmallnut 5); break; case GARGANTUAR: this->player->PlacePlant(SQUASH, this->generating_row, (j - 
#define _posandvaluepepper 1 < 0 ? 0 : j - 
#define _posandvaluesquash 1)); if (j < 4) this->player->PlacePlant(PEPPER, this->generating_row, 8); 
#define _intgeneratingrow break; case NORMAL: this->player->PlacePlant(SMALLNUT, this->generating_row, (j - 1 
#define _IPlayerplayer < 0 ? 1 : j - 1)); 
#define _Gamegame break; } if (j < (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 
#define _doublevaluePLANTKIND1 + 1 && this->PlaceCD[SQUASH - 1] != 0) 
#define _intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum { this->player->PlacePlant(PEPPER, i, 8); } k++; } } 
#define _intKillZombiesScore } int num = 0, pos = 0; 
#define _intLeftPlants for (int i = 0; i < COLUMN; 
#define _intScore i++) { if (Plants[this->generating_row][i] == SUNFLOWER) { num++; 
#define _inttime } if (Plants[this->generating_row][i] != NOPLANT) { pos = 
#define _intPlaceCD i; } } if (num < 5) this->player->PlacePlant(SUNFLOWER, 
#define _intPlants this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1); if (alarming_flag != -1) 
#define _intZombies { if (this->PlaceCD[SQUASH - 1] == 0) { 
#define _intLeftLines this->player->PlacePlant(SQUASH, alarming_flag, COLUMN - 1); } else this->player->PlacePlant(PEPPER, 
#define _intSun alarming_flag, COLUMN - 1); } } } void 
#define _intzombienumsvalueplantfuncintNotBrokenLinesNum GameState_50_200() { if (this->time > 50 && this->time 
#define _intKillZombiesScore_ < 200) { if (this->Sun >= 400) this->player->PlacePlant(WINTERPEASHOOTER, 
#define _intScore_ this->generating_row, 0); } } void value_peashooter_origin() { if 
#define _inttime_ (this->time > 10) if (this->PlaceCD[PEASHOOTER - 1] == 
#define _intPlaceCD_ 0) { double **loss = (double **)malloc(ROW * 
#define _intPlants_ sizeof(double *)); for (int i = 0; i 
#define _intZombies_ < ROW; i++) { loss[i] = (double *)malloc(COLUMN 
#define _intLeftLines_ * sizeof(double)); memset(loss[i], 0, COLUMN * sizeof(double)); } 
#define _intSunIPlayerplayer double max = -10000, max_index[2] = {0, 0}; 
#define _GamegamethisNotBrokenLinesNumNotBrokenLinesNum for (int i = 0; i < ROW; 
#define _thisKillZombiesScoreKillZombiesScore i++) for (int j = 0; j < 
#define _thisScoreScore COLUMN; j++) { if (this->Plants[i][j] != NOPLANT) loss[i][j] 
#define _thistimetime = -10000; else { double row = (i 
#define _thisPlaceCDPlaceCD == this->generating_row ? -10 : 0); loss[i][j] += 
#define _thisPlantsPlants row; double zombie[ZOMBIE_KIND] = {6, -10, -2, -40, 
#define _thisZombiesZombies -20}; for (int column0 = 0; j < 
#define _thisLeftLinesLeftLines COLUMN; j++) { int k = 0; while 
#define _thisSunSun (Zombies[i][column0][k] != -1) { loss[i][j] += zombie[Zombies[i][column0][k] - 
#define _thisplayerplayer 1] / (+COLUMN - j); k++; } } 
#define _thisgeneratingrow1 double plant[PLANT_KIND] = {2, 0, -2, 5, 2, 
#define _thisgamegameintsumplantsperrow 0}; for (int column0 = 0; j < 
#define _rowsplantskindnumperrow COLUMN; j++) { if (this->Plants[i][column0] != NOPLANT) loss[i][j] 
#define _intplantsnumformatintmallocROWsizeofint += plant[this->Plants[i][column0]] * (1 + (column0 - COLUMN 
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND / 2) / 40); } double time_rate = 
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER 30; loss[i][j] += time_rate * (1 / (1 
#define _plantsnumformatiSUNFLOWER + exp((+this->time - TOTAL_TIME / 5) / 600)) 
#define _break_______________ - 0.5); } if (max < loss[i][j]) { 
#define _caseWINTERPEASHOOTER_ max_index[0] = i; max_index[1] = j; } } 
#define _plantsnumformatiWINTERPEASHOOTER this->peashooter.pos[0] = max_index[0]; this->peashooter.pos[1] = max_index[1]; this->peashooter.value = 
#define _break________________ max; } } bool have_type_of_zombies(int *zombie, int type) 
#define _casePEASHOOTER_ { int k = 0; while (zombie[k] != 
#define _plantsnumformatiPEASHOOTER -1) { if (zombie[k] == type) return true; 
#define _break_________________ k++; } return false; } int search_for_nearest_zombie(int ***zombie, 
#define _caseSMALLNUT_ int row, int column) { int nearest = 
#define _plantsnumformatiSMALLNUT 100; for (int j = 0; j < 
#define _break__________________ COLUMN; j++) { int k = 0; while 
#define _casePEPPER_ (Zombies[row][j][k] != -1) { if (nearest > j 
#define _plantsnumformatiPEPPER - column) nearest = j - column; k++; 
#define _break___________________ } } return nearest; } void judge_Lines_not_broken(double *final_choice) 
#define _caseSQUASH_ { for (int i = 0; i < 
#define _plantsnumformatiSQUASH ROW; i++) { if (this->LeftLines[i] == 0) { 
#define _breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1 final_choice[i] = -100000; } } } void value_peashooter0() 
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1 { if (this->time > 30) { if (this->PlaceCD[PEASHOOTER 
#define _voidGameState250ifthistime2thistime200intalarmingflag1 - 1] == 0) { for (int i 
#define _forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0 = 0; i < ROW; i++) { if 
#define _whilethisZombiesijk1ifj3 (LeftLines[i] == 1) { for (int j = 
#define _alarmingflagi 0; j < COLUMN; j++) { int k 
#define _ifthisSun70 = 0; while (Zombies[i][j][k] != -1) { k++; 
#define _switchthisZombiesijkcasePOLEVAULT } if (k == 1 && Zombies[i][j][0] == 
#define _caseSLED_ NORMAL && j >= COLUMN - 2) { 
#define _thisplayerPlacePlantSQUASHij100j1 this->player->PlacePlant(PEASHOOTER, i, 0); } else if (k > 
#define _break____________________ 0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) && 
#define _caseBUCKET_ Sun < 400 && time < 500 && 
#define _ifthisPlaceCDSQUASH0 j < 5) { int start = 0; 
#define _thisplayerPlacePlantSQUASHij100j1_ while (Plants[i][start] != NOPLANT) { start++; } if 
#define _elseifj3 (search_for_nearest_zombie(Zombies, i, start) >= 1) { player->PlacePlant(PEASHOOTER, i, 
#define _thisplayerPlacePlantPEPPERij100j1 start); } } } } } } } 
#define _break_____________________ } void value_peashooter() { double score[5] = {0, 
#define _caseGARGANTUAR_ 0, 0, 0, 0}; double plant_cost[7] = {0, 
#define _thisplayerPlacePlantSQUASHij100j1__ 10, -6, -8, 15, 10, 0}; judge_Lines_not_broken(score); for 
#define _ifj4 (int i = 0; i < ROW; i++) 
#define _thisplayerPlacePlantPEPPERi8 { for (int j = 0; j < 
#define _break______________________ COLUMN; j++) { double distance_cost = 1; switch 
#define _caseNORMAL (Plants[i][j]) { case SUNFLOWER: distance_cost *= 1 + 
#define _thisplayerPlacePlantPEASHOOTERi1 j / 100; } score[i] += plant_cost[Plants[i][j]] * 
#define _thisplayerPlacePlantSMALLNUTij100j1 distance_cost; } } double zombie_cost[5] = {10, 5, 
#define _breakkelse -5, -20, -20}; for (int i = 0; 
#define _forintj0jCOLUMNjintk0 i < ROW; i++) { for (int j 
#define _whilethisZombiesthisgeneratingrowjk1ifthisSun70 = 0; j < COLUMN; j++) { int 
#define _switchthisZombiesthisgeneratingrowjk k = 0; while (Zombies[i][j][k] != -1) { 
#define _casePOLEVAULT_ double distance_cost = 1; switch (Zombies[i][j][k]) { case 
#define _caseBUCKET__ NORMAL: distance_cost = 1 - j / 30; 
#define _caseSLED__ } score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost; 
#define _thisplayerPlacePlantSQUASHthisgeneratingrow5 k++; } } } int *serial_num = rank(score, 
#define _break_______________________ ROW); int i = 0; for (; i 
#define _caseGARGANTUAR__ < 10; i++) { if (Plants[serial_num[0]][i] == NOPLANT) 
#define _thisplayerPlacePlantSQUASHthisgeneratingrowj100j1 break; } if (i <= 3) { if 
#define _ifj4_ (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) || 
#define _thisplayerPlacePlantPEPPERthisgeneratingrow8 have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR))) player->PlacePlant(PEASHOOTER, 
#define _break________________________ serial_num[0], i); } free(serial_num); } int *rank(double *array, 
#define _caseNORMAL_ int len) { double max = array[0]; int 
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k *serial_num = (int *)malloc(len * sizeof(int)); for (int 
#define _thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1 i = 0; i < len; i++) { 
#define _ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else serial_num[i] = i; } for (int i = 
#define _thisplayerPlacePlantPEPPERalarmingflagCOLUMN1 0; i < len - 1; i++) { 
#define _voidGameState50200ifthistime50thistime200ifthisSun400 for (int j = 0; j < len 
#define _thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0 - 1; j++) { if (array[j] < array[j 
#define _voidvaluepeashooteroriginifthistime50 + 1]) { double swap = array[j]; array[j] 
#define _ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble = array[j + 1]; array[j + 1] = 
#define _forinti0iROWilossidoublemallocCOLUMNsizeofdouble swap; int serial_swap = serial_num[j]; serial_num[j] = serial_num[j 
#define _memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200 + 1]; serial_num[j + 1] = serial_swap; } 
#define _forinti0iROWi } } return serial_num; } void value_sunflower() { 
#define _forintj0jCOLUMNjifthisPlantsijNOPLANT int sunflower_num = 0; for (int i = 
#define _lossij10000 0; i < ROW; i++) for (int j 
#define _else____ = 0; j < COLUMN; j++) { if 
#define _doublerowithisgeneratingrow100 (Plants[i][j] == SUNFLOWER) { sunflower_num++; } } double 
#define _lossijrow b = -0.01 * (this->time - 300) * 
#define _doublecolumn25 (this->time - 300) / 10000 + 1; if 
#define _lossijcolumnexpcolumn10 (this->time > 9 && sunflower_num < 9 + 
#define _doublezombieZOMBIEKIND61024020 (b < 0 ? 0 : b) && 
#define _forintcolumn00jCOLUMNjintk0 this->Sun < 1000) if (this->PlaceCD[SUNFLOWER - 1] == 
#define _whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj 0) { double score[5] = {0, 0, 0, 
#define _k__ 0, 0}; judge_Lines_not_broken(score); for (int i = 0; 
#define _doubleplantPLANTKIND202520 i < ROW; i++) { for (int j 
#define _forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT = 0; j < COLUMN; j++) { if 
#define _lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30 (Plants[i][j] == SUNFLOWER) score[i] -= 120; if (Plants[i][j] 
#define _lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i == PEASHOOTER) score[i] += 50 * (1 * 
#define _maxindex1j (exp(-j / 5))); if (Plants[i][j] == WINTERPEASHOOTER) score[i] 
#define _thispeashooterpos0maxindex0 += 100 * (1 * (exp(-j / 5))); 
#define _thispeashooterpos1maxindex1 if (Plants[i][j] == SMALLNUT) score[i] += 100 * 
#define _thispeashootervaluemax (-0.01 * (j - 5) * (j - 
#define _boolhavetypeofzombiesintzombieinttypeintk0 5) + 1); } } for (int i 
#define _whilezombiek1ifzombiektype = 0; i < ROW; i++) for (int 
#define _returntrue j = 0; j < COLUMN; j++) { 
#define _kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0 int k = 0; while (Zombies[i][j][k] != -1) 
#define _forintj0jCOLUMNjintk0_ { if (Zombies[i][j][k] == NORMAL) score[i] -= 10 
#define _whileZombiesrowjk1ifnearestjcolumn * (1 / (0.1 + j)); if (Zombies[i][j][k] 
#define _nearestjcolumn == BUCKET) score[i] -= 50 * (1 / 
#define _k___ (0.1 + j)); if (Zombies[i][j][k] == POLEVAULT) score[i] 
#define _returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0 -= 30 * (1 / (0.1 + j)); 
#define _whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0 if (Zombies[i][j][k] == GARGANTUAR) score[i] -= 100 * 
#define _whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart (1 / (0.1 + j)); if (Zombies[i][j][k] == 
#define _intrankdoublearrayintlendoublemaxarray0 SLED) score[i] -= 80 * (1 / (0.1 
#define _intserialnumintmalloclensizeofint + j)); k++; } } int *serial_num = 
#define _forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj rank(score, ROW); int j = 0; while (Plants[serial_num[0]][j 
#define _arrayjarrayj1 + 2] != NOPLANT && j < 8) 
#define _arrayj1swap { j++; } if (j < 8) if 
#define _intserialswapserialnumj (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) || 
#define _serialnumjserialnumj1 have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR))) player->PlacePlant(SUNFLOWER, 
#define _serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10 serial_num[0], j + 2); free(serial_num); } } void 
#define _ifthisPlaceCDSUNFLOWER0doublescore500000 value_smallmnut() { if (this->PlaceCD[SMALLNUT - 1] == 0) 
#define _judgeLinesnotbrokenscore if (this->time > 20) { double score[ROW] = 
#define _forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER {0, 0, 0, 0, 0}; judge_Lines_not_broken(score); double plants_score[7] 
#define _scorei10 = {0, 5, 20, 20, -300, -2, 0}; 
#define _ifPlantsijPEASHOOTER for (int i = 0; i < ROW; 
#define _scorei501expj i++) { for (int j = 0; j 
#define _ifPlantsijWINTERPEASHOOTER < COLUMN; j++) { double distance_cost = 1; 
#define _scorei1001expj switch (Plants[i][j]) { case SUNFLOWER: distance_cost = 1.5 
#define _ifPlantsijSMALLNUT - 0.05 * j; break; case PEASHOOTER: distance_cost 
#define _scorei100001j5j51 = 2 - 0.09 * j; break; case 
#define _forinti0iROWi_ WINTERPEASHOOTER: distance_cost = 2 - 0.1 * j; 
#define _forintj0jCOLUMNjintk0__ break; } score[i] += plants_score[Plants[i][j]] * distance_cost; } 
#define _whileZombiesijk1ifZombiesijkNORMAL } double zombie_cost[5] = {2.0, 10, 12, -1000, 
#define _scorei10101j -2000}; int nearest_zombie_per_row[5] = {10, 10, 10, 10, 
#define _ifZombiesijkBUCKET 10}; for (int i = 0; i < 
#define _scorei50101j ROW; i++) { for (int j = COLUMN 
#define _ifZombiesijkPOLEVAULT - 1; j >= 0; j--) { int 
#define _scorei30101j k = 0; while (Zombies[i][j][k] != -1) { 
#define _ifZombiesijkGARGANTUAR double distance_cost = 1; switch (Zombies[i][j][k]) { case 
#define _scorei100101j NORMAL: distance_cost = 1.2 - 0.02 * (j); 
#define _ifZombiesijkSLED break; case POLEVAULT: distance_cost = 1.1 - 0.01 
#define _scorei80101j * j; break; case BUCKET: distance_cost = 1.3 
#define _kintsunflowernumingeneratingrow0 - 0.04 * j; break; } score[i] += 
#define _forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER zombie_cost[(Zombies[i][j][k] - 1)] * distance_cost; k++; nearest_zombie_per_row[i] = 
#define _sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW j; } } } int *serial_num = rank(score, 
#define _forinti0iROWiintj0 ROW); int j = COLUMN - 1; if 
#define _whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT) { for (; 
#define _voidvaluesmallmnutifthisPlaceCDSMALLNUT0 j >= 0; j--) { if (Plants[serial_num[0]][j] == 
#define _ifthistime20doublescoreROW00000 NOPLANT) break; } player->PlacePlant(SMALLNUT, serial_num[0], j); } else 
#define _judgeLinesnotbrokenscorevalueplants player->PlacePlant(SMALLNUT, serial_num[0], (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 
#define _doubleplantsscore7052020710 0 : (nearest_zombie_per_row[serial_num[0]] - 1)); free(serial_num); } } 
#define _forinti0iROWiforintj0jCOLUMNjdoubledistancecost1 void value_winterpeashooter() { if (this->PlaceCD[WINTERPEASHOOTER - 1] == 
#define _switchPlantsijcaseSUNFLOWER 0) { if (this->time > 70) { double 
#define _distancecost15005j score[5] = {0.0, 0, 0, 0, 0}; judge_Lines_not_broken(score); 
#define _break_________________________ double plant_cost[7] = {0.0, -2.5, -4, -5, -10, 
#define _casePEASHOOTER__ 6, 0}; if (time > 450) { plant_cost[4] 
#define _distancecost2009j = 2; } for (int i = 0; 
#define _break__________________________ i < ROW; i++) { for (int j 
#define _caseWINTERPEASHOOTER__ = 0; j < COLUMN; j++) { score[i] 
#define _distancecost201j += plant_cost[Plants[i][j]]; } } double zombie_cost[5] = {5, 
#define _breakscoreiPlantsijplantsscoreidistancecostvaluezombies 20, 10, 2, -4}; for (int i = 
#define _doublezombiecost520101246 0; i < ROW; i++) for (int j 
#define _intnearestzombieperrow500000 = 0; j < COLUMN; j++) { int 
#define _forinti0iROWiforintjCOLUMN1j0jintk0 k = 0; while (Zombies[i][j][k] != -1) { 
#define _whileZombiesijk1doubledistancecost1 score[i] += zombie_cost[Zombies[i][j][k] - 1]; k++; } } 
#define _switchZombiesijk int *serial_num = rank(score, ROW); if (this->time < 
#define _caseNORMAL__ 300) { int j = 0; while (Plants[serial_num[0]][j] 
#define _distancecost12002j != NOPLANT && j < 8) { j++; 
#define _break___________________________ } if (j < 5) { if (search_for_nearest_zombie(Zombies, 
#define _casePOLEVAULT__ serial_num[0], j) >= 1) { player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j); 
#define _distancecost11001j } } } else { int limit = 
#define _break____________________________ (int)(this->time / 400) + 3; for (int i 
#define _caseBUCKET___ = 0; i < limit; i++) { if 
#define _distancecost13004j ((Plants[serial_num[0]][i] == PEASHOOTER && this->time > 600) || 
#define _breakscoreizombiecostZombiesijk1distancecost (Plants[serial_num[0]][i] == SUNFLOWER)) { if (search_for_nearest_zombie(Zombies, serial_num[0], i) 
#define _k____ >= 1 && this->Sun > 400) { player->removePlant(serial_num[0], 
#define _nearestzombieperrowij i); player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i); break; } } } 
#define _intserialnumrankscoreROW } free(serial_num); } } } void value_squash() { 
#define _forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1 if (this->PlaceCD[SQUASH - 1] == 0 && this->time 
#define _voidvaluethisvaluepeashooter > 50) { double score[5] = {0, 0, 
#define _thisvaluesunflower 0, 0, 0}; double plant_cost[7] = {0, 5, 
#define _thisvaluesmallmnut 20, 3, -10, -100, -200}; for (int i 
#define _doublemax100000 = 0; i < 5; i++) { for 
#define _doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue (int j = 0; j < COLUMN; j++) 
#define _thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation { double distance_cost = 0.2 + 0.08 * 
#define _thisGameState250 j; score[i] += plant_cost[Plants[i][j]] * distance_cost; } } 
#define _thisGameState50200 double zombie_cost[5] = {-5, 10, 2, 100, 200}; 
#define _thisvalue for (int i = 0; i < ROW; 
#define _classvaluezombiefuncpublic i++) for (int j = 0; j < 
#define _intnozombie COLUMN; j++) { int k = 0; while 
#define _intnormalchoice (Zombies[i][j][k] != -1) { double distance_cost = 11 
#define _intbucketchoice / (j + 1); score[i] += zombie_cost[Zombies[i][j][k] - 
#define _intpolevaultchoice 1] * distance_cost; k++; } } int *serial_num 
#define _intsledchoice = rank(score, ROW); int nearest_zombie = 10; for 
#define _intgargantuarchoice (int j = COLUMN - 1; j >= 
#define _doublevalueZOMBIEKIND 0; j--) { int k = 0; while 
#define _intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore (Zombies[serial_num[0]][j][k] != -1) { nearest_zombie = j; k++; 
#define _intKillPlantsScore } } if (nearest_zombie - 1 >= 0 
#define _intLeftPlants_ && nearest_zombie != 9) { if (Plants[serial_num[0]][nearest_zombie - 
#define _intScore__ 1] == NOPLANT) { player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 
#define _inttime__ 1); } else if (Plants[serial_num[0]][nearest_zombie - 1] != 
#define _intPlaceCD__ WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 1] != SMALLNUT && 
#define _intPlants__ Plants[serial_num[0]][nearest_zombie - 1] != NOPLANT && time > 
#define _intZombies__ 400 && this->Sun > 50) { player->removePlant(serial_num[0], nearest_zombie 
#define _intLeftLines__ - 1); player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1); } 
#define _intSun_ } else { for (int j = COLUMN 
#define _intzombienums - 1; j >= 0; j--) { if 
#define _GamegamevaluezombiefuncintBrokenLinesScore (Plants[serial_num[0]][j] != NOPLANT && j >= 6) { 
#define _intKillPlantsScore_ player->PlacePlant(SQUASH, serial_num[0], j); } } } free(serial_num); } 
#define _intScore___ } void value_pepper() { if (this->PlaceCD[PEPPER - 1] 
#define _inttime___ == 0 && this->PlaceCD[SQUASH - 1] != 0) 
#define _intPlaceCD___ { double score[ROW] = {0, 0, 0, 0, 
#define _intPlants___ 0}; int warning_flag[5] = {0, 0, 0, 0, 
#define _intZombies___ 0}; int have_zombies[5] = {0, 0, 0, 0, 
#define _intLeftLines___ 0}; double zombie_cost[5] = {1, 3, 2, 20, 
#define _intSun__ 80}; for (int i = 0; i < 
#define _intzombienums_ ROW; i++) { for (int j = 0; 
#define _Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0 j < COLUMN; j++) { int k = 
#define _thisBrokenLinesScoreBrokenLinesScore 0; while (Zombies[i][j][k] != -1) { double distance_cost 
#define _thisKillPlantsScoreKillPlantsScore = 10 / (1 + j); score[i] += 
#define _thisScoreScore_ distance_cost * zombie_cost[Zombies[i][j][k] - 1]; have_zombies[i] = 1; 
#define _thistimetime_ if (j <= 3) warning_flag[i] = 1; k++; 
#define _thisPlaceCDPlaceCD_ } } } double plant_cost[7] = {0, 0, 
#define _thisPlantsPlants_ -20, -3, -1, -80, -80}; for (int i 
#define _thisZombiesZombies_ = 0; i < ROW; i++) { for 
#define _thisLeftLinesLeftLines_ (int j = 0; j < COLUMN; j++) 
#define _thisSunSun_ { score[i] += plant_cost[Plants[i][j]]; } } double time_cost 
#define _thiszombienumszombienums = 10 * (1 / (1 + exp((time 
#define _thisgamegame - 1000) / 500))); int *serial_num = rank(score, 
#define _forinti0iZOMBIEKINDi ROW); int deal_with_warning_flag = 0; for (int i 
#define _thisvaluei0 = 0; i < ROW; i++) { if 
#define _memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile (warning_flag[serial_num[i]] == 1) { int flag = 0; 
#define _fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0 for (int j = 0; j < COLUMN; 
#define _forinti0iROWiaveragecostiaverage5 j++) { if (Plants[serial_num[i]][j] == NOPLANT) { player->PlacePlant(PEPPER, 
#define _forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05 serial_num[i], j); flag = 1; deal_with_warning_flag = 1; 
#define _squaredistance5ifsquaredistancepowthistime001100return1else } if (flag == 1) break; } break; 
#define _return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow } } if (deal_with_warning_flag == 0) { if 
#define _ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei (score[0] >= 0) { int flag = 0; 
#define _decision0i1 for (int j = 0; j < COLUMN; 
#define _decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei j++) { if (Plants[serial_num[0]][j] == NOPLANT && have_zombies[serial_num[0]] 
#define _decision0i1_ == 1) { player->PlacePlant(PEPPER, serial_num[0], j); flag = 
#define _decision1thischoicei 1; } if (flag == 1) break; } 
#define _ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum } } free(serial_num); } } void value() { 
#define _thisKillZombiesScoreKillZombiesScore_ this->value_peashooter(); this->value_sunflower(); this->value_smallmnut(); this->value_winterpeashooter(); this->value_squash(); this->value_pepper(); } void 
#define _thisLeftPlantsLeftPlants make_decision() { this->beginning_operation(); this->GameState_2_400(); if (this->time > 20) 
#define _thisScoreScore__ this->value(); } }; class value_zombie_func { public: int 
#define _thistimetime__ nozombie; int normal_choice; int bucket_choice; int polevault_choice; int 
#define _thisPlaceCDPlaceCD__ sled_choice; int gargantuar_choice; double value[ZOMBIE_KIND]; int choice[ZOMBIE_KIND] = 
#define _thisPlantsPlants__ {this->normal_choice, this->bucket_choice, this->polevault_choice, this->sled_choice, this->gargantuar_choice}; int BrokenLinesScore; int 
#define _thisZombiesZombies__ KillPlantsScore; int LeftPlants; int Score; int time; int 
#define _thisLeftLinesLeftLines__ *PlaceCD; int **Plants; int ***Zombies; int *LeftLines; int 
#define _thisSunSunforinti0iROWifinalchoicei0 Sun; int zombie_nums; int give_up_whole_attack; Game game; value_zombie_func(int 
#define _boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10 BrokenLinesScore, int KillPlantsScore, int Score, int time, int 
#define _thisvaluekind1100000 *PlaceCD, int **Plants, int ***Zombies, int *LeftLines, int 
#define _returntrueelse Sun, int zombie_nums, Game game) { this->normal_choice = 
#define _returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00 this->bucket_choice = this->polevault_choice = this->sled_choice = this->gargantuar_choice = 
#define _ifthisLeftLinesrow0cost100000elseintnumperrow0 0; this->BrokenLinesScore = BrokenLinesScore; this->KillPlantsScore = KillPlantsScore; this->Score 
#define _doubletoomanyzombiescost15 = Score; this->time = time; this->PlaceCD = PlaceCD; 
#define _forintj0jCOLUMNjintk0___ this->Plants = Plants; this->Zombies = Zombies; this->LeftLines = 
#define _whilethisZombiesrowjk1switchkindcasePOLEVAULT LeftLines; this->Sun = Sun; this->zombie_nums = zombie_nums; this->game 
#define _costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost = game; this->give_up_whole_attack = 0; for (int i 
#define _break_____________________________ = 0; i < ZOMBIE_KIND; i++) this->value[i] = 
#define _default 0; memset(this->choice, 0, ZOMBIE_KIND * (sizeof(int))); } int 
#define _costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k judge_whether_big_cost_in_one_row(int *cost) { double average = 0, square_distance 
#define _numperrow = 0; for (int i = 0; i 
#define _costnumperrowtoomanyzombiescostreturncostintsumplantsperrow < ROW; i++) { average += cost[i]; } 
#define _rowsplantskindnumperrow_ average /= 5; for (int i = 0; 
#define _intplantsnumformatintmallocROWsizeofint_ i < ROW; i++) { square_distance += (cost[i] 
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_ - average) * (cost[i] - average); } square_distance 
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_ = pow(square_distance, 0.5); square_distance /= 5; if (square_distance 
#define _plantsnumformatiSUNFLOWER1 > pow(this->time, 0.2) * 400) { return 1; 
#define _break______________________________ } else return 0; } void make_decision(int *decision) 
#define _caseWINTERPEASHOOTER___ { double max = -10000; for (int i 
#define _plantsnumformatiWINTERPEASHOOTER1 = 0; i < 5; i++) { if 
#define _break_______________________________ (max < this->value[i]) { max = this->value[i]; decision[0] 
#define _casePEASHOOTER___ = i + 1; decision[1] = this->choice[i]; } 
#define _plantsnumformatiPEASHOOTER1 } if (this->give_up_whole_attack == 1) { decision[0] = 
#define _break________________________________ NOZOMBIE; decision[1] = 0; } } bool whether_need_compute(int 
#define _caseSMALLNUT__ kind) { if (this->PlaceCD[kind - 1] > 0 
#define _plantsnumformatiSMALLNUT1 || this->time < 120) { this->choice[kind - 1] 
#define _break_________________________________ = 0; this->value[kind - 1] = -100000; return 
#define _casePEPPER__ true; } else return false; } void whether_give_up_attack(double 
#define _plantsnumformatiPEPPER1 *score) { int num[5] = {0, 0, 0, 
#define _break__________________________________ 0, 0}; for (int i = 0; i 
#define _caseSQUASH__ < ROW; i++) { for (int j = 
#define _plantsnumformatiSQUASH1 0; j < COLUMN; j++) { if (Plants[i][j] 
#define _breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00 == WINTERPEASHOOTER) num[i]++; } } int give_up_lines = 
#define _switchkindcaseNORMAL 0; for (int i = 0; i < 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10 ROW; i++) { if (num[i] >= 5) { 
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12 score[i] = -100000; give_up_lines++; } } if (give_up_lines 
#define _break___________________________________ == 5) this->give_up_whole_attack = 1; } double zombie_cost(int 
#define _caseBUCKET____ row, double *zombies_paras, double distance_cost, double distance_rate, int 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10 kind) { double cost = 0.0; if (this->LeftLines[row] 
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1 == 0) { cost = -100000; } else 
#define _break____________________________________ { int num_per_row = 0; double too_many_zombies_cost = 
#define _casePOLEVAULT___ -1.5; for (int j = 0; j < 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED COLUMN; j++) { int k = 0; while 
#define _ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break (this->Zombies[row][j][k] != -1) { switch (kind) { case 
#define _caseGARGANTUAR___ POLEVAULT: cost += zombies_paras[this->Zombies[row][j][k] - 1] * ((COLUMN 
#define _ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11 - j - distance_cost) * (COLUMN - j 
#define _plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11 - distance_cost)); break; default: cost += zombies_paras[this->Zombies[row][j][k] - 
#define _forintj0jCOLUMNjifPlantsrowjNOPLANT 1] * (-distance_rate * (COLUMN - j - 
#define _costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000 distance_cost) * (COLUMN - j - distance_cost) + 
#define _intindex0 2); } k++; num_per_row++; } } cost += 
#define _forinti0ilengthiifmaxaimaxai num_per_row * too_many_zombies_cost; } return cost; } int 
#define _indexi **sum_plants_per_row() { int **plants_num_format = (int **)malloc(ROW * 
#define _returnindex sizeof(int *)); for (int i = 0; i 
#define _NORMAL_ < ROW; i++) { plants_num_format[i] = (int *)malloc(sizeof(int) 
#define _BUCKET_ * PLANT_KIND); memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int)); } 
#define _POLEVAULT_ for (int i = 0; i < ROW; 
#define _SLED_ i++) { for (int j = 0; j 
#define _GARGANTUARSUNFLOWER < PLANT_KIND; j++) { plants_num_format[i][j] = 0; } 
#define _WINTERPEASHOOTER_ } for (int i = 0; i < 
#define _PEASHOOTER_ ROW; i++) { for (int j = 0; 
#define _SMALLNUT_ j < COLUMN; j++) { switch (this->Plants[i][j]) { 
#define _PEPPER_ case SUNFLOWER: plants_num_format[i][SUNFLOWER - 1]++; break; case WINTERPEASHOOTER: 
#define _SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000 plants_num_format[i][WINTERPEASHOOTER - 1]++; break; case PEASHOOTER: plants_num_format[i][PEASHOOTER - 
#define _judgeLinesnotbrokenfinalchoice 1]++; break; case SMALLNUT: plants_num_format[i][SMALLNUT - 1]++; break; 
#define _ifthiswhetherneedcomputeNORMALreturn case PEPPER: plants_num_format[i][PEPPER - 1]++; break; case SQUASH: 
#define _zombie plants_num_format[i][SQUASH - 1]++; break; } } } return 
#define _doublezombiesparasZOMBIEKIND54231 plants_num_format; } double plant_cost(int row, int **plants_num_format, double 
#define _doubledistancecost1distancerate005 *plants_para, int kind) { double origin_para[PLANT_KIND]; for (int 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL i = 0; i < PLANT_KIND; i++) { 
#define _plant origin_para[i] = plants_para[i]; } double cost = 0.0; 
#define _intplantsnumformatROWPLANTKIND0 switch (kind) { case NORMAL: if (plants_num_format[row][SMALLNUT - 
#define _doubleplantsparaPLANTKIND88221005 1] > 0 && plants_num_format[row][PEASHOOTER - 1] + 
#define _intsumplantsperrow0thissumplantsperrow plants_num_format[row][WINTERPEASHOOTER - 1] > 0) plants_para[SMALLNUT - 1] 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL *= (plants_num_format[row][PEASHOOTER - 1] * 1 + plants_num_format[row][WINTERPEASHOOTER 
#define _time - 1] * 2); break; case BUCKET: if 
#define _doubletimecost2011expthistimeTOTALTIME210005 (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][WINTERPEASHOOTER - 
#define _forinti0iROWi__ 1] > 0) plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER 
#define _finalchoiceitimecostSun - 1] * 0.2 + plants_num_format[row][WINTERPEASHOOTER - 1]); 
#define _doublesunbaseline60sunsub02 break; case POLEVAULT: if (plants_num_format[row][SMALLNUT - 1] > 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 
#define _forinti0iROWi___ 1] > 0) { plants_para[SMALLNUT - 1] *= 
#define _finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW ((1.5 - plants_num_format[row][SMALLNUT - 1]) * (3 - 
#define _thisvalueNORMAL1finalchoicethischoiceNORMAL1 plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1])); } 
#define _voidvaluebucketdoublefinalchoiceROW00000 break; case SLED: if (plants_num_format[row][SMALLNUT - 1] > 
#define _judgeLinesnotbrokenfinalchoice_ 1 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 
#define _ifthiswhetherneedcomputeBUCKETreturn 1] > 0) { plants_para[SMALLNUT - 1] *= 
#define _zombie_ (plants_num_format[row][SMALLNUT - 1] * plants_num_format[row][SMALLNUT - 1]) * 
#define _doublezombiesparasZOMBIEKIND254thistime100100522 (plants_num_format[row][WINTERPEASHOOTER - 1]); } if (plants_num_format[row][WINTERPEASHOOTER - 1] 
#define _doubledistancecost25distancerate01 >= 2) { plants_para[WINTERPEASHOOTER - 1] = 6 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET - 2 * plants_num_format[row][WINTERPEASHOOTER - 1]; } break; 
#define _plant_ case GARGANTUAR: if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2) 
#define _intplantsnumformatROWPLANTKIND0_ { plants_para[WINTERPEASHOOTER - 1] = 6 - 2 
#define _doubleplantsparaPLANTKIND63231004 * plants_num_format[row][WINTERPEASHOOTER - 1]; } break; } plants_para[SUNFLOWER 
#define _intsumplantsperrowthissumplantsperrow - 1] *= (1 + 1 / (COLUMN 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET - plants_num_format[row][SUNFLOWER - 1] + 1)); for (int 
#define _time_ j = 0; j < COLUMN; j++) { 
#define _doubletimecost2011expthistimeTOTALTIME310005 if (Plants[row][j] != NOPLANT) cost += plants_para[Plants[row][j] - 
#define _forinti0iROWi____ 1] * (plants_para[Plants[row][j] - 1] > 0 ? 
#define _finalchoiceitimecostSun_ (j + 1) * (j + 1) : 
#define _doublesunbaseline150sunsub05 (COLUMN - j)); } for (int i = 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub 0; i < PLANT_KIND; i++) { plants_para[i] = 
#define _forinti0iROWi_____ origin_para[i]; } return cost; } int max_index(double *a, 
#define _finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW int length) { double max = -10000; int 
#define _thisvalueBUCKET1finalchoicethischoiceBUCKET1 index = 0; for (int i = 0; 
#define _voidvaluepolevaultdoublefinalchoiceROW00000 i < length; i++) { if (max < 
#define _judgeLinesnotbrokenfinalchoice__ a[i]) { max = a[i]; index = i; 
#define _ifthiswhetherneedcomputePOLEVAULTreturn } } return index; } void value_normal() { 
#define _zombie__ double final_choice[ROW] = {0, 0, 0, 0, 0}; 
#define _doublezombiesparasZOMBIEKIND1thistime10010051523 if (this->whether_need_compute(NORMAL)) { return; } whether_give_up_attack(final_choice); double zombies_paras[ZOMBIE_KIND] 
#define _doubledistancecost25distancerate01_ = {-5, 4, 2, 3, 1}; double distance_cost 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT = 1, distance_rate = 0.05; for (int i 
#define _plant__ = 0; i < ROW; i++) { final_choice[i] 
#define _intplantsnumformatROWPLANTKIND0__ += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, NORMAL); } int 
#define _doubleplantsparaPLANTKIND52181001 plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; 
#define _intsumplantsperrowthissumplantsperrow_ i < ROW; i++) for (int j = 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 
#define _time__ 0; } double plants_para[PLANT_KIND] = {8, -8, -2, 
#define _doubletimecost2011expthistimeTOTALTIME510005 -2, -100, 20}; int **sum_plants_per_row0 = this->sum_plants_per_row(); for 
#define _forinti0iROWi______ (int i = 0; i < ROW; i++) 
#define _finalchoiceitimecostSun__ { final_choice[i] += this->plant_cost(i, sum_plants_per_row0, plants_para, NORMAL); } 
#define _doublesunbaseline120sunsub04 for (int i = 0; i < ROW; 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub i++) { free(sum_plants_per_row0[i]); } free(sum_plants_per_row0); double time_cost = 
#define _forinti0iROWi_______ 20 * (1 / (1 + exp((this->time - 
#define _finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW TOTAL_TIME / 2) / 500)) - 0.5); for 
#define _thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1 (int i = 0; i < ROW; i++) 
#define _voidvaluesleddoublefinalchoiceROW00000 final_choice[i] += time_cost; double sun_baseline = 60, sun_sub 
#define _judgeLinesnotbrokenfinalchoice___ = 1; double sun_cost = (this->Sun - sun_baseline 
#define _ifthiswhetherneedcomputeSLEDreturn > 0 ? 1 / (1 + exp((-this->Sun 
#define _zombie___ + sun_baseline) / 400)) * 15 : -pow(sun_baseline 
#define _doublezombiesparasZOMBIEKIND32174 - this->Sun, 1 / sun_sub)); for (int i 
#define _doubledistancecost25distancerate01__ = 0; i < ROW; i++) final_choice[i] += 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED sun_cost; this->choice[NORMAL - 1] = this->max_index(final_choice, ROW); this->value[NORMAL 
#define _plant___ - 1] = final_choice[this->choice[NORMAL - 1]]; } void 
#define _intplantsnumformatROWPLANTKIND0___ value_bucket() { double final_choice[ROW] = {0, 0, 0, 
#define _doubleplantsparaPLANTKIND510361001and 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(BUCKET)) { return; } 
#define _intsumplantsperrowthissumplantsperrow__ double zombies_paras[ZOMBIE_KIND] = {2.5, -4, this->time < 100 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED ? -100 : -5, 2, -2}; double distance_cost 
#define _time___ = 2.5, distance_rate = 0.1; for (int i 
#define _doubletimecost2011expthistimeTOTALTIME520005 = 0; i < ROW; i++) { final_choice[i] 
#define _forinti0iROWi________ += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, BUCKET); } int 
#define _finalchoiceitimecostSun___ plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; 
#define _doublesunbaseline200sunsub05 i < ROW; i++) for (int j = 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 
#define _forinti0iROWi_________ 0; } double plants_para[PLANT_KIND] = {6, -2, 6, 
#define _finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW -1, -100, -4}; int **sum_plants_per_row = this->sum_plants_per_row(); for 
#define _thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000 (int i = 0; i < ROW; i++) 
#define _judgeLinesnotbrokenfinalchoice____ { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, BUCKET); } 
#define _ifthiswhetherneedcomputeGARGANTUARreturn for (int i = 0; i < ROW; 
#define _zombie____ i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost = 
#define _doublezombiesparasZOMBIEKIND2452015 20 * (1 / (1 + exp((-this->time + 
#define _doubledistancecost25distancerate01___ TOTAL_TIME / 3) / 400)) - 0.5); for 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR (int i = 0; i < ROW; i++) 
#define _plant____ final_choice[i] += time_cost; double sun_baseline = 150, sun_sub 
#define _intplantsnumformatROWPLANTKIND0____ = 1; double sun_cost = (this->Sun - sun_baseline 
#define _doubleplantsparaPLANTKIND01002510010and > 0 ? 1 / (1 + exp((-this->Sun 
#define _intsumplantsperrowthissumplantsperrow___ + sun_baseline) / 400)) * 5 : -pow(sun_baseline 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR - this->Sun, 1 / sun_sub)); for (int i 
#define _time____ = 0; i < ROW; i++) final_choice[i] += 
#define _doubletimecost sun_cost; this->choice[BUCKET - 1] = this->max_index(final_choice, ROW); this->value[BUCKET 
#define _ifabsthistime50025absthistime100025absthistime150025 - 1] = final_choice[this->choice[BUCKET - 1]]; } void 
#define _timecost100 value_polevault() { double final_choice[ROW] = {0, 0, 0, 
#define _timecost10011expthistimeTOTALTIME540004 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(POLEVAULT)) { return; } 
#define _forinti0iROWi__________ double zombies_paras[ZOMBIE_KIND] = {1, this->time < 100 ? 
#define _finalchoiceitimecostSun____ -100 : -5, -1.5, 2, -3}; double distance_cost 
#define _doublesunbaseline350sunsub06 = 2.5, distance_rate = 0.1; for (int i 
#define _doublesuncost11expthisSunsunbaseline10020010 = 0; i < ROW; i++) { final_choice[i] 
#define _forinti0iROWi___________ += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, POLEVAULT); } int 
#define _finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; 
#define _thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1 i < ROW; i++) for (int j = 
#define _externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 
#define _gamemaintainplayerclassICamppublic 0; } double plants_para[PLANT_KIND] = {4, -50, -8, 
#define _virtualintgetCurrentPlants0 7, -100, -10}; int **sum_plants_per_row = this->sum_plants_per_row(); for 
#define _Plantsijij0virtualintgetCurrentZombies0Zombiesijij (int i = 0; i < ROW; i++) 
#define _kk0Zombiesijk1 { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, POLEVAULT); } 
#define _Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic for (int i = 0; i < ROW; 
#define _ICampCamp i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost = 
#define _virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0 10 * (1 / (1 + exp((-this->time + 
#define _virtualintgetScore0 TOTAL_TIME / 5) / 300)) - 0.5); for 
#define _virtualintgetKillPlantsScore0 (int i = 0; i < ROW; i++) 
#define _virtualintgetKillZombiesScore0 final_choice[i] += time_cost; double sun_baseline = 120, sun_sub 
#define _virtualintgetNotBrokenLines0 = 1; double sun_cost = (this->Sun - sun_baseline 
#define _virtualintgetBrokenLinesScore0 > 0 ? 1 / (1 + exp((-this->Sun 
#define _virtualintgetLeftPlants0intTypeplayerCampgetCurrentType + sun_baseline) / 500)) * 6 : -pow(sun_baseline 
#define _ifType0intNotBrokenLinesNumplayergetNotBrokenLines - this->Sun, 1 / sun_sub)); for (int i 
#define _intKillZombiesScoreplayergetKillZombiesScore = 0; i < ROW; i++) final_choice[i] += 
#define _intLeftPlantsplayergetLeftPlants sun_cost; this->choice[POLEVAULT - 1] = this->max_index(final_choice, ROW); this->value[POLEVAULT 
#define _intScoreplayergetScore - 1] = final_choice[this->choice[POLEVAULT - 1]]; } void 
#define _inttime0playergetTime value_sled() { double final_choice[ROW] = {0, 0, 0, 
#define _introwsplayerCampgetRows 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(SLED)) { return; } 
#define _intcolumnsplayerCampgetColumns double zombies_paras[ZOMBIE_KIND] = {3, -2, -1, -7, -4}; 
#define _intPlaceCDplayerCampgetPlantCD double distance_cost = 2.5, distance_rate = 0.1; for 
#define _intPlantsplayerCampgetCurrentPlants (int i = 0; i < ROW; i++) 
#define _intZombiesplayerCampgetCurrentZombies { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, SLED); 
#define _intLeftLinesplayerCampgetLeftLines } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i 
#define _intSunplayerCampgetSun = 0; i < ROW; i++) for (int 
#define _Zombiesnumzombiesnum j = 0; j < PLANT_KIND; j++) { 
#define _zombiesnumcomputenumZombiesrowscolumns plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = {3, 
#define _Plantsnumplantsnum 10, 2, 7, -100, -30}; int **sum_plants_per_row = 
#define _plantsnumcomputenumPlantsrowscolumns this->sum_plants_per_row(); for (int i = 0; i < 
#define _playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51 ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, 
#define _playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52 SLED); } for (int i = 0; i 
#define _ifplantsnumsunflower3 < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double 
#define _playerPlacePlantSUNFLOWER0plantsnumsunflower1 time_cost; if (time < 600) time_cost = 15 
#define _playerPlacePlantSMALLNUT0plantsnumsmallnut5 * (1 / (1 + exp((-this->time + TOTAL_TIME 
#define _playerPlacePlantSQUASH04 / 5) / 400)) - 0.5); else { 
#define _playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54 time_cost = 30 * (1 / (1 + 
#define _iftime06 exp((+this->time - TOTAL_TIME / 5) / 300)) - 
#define _playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45 0.5); } for (int i = 0; i 
#define _ifSun400 < ROW; i++) final_choice[i] += time_cost; double sun_baseline 
#define _playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame = 200, sun_sub = 1; double sun_cost = 
#define _valuemakedecisionifType1 (this->Sun - sun_baseline > 0 ? 1 / 
#define _intBrokenLinesScoreplayergetBrokenLinesScore (1 + exp(-this->Sun + sun_baseline + 100) / 
#define _intKillPlantsScoreplayergetKillPlantsScore 500) * 10 : 0); for (int i 
#define _intScoreplayergetScore_ = 0; i < ROW; i++) final_choice[i] += 
#define _inttimeplayergetTime sun_cost; this->choice[SLED - 1] = this->max_index(final_choice, ROW); this->value[SLED 
#define _introwsplayerCampgetRows_ - 1] = final_choice[this->choice[SLED - 1]]; } void 
#define _intcolumnsplayerCampgetColumns_ value_gargantuar() { double final_choice[ROW] = {0, 0, 0, 
#define _intPlaceCDplayerCampgetPlantCD_ 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(GARGANTUAR)) { return; } 
#define _intPlantsplayerCampgetCurrentPlants_ double zombies_paras[ZOMBIE_KIND] = {2, -4, -5, -20, -15}; 
#define _intZombiesplayerCampgetCurrentZombies_ double distance_cost = 2.5, distance_rate = 0.1; for 
#define _intLeftLinesplayerCampgetLeftLines_ (int i = 0; i < ROW; i++) 
#define _intSunplayerCampgetSun_ { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, GARGANTUAR); 
#define _iftime3intzombienumcalculatezombienumsZombies49 } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i 
#define _valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame = 0; i < ROW; i++) for (int 
#define _valuevaluenormal j = 0; j < PLANT_KIND; j++) { 
#define _valuevaluebucket plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = {1, 
#define _valuevaluepolevault 10, 2, 8, -100, -10}; int **sum_plants_per_row = 
#define _valuevaluesled this->sum_plants_per_row(); for (int i = 0; i < 
#define _valuevaluegargantuar ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, 
#define _intdecision200 GARGANTUAR); } for (int i = 0; i 
#define _valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0 < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double 
#define _whileZombiesijk1 time_cost; if (abs(this->time - 500) < 25 || 
#define _kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1 abs(this->time - 1000) < 25 || abs(this->time - 
#define _elseplayerPlaceZombiePOLEVAULT1 1500) < 25) time_cost = 100; time_cost = 
#define _playerPlaceZombieNORMAL2 120 * (1 / (1 + exp((-this->time + 
#define _playerPlaceZombieBUCKET3 TOTAL_TIME / 5) / 400)) - 0.5); for (int i = 0; i < ROW; i++) final_choice[i] += time_cost; double sun_baseline = 350, sun_sub = 1; double sun_cost = 1 / (1 + exp(-this->Sun + sun_baseline) / 500) * 10; for (int i = 0; i < ROW; i++) final_choice[i] += sun_cost; this->choice[GARGANTUAR - 1] = this->max_index(final_choice, ROW); this->value[GARGANTUAR - 1] = final_choice[this->choice[GARGANTUAR - 1]]*8; } }; static Game game; void player_ai(IPlayer *player) { int Type = player->Camp->getCurrentType(); if (Type == 0) { int NotBrokenLinesNum = player->getNotBrokenLines(); int KillZombiesScore = player->getKillZombiesScore(); int LeftPlants = player->getLeftPlants(); int Score = player->getScore(); int time0 = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player, game); value.make_decision(); } if (Type == 1) { int BrokenLinesScore = player->getBrokenLinesScore(); int KillPlantsScore = player->getKillPlantsScore(); int Score = player->getScore(); int time = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); if (time > 3) { int zombie_num = calculate_zombie_nums(Zombies, 4, 9); value_zombie_func value(BrokenLinesScore, KillPlantsScore, Score, time, PlaceCD, Plants, Zombies, LeftLines, Sun, zombie_num, game); value.value_normal(); value.value_bucket(); value.value_polevault(); value.value_sled(); value.value_gargantuar(); int decision[2] = {0, 0}; value.make_decision(decision); if (decision[0] != NOZOMBIE) { player->PlaceZombie((decision[0] > ZOMBIE_KIND ? NORMAL : decision[0]), decision[1] > ROW - 1 ? ROW - 1 : decision[1]); } } else { player->PlaceZombie(POLEVAULT, 1); player->PlaceZombie(NORMAL, 2); player->PlaceZombie(BUCKET, 3); } } } 

_includeaih 
_includeiostream 
_includestdlibh 
_includemathh 
_includecstring 
_includevector 
_includequeue 
_usingnamespacestd 
_defineZOMBIEKIND5 
_definePLANTKIND6 
_defineTOTALTIME2000 
_defineCOLUMN10 
_defineROW5 
_FILEfile 
_errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw 
_enumPlantTypeNOPLANT0 
_SUNFLOWER 
_WINTERPEASHOOTER 
_PEASHOOTER 
_SMALLNUT 
_PEPPER 
_SQUASHenumZombieTypeNOZOMBIE0 
_NORMAL 
_BUCKET 
_POLEVAULT 
_SLED 
_GARGANTUAR 
_zrfscodestarts 
_constintplantCost70504001005012550 
_constintplantCd70103010406060 
_constintzombieCost6050125125300300 
_constintzombieCd601520202525 
_constintplantHp70300300300400000 
_constintplantDps7002010000 
_intzombieHp6027082020016003000 
_structSunflowerintrowcolumncd 
_SunflowerintRowintColumncd24 
_rowRowcolumnColumn 
_intzombieNumintzombiesintcnt7pcnt 
_forinti0i5i 
_forintj0j10j 
_forintk0k10kifzombiesijk1 
_break 
_else 
_cntzombiesijkreturnp 
_zombies 
_intzombieNumintzombies51010intcnt7pcnt 
_forinti0i5i_ 
_forintj0j10j_ 
_forintk0k10kifzombiesijk1_ 
_break_ 
_else_ 
_cntzombiesijkreturnpstructZombieintnum 
_inthp 
_intcoXcoY 
_ZombieintNumintrowcoXrowcoY9 
_hpzombieHpNum 
_numNumintspeedstructPlantintnum 
_inthp_ 
_intcoXcoY_ 
_intdps 
_PlantintNumintrowintcolnumNum 
_coXrowcoYcol 
_hpplantHpNum 
_dpsplantDpsNum 
_structActionlistintplantPlace510zombiePlace5 
_intplantRemove510classGamepublic 
_inttimesunmoon 
_intplants510zombies51010 
_intcdPlant7cdZombie6tick 
_intdps5dps 
_intflagPlant7flagZombie610 
_intflagShovel51010 
_intzombieCostPerRow5 
_vectorSunflowersunFlowers 
_vectorPlantvectorPlants 
_vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij 
_flagShovelij1voidmaintainIPlayerplayertime 
_intPlantsplayerCampgetCurrentPlantscurrentPlants 
_intZombiesplayerCampgetCurrentZombiescurrentZombies 
_mooninttime20001 
_forinti0i5i__ 
_forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij 
_moonplantCostnum5intsqrtplantHpnum 
_dpsiplantDpsnum 
_ifnum1forintk0ksunFlowerssizek 
_ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink 
_break__ 
_elseifplantsijPlantsijintnumPlantsij 
_sunplantCostnum 
_dpsiplantDpsnum_ 
_cdPlantnumplantCdnum 
_flagPlantnum0 
_ifnum1sun25 
_sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij 
_intflag0 
_forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink 
_k 
_ifPlantsij0 
_vectorPlantspushbackPlantPlantsijijflag1 
_break___ 
_ifflag0Plantsij0 
_vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies 
_forinti0i5iintrowZombie6RowZombie6 
_forintj0j10j__ 
_forintk0k10kifzombiesijk1__ 
_break____ 
_else__ 
_rowZombiezombiesijkforintj0j10j 
_forintk0k10kifZombiesijk1 
_break_____ 
_else___ 
_RowZombieZombiesijk 
_forintj0j6j 
_ifRowZombiejrowZombiej 
_zombieCostPerRowizombieCostjforinti0i7iifziZi 
_zombiedie 
_elseifziZimoonzombieCosti 
_cdZombieizombieCdi 
_flagZombiei0 
_zombieplaced 
_forinti0i5iforintj0j10jintk0 
_whileZombiesijk1zombiesijkZombiesijk 
_k_ 
_vectorinthaveerased 
_forinti0ivectorZombiessizeiinthaveerasedflag0 
_forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1 
_breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum 
_intoriginalnumofthiskind0nownumofthiskind0 
_intk0 
_whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0 
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum 
_forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj 
_ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin 
_iforiginalnumofthiskindnownumofthiskind1 
_findthesmallesthp 
_intsmallhp5000smallhpnum0 
_forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp 
_smallhpnumk 
_vectorZombieserasesmallhpnumvectorZombiesbegin 
_haveerasedpushbackvectorZombiesicoX 
_haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum 
_intk0_ 
_intflagself0 
_intflagnear0 
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1 
_k0 
_whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1 
_ifflagself1flagnear1vectorZombieserasevectorZombiesbegini 
_iforinti0i7iifcdPlanti0 
_cdPlanti 
_ifcdPlanti0 
_flagPlanti1 
_forinti0i6iifcdZombiei0 
_cdZombiei 
_ifcdZombiei0 
_flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0 
_sunFlowersicd 
_ifsunFlowersicd0sun25 
_sunFlowersicd24ticktick 
_Gametime0 
_sun400moon300 
_forinti0i5i___ 
_forintj0j10j___ 
_plantsij0flagShovelij0 
_forinti0i5i____ 
_forintj0j10j____ 
_forintk0k10k 
_zombiesijk0 
_forinti0i5i_____ 
_dpsi0zombieCostPerRowi0 
_forinti0i7i 
_cdPlanti0flagPlanti1 
_forinti0i6i 
_cdZombiei0flagZombiei1 
_initialize 
_GametranStateActionlistqIPlayerplayerq 
_globalstatus 
_GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon 
_forinti0i5i______ 
_forintj0j10j_____ 
_newGameplantsijthisplantsijflagShovelijthisflagShovelij 
_forinti0i5i_______ 
_forintj0j10j______ 
_forintk0k10k_ 
_newGamezombiesijkthiszombiesijk 
_forinti0i7i_ 
_newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti 
_forinti0i6i_ 
_newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei 
_forinti0i5i________ 
_newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame 
_forinti0i5i_________ 
_forintj0j10jifqplantPlaceij0intnumqplantPlaceij 
_newGamesunplantCostnum 
_newGamecdPlantnumplantCdnum 
_newGameflagPlantnum0 
_newGamedpsiplantDpsnum 
_newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei 
_newGamemoonzombieCostnum 
_newGamecdZombienumzombieCdnum 
_newGameflagZombienum0 
_newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic 
_intnormal 
_intbucket 
_intpolevault 
_intsled 
_intgargantuar 
_inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0 
_forinti0irowsiforintj0jcolumnsjintk0 
_whilezombiesijk1switchzombiesijkcaseNORMAL 
_thisnormal 
_break______ 
_caseBUCKET 
_thisbucket 
_break_______ 
_casePOLEVAULT 
_thispolevault 
_break________ 
_caseSLED 
_thissled 
_break_________ 
_caseGARGANTUAR 
_thisgargantuar 
_breaknum 
_kclassPlantsnumpublic 
_intsunflower 
_intwinterpeashooter 
_intpeashooter 
_intsmallnut 
_intpepper 
_intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi 
_forintj0jcolumnsjswitchplantsijcaseSUNFLOWER 
_thissunflower 
_break__________ 
_caseWINTERPEASHOOTER 
_thiswinterpeashooter 
_break___________ 
_casePEASHOOTER 
_thispeashooter 
_break____________ 
_caseSMALLNUT 
_thissmallnut 
_break_____________ 
_casePEPPER 
_thispepper 
_break______________ 
_caseSQUASH 
_thissquash 
_breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0 
_forinti0irowsiforintj0jcolumnsjintk0_ 
_whilezombiesijk1num 
_kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT 
_returnireturnrandROWtypedefstructposandvalueintpos2 
_doublevalue 
_posandvalueclassvalueplantfuncpublic 
_doublenoplant 
_posandvaluesunflower 
_posandvaluepeashooter 
_posandvaluewinterpeashooter 
_posandvaluesmallnut 
_posandvaluepepper 
_posandvaluesquash 
_intgeneratingrow 
_IPlayerplayer 
_Gamegame 
_doublevaluePLANTKIND1 
_intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum 
_intKillZombiesScore 
_intLeftPlants 
_intScore 
_inttime 
_intPlaceCD 
_intPlants 
_intZombies 
_intLeftLines 
_intSun 
_intzombienumsvalueplantfuncintNotBrokenLinesNum 
_intKillZombiesScore_ 
_intScore_ 
_inttime_ 
_intPlaceCD_ 
_intPlants_ 
_intZombies_ 
_intLeftLines_ 
_intSunIPlayerplayer 
_GamegamethisNotBrokenLinesNumNotBrokenLinesNum 
_thisKillZombiesScoreKillZombiesScore 
_thisScoreScore 
_thistimetime 
_thisPlaceCDPlaceCD 
_thisPlantsPlants 
_thisZombiesZombies 
_thisLeftLinesLeftLines 
_thisSunSun 
_thisplayerplayer 
_thisgeneratingrow1 
_thisgamegameintsumplantsperrow 
_rowsplantskindnumperrow 
_intplantsnumformatintmallocROWsizeofint 
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND 
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER 
_plantsnumformatiSUNFLOWER 
_break_______________ 
_caseWINTERPEASHOOTER_ 
_plantsnumformatiWINTERPEASHOOTER 
_break________________ 
_casePEASHOOTER_ 
_plantsnumformatiPEASHOOTER 
_break_________________ 
_caseSMALLNUT_ 
_plantsnumformatiSMALLNUT 
_break__________________ 
_casePEPPER_ 
_plantsnumformatiPEPPER 
_break___________________ 
_caseSQUASH_ 
_plantsnumformatiSQUASH 
_breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1 
_thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1 
_voidGameState250ifthistime2thistime200intalarmingflag1 
_forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0 
_whilethisZombiesijk1ifj3 
_alarmingflagi 
_ifthisSun70 
_switchthisZombiesijkcasePOLEVAULT 
_caseSLED_ 
_thisplayerPlacePlantSQUASHij100j1 
_break____________________ 
_caseBUCKET_ 
_ifthisPlaceCDSQUASH0 
_thisplayerPlacePlantSQUASHij100j1_ 
_elseifj3 
_thisplayerPlacePlantPEPPERij100j1 
_break_____________________ 
_caseGARGANTUAR_ 
_thisplayerPlacePlantSQUASHij100j1__ 
_ifj4 
_thisplayerPlacePlantPEPPERi8 
_break______________________ 
_caseNORMAL 
_thisplayerPlacePlantPEASHOOTERi1 
_thisplayerPlacePlantSMALLNUTij100j1 
_breakkelse 
_forintj0jCOLUMNjintk0 
_whilethisZombiesthisgeneratingrowjk1ifthisSun70 
_switchthisZombiesthisgeneratingrowjk 
_casePOLEVAULT_ 
_caseBUCKET__ 
_caseSLED__ 
_thisplayerPlacePlantSQUASHthisgeneratingrow5 
_break_______________________ 
_caseGARGANTUAR__ 
_thisplayerPlacePlantSQUASHthisgeneratingrowj100j1 
_ifj4_ 
_thisplayerPlacePlantPEPPERthisgeneratingrow8 
_break________________________ 
_caseNORMAL_ 
_thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k 
_thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1 
_ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else 
_thisplayerPlacePlantPEPPERalarmingflagCOLUMN1 
_voidGameState50200ifthistime50thistime200ifthisSun400 
_thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0 
_voidvaluepeashooteroriginifthistime50 
_ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble 
_forinti0iROWilossidoublemallocCOLUMNsizeofdouble 
_memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200 
_forinti0iROWi 
_forintj0jCOLUMNjifthisPlantsijNOPLANT 
_lossij10000 
_else____ 
_doublerowithisgeneratingrow100 
_lossijrow 
_doublecolumn25 
_lossijcolumnexpcolumn10 
_doublezombieZOMBIEKIND61024020 
_forintcolumn00jCOLUMNjintk0 
_whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj 
_k__ 
_doubleplantPLANTKIND202520 
_forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT 
_lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30 
_lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i 
_maxindex1j 
_thispeashooterpos0maxindex0 
_thispeashooterpos1maxindex1 
_thispeashootervaluemax 
_boolhavetypeofzombiesintzombieinttypeintk0 
_whilezombiek1ifzombiektype 
_returntrue 
_kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0 
_forintj0jCOLUMNjintk0_ 
_whileZombiesrowjk1ifnearestjcolumn 
_nearestjcolumn 
_k___ 
_returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0 
_whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0 
_whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart 
_intrankdoublearrayintlendoublemaxarray0 
_intserialnumintmalloclensizeofint 
_forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj 
_arrayjarrayj1 
_arrayj1swap 
_intserialswapserialnumj 
_serialnumjserialnumj1 
_serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10 
_ifthisPlaceCDSUNFLOWER0doublescore500000 
_judgeLinesnotbrokenscore 
_forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER 
_scorei10 
_ifPlantsijPEASHOOTER 
_scorei501expj 
_ifPlantsijWINTERPEASHOOTER 
_scorei1001expj 
_ifPlantsijSMALLNUT 
_scorei100001j5j51 
_forinti0iROWi_ 
_forintj0jCOLUMNjintk0__ 
_whileZombiesijk1ifZombiesijkNORMAL 
_scorei10101j 
_ifZombiesijkBUCKET 
_scorei50101j 
_ifZombiesijkPOLEVAULT 
_scorei30101j 
_ifZombiesijkGARGANTUAR 
_scorei100101j 
_ifZombiesijkSLED 
_scorei80101j 
_kintsunflowernumingeneratingrow0 
_forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER 
_sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW 
_forinti0iROWiintj0 
_whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j 
_voidvaluesmallmnutifthisPlaceCDSMALLNUT0 
_ifthistime20doublescoreROW00000 
_judgeLinesnotbrokenscorevalueplants 
_doubleplantsscore7052020710 
_forinti0iROWiforintj0jCOLUMNjdoubledistancecost1 
_switchPlantsijcaseSUNFLOWER 
_distancecost15005j 
_break_________________________ 
_casePEASHOOTER__ 
_distancecost2009j 
_break__________________________ 
_caseWINTERPEASHOOTER__ 
_distancecost201j 
_breakscoreiPlantsijplantsscoreidistancecostvaluezombies 
_doublezombiecost520101246 
_intnearestzombieperrow500000 
_forinti0iROWiforintjCOLUMN1j0jintk0 
_whileZombiesijk1doubledistancecost1 
_switchZombiesijk 
_caseNORMAL__ 
_distancecost12002j 
_break___________________________ 
_casePOLEVAULT__ 
_distancecost11001j 
_break____________________________ 
_caseBUCKET___ 
_distancecost13004j 
_breakscoreizombiecostZombiesijk1distancecost 
_k____ 
_nearestzombieperrowij 
_intserialnumrankscoreROW 
_forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1 
_voidvaluethisvaluepeashooter 
_thisvaluesunflower 
_thisvaluesmallmnut 
_doublemax100000 
_doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue 
_thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation 
_thisGameState250 
_thisGameState50200 
_thisvalue 
_classvaluezombiefuncpublic 
_intnozombie 
_intnormalchoice 
_intbucketchoice 
_intpolevaultchoice 
_intsledchoice 
_intgargantuarchoice 
_doublevalueZOMBIEKIND 
_intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore 
_intKillPlantsScore 
_intLeftPlants_ 
_intScore__ 
_inttime__ 
_intPlaceCD__ 
_intPlants__ 
_intZombies__ 
_intLeftLines__ 
_intSun_ 
_intzombienums 
_GamegamevaluezombiefuncintBrokenLinesScore 
_intKillPlantsScore_ 
_intScore___ 
_inttime___ 
_intPlaceCD___ 
_intPlants___ 
_intZombies___ 
_intLeftLines___ 
_intSun__ 
_intzombienums_ 
_Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0 
_thisBrokenLinesScoreBrokenLinesScore 
_thisKillPlantsScoreKillPlantsScore 
_thisScoreScore_ 
_thistimetime_ 
_thisPlaceCDPlaceCD_ 
_thisPlantsPlants_ 
_thisZombiesZombies_ 
_thisLeftLinesLeftLines_ 
_thisSunSun_ 
_thiszombienumszombienums 
_thisgamegame 
_forinti0iZOMBIEKINDi 
_thisvaluei0 
_memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile 
_fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0 
_forinti0iROWiaveragecostiaverage5 
_forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05 
_squaredistance5ifsquaredistancepowthistime001100return1else 
_return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow 
_ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei 
_decision0i1 
_decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei 
_decision0i1_ 
_decision1thischoicei 
_ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum 
_thisKillZombiesScoreKillZombiesScore_ 
_thisLeftPlantsLeftPlants 
_thisScoreScore__ 
_thistimetime__ 
_thisPlaceCDPlaceCD__ 
_thisPlantsPlants__ 
_thisZombiesZombies__ 
_thisLeftLinesLeftLines__ 
_thisSunSunforinti0iROWifinalchoicei0 
_boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10 
_thisvaluekind1100000 
_returntrueelse 
_returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00 
_ifthisLeftLinesrow0cost100000elseintnumperrow0 
_doubletoomanyzombiescost15 
_forintj0jCOLUMNjintk0___ 
_whilethisZombiesrowjk1switchkindcasePOLEVAULT 
_costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost 
_break_____________________________ 
_default 
_costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k 
_numperrow 
_costnumperrowtoomanyzombiescostreturncostintsumplantsperrow 
_rowsplantskindnumperrow_ 
_intplantsnumformatintmallocROWsizeofint_ 
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_ 
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_ 
_plantsnumformatiSUNFLOWER1 
_break______________________________ 
_caseWINTERPEASHOOTER___ 
_plantsnumformatiWINTERPEASHOOTER1 
_break_______________________________ 
_casePEASHOOTER___ 
_plantsnumformatiPEASHOOTER1 
_break________________________________ 
_caseSMALLNUT__ 
_plantsnumformatiSMALLNUT1 
_break_________________________________ 
_casePEPPER__ 
_plantsnumformatiPEPPER1 
_break__________________________________ 
_caseSQUASH__ 
_plantsnumformatiSQUASH1 
_breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00 
_switchkindcaseNORMAL 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10 
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12 
_break___________________________________ 
_caseBUCKET____ 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10 
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1 
_break____________________________________ 
_casePOLEVAULT___ 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED 
_ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break 
_caseGARGANTUAR___ 
_ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11 
_plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11 
_forintj0jCOLUMNjifPlantsrowjNOPLANT 
_costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000 
_intindex0 
_forinti0ilengthiifmaxaimaxai 
_indexi 
_returnindex 
_NORMAL_ 
_BUCKET_ 
_POLEVAULT_ 
_SLED_ 
_GARGANTUARSUNFLOWER 
_WINTERPEASHOOTER_ 
_PEASHOOTER_ 
_SMALLNUT_ 
_PEPPER_ 
_SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice 
_ifthiswhetherneedcomputeNORMALreturn 
_zombie 
_doublezombiesparasZOMBIEKIND54231 
_doubledistancecost1distancerate005 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL 
_plant 
_intplantsnumformatROWPLANTKIND0 
_doubleplantsparaPLANTKIND88221005 
_intsumplantsperrow0thissumplantsperrow 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL 
_time 
_doubletimecost2011expthistimeTOTALTIME210005 
_forinti0iROWi__ 
_finalchoiceitimecostSun 
_doublesunbaseline60sunsub02 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub 
_forinti0iROWi___ 
_finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW 
_thisvalueNORMAL1finalchoicethischoiceNORMAL1 
_voidvaluebucketdoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice_ 
_ifthiswhetherneedcomputeBUCKETreturn 
_zombie_ 
_doublezombiesparasZOMBIEKIND254thistime100100522 
_doubledistancecost25distancerate01 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET 
_plant_ 
_intplantsnumformatROWPLANTKIND0_ 
_doubleplantsparaPLANTKIND63231004 
_intsumplantsperrowthissumplantsperrow 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET 
_time_ 
_doubletimecost2011expthistimeTOTALTIME310005 
_forinti0iROWi____ 
_finalchoiceitimecostSun_ 
_doublesunbaseline150sunsub05 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub 
_forinti0iROWi_____ 
_finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW 
_thisvalueBUCKET1finalchoicethischoiceBUCKET1 
_voidvaluepolevaultdoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice__ 
_ifthiswhetherneedcomputePOLEVAULTreturn 
_zombie__ 
_doublezombiesparasZOMBIEKIND1thistime10010051523 
_doubledistancecost25distancerate01_ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT 
_plant__ 
_intplantsnumformatROWPLANTKIND0__ 
_doubleplantsparaPLANTKIND52181001 
_intsumplantsperrowthissumplantsperrow_ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT 
_time__ 
_doubletimecost2011expthistimeTOTALTIME510005 
_forinti0iROWi______ 
_finalchoiceitimecostSun__ 
_doublesunbaseline120sunsub04 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub 
_forinti0iROWi_______ 
_finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW 
_thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1 
_voidvaluesleddoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice___ 
_ifthiswhetherneedcomputeSLEDreturn 
_zombie___ 
_doublezombiesparasZOMBIEKIND32174 
_doubledistancecost25distancerate01__ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED 
_plant___ 
_intplantsnumformatROWPLANTKIND0___ 
_doubleplantsparaPLANTKIND510361001and 
_intsumplantsperrowthissumplantsperrow__ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED 
_time___ 
_doubletimecost2011expthistimeTOTALTIME520005 
_forinti0iROWi________ 
_finalchoiceitimecostSun___ 
_doublesunbaseline200sunsub05 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub 
_forinti0iROWi_________ 
_finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW 
_thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice____ 
_ifthiswhetherneedcomputeGARGANTUARreturn 
_zombie____ 
_doublezombiesparasZOMBIEKIND2452015 
_doubledistancecost25distancerate01___ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR 
_plant____ 
_intplantsnumformatROWPLANTKIND0____ 
_doubleplantsparaPLANTKIND01002510010and 
_intsumplantsperrowthissumplantsperrow___ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR 
_time____ 
_doubletimecost 
_ifabsthistime50025absthistime100025absthistime150025 
_timecost100 
_timecost10011expthistimeTOTALTIME540004 
_forinti0iROWi__________ 
_finalchoiceitimecostSun____ 
_doublesunbaseline350sunsub06 
_doublesuncost11expthisSunsunbaseline10020010 
_forinti0iROWi___________ 
_finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW 
_thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1 
_externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame 
_gamemaintainplayerclassICamppublic 
_virtualintgetCurrentPlants0 
_Plantsijij0virtualintgetCurrentZombies0Zombiesijij 
_kk0Zombiesijk1 
_Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic 
_ICampCamp 
_virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0 
_virtualintgetScore0 
_virtualintgetKillPlantsScore0 
_virtualintgetKillZombiesScore0 
_virtualintgetNotBrokenLines0 
_virtualintgetBrokenLinesScore0 
_virtualintgetLeftPlants0intTypeplayerCampgetCurrentType 
_ifType0intNotBrokenLinesNumplayergetNotBrokenLines 
_intKillZombiesScoreplayergetKillZombiesScore 
_intLeftPlantsplayergetLeftPlants 
_intScoreplayergetScore 
_inttime0playergetTime 
_introwsplayerCampgetRows 
_intcolumnsplayerCampgetColumns 
_intPlaceCDplayerCampgetPlantCD 
_intPlantsplayerCampgetCurrentPlants 
_intZombiesplayerCampgetCurrentZombies 
_intLeftLinesplayerCampgetLeftLines 
_intSunplayerCampgetSun 
_Zombiesnumzombiesnum 
_zombiesnumcomputenumZombiesrowscolumns 
_Plantsnumplantsnum 
_plantsnumcomputenumPlantsrowscolumns 
_playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51 
_playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52 
_ifplantsnumsunflower3 
_playerPlacePlantSUNFLOWER0plantsnumsunflower1 
_playerPlacePlantSMALLNUT0plantsnumsmallnut5 
_playerPlacePlantSQUASH04 
_playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54 
_iftime06 
_playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45 
_ifSun400 
_playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame 
_valuemakedecisionifType1 
_intBrokenLinesScoreplayergetBrokenLinesScore 
_intKillPlantsScoreplayergetKillPlantsScore 
_intScoreplayergetScore_ 
_inttimeplayergetTime 
_introwsplayerCampgetRows_ 
_intcolumnsplayerCampgetColumns_ 
_intPlaceCDplayerCampgetPlantCD_ 
_intPlantsplayerCampgetCurrentPlants_ 
_intZombiesplayerCampgetCurrentZombies_ 
_intLeftLinesplayerCampgetLeftLines_ 
_intSunplayerCampgetSun_ 
_iftime3intzombienumcalculatezombienumsZombies49 
_valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame 
_valuevaluenormal 
_valuevaluebucket 
_valuevaluepolevault 
_valuevaluesled 
_valuevaluegargantuar 
_intdecision200 
_valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0 
_whileZombiesijk1 
_kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1 
_elseplayerPlaceZombiePOLEVAULT1 
_playerPlaceZombieNORMAL2 
_playerPlaceZombieBUCKET3 
