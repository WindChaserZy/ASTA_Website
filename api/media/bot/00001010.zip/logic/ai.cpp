#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
int row = 0;
void player_ai(IPlayer * player)
{
    int Type = player->Camp->getCurrentType();
    if (Type == 0) {
        //ֲ�﷽
        int Step = player->getTime();//�غ���
        int Sun = player->Camp->getSun();//����
        int Row = player->Camp->getRows();//����
        int Column = player->Camp->getColumns();//����
        int** _Plants = player->Camp->getCurrentPlants();//ֲ������
        int*** _Zombies = player->Camp->getCurrentZombies();//��ʬ����
        int* CD = player->Camp->getPlantCD();//����ֲ���CD

        //���з��غ����ݴ
        //ѭ�������ݶ�Ӧλ���Ƿ��ܷ��سɹ�
        if (Step == 2)
        {
            player->PlacePlant(3, 0, 0);
        }
        if (Step == 12)
        {
            player->PlacePlant(3, 0, 1);
        }
    }
    if (Type == 1) {
        //��ʬ��
        int Sun = player->Camp->getSun();//�¹���
        int Row = player->Camp->getRows();//����
        int Column = player->Camp->getColumns();//����
        int** Plants = player->Camp->getCurrentPlants();//ֲ������
        int*** Zombies = player->Camp->getCurrentZombies();//��ʬ����
        int* CD = player->Camp->getPlantCD();//��ʬCD
        int Step = player->getTime();//�غ���
        //ǰ����������
        if (Sun >= 300) {
            player->PlaceZombie(5, row);
            row = (row + 1) % 5;
        }
    }
}