#include "ai.h"
#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>
using namespace std;


typedef pair<int, int > node;

float zombiePH(int m_type,int steps) {
    float PH=0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270;
            break;
        case 2:PH = 820;
            break;
        case 3: PH = 200;
            break;
        case 4:PH = 1600;
            break;
        case 5:PH = 3000;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270 * steps / 1000;
            break;
        case 2:PH = 820 * steps / 1000;
            break;
        case 3: PH = 500 * steps / 1000;
            break;
        case 4:PH = 1350 * steps / 1000;
            break;
        case 5:PH = 3000 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return PH;
   
}

float zombiespeed(int m_type, int steps) {
    float speed = 0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: speed = 0;
            break;
        case 1:speed = 0.2;
            break;
        case 2:speed = 0.4;
            break;
        case 3: speed = 0.222;
            break;
        case 4:speed = 0.333;
            break;
        case 5:speed = 0.2;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: speed = 0 * steps / 1000;
            break;
        case 1:speed = 0.2 * steps / 1000;
            break;
        case 2:speed = 0.4 * steps / 1000;
            break;
        case 3: speed = 0.222 * steps / 1000;
            break;
        case 4:speed = 0.333 * steps / 1000;
            break;
        case 5:speed = 0.2 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return speed;
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 20;
        break;
    case 3:return 10;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}
int getZombieAttack(int m_type) {
    if (m_type > 0 && m_type <= 3) return 75;
    else return 0;
}


void player_ai(IPlayer* player)
{
    int Type = player->Camp->getCurrentType();//获取植物方还是僵尸方
    int** Plants = player->Camp->getCurrentPlants();//获取当前植物情况（向日葵1，冰豌豆2，豌豆射手3，坚果4，辣椒5，倭瓜6）
    int*** Zombies = player->Camp->getCurrentZombies();//获取当前僵尸情况（普通1，铁通2，撑杆跳3，路障4，伽刚特尔5）
    int rows = player->Camp->getRows();//返回有几行
    int columns = player->Camp->getColumns();//返回有几列
    int sun = player->Camp->getSun();//当前阳光数
    int time = player->getTime();//当前step
    int* LeftLines = player->Camp->getLeftLines();//各行是否攻破，1为未攻破
    int* PlantCD = player->Camp->getPlantCD();//获取当前CD
    
    float plantdamage[5];//统计植物方每一排的输出
    int plantfront[5];//统计植物前排位置
    int plantnum[5];//统计每一排植物数量
    int zombiefront[5];//统计植物前排位置
    float zombiedefence[5];//统计每一排僵尸防御
    int zombienum[5];//统计每一排僵尸的数量

    //遍历各行进行基础统计
    //遍历各行进行基础统计
    for (int i = 0; i < rows; i++) {
        plantdamage[i] = 0;
        plantfront[i] = 1;
        zombiefront[i] = 9;
        zombienum[i] = 0;
        zombiedefence[i] = 0;
        for (int j = 0; j < columns; j++) {
            if (Zombies[i][j][0] != -1) {
                if (j < zombiefront[i]) zombiefront[i] = j;//找出最靠前僵尸的坐标
                int k = 0;
                while (Zombies[i][j][k] != -1) {
                    zombiedefence[i] += zombiePH(Zombies[i][j][k], time);//统计这一排僵尸的血量
                    k++;
                    zombienum[i]++;
                }
            }

            if (j > plantfront[i] && Plants[i][j] != 0 && Plants[i][j] != 5 && Plants[i][j] != 6 && Plants[i][j] != 4) plantfront[i] = j;//找出最靠前的植物坐标

            if (Plants[i][j] != -1) {//统计一排的植物的 单位时间 输出总和
                if (Plants[i][j] == 2 || Plants[i][j] == 3)
                    plantdamage[i] += PlantAttack(Plants[i][j]);
            }
        }
    }


    if (Type == 0) {//当前为植物方


        //根据对面放的僵尸进行防守
        for (int i = 0; i < rows; i++) {

            float damage = 0;

            damage = (zombiefront[i] - plantfront[i] - 1) * 5 * plantdamage[i];

            if (zombiefront[i] < plantfront[i] && LeftLines[i] == 1 && PlantCD[4] == 0 && sun >= 125 && plantfront[i] + 1 < 10) {
                player->PlacePlant(5, i, plantfront[i] + 1);
                Plants[i][plantfront[i] + 1] = 5;
                sun -= 125;
                plantfront[i]++;
                PlantCD[4] == 1;
            }//僵尸跑到植物后面去了要出问题，放辣椒

            //if (time == 3)cout << zombiedefence[i] - damage << LeftLines[i] << PlantCD[5] << sun << zombiefront[i] - 1 << Plants[i][zombiefront[i] - 1] << endl;
            if (damage > zombiedefence[i]) continue;//防御力看起来够的话就先不放植物

            else if (zombiedefence[i] - damage > 1800 && LeftLines[i] == 1 && PlantCD[4] == 0 && sun >= 125 && zombiefront[i] - 1 < 10 && Plants[i][zombiefront[i]] == 0) {
                player->PlacePlant(5, i, zombiefront[i]);
                Plants[i][zombiefront[i] - 1] = 5;
                sun -= 125;
                PlantCD[4] = 1;
            }//对面比较强放辣椒

            else if (zombiedefence[i] - damage > 500 && LeftLines[i] == 1 && PlantCD[5] == 0 && sun >= 50 && zombiefront[i] - 1 < 10 && Plants[i][zombiefront[i]] == 0) {
                player->PlacePlant(6, i, zombiefront[i]);
                Plants[i][zombiefront[i] - 1] = 6;
                sun -= 50;
                PlantCD[5] = 1;
            }//阳光比较少种倭瓜

            else if (zombiedefence[i] - damage > 0 && LeftLines[i] == 1 && PlantCD[1] == 0 && sun >= 400 && plantfront[i] + 1 < 10 && Plants[i][plantfront[i] + 1] == 0) {
                player->PlacePlant(2, i, plantfront[i] + 1);
                Plants[i][plantfront[i] + 1] = 2;
                sun -= 400;
                plantfront[i]++;
                PlantCD[1] = 1;
            }//阳光更多一点种冰豌豆  
            else if (zombiedefence[i] - damage > 0 && LeftLines[i] == 1 && PlantCD[1] == 0 && sun >= 400 && plantfront[i] + 1 < 10 && Plants[i][plantfront[i] + 2] == 0) {
                player->PlacePlant(2, i, plantfront[i] + 2);
                Plants[i][plantfront[i] + 2] = 2;
                sun -= 400;
                plantfront[i]++;
                PlantCD[1] = 1;
            }//阳光更多一点种冰豌豆 

            else if (zombiedefence[i] - damage > 0 && zombiedefence[i] - damage < (zombiefront[i] - plantfront[i] - 1) * 5 * 10 && LeftLines[i] == 1 && PlantCD[2] == 0 && sun >= 100 && plantfront[i] + 1 < 10 && Plants[i][plantfront[i] + 1] == 0) {
                player->PlacePlant(3, i, plantfront[i] + 1);
                Plants[i][plantfront[i] + 1] = 3;
                sun -= 100;
                plantfront[i]++;
                PlantCD[2] = 1;
            }//阳光比较多种豌豆

            else if (zombiedefence[i] - damage > 0 && PlantCD[3] == 0 && sun >= 50 && plantfront[i] + 3 < 10 && Plants[i][plantfront[i] + 3] == 0 && plantfront[i] <= 5) {

                player->PlacePlant(4, i, plantfront[i] + 3);
                Plants[i][plantfront[i] + 5] = 3;
                sun -= 50;
                plantfront[i]++;
                PlantCD[3] = 1;
            }//阳光不太够种个坚果
            else if (zombiedefence[i] - damage > 0 && PlantCD[3] == 0 && sun >= 50 && plantfront[i] + 1 < 10 && Plants[i][plantfront[i] + 1] == 0 && zombiefront[i] >= plantfront[i] + 1 && plantfront[i] > 5) {

                player->PlacePlant(4, i, plantfront[i] + 1);
                Plants[i][plantfront[i] + 1] = 3;
                sun -= 50;
                plantfront[i]++;
                PlantCD[3] = 1;
            }//阳光不太够种个坚果
            else if (zombiedefence[i] - damage > 0 && PlantCD[3] == 0 && sun >= 50 && zombiefront[i] < 10 && Plants[i][zombiefront[i]] == 0 && zombiefront[i] <= plantfront[i] + 1) {

                player->PlacePlant(4, i, zombiefront[i]);
                Plants[i][zombiefront[i]] = 3;
                sun -= 50;
                plantfront[i]++;
                PlantCD[3] = 1;
            }//阳光不太够种个坚果
        }

        //防守结束开始种向日葵
        for (int i = 0; i < rows; i++) {
            if (Plants[i][0] == 0 && LeftLines[i] == 1 && PlantCD[0] == 0 && sun >= 50) {
                player->PlacePlant(1, i, 0);//在第0列种向日葵
                Plants[i][0] = 1;
                sun -= 50;
                PlantCD[0] = 1;
            }
            else if (Plants[i][0] == 1 && Plants[i][1] == 0 && LeftLines[i] == 1 && PlantCD[0] == 0 && sun >= 50) {
                player->PlacePlant(1, i, 1);//在第1列种向日葵
                Plants[i][1] = 1;
                sun -= 50;
                PlantCD[0] = 1;
            }
        }

        //阳光充足的时候种植物,找到最弱的一排加强一下
        int weak = 0;//最弱的一排

        for (int i = 0; i < 5; i++) {
            if (LeftLines[weak] == 0)weak++;
            if (plantdamage[weak] > plantdamage[i] && LeftLines[i] != 0) weak = i;
        }

        if (plantfront[weak] == 9 && PlantCD[1] == 0 && sun > 400) {
            for (int m = 0; m < plantfront[weak]; m++) {
                if (Plants[weak][m] == 0) {
                    player->PlacePlant(2, weak, m);
                    Plants[weak][m] = 2;
                    sun -= 400;
                    PlantCD[1] = 1;
                    break;
                }
                if (Plants[weak][m] == 4) {
                    player->removePlant(weak, m);
                    player->PlacePlant(2, weak, m);
                    Plants[weak][m] = 2;
                    sun -= 400;
                    PlantCD[3] = 1;
                    break;
                }
            }
        }

        if (sun > 400) {
            if (PlantCD[1] == 0) {
                int flag = 0;
                if (plantfront[weak] + 1 >= 7) {//太靠前了
                    for (int m = 0; m < plantfront[weak]; m++) {//补空格
                        if (Plants[weak][m] == 0) {
                            player->PlacePlant(2, weak, m);
                            Plants[weak][m] = 2;
                            sun -= 400;
                            PlantCD[1] = 1;
                            flag = 1;
                            break;
                        }
                    }
                    for (int m = 0; m < plantfront[weak] && flag == 0; m++) {//补空格
                        if (Plants[weak][m] == 4) {
                            player->removePlant(weak, m);
                            player->PlacePlant(2, weak, m);
                            Plants[weak][m] = 2;
                            sun -= 400;
                            PlantCD[3] = 1;
                            flag = 1;
                            break;
                        }
                    }
                    for (int m = 0; m < plantfront[weak] && flag == 0; m++) {//把后面的豌豆铲掉
                        if (Plants[weak][m] == 2) {
                            player->removePlant(weak, m);
                            player->PlacePlant(2, weak, m);
                            Plants[weak][m] = 2;
                            sun -= 400;
                            PlantCD[1] = 1;
                            flag = 1;
                            break;
                        }
                    }
                }
                else {
                    if (Plants[weak][plantfront[weak] + 1] == 0) {
                        player->PlacePlant(2, weak, plantfront[weak] + 1);
                        Plants[weak][plantfront[weak] + 1] = 2;
                        sun -= 400;
                        plantfront[weak]++;
                        PlantCD[1] = 1;
                    }
                    else if (Plants[weak][plantfront[weak] + 2] == 0) {
                        player->PlacePlant(2, weak, plantfront[weak] + 2);
                        Plants[weak][plantfront[weak] + 2] = 2;
                        sun -= 400;
                        plantfront[weak]++;
                        PlantCD[1] = 1;
                    }

                }
            }
            else if (PlantCD[2] == 0) {
                player->PlacePlant(3, weak, plantfront[weak] + 1);
                Plants[weak][plantfront[weak] + 1] = 3;
                sun -= 100;
                plantfront[weak]++;
                PlantCD[2] = 1;
            }
            else if (PlantCD[5] == 0 && Plants[weak][9] == 0) {
                player->PlacePlant(6, weak, 9);
                Plants[weak][9] = 6;
                sun -= 50;
                PlantCD[5] = 1;
            }
        }
        //考虑铲除植物，如果冰豌豆的位置过于靠前，就把后面的豌豆铲掉
        //如果都放满了就把后面的豌豆铲掉放冰豌豆


    }
    else {//当前为僵尸方
        vector<node> v;
        //damage = (zombiefront[i] - plantfront[i] - 1) * 5 * plantdamage[i];

        int nutsNum[5] = { 0,0,0,0,0 };
        int ZombieAttact[5] = { 0,0,0,0,0 };
        bool haveBoss[5] = { 0,0,0,0,0 };//伽刚特尔或雪橇车

        for (int i = 0; i < 5; i++)
            if (LeftLines[i] != 0)
        {
            int t = i;
            for (int j = 0; j < columns; j++)
            {
                nutsNum[t] += (Plants[t][j] == 4);
            }
            for (int j = 0; j < columns; j++)
            {
                for (int k = 0;; k++)
                {
                    if (Zombies[t][j][k] == -1)break;
                    ZombieAttact[t] += getZombieAttack(Zombies[t][j][k]);
                    haveBoss[t] = (haveBoss[t] || (Zombies[t][j][k] == 4) || (Zombies[t][j][k] == 5));
                }
            }
        }

        for(int i = 0; i < 5;i++)
            if (LeftLines[i] != 0)
            {
                int temp = (zombiefront[i] - plantfront[i] - 1) * 5 * plantdamage[i] ;
                if (!haveBoss[i])temp += (1000LL * nutsNum[i] / (ZombieAttact[i] + 75)) * plantdamage[i];
                v.push_back(make_pair(temp, i));
            }

        sort(v.begin(), v.end());
        if (v.empty()) return;

        memset(nutsNum, 0, sizeof nutsNum);
        memset(haveBoss, 0, sizeof haveBoss);

        for (int i = 0; i < v.size(); i++)
        {
            int t = v[i].second;
            for (int j = 0; j < columns; j++)
            {
                nutsNum[t] += (Plants[t][j] == 4);
            }
            for (int j = 0; j < columns; j++)
            {
                for (int k = 0;; k++)
                {
                    if (Zombies[t][j][k] == -1)break;
                    haveBoss[t] = (haveBoss[t] || (Zombies[t][j][k]== 4)|| (Zombies[t][j][k] == 5));
                }
            }
        }
        for (int i = 0; i < v.size();)
        {
            int t = v[i].second;
            int suibianqudechangshu = 100;
            bool placed = false;
            if (sun >= 300 && PlantCD[4] == 0) {//伽刚特尔
                player->PlaceZombie(5, t);
                sun -= 300;
                placed = true;
            }
            if (sun >= 200 && PlantCD[3] == 0) {//雪橇车
                player->PlaceZombie(4, t);
                sun -= 200;
                placed = true;
            }
            if (sun >= 125 && PlantCD[1] == 0 ) {//铁桶
                player->PlaceZombie(2, t);
                sun -= 125;
                placed = true;
            }// 
            if (sun >= 125 && PlantCD[2] == 0&&(v[i].first - 200 + suibianqudechangshu < 0 || sun >= 250) && (nutsNum[t] < 2 || haveBoss[t])) {
                player->PlaceZombie(3, t);
                sun -= 125;
                placed = true;
            }
            if (sun >= 50 && PlantCD[0] == 0 && v[i].first - 270 + suibianqudechangshu < 0 && (nutsNum[t] < 2 || haveBoss[t])) {
                player->PlaceZombie(1, t);
                sun -= 50;
                placed = true;
            }
            if (placed == false) i++;
        }
    }
}
