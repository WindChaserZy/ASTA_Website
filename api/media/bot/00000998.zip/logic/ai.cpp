#include "ai.h"
#include<iostream>
void player_ai(IPlayer* player) 
{

#pragma region GameStatus
    int plantNum = 0;
    int zombieRowNum[5] = { 0 };
    bool isPlant = false;//判断场上是否有植物存在
    bool isZombie = false;//判断场上是否有僵尸存在
    //bool isZombie_0 = false; 不用了
    //int Sun = player->Camp->getSun();
    //bool sunSupply = Sun > 600;
#pragma endregion

#pragma region Interface
    //int Type = player->Camp->getCurrentType();

    //int time = player->getTime();//获取当前回合数

    int** plantsInfo = player->Camp->getCurrentPlants();//获取当前植物情况
    // plantsInfo[i][j]表示第i行j列的植物情况0表示不存在
    int*** zombieInfo = player->Camp->getCurrentZombies();//获取当前僵尸情况
    //zombieInfo[i][j]表示第i行j列的僵尸情况，最后一位i，j，k代表 这各结束
    int rows = player->Camp->getRows();//获取当前行数
    int columns = player->Camp->getColumns();//获取当前列数

    for (int i = 0; i < rows; i++)//遍历植物
    {
        for (int j = 0; j < columns; j++)
        {
            if (plantsInfo[i][j] != 0)
            {
                plantNum++;
            }
        }
    }
    for (int i = 0; i < rows; i++)//   遍历僵尸,得到各行的僵尸总数
    {
        for (int j = 0; j < columns; j++)
        {
            int k = 0;
            while (zombieInfo[i][j][k] != -1)
            {
                zombieRowNum[i]++;
                k++;
            }

        }
    }

#pragma endregion

    int time = player->getTime();//获得当前回合数
    //int rows = player->Camp->getRows();//获得行数
    //int columns = player->Camp->getColumns();//获得列数
    int type = player->Camp->getCurrentType();//获得当前玩家类型
    int** plants = player->Camp->getCurrentPlants();//当前植物情况二维数组
    int*** zombies = player->Camp->getCurrentZombies();//当前僵尸情况三维数组

    //以下声明了很多个一维数组，用以计算某一行每种植物或僵尸数量，进而寻求对某一行的最优解
    int rowPlantNum[5] = { 0,0,0,0,0 };//植物总数
    int rowZombieNum[5] = { 0,0,0,0,0 };//僵尸总数
    int rowPeaNum[5] = { 0,0,0,0,0 };//豌豆射手总数
    int rowIceNum[5] = { 0,0,0,0,0 };//冰豌豆射手总数
    int rowPumpkinNum[5] = { 0,0,0,0,0 };//倭瓜总数
    int rowNutNum[5] = { 0,0,0,0,0 };//坚果总数

    //遍历植物二维数组计算每行植物数组对应的数量
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            if (plants[i][j] != 0)
            {
                rowPlantNum[i] += 1;
            }
            if (plants[i][j] == 2)
            {
                rowIceNum[i] += 1;
            }
            if (plants[i][j] == 3)
            {
                rowPeaNum[i] += 1;
            }
            if (plants[i][j] == 6)
            {
                rowPumpkinNum[i] += 1;
            }
            if (plants[i][j] == 4)
            {
                rowNutNum[i] += 1;
            }
        }
    }

    //植物方操作
    if (type == 0)
    {
        int Sun = player->Camp->getSun();
        bool sunSupply = Sun > 600;
        for (int i = 0; i < rows; i++) 
        {
            if (zombieRowNum[i] == 0 && plantsInfo[i][2] == 0)
            {
                player->PlacePlant(1, i, 2);
            }
            else if (zombieRowNum[i] == 0 && plantsInfo[i][2] != 0) 
            {
                player->PlacePlant(1, i, 3);             //种阳光花，首选种在没有僵尸的行的2列、3列
            }
            else if (zombieRowNum[i] == 1)
            {
                int zomPosition = -1;
                int zomType = -1;               
                for (int j = columns - 1; j >= 0; j--) 
                {
                    if (zombieInfo[i][j][0] != -1)
                    {
                        zomPosition = j;
                        zomType = zombieInfo[i][j][0];
                        break;           
                    }
                }                   //得到这一个僵尸的种类和位置   
                if (zomPosition <= 4)        //僵尸较近时，用倭瓜
                {
                    player->PlacePlant(6, i, zomPosition - 1);
                    player->PlacePlant(6, i, zomPosition);
                    player->PlacePlant(6, i, zomPosition - 2);
                }
                else if (zomType == 1)       //普通僵尸，用豌豆
                {
                    player->PlacePlant(3, i, 0);

                }
                else if (zomType == 3)        //撑杆跳：用坚果墙或者向日葵垫一下，后面种向日葵
                {
                    player->PlacePlant(4, i, 4);
                    player->PlacePlant(3, i, 0);
                }
                else if (zomType == 2 && !sunSupply || zomType == 4)  //雪车出现或铁桶出现（且阳光不充足），用倭瓜
                {
                    player->PlacePlant(6, i, zomPosition - 1);
                    player->PlacePlant(6, i, zomPosition);
                    player->PlacePlant(6, i, zomPosition - 2);
                }
                else if (zomType == 2 && sunSupply)  //铁桶出现，且阳光充足，用冰豆
                {
                    player->PlacePlant(2, i, 0);
                    player->PlacePlant(2, i, 1);
                }
        
                else if (zomType == 5)   //伽刚特尔，用倭瓜和炸弹
                {
                    player->PlacePlant(6, i, zomPosition - 1);
                    player->PlacePlant(6, i, zomPosition);
                    player->PlacePlant(6, i, zomPosition - 2);
                    player->PlacePlant(5, i, zomPosition - 1);
                    player->PlacePlant(5, i, zomPosition - 2);
                    player->PlacePlant(5, i, zomPosition - 3);
                }
            }
           else if (zombieRowNum[i] > 1)  //一行的僵尸多于一个时
            {
                bool isCarOrGiant=false;    //是否有雪车和伽刚特尔
                int* zomPosition = new int[zombieRowNum[i]];
                int* zomType =  new int[zombieRowNum[i]];
                int a = 0;
                for (int j = columns - 1; j >= 0; j--) 
                {
                    int k = 0;
                    while (zombieInfo[i][j][k] != -1) 
                    {
                        zomPosition[a] = k;
                        zomType[a] = zombieInfo[i][j][k];
                        a++;
                        k++;
                    }             //得到这一行的僵尸位置及其种类
                }
                for (int j = 0; j < zombieRowNum[i]; j++) 
                {
                   if (zomType[j] == 4 || zomType[j] == 5)
                   {
                        isCarOrGiant = true;
                        break;
                   }
                }  //判断本行有无雪车和伽刚
                if (isCarOrGiant||zombieRowNum[i]>2) 
                {
                    player->PlacePlant(5, i, 1);
                    player->PlacePlant(5, i, 2);
                    player->PlacePlant(5, i, 3);
                    player->PlacePlant(5, i, 4);
                    player->PlacePlant(5, i, 5);
                    player->PlacePlant(5, i, 6);
                    player->PlacePlant(5, i, 7);
                   }  //若有雪车，或者僵尸数大于2，就炸了
                      

                else if (plantsInfo[i][0] == 3 || plantsInfo[i][0] == 2 || plantsInfo[i][1] == 3 || plantsInfo[i][0] == 2)
                {
                    if (sunSupply) 
                    {
                        player->PlacePlant(2, i, 0);
                        player->PlacePlant(2, i, 0);
                    }
                    else 
                    {
                        player->PlacePlant(3, i, 0);
                        player->PlacePlant(3, i, 0);
                    }
                } 
                delete[]zomPosition;
                delete[]zomType;

          }
        }
    }

    
   //僵尸方操作
    if(type == 1)
    {
        int sun = player->Camp->getSun();
        int* zombieCD = player->Camp->getPlantCD();

        for (int i = 0; i < rows; i++)
        {
            if (rowPeaNum[i] != 0 || rowIceNum[i] != 0)
            {
                if (rowPumpkinNum[i] == 0)
                {
                    if (rowNutNum[i] == 0)
                    {
                        if (rowIceNum[i] == 0)
                        {
                            if (rowZombieNum[i] <= 1)
                            {
                                if (zombieCD[2] == 0)
                                {
                                    player->PlaceZombie(2, i);
                                }
                                if (zombieCD[3] == 0)
                                {
                                    player->PlaceZombie(3, i);
                                }
                            }
                        }
                        else
                        {
                            if (rowZombieNum[i] == 0)
                            {
                                player->PlaceZombie(4, i);
                            }
                        }
                    }
                    else
                    {
                        if (rowZombieNum[i] <= 1)
                        {
                            if (zombieCD[4] == 0)
                            {
                                player->PlaceZombie(4, i);
                            }
                            if (zombieCD[2] == 0)
                            {
                                player->PlaceZombie(2, i);
                            }
                        }
                    }
                }
                else
                {
                    if (rowZombieNum[i] <= 1)
                    {
                        if (zombieCD[1] == 0)
                        {
                            player->PlaceZombie(1, i);
                        }
                        if (zombieCD[2] == 0)
                        {
                            player->PlaceZombie(2, i);
                        }
                    }
                }
            }

            else if (time != 1)
            {
                if (rowPumpkinNum[i] == 0)
                {
                    if (rowZombieNum[i] == 0)
                    {
                        player->PlaceZombie(1, i);
                    }
                }
            }
        }
    }
}