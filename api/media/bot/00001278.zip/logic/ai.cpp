#include "ai.h"
#include <iostream>


int zombiePH(int m_type) {
    switch (m_type)
    {
    case 0: return 0;
        break;
    case 1:return 270;
        break;
    case 2:return 1370;
        break;
    case 3: return 500;
        break;
    case 4:return 1350;
        break;
    case 5:return 3000;
        break;
    default:
        break;
    }
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 26;
        break;
    case 3:return 20;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}

// ֲ�����
static int phealth[10] = { 0,300,300,300,4000,300,300 };
static int pcost[10] = { 0,50,400,100,125,50,50 };
static int pcd[10] = { 0,10,30,10,40,60,60 };

// ��ʬ����
static int zhealth[10] = { 0,270,820,200,1600,3000 };
static int zhealth0[10] = { 0,270,820,200,1600,3000 };
static int zcost[10] = { 0,50,125,125,300,300 };
static int zattack[10] = { 0,75,75,75,8000,8000 };
static int zattack0[10] = { 0,75,75,75,8000,8000 };
static double zspeed[10] = { 0,0.2,0.2,0.4,0.33333,0.2 };
static int zcd[10] = { 0,15,20,20,25,25 };

struct PLant {
    int type; // 1-6
    int health;
    int state; // �㶹0-2 ����0-3��0ʱ�������ã�
};

struct ZOmbie {
    int type; // 1-5
    int health;
    double x;
    int debuff; // 0-10
    int state; // �Ÿ�0 1��0ʱδ����
};

//ȫ�ּ�¼����

PLant p[5][10] = { 0 };
ZOmbie z[5][10][100] = { 0 };

//ģ�⺯��

static int work(PLant* a, ZOmbie b[][100], int& Step) {
    int result = 10;
    for (int i = 0; i < 10; i++) {
        if (b[i][0].type) {
            result = i;
            break;
        }
    }
    int K = 200;
    if (Step == -1) K = 1;
    Step = 1;
    for (int k = 1; k <= K; k++) {
        for (int i = 0; i < 10; i++) {
            if (a[i].type == 6) {
                if (b[i][0].type) {
                    for (int j = 0; j < 100; j++) {
                        if (!b[i][j].type) break;
                        b[i][j].health -= 1800;
                    }
                    a[i].type = 0;
                }
            }
            if (a[i].type == 5) {
                for (int m = 0; m < 10; m++) {
                    for (int j = 0; j < 100; j++) {
                        if (!b[m][j].type) break;
                        b[m][j].health -= 1800;
                    }
                }
                a[i].type = 0;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                for (int j = 0; j < p; j++) {
                    if (b[i][j].health <= 0) {
                        b[i][j].type = 0;
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j + 1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                int p2 = 0;
                if (i) {
                    while (b[i - 1][p2].type) p2++;
                }
                if (a[i].type) {
                    for (int j = 0; j < p; j++) {
                        if (b[i][j].debuff) a[i].health -= zattack[b[i][j].type] / 2;
                        else a[i].health -= zattack[b[i][j].type];
                        if (a[i].health <= 0) a[i].type = 0;
                        if (b[i][j].debuff) b[i][j].debuff--;
                        if (b[i][j].type == 3 && b[i][j].state == 0) {
                            if (!i) return -1;
                            else {
                                b[i][j].state = 1;
                                b[i][j].x -= 1;
                                b[i - 1][p2] = b[i][j];
                                p2++;
                            }
                            b[i][j].type = 0;
                        }
                    }
                }
                if (!a[i].type) {
                    for (int j = 0; j < p; j++) {
                        if (b[i][j].type) {
                            double Speed = zspeed[b[i][j].type];
                            if (b[i][j].type == 3 && b[i][j].state == 1) Speed = 0.22222;
                            if (b[i][j].type == 4 && i < 6) Speed = 0.125;
                            if (b[i][j].type == 4 && i >= 6) Speed = 0.06944 * i - 0.29164;
                            if (b[i][j].debuff) b[i][j].x -= Speed / 2;
                            else b[i][j].x -= Speed;
                            if (b[i][j].debuff) b[i][j].debuff--;
                            if (b[i][j].x <= 0) return -1;
                            if (((int)b[i][j].x) < i) {
                                b[i - 1][p2] = b[i][j];
                                p2++;
                                b[i][j].type = 0;
                            }
                        }
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j + 1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type && i < result) {
                result = i;
                break;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (a[i].health <= 0) a[i].type = 0;
        }
        for (int i = 0; i < 10; i++) {
            if (a[i].type == 2) {
                if (a[i].state == 0) {
                    for (int j = i; j < 10; j++) {
                        if (b[j][0].type) {
                            double minn = 10;
                            int temp = 0;
                            int p = 0;
                            while (b[j][p].type) p++;
                            for (int m = 0; m < p; m++) {
                                if (b[j][m].x < minn) {
                                    minn = b[j][m].x;
                                    temp = m;
                                }
                            }
                            b[j][temp].health -= 60;
                            b[j][temp].debuff = 10;
                            break;
                        }
                    }
                }
                a[i].state = (a[i].state + 1) % 4;
            }
            if (a[i].type == 3) {
                if (a[i].state == 0) {
                    for (int j = i; j < 10; j++) {
                        if (b[j][0].type) {
                            double minn = 10;
                            int temp = 0;
                            int p = 0;
                            while (b[j][p].type) p++;
                            for (int m = 0; m < p; m++) {
                                if (b[j][m].x < minn) {
                                    minn = b[j][m].x;
                                    temp = m;
                                }
                            }
                            b[j][temp].health -= 20;
                            break;
                        }
                    }
                }
                a[i].state = (a[i].state + 1) % 3;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                int p = 0;
                while (b[i][p].type) p++;
                for (int j = 0; j < p; j++) {
                    if (b[i][j].health <= 0) {
                        b[i][j].type = 0;
                    }
                }
                for (int j = 0; j < p; j++) {
                    if (!b[i][j].type) {
                        for (int m = j + 1; m < p; m++) {
                            if (b[i][m].type) {
                                b[i][j] = b[i][m];
                                b[i][m].type = 0;
                            }
                        }
                    }
                }
            }
        }
        int f4 = 0;
        for (int i = 0; i < 10; i++) {
            if (b[i][0].type) {
                f4 = 1;
            }
        }
        if (f4) Step++;
    }
    return result;
}

void player_ai(IPlayer* player) {

    int Type = player->Camp->getCurrentType();

    if (Type == 0) {
        int NotBrokenLinesNum = player->getNotBrokenLines();
        int KillZombiesScore = player->getKillZombiesScore();
        int time = player->getTime();
        int* LeftLines = player->Camp->getLeftLines();
        int Sun = player->Camp->getSun();
        int* CD = player->Camp->getPlantCD();
        int** Plants = player->Camp->getCurrentPlants();
        int*** Zombies = player->Camp->getCurrentZombies();

        // ����ȫ������

        if (time > 1000) {
		            for (int i = 1; i <= 5; i++) {
		                zhealth[i] = (int)(zhealth0[i] * (time / 1000.0));
		                zattack[i] = (int)(zattack0[i] * (time / 1000.0));
		            }
		        }
		        for (int i = 0; i < 5; i++) {
						            if (LeftLines[i]) {
						                for (int j = 0; j < 10; j++) {
						                    p[i][j].type = Plants[i][j];
						                    p[i][j].health = phealth[Plants[i][j]];
						                    if (j >= 8) p[i][j].health = (int)(p[i][j].health * 0.8);
						                    p[i][j].state = 2;
						                }
						               
						            }
						        }
						        for (int i = 0; i < 5; i++) {
						            if (LeftLines[i]) {
						                for (int j = 0; j < 10; j++) {
						                    int p = 0;
						                    while (Zombies[i][j][p] != -1) {
						                        z[i][j][p].type = Zombies[i][j][p];
						                        z[i][j][p].health = zhealth[z[i][j][p].type];
						                        z[i][j][p].debuff = 0;
						                        z[i][j][p].x = j+0.5;
						                        z[i][j][p].state = 0;
						                        if(j<=3) z[i][j][p].state = 1;
						                        p++;
						                    }
						                }
						            }
						        }

        // Movement
        if (time <= 22) {
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        int p = 0;
                        while (Zombies[i][j][p] != -1) p++;
                        s += p;
                    }
                    if (s >= 3) {
                        for (int m = 0; m < 4; m++) {
                            if (Zombies[i][m][0] != -1) player->PlacePlant(5, i, 9);
                        }
                        if (Sun >= 125 && !CD[0]) { //���տ�
                            for (int m = 4; m >= 0; m--) {
                                if (!Plants[m][1]) player->PlacePlant(1, m, 1);
                            }
                        }
                        return;
                    }
                }
            }
        }


        PLant p1[5][10] = { 0 };
        ZOmbie z1[5][10][100] = { 0 };
        int result[5] = { 0 };
        int take[5] = { 0 };
        int front[5] = { 0 };

        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                for (int j = 0; j < 10; j++) p1[i][j] = p[i][j];
                for (int j = 0; j < 10; j++) {
                    for (int r = 0; r < 100; r++) {
                        if (!z[i][j][r].type) break;
                        z1[i][j][r] = z[i][j][r];
                    }
                }
                result[i] = work(p1[i], z1[i], take[i]);
            }
        }
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                for (int j = 0; j < 10; j++) {
                    if (Plants[i][j] && Plants[i][j] != 4 && Plants[i][j] != 5 && Plants[i][j] != 6) front[i] = j;
                }
            }
        }
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            if (LeftLines[i]) {
                if (result[i] < front[i]) sum++;
            }
        }


        if (sum == 0) {
            int flag1 = 1;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i] && result[i] != 10) flag1 = 0;
            }
            int temp = 0;
            if (flag1) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    if (LeftLines[i]) {
                        int s = 0;
                        for (int j = 0; j < 10; j++) {
                            if (Plants[i][j] == 3 || Plants[i][j] == 4) s++;
                            if (Plants[i][j] == 2) s += 3;
                        }
                        if (s < minn) {
                            minn = s;
                            temp = i;
                        }
                    }
                }
            }
            else {
                int minn = 10;
                for (int i = 0; i < 5; i++) {
                    if (LeftLines[i] && result[i] < minn) {
                        minn = result[i];
                        temp = i;
                    }
                }
            }
            if (Sun >= 500 && !CD[1] && time > 100) { //���㶹
                for (int j = 0; j < 6; j++) {
                    if (Sun < 525 && j >= 2) break;
                    if (Sun < 575 && j >= 3) break;
                    if (Plants[temp][j] != 2 && j != 1) {
                        if (Plants[temp][j]) player->removePlant(temp, j);
                        player->PlacePlant(2, temp, j);
                        break;
                    }
                }
            }
            if (Sun >= 50 && !CD[0]) { //���տ�
                for (int i = 4; i >= 0; i--) {
                    if (result[i] >= 8 && Plants[i][1] != 1 && time > 30) {
                        player->removePlant(i, 1);
                        player->PlacePlant(1, i, 1);
                        break;
                    }
                    if (result[i] >= 2 && !Plants[i][1]) player->PlacePlant(1, i, 1);
                }
                for (int i = 4; i >= 0; i--) {
                    if (result[i] >= 3 && !Plants[i][2]) player->PlacePlant(1, i, 2);
                }
            }
            if (Sun >= 275 && !CD[2] && time >= 60) { //�㶹
                int fl1 = 1;
                for (int m = 0; m < 5; m++) {
                    if (Plants[m][0] != 2) fl1 = 0;
                }
                if (fl1) {
                    for (int j = 3; j < 6; j++) {
                        if (Sun < 525 && j >= 4) break;
                        if (!Plants[temp][j]) {
                            player->PlacePlant(3, temp, j);
                            break;
                        }
                    }
                }
            }
            if (Sun >= 225 && !CD[3] && time > 100) { //���
                for (int j = 6; j < 8; j++) {
                    if (!p[temp][j].type) {
                        player->PlacePlant(4, temp, j);
                        break;
                    }
                }
            }
        }

        
        else {
            for (int i = 0; i < 5; i++) {
                int temp = 0;
                int minn = 10;
                int temp2 = 10;
                for (int j = 0; j < 5; j++) {
                    if (LeftLines[j] && result[j] < minn) {
                        minn = result[j];
                        for (int m = 0; m < 10; m++) {
                            if (Zombies[j][m][0] != -1) {
                                temp2 = m;
                                break;
                            }
                        }
                        temp = j;
                    }
                    else if (LeftLines[j] && result[j] == minn) {
                        for (int m = 0; m < 10; m++) {
                            if (Zombies[j][m][0] != -1) {
                                if (m < temp2) {
                                    temp2 = m;
                                    temp = j;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (result[temp] >= front[temp]) {
                    break;
                }

                PLant p2[10] = { 0 };
                for (int j = 0; j < 10; j++) {
                    p2[j] = p[temp][j];
                }
                int f3 = 0;
                for (int j = 0; j < 10; j++) {
                    for (int r = 0; r < 100; r++) {
                        if (!z[temp][j][r].type) break;
                        if (z[temp][j][r].type == 4 || z[temp][j][r].type == 5) f3 = 1;
                    }
                }

                if (Sun >= 125 && !CD[2]) { //�㶹
                    PLant p3[10] = { 0 };
                    ZOmbie z3[10][100] = { 0 };
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    int ttemp = -1;
                    for (int j = 0; j < 7; j++) {
                        if (!p3[j].type) {
                            ttemp = j;
                            p3[j].type = 3;
                            p3[j].health = phealth[p3[j].type];
                            p3[j].state = 0;
                            break;
                        }
                    }

                    if (ttemp != -1) {
                        int taken = 0;
                        int result2 = work(p3, z3, taken);
                        int s4 = 0;
                        for (int j = 0; j < 10; j++) {
                            for (int r = 0; r < 100; r++) {
                                if (z[temp][j][r].type) s4 += z[temp][j][r].health;
                            }
                        }
                        if (!(time <= 40 && s4 > 270)) {
                            if (result2 > result[temp] || (result2 == -1 && taken - take[temp] >= 35) || (!f3 && CD[3] <= 5 && temp2 > 1) ) {
                                player->PlacePlant(3, temp, ttemp);
                                p2[ttemp].type = 3;
                                p2[ttemp].health = phealth[p2[ttemp].type];
                                p2[ttemp].state = 0;
                                result[temp] = result2;
                                take[temp] = taken;
                                if (result[temp] >= front[temp]) continue;
                            }
                        }
                        
                    }
                }
                if (Sun >= 50 && !CD[3]) { //���
                    PLant p3[10] = { 0 };
                    ZOmbie z3[10][100] = { 0 };
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    int f = 6;
                    for (int j = 0; j < 8; j++) {
                        if (Zombies[temp][j][0] != -1) {
                            f = j - 1;
                            break;
                        }
                    }
                    if (!p3[f].type) {
                        p3[f].type = 4;
                        p3[f].health = phealth[p3[f].type];
                        p3[f].state = 0;
                    }
                    int taken = 0;
                    int result2 = work(p3, z3, taken);
                    if (result2 > result[temp] || (result2 ==-1 && taken - take[temp] >= 40)) {
                        player->PlacePlant(4, temp, f);
                        p2[f].type = 4;
                        p2[f].health = phealth[p2[f].type];
                        p2[f].state = 0;
                        result[temp] = result2;
                        take[temp] = taken;
                        if (result[temp] >= front[temp]) continue;
                    }
                }
                if (Sun >= 550 && !CD[1]) { //���㶹
                    PLant p3[10] = { 0 };
                    ZOmbie z3[10][100] = { 0 };
                    for (int j = 0; j < 10; j++) p3[j] = p2[j];
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (!z[temp][j][r].type) break;
                            z3[j][r] = z[temp][j][r];
                        }
                    }
                    int ttemp = -1;
                    for (int j = 0; j < 5; j++) {
                        if (Plants[temp][j] != 2 && temp2 > j+1) {
                            ttemp = j;
                            p3[j].type = 2;
                            p3[j].health = phealth[p3[j].type];
                            p3[j].state = 0;
                            break;
                        }
                    }

                    if (ttemp != -1) {
                        int taken = 0;
                        int result2 = work(p3, z3, taken);
                        if (result2 > result[temp] || (result2 == -1 && taken - take[temp] >= 35) ||(!f3 && CD[3] <= 5) || (f3 && Sun>=575)) {
                            if (Plants[temp][ttemp]) {
                                player->removePlant(temp, ttemp);
                            }
                            player->PlacePlant(2, temp, ttemp);
                            p2[ttemp].type = 2;
                            p2[ttemp].health = phealth[p2[ttemp].type];
                            p2[ttemp].state = 0;
                            result[temp] = result2;
                            take[temp] = taken;
                            if (result[temp] >= front[temp]) continue;
                        }
                    }
                }

                if (Sun >= 50 && !CD[5]) { //����
                    PLant p3[10] = { 0 };
                    ZOmbie z3[10][100] = { 0 };
                    int maxn = 0, te = 0;
                    for (int j = 0; j < 10; j++) {
                        int s = 0;
                        for (int r = 0; r < 100; r++) {
                            if (z[temp][j][r].type) s += z[temp][j][r].health;
                        }
                        if (s > maxn) maxn = s, te = j - 1;
                    }
                    if (te < 0) te = 0;
                    if ((maxn>270 || temp2<=2) && !Plants[temp][te]) {
                        player->PlacePlant(6, temp, te);
                        p2[te].type = 6;
                        p2[te].health = phealth[p2[te].type];
                        p2[te].state = 0;

                        for (int j = 0; j < 10; j++) p3[j] = p2[j];
                        for (int j = 0; j < 10; j++) {
                            for (int r = 0; r < 100; r++) {
                                if (!z[temp][j][r].type) break;
                                z3[j][r] = z[temp][j][r];
                            }
                        }
                        int taken = 0;
                        result[temp] = work(p3, z3, taken);
                        take[temp] = taken;
                        if (result[temp] >= front[temp]) continue;
                    }
                }
                if (Sun >= 125 && !CD[4]) { //����
                    PLant p3[10] = { 0 };
                    ZOmbie z3[10][100] = { 0 };
                    int s = 0, flag4 = 0, minnum = 10;
                    for (int j = 0; j < 10; j++) {
                        for (int r = 0; r < 100; r++) {
                            if (z[temp][j][r].type) s += z[temp][j][r].health;
                        }
                    }
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[temp][j][0] != -1) {
                            minnum = j;
                            break;
                        }
                    }
                    if (s > 1600) flag4 = 1;
                    if (minnum <= 8 && s >= 600) flag4 = 1;
                    if (minnum <= 1 && result[temp] == -1 && take[temp] < 10) flag4 = 1;
                    if (flag4) {
                        for (int j = 3; j < 10; j++) {
                            if (!Plants[temp][j]) {
                                player->PlacePlant(5, temp, j);
                                p2[j].type = 5;
                                p2[j].health = phealth[p2[j].type];
                                p2[j].state = 0;
                            }
                        }
                        for (int j = 0; j < 10; j++) p3[j] = p2[j];
                        for (int j = 0; j < 10; j++) {
                            for (int r = 0; r < 100; r++) {
                                if (!z[temp][j][r].type) break;
                                z3[j][r] = z[temp][j][r];
                            }
                        }
                        int taken = 0;
                        result[temp] = work(p3, z3, taken);
                        take[temp] = taken;
                        if (result[temp] >= front[temp]) continue;
                    }
                }
                if (Sun >= 125 && !CD[0]) { //���տ�
                    for (int j = 4; j >= 0; j--) {
                        if (LeftLines[j] && result[j] >= 8 && Plants[j][1] && Plants[j][1] != 1 && time >= 40) {
                            player->removePlant(j, 1);
                            //player->PlacePlant(1, j, 1);
                            break;
                        }
                        if (LeftLines[j] && result[j] >= 2 && !Plants[j][1]) {
                            player->PlacePlant(1, j, 1);
                            break;
                        }
                    }
                    for (int j = 4; j >= 0; j--) {
                        if (LeftLines[j] && result[j] >= 3 && !Plants[j][2]) {
                            player->PlacePlant(1, j, 2);
                            break;
                        }
                    }
                }
            }
        }
    }

    if (Type == 1) {
        int BrokenLinesScore = player->getBrokenLinesScore();
        int KillPlantsScore = player->getKillPlantsScore();
        int time = player->getTime();
        int* LeftLines = player->Camp->getLeftLines();
        int Sun = player->Camp->getSun();
        int* CD = player->Camp->getPlantCD();
        int** Plants = player->Camp->getCurrentPlants();
        int*** Zombies = player->Camp->getCurrentZombies();

        // ����ȫ������

        if (time > 1000) {
		            for (int i = 1; i <= 5; i++) {
		                zhealth[i] = (int)(zhealth0[i] * (time / 1000.0));
		                zattack[i] = (int)(zattack0[i] * (time / 1000.0));
		            }
		        }
		        for (int i = 0; i < 5; i++) {
						            if (LeftLines[i]) {
						                for (int j = 0; j < 10; j++) {
						                    p[i][j].type = Plants[i][j];
						                    p[i][j].health = phealth[Plants[i][j]];
						                    if (j >= 8) p[i][j].health = (int)(p[i][j].health * 0.8);
						                    p[i][j].state = 2;
						                }
						               
						            }
						        }
						        for (int i = 0; i < 5; i++) {
						            if (LeftLines[i]) {
						                for (int j = 0; j < 10; j++) {
						                    int p = 0;
						                    while (Zombies[i][j][p] != -1) {
						                        z[i][j][p].type = Zombies[i][j][p];
						                        z[i][j][p].health = zhealth[z[i][j][p].type];
						                        z[i][j][p].debuff = 0;
						                        z[i][j][p].x = j+0.5;
						                        z[i][j][p].state = 0;
						                        if(j<=3) z[i][j][p].state = 1;
						                        p++;
						                    }
						                }
						            }
						        }

        // Movement
        
        if (time == 1) {
            player->PlaceZombie(2, 3);
        }
        if (time == 2) {
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i] && i != 3) {
                    int fl = 1;
                    for (int j = 0; j < 10; j++) {
                        if (Plants[i][j]) fl = 0;
                    }
                    if (fl) player->PlaceZombie(3, i);
                }
            }
        }
        if (time == 3) {
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    int fl = 1;
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1 || Plants[i][j]) fl = 0;
                    }
                    if (fl) player->PlaceZombie(1, i);
                }
            }
        }
        if (time >= 4 && time <= 40 && !CD[0]) {
            int temp = 4;
            int minn = 30;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    int fl = 1;
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) fl = 0;
                    }
                    if (fl) {
                        int s = 0;
                        for (int j = 0; j < 10; j++) {
                            if (p[i][j].type == 3 || p[i][j].type == 4) s += 2;
                            if (p[i][j].type == 1) s--;
                            if (p[i][j].type == 2) s += 3;
                        }
                        if (s <= minn) {
                            minn = s;
                            temp = i;
                        }
                    }
                }
            }
            player->PlaceZombie(1, temp);
        }




        if (time == 488) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(2, temp);
        }
        if (time == 495) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(3, temp);
            player->PlaceZombie(5, temp);
        }
        if (time == 501) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(2, temp);
            player->PlaceZombie(3, temp);
        }
        if (time >= 502 && time <= 512) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(5, temp);
        }



        if (time == 991) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1001) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }


        if (time == 1466) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1491) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1501) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }


        if (time == 1865) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1890) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
        if (time == 1915) {
            int temp = 4;
            int flag3 = 0;
            for (int i = 0; i < 5; i++) {
                if (LeftLines[i]) {
                    for (int j = 0; j < 10; j++) {
                        if (Zombies[i][j][0] != -1) temp = i, flag3 = 1;
                    }
                }
                if (flag3) break;
            }
            if (!flag3) {
                int minn = 30;
                for (int i = 0; i < 5; i++) {
                    int s = 0;
                    for (int j = 0; j < 10; j++) {
                        if (p[i][j].type == 3 || p[i][j].type == 4) s++;
                        if (p[i][j].type == 1) s -= 2;
                        if (p[i][j].type == 2) s += 4;
                    }
                    if (LeftLines[i] && s <= minn) {
                        minn = s;
                        temp = i;
                    }
                }
            }
            player->PlaceZombie(4, temp);
            player->PlaceZombie(5, temp);
            player->PlaceZombie(3, temp);
            player->PlaceZombie(2, temp);
            player->PlaceZombie(1, temp);
        }
    }
}
