#include <vector>
#include "ai.h"


class Zombies
{
public:
	int everyRowNum[5] = { 0 };
	int everyRowZombieNum[5][6] = { 0 };
	std::vector<std::pair<int, int>> ZombieType[5];
	Zombies(int*** zombies)
	{
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				int k = 0;
				while (zombies[i][j][k]!=-1)
				{	
					everyRowNum[i]++;
					everyRowZombieNum[i][zombies[i][j][k]]++;
					ZombieType[zombies[i][j][k]].push_back(std::pair<int,int>(i, j));
					k++;
				}
			}
		}
	}
};


void placeSunFlower(IPlayer*player, int sun, int CD, int **plants, int* leftLines)
{
	for (int j = 2; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 150 && leftLines[i])
			{
				player->PlacePlant(1, i, j);
			}
		}
	}
}

void placePeaShooter(IPlayer* player, int sun, int CD, int** plants, Zombies zombies, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowZombieNum[i][1] && !CD && sun >= 200 && leftLines[i])
		{
			if (!plants[i][1])
			{
				player->PlacePlant(2, i, 1);
				return;
			}
			if (!plants[i][0])
			{
				player->PlacePlant(2, i, 0);
				return;
			}
			
		}
	}

	for (int j = 0; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 200 && leftLines[i])
			{
				player->PlacePlant(2, i, j);
			}
		}
	}
}


void placeIcePeaShooter(IPlayer* player, int sun, int CD, int** plants, Zombies zombies, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowZombieNum[i][1] && !CD && sun >= 500 && leftLines[i])
		{
			if (plants[i][1])
			{
				player->removePlant(i, 1);
				player->PlacePlant(3, i, 1);
				return;
			}
			if (plants[i][0])
			{
				player->removePlant(i, 1);
				player->PlacePlant(3, i, 0);
				return;
			}
		}
	}

	for (int j = 0; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 200 && leftLines[i])
			{
				player->PlacePlant(3, i, j);
			}
		}
	}
}

void placeChili(IPlayer* player, int sun, int CD, int** plants, Zombies zombies, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowNum[i] >= 4 && !CD && sun >=125 && leftLines[i])
		{
			player->PlacePlant(4, i, 4);
		}
	}
}

void placeWogua(IPlayer* player, int sun, int CD, int** plants, Zombies zombies, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.ZombieType[i].size()!=0 && !CD && sun >= 50 && leftLines[i])
		{
			if (!plants[zombies.ZombieType[i][0].first][zombies.ZombieType[i][0].second - 1])
				player->PlacePlant(5, zombies.ZombieType[i][0].first, zombies.ZombieType[i][0].second - 1);
		}
	}
}

void placeNut(IPlayer* player, int sun, int CD, int** plants, Zombies zombies, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	{
		if (zombies.everyRowZombieNum[i][3] && !CD && sun >= 50 && leftLines[i])
		{
			for (int j = 6; j < 10; j++)
				if (!plants[i][j])
					player->PlacePlant(6, i, j);
		}
	}

	for (int j = 6; j < 10; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			if (!plants[i][j] && !CD && sun >= 200 && leftLines[i])
			{
				player->PlacePlant(6, i, j);
			}
		}
	}
}

void placeNormalZombie(IPlayer* player, int sun, int CD, int** plants, int* leftLines)
{
	for (int i = 0; i < 5; i++)
	if (!CD && sun >= 150 && leftLines[i])
		player->PlaceZombie(1, i);
}

void placeCaplZombie(IPlayer* player, int sun, int CD, int** plants, int* leftLines)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300 && leftLines[i])
			player->PlaceZombie(2, i);
}

void placeStickZombie(IPlayer* player, int sun, int CD, int** plants, int* leftLines)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 300 && leftLines[i])
			player->PlaceZombie(3, i);
}

void placeCarZombie(IPlayer* player, int sun, int CD, int** plants, int* leftLines)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 500 && leftLines[i])
			player->PlaceZombie(4, i);
}

void placeGangZombie(IPlayer* player, int sun, int CD, int** plants, int* leftLines)
{
	for (int i = 0; i < 5; i++)
		if (!CD && sun >= 500 && leftLines[i])
			player->PlaceZombie(5, i);
}


void player_ai(IPlayer* player)
{
	auto type = player->Camp->getCurrentType();
	auto CD = player->Camp->getPlantCD();
	auto zombies(player->Camp->getCurrentZombies());
	auto plants = player->Camp->getCurrentPlants();
	auto leftLines = player->Camp->getLeftLines();

	// 植物方
	if (type == 0)
	{
		placeSunFlower(player, player->Camp->getSun(), CD[0], plants, leftLines);
		placeIcePeaShooter(player, player->Camp->getSun(), CD[2], plants, zombies, leftLines);
		placePeaShooter(player, player->Camp->getSun(), CD[1], plants, zombies, leftLines);
		placeChili(player, player->Camp->getSun(), CD[3], plants, zombies, leftLines);
		placeWogua(player, player->Camp->getSun(), CD[4], plants, zombies, leftLines);
		placeNut(player, player->Camp->getSun(), CD[5], plants, zombies, leftLines);
	}

	// 僵尸方
	if (type == 1)
	{
		placeNormalZombie(player, player->Camp->getSun(), CD[0], plants, leftLines);
		placeCaplZombie(player, player->Camp->getSun(), CD[1], plants, leftLines);
		placeStickZombie(player, player->Camp->getSun(), CD[2], plants, leftLines);
		placeCarZombie(player, player->Camp->getSun(), CD[3], plants, leftLines);
		placeGangZombie(player, player->Camp->getSun(), CD[4], plants, leftLines);
	}
}