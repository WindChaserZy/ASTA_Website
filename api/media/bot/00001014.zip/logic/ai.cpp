#include "ai.h"
#include <algorithm>
#include <iostream>
using namespace std;

void player_ai(IPlayer *player)
{
    int x = 0;
    while (x < 5 && player->Camp->getLeftLines()[x] == 0)
    {
        ++x;
    }
    if(player->Camp->getSun() >= 600)
    {
        player->PlaceZombie(5, x);
        x = min(5, x + 1);
        player->PlaceZombie(4, x);
    }
}