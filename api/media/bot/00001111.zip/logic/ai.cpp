/**
 * This file is preprocessed by an obfuscator
 * to protect its copyright
 *
 * Please do not try to parse it
 * 
 * Obfuscator is written by Futrime<https://github.com/Futrime>
 */

#include "ai.h"

#include <iostream>

#include <stdlib.h>

#include <math.h>

#include <cstring>

#include <vector>

#include <queue>

using namespace std;
#define ZOMBIE_KIND 5

#define PLANT_KIND 6

#define TOTAL_TIME 2000

#define COLUMN 10

#define ROW 5

#define _includeaih enum PlantType { NOPLANT = 0, SUNFLOWER, WINTERPEASHOOTER, 
#define _includeiostream PEASHOOTER, SMALLNUT, PEPPER, SQUASH }; enum ZombieType { 
#define _includestdlibh NOZOMBIE = 0, NORMAL, BUCKET, POLEVAULT, SLED, GARGANTUAR 
#define _includemathh }; const int plantCost[7] = {0, 50, 400, 
#define _includecstring 100, 50, 125, 50}; const int plantCd[7] = 
#define _includevector {0, 10, 30, 10, 40, 60, 60}; const 
#define _includequeue int zombieCost[6] = {0, 50, 125, 125, 300, 
#define _usingnamespacestd 300}; const int zombieCd[6] = {0, 15, 20, 
#define _defineZOMBIEKIND5 20, 25, 25}; const int plantHp[7] = {0, 
#define _definePLANTKIND6 300, 300, 300, 4000, 0, 0}; const int 
#define _defineTOTALTIME2000 plantDps[7] = {0, 0, 20, 10, 0, 0, 
#define _defineCOLUMN10 0}; int zombieHp[6] = {0, 270, 820, 200, 
#define _defineROW5 1600, 3000}; struct Sunflower { int row, column, 
#define _FILEfile cd; Sunflower(int Row, int Column) { cd = 
#define _errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw 24; row = Row, column = Column; } 
#define _enumPlantTypeNOPLANT0 }; int *zombieNum(int ***zombies) { int cnt[7] = 
#define _SUNFLOWER {}, *p = cnt; for (int i = 
#define _WINTERPEASHOOTER 0; i < 5; i++) for (int j 
#define _PEASHOOTER = 0; j < 10; j++) for (int 
#define _SMALLNUT k = 0; k < 10; k++) { 
#define _PEPPER if (zombies[i][j][k] = -1) break; else cnt[zombies[i][j][k]]++; } 
#define _SQUASHenumZombieTypeNOZOMBIE0 return p; } int *zombieNum(int zombies[5][10][10]) { int 
#define _NORMAL cnt[7] = {}, *p = cnt; for (int 
#define _BUCKET i = 0; i < 5; i++) for 
#define _POLEVAULT (int j = 0; j < 10; j++) 
#define _SLED for (int k = 0; k < 10; 
#define _GARGANTUAR k++) { if (zombies[i][j][k] = -1) break; else 
#define _zrfscodestarts cnt[zombies[i][j][k]]++; } return p; } struct Zombie { 
#define _constintplantCost70504001005012550 int num; int hp; int coX, coY; Zombie(int 
#define _constintplantCd70103010406060 Num, int row) { coX = row, coY 
#define _constintzombieCost6050125125300300 = 9; hp = zombieHp[Num]; num = Num; 
#define _constintzombieCd601520202525 } }; struct Plant { int num; int 
#define _constintplantHp70300300300400000 hp; int coX, coY; int dps; Plant(int Num, 
#define _constintplantDps7002010000 int row, int col) { num = Num; 
#define _intzombieHp6027082020016003000 coX = row, coY = col; hp = 
#define _structSunflowerintrowcolumncd plantHp[Num]; dps = plantDps[Num]; } }; struct Actionlist 
#define _SunflowerintRowintColumncd24 { int plantPlace[5][10] = {}, zombiePlace[5] = {}; 
#define _rowRowcolumnColumn int plantRemove[5][10] = {}; }; class Game { 
#define _intzombieNumintzombiesintcnt7pcnt public: int time, sun, moon; int plants[5][10], zombies[5][10][10]; 
#define _forinti0i5i int cdPlant[7], cdZombie[6]; int dps[5]; int flagPlant[7], flagZombie[6]; 
#define _forintj0j10j int flagShovel[5][10]; int zombieCostPerRow[5]; vector<Sunflower> sunFlowers; vector<Plant> vectorPlants; 
#define _forintk0k10kifzombiesijk1 vector<Zombie> vectorZombies; void plantremove(int i, int j, IPlayer 
#define _break *player) { player->removePlant(i, j); flagShovel[i][j] = 1; } 
#define _else void maintain(IPlayer *player) { time++; int **Plants = 
#define _cntzombiesijkreturnp player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); moon += int(time 
#define _zombies / 200.0) + 1; for (int i = 
#define _intzombieNumintzombies51010intcnt7pcnt 0; i < 5; i++) for (int j 
#define _forinti0i5i_ = 0; j < 10; j++) { if 
#define _forintj0j10j_ (plants[i][j] > Plants[i][j] && plants[i][j] != PEPPER && 
#define _forintk0k10kifzombiesijk1_ plants[i][j] != SQUASH) { if (flagShovel[i][j] == 1) 
#define _break_ { flagShovel[i][j] = 0; } else { int 
#define _else_ num = plants[i][j]; moon += plantCost[num] / 5 
#define _cntzombiesijkreturnpstructZombieintnum + int(sqrt(plantHp[num])); dps[i] -= plantDps[num]; if (num == 
#define _inthp 1) { for (int k = 0; k 
#define _intcoXcoY < sunFlowers.size(); k++) if (sunFlowers[k].row == i && 
#define _ZombieintNumintrowcoXrowcoY9 sunFlowers[k].column == j) { sunFlowers.erase(sunFlowers.begin() + k); break; 
#define _hpzombieHpNum } } } } else if (plants[i][j] < 
#define _numNumintspeedstructPlantintnum Plants[i][j]) { int num = Plants[i][j]; sun -= 
#define _inthp_ plantCost[num]; dps[i] += plantDps[num]; cdPlant[num] = plantCd[num]; flagPlant[num] 
#define _intcoXcoY_ = 0; if (num == 1) { sun 
#define _intdps += 25; sunFlowers.push_back(Sunflower(i, j)); } vectorPlants.push_back(Plant(Plants[i][j], i, j)); 
#define _PlantintNumintrowintcolnumNum } plants[i][j] = Plants[i][j]; int flag = 0; 
#define _coXrowcoYcol for (int k = 0; k < vectorPlants.size(); 
#define _hpplantHpNum k++) { if (vectorPlants[k].coX == i && vectorPlants[k].coY 
#define _dpsplantDpsNum == j) { if (vectorPlants[k].num != Plants[i][j]) { 
#define _structActionlistintplantPlace510zombiePlace5 vectorPlants.erase(vectorPlants.begin() + k); k--; if (Plants[i][j] != 0) 
#define _intplantRemove510classGamepublic vectorPlants.push_back(Plant(Plants[i][j], i, j)); } flag = 1; break; 
#define _inttimesunmoon } } if (flag == 0 && Plants[i][j] 
#define _intplants510zombies51010 != 0) vectorPlants.push_back(Plant(Plants[i][j], i, j)); } int *z 
#define _intcdPlant7cdZombie6tick = zombieNum(zombies), *Z = zombieNum(Zombies); for (int i 
#define _intdps5dps = 0; i < 5; i++) { int 
#define _intflagPlant7flagZombie610 rowZombie[6] = {}, RowZombie[6] = {}; for (int 
#define _intflagShovel51010 j = 0; j < 10; j++) for 
#define _intzombieCostPerRow5 (int k = 0; k < 10; k++) 
#define _vectorSunflowersunFlowers { if (zombies[i][j][k] = -1) break; else rowZombie[zombies[i][j][k]]++; 
#define _vectorPlantvectorPlants } for (int j = 0; j < 
#define _vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij 10; j++) for (int k = 0; k 
#define _flagShovelij1voidmaintainIPlayerplayertime < 10; k++) { if (Zombies[i][j][k] = -1) 
#define _intPlantsplayerCampgetCurrentPlantscurrentPlants break; else RowZombie[Zombies[i][j][k]]++; ; } for (int j 
#define _intZombiesplayerCampgetCurrentZombiescurrentZombies = 0; j < 6; j++) if (RowZombie[j] 
#define _mooninttime20001 > rowZombie[j]) zombieCostPerRow[i] += zombieCost[j]; } for (int 
#define _forinti0i5i__ i = 0; i < 7; i++) { 
#define _forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij if (z[i] < Z[i]) { } else if 
#define _moonplantCostnum5intsqrtplantHpnum (z[i] > Z[i]) { moon -= zombieCost[i]; cdZombie[i] 
#define _dpsiplantDpsnum = zombieCd[i]; flagZombie[i] = 0; } } for 
#define _ifnum1forintk0ksunFlowerssizek (int i = 0; i < 5; i++) 
#define _ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink { for (int j = 0; j < 
#define _break__ 10; j++) { int k = 0; while 
#define _elseifplantsijPlantsijintnumPlantsij (Zombies[i][j][k] != -1) { zombies[i][j][k] = Zombies[i][j][k]; k++; 
#define _sunplantCostnum } } } vector<int> have_erased; for (int i 
#define _dpsiplantDpsnum_ = 0; i < vectorZombies.size(); i++) { int 
#define _cdPlantnumplantCdnum have_erased_flag = 0; for (int z = 0; 
#define _flagPlantnum0 z < have_erased.size(); z += 2) { if 
#define _ifnum1sun25 (vectorZombies[i].coX == have_erased[z] && vectorZombies[i].coY == have_erased[z + 
#define _sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij 1]) { have_erased_flag = 1; break; } } 
#define _intflag0 if (Plants[vectorZombies[i].coX][vectorZombies[i].coY] != SMALLNUT || have_erased_flag == 1) 
#define _forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink { continue; } else { int num = 
#define _k vectorZombies[i].num; int original_num_of_this_kind = 0, now_num_of_this_kind = 0; 
#define _ifPlantsij0 int k = 0; while (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1) 
#define _vectorPlantspushbackPlantPlantsijijflag1 { if (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num) { original_num_of_this_kind++; } 
#define _break___ k++; } k = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != 
#define _ifflag0Plantsij0 -1) { if (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num) { now_num_of_this_kind++; 
#define _vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies } k++; } if (original_num_of_this_kind - now_num_of_this_kind > 
#define _forinti0i5iintrowZombie6RowZombie6 0) { vector<int> serialNum; for (int j = 
#define _forintj0j10j__ 0; j < vectorZombies.size(); j++) { if (vectorZombies[j].num 
#define _forintk0k10kifzombiesijk1__ == num && vectorZombies[i].coY == vectorZombies[j].coY && vectorZombies[i].coX 
#define _break____ == vectorZombies[j].coX) { serialNum.push_back(j); } } if (now_num_of_this_kind 
#define _else__ == 0) { for (int i = serialNum.size() 
#define _rowZombiezombiesijkforintj0j10j - 1; i >= 0; i--) { vectorZombies.erase(serialNum[i] 
#define _forintk0k10kifZombiesijk1 + vectorZombies.begin()); } } if (original_num_of_this_kind - now_num_of_this_kind 
#define _break_____ == 1) { int small_hp = 5000, small_hp_num 
#define _else___ = 0; for (int k = 0; k 
#define _RowZombieZombiesijk < serialNum.size(); k++) { if (small_hp > vectorZombies[serialNum[k]].hp) 
#define _forintj0j6j { small_hp = vectorZombies[serialNum[k]].hp; small_hp_num = k; } 
#define _ifRowZombiejrowZombiej } vectorZombies.erase(small_hp_num + vectorZombies.begin()); } have_erased.push_back(vectorZombies[i].coX); have_erased.push_back(vectorZombies[i].coY); } 
#define _zombieCostPerRowizombieCostjforinti0i7iifziZi } } for (int i = 0; i 
#define _zombiedie < vectorZombies.size(); i++) { int num = vectorZombies[i].num; 
#define _elseifziZimoonzombieCosti int k = 0; int flag_self = 0; 
#define _cdZombieizombieCdi int flag_near = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1) 
#define _flagZombiei0 { if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { break; } 
#define _zombieplaced else { flag_self = 1; } } k 
#define _forinti0i5iforintj0j10jintk0 = 0; while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY - 1][k] != -1) 
#define _whileZombiesijk1zombiesijkZombiesijk { if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k]) { vectorZombies[i].coY--; } 
#define _k_ else { flag_near = 1; } } if 
#define _vectorinthaveerased (flag_self == 1 && flag_near == 1) { 
#define _forinti0ivectorZombiessizeiinthaveerasedflag0 vectorZombies.erase(vectorZombies.begin() + i); i--; } } for (int 
#define _forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1 i = 0; i < 7; i++) { 
#define _breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum if (cdPlant[i] > 0) cdPlant[i]--; if (cdPlant[i] == 
#define _intoriginalnumofthiskind0nownumofthiskind0 0) flagPlant[i] = 1; } for (int i 
#define _intk0 = 0; i < 6; i++) { if 
#define _whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0 (cdZombie[i] > 0) cdZombie[i]--; if (cdZombie[i] == 0) 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum flagZombie[i] = 1; } for (int i = 
#define _forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj 0; i < sunFlowers.size(); i++) { if (sunFlowers[i].cd 
#define _ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin > 0) sunFlowers[i].cd--; if (sunFlowers[i].cd == 0) { 
#define _iforiginalnumofthiskindnownumofthiskind1 sun += 25; sunFlowers[i].cd = 24; } } 
#define _findthesmallesthp } Game() { time = 0; sun = 
#define _intsmallhp5000smallhpnum0 400, moon = 300; for (int i = 
#define _forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp 0; i < 5; i++) for (int j 
#define _smallhpnumk = 0; j < 10; j++) plants[i][j] = 
#define _vectorZombieserasesmallhpnumvectorZombiesbegin 0, flagShovel[i][j] = 0; for (int i = 
#define _haveerasedpushbackvectorZombiesicoX 0; i < 5; i++) for (int j 
#define _haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum = 0; j < 10; j++) for (int 
#define _intk0_ k = 0; k < 10; k++) zombies[i][j][k] 
#define _intflagself0 = 0; for (int i = 0; i 
#define _intflagnear0 < 5; i++) dps[i] = 0, zombieCostPerRow[i] = 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1 0; for (int i = 0; i < 
#define _k0 7; i++) cdPlant[i] = 0, flagPlant[i] = 1; 
#define _whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1 for (int i = 0; i < 6; 
#define _ifflagself1flagnear1vectorZombieserasevectorZombiesbegini i++) cdZombie[i] = 0, flagZombie[i] = 1; } 
#define _iforinti0i7iifcdPlanti0 Game tranState(Actionlist q, IPlayer *player); }; Game Game::tranState(Actionlist 
#define _cdPlanti q, IPlayer *player) { Game newGame; { newGame.time 
#define _ifcdPlanti0 = this->time, newGame.sun = this->sun, newGame.moon = this->moon; 
#define _flagPlanti1 for (int i = 0; i < 5; 
#define _forinti0i6iifcdZombiei0 i++) for (int j = 0; j < 
#define _cdZombiei 10; j++) newGame.plants[i][j] = this->plants[i][j], flagShovel[i][j] = this->flagShovel[i][j]; 
#define _ifcdZombiei0 for (int i = 0; i < 5; 
#define _flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0 i++) for (int j = 0; j < 
#define _sunFlowersicd 10; j++) for (int k = 0; k 
#define _ifsunFlowersicd0sun25 < 10; k++) newGame.zombies[i][j][k] = this->zombies[i][j][k]; for (int 
#define _sunFlowersicd24ticktick i = 0; i < 7; i++) newGame.cdPlant[i] 
#define _Gametime0 = this->cdPlant[i], newGame.flagPlant[i] = this->flagPlant[i]; for (int i 
#define _sun400moon300 = 0; i < 6; i++) newGame.cdZombie[i] = 
#define _forinti0i5i___ this->cdZombie[i], newGame.flagZombie[i] = this->flagZombie[i]; for (int i = 
#define _forintj0j10j___ 0; i < 5; i++) newGame.dps[i] = this->dps[i], 
#define _plantsij0flagShovelij0 newGame.zombieCostPerRow[i] = this->zombieCostPerRow[i]; } for (int i = 
#define _forinti0i5i____ 0; i < 5; i++) for (int j 
#define _forintj0j10j____ = 0; j < 10; j++) { if 
#define _forintk0k10k (q.plantPlace[i][j] > 0) { int num = q.plantPlace[i][j]; 
#define _zombiesijk0 newGame.sun -= plantCost[num]; newGame.cdPlant[num] = plantCd[num]; newGame.flagPlant[num] = 
#define _forinti0i5i_____ 0; newGame.dps[i] += plantDps[num]; newGame.plants[i][j] = num; } 
#define _dpsi0zombieCostPerRowi0 if (q.zombiePlace[i] > 0) { int num = 
#define _forinti0i7i q.zombiePlace[i]; newGame.moon -= zombieCost[num]; newGame.cdZombie[num] = zombieCd[num]; newGame.flagZombie[num] 
#define _cdPlanti0flagPlanti1 = 0; } } newGame.maintain(player); return newGame; } 
#define _forinti0i6i class Zombies_num { public: int normal; int bucket; 
#define _cdZombiei0flagZombiei1 int polevault; int sled; int gargantuar; int total_num; 
#define _initialize Zombies_num() { this->normal = this->bucket = this->polevault = 
#define _GametranStateActionlistqIPlayerplayerq this->sled = this->gargantuar = this->total_num = 0; } 
#define _globalstatus void compute_num(int ***zombies, int rows, int columns) { 
#define _GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon int num = 0; for (int i = 
#define _forinti0i5i______ 0; i < rows; i++) { for (int 
#define _forintj0j10j_____ j = 0; j < columns; j++) { 
#define _newGameplantsijthisplantsijflagShovelijthisflagShovelij int k = 0; while (zombies[i][j][k] != -1) 
#define _forinti0i5i_______ { switch (zombies[i][j][k]) { case NORMAL: this->normal++; break; 
#define _forintj0j10j______ case BUCKET: this->bucket++; break; case POLEVAULT: this->polevault++; break; 
#define _forintk0k10k_ case SLED: this->sled++; break; case GARGANTUAR: this->gargantuar++; break; 
#define _newGamezombiesijkthiszombiesijk } num++; k++; } } } } }; 
#define _forinti0i7i_ class Plants_num { public: int sunflower; int winterpeashooter; 
#define _newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti int peashooter; int smallnut; int pepper; int squash; 
#define _forinti0i6i_ Plants_num() { this->sunflower = this->winterpeashooter = this->peashooter = 
#define _newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei this->smallnut = this->pepper = this->squash = 0; } 
#define _forinti0i5i________ void compute_num(int **plants, int rows, int columns) { 
#define _newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame for (int i = 0; i < rows; 
#define _forinti0i5i_________ i++) for (int j = 0; j < 
#define _forintj0j10jifqplantPlaceij0intnumqplantPlaceij columns; j++) { switch (plants[i][j]) { case SUNFLOWER: 
#define _newGamesunplantCostnum this->sunflower++; break; case WINTERPEASHOOTER: this->winterpeashooter++; break; case PEASHOOTER: 
#define _newGamecdPlantnumplantCdnum this->peashooter++; break; case SMALLNUT: this->smallnut++; break; case PEPPER: 
#define _newGameflagPlantnum0 this->pepper++; break; case SQUASH: this->squash++; break; } } 
#define _newGamedpsiplantDpsnum } }; int calculate_zombie_nums(int ***zombies, int rows, int 
#define _newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei columns) { int num = 0; for (int 
#define _newGamemoonzombieCostnum i = 0; i < rows; i++) { 
#define _newGamecdZombienumzombieCdnum for (int j = 0; j < columns; 
#define _newGameflagZombienum0 j++) { int k = 0; while (zombies[i][j][k] 
#define _newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic != -1) { num++; k++; } } } 
#define _intnormal return num; } int choose_Lines_not_Broken(int *Left_lines, int **plants, 
#define _intbucket int column) { for (int i = 0; 
#define _intpolevault ; i++) { if (Left_lines[i] == 1 && 
#define _intsled plants[i][column] == NOPLANT) return i; } return rand() 
#define _intgargantuar % ROW; } typedef struct pos_and_value { int 
#define _inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0 pos[2]; double value; } pos_and_value; class value_plant_func { 
#define _forinti0irowsiforintj0jcolumnsjintk0 public: double noplant; pos_and_value sunflower; pos_and_value peashooter; pos_and_value 
#define _whilezombiesijk1switchzombiesijkcaseNORMAL winterpeashooter; pos_and_value smallnut; pos_and_value pepper; pos_and_value squash; int 
#define _thisnormal generating_row; IPlayer *player; Game game; int NotBrokenLinesNum; int 
#define _break______ KillZombiesScore; int LeftPlants; int Score; int time; int 
#define _caseBUCKET *PlaceCD; int **Plants; int ***Zombies; int *LeftLines; int 
#define _thisbucket Sun; int zombie_nums; value_plant_func(int NotBrokenLinesNum, int KillZombiesScore, int 
#define _break_______ Score, int time, int *PlaceCD, int **Plants, int 
#define _casePOLEVAULT ***Zombies, int *LeftLines, int Sun, IPlayer *player, Game 
#define _thispolevault game) { this->NotBrokenLinesNum = NotBrokenLinesNum; this->KillZombiesScore = KillZombiesScore; 
#define _break________ this->Score = Score; this->time = time; this->PlaceCD = 
#define _caseSLED PlaceCD; this->Plants = Plants; this->Zombies = Zombies; this->LeftLines 
#define _thissled = LeftLines; this->Sun = Sun; this->player = player; 
#define _break_________ this->generating_row = 1; this->game = game; } int 
#define _caseGARGANTUAR **sum_plants_per_row() { int **plants_num_format = (int **)malloc(ROW * 
#define _thisgargantuar sizeof(int *)); for (int i = 0; i 
#define _breaknum < ROW; i++) { plants_num_format[i] = (int *)malloc(sizeof(int) 
#define _kclassPlantsnumpublic * PLANT_KIND); memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int)); } 
#define _intsunflower for (int i = 0; i < ROW; 
#define _intwinterpeashooter i++) { for (int j = 0; j 
#define _intpeashooter < COLUMN; j++) { switch (this->Plants[i][j]) { case 
#define _intsmallnut SUNFLOWER: plants_num_format[i][SUNFLOWER]++; break; case WINTERPEASHOOTER: plants_num_format[i][WINTERPEASHOOTER]++; break; case 
#define _intpepper PEASHOOTER: plants_num_format[i][PEASHOOTER]++; break; case SMALLNUT: plants_num_format[i][SMALLNUT]++; break; case 
#define _intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi PEPPER: plants_num_format[i][PEPPER]++; break; case SQUASH: plants_num_format[i][SQUASH]++; break; } 
#define _forintj0jcolumnsjswitchplantsijcaseSUNFLOWER } } return plants_num_format; } void beginning_operation() { 
#define _thissunflower if (this->time == 3) { this->player->PlacePlant(SUNFLOWER, this->generating_row, 1); 
#define _break__________ } } void GameState_2_400() { if (this->time > 
#define _caseWINTERPEASHOOTER 2 && this->time < 150) { int alarming_flag 
#define _thiswinterpeashooter = -1; for (int i = 0; i 
#define _break___________ < ROW; i++) { if (i != this->generating_row) 
#define _casePEASHOOTER { if (time < 25) for (int j 
#define _thispeashooter = 0; j < COLUMN; j++) { int 
#define _break____________ k = 0; while (this->Zombies[i][j][k] != -1) { 
#define _caseSMALLNUT if (j < 3) alarming_flag = i; if 
#define _thissmallnut (this->Sun >= 70) switch (this->Zombies[i][j][k]) { case POLEVAULT: 
#define _break_____________ case SLED: this->player->PlacePlant(SQUASH, i, (j - 1 < 
#define _casePEPPER 0 ? 0 : j - 1)); break; 
#define _thispepper case BUCKET: if (this->PlaceCD[SQUASH] == 0) this->player->PlacePlant(SQUASH, i, 
#define _break______________ (j - 1 < 0 ? 0 : 
#define _caseSQUASH j - 1)); else if (j <= 5) 
#define _thissquash this->player->PlacePlant(PEPPER, i, (j - 1 < 0 ? 
#define _breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0 0 : j - 1)); break; case GARGANTUAR: 
#define _forinti0irowsiforintj0jcolumnsjintk0_ this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 
#define _whilezombiesijk1num 0 : j - 1)); if (j < 
#define _kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT 4) this->player->PlacePlant(PEPPER, i, 8); break; case NORMAL: this->player->PlacePlant(PEASHOOTER, 
#define _returnireturnrandROWtypedefstructposandvalueintpos2 i, 0); this->player->PlacePlant(SMALLNUT, i, (j - 1 < 
#define _doublevalue 0 ? 0 : j - 1)); break; 
#define _posandvalueclassvalueplantfuncpublic } k++; } } } else for (int 
#define _doublenoplant j = 0; j < COLUMN; j++) { 
#define _posandvaluesunflower int k = 0; while (this->Zombies[this->generating_row][j][k] != -1) 
#define _posandvaluepeashooter { if (this->Sun >= 70) switch (this->Zombies[this->generating_row][j][k]) { 
#define _posandvaluewinterpeashooter case POLEVAULT: case BUCKET: case SLED: this->player->PlacePlant(SQUASH, this->generating_row, 
#define _posandvaluesmallnut 5); break; case GARGANTUAR: this->player->PlacePlant(SQUASH, this->generating_row, (j - 
#define _posandvaluepepper 1 < 0 ? 0 : j - 
#define _posandvaluesquash 1)); if (j < 4) this->player->PlacePlant(PEPPER, this->generating_row, 8); 
#define _intgeneratingrow break; case NORMAL: this->player->PlacePlant(SMALLNUT, this->generating_row, (j - 1 
#define _IPlayerplayer < 0 ? 1 : j - 1)); 
#define _Gamegame break; } if (j < (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 
#define _doublevaluePLANTKIND1 + 1 && this->PlaceCD[SQUASH - 1] != 0) 
#define _intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum { this->player->PlacePlant(PEPPER, i, 8); } k++; } } 
#define _intKillZombiesScore } int num = 0, pos = 0; 
#define _intLeftPlants for (int i = 0; i < COLUMN; 
#define _intScore i++) { if (Plants[this->generating_row][i] == SUNFLOWER) { num++; 
#define _inttime } if (Plants[this->generating_row][i] != NOPLANT) { pos = 
#define _intPlaceCD i; } } if (num < 5) this->player->PlacePlant(SUNFLOWER, 
#define _intPlants this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1); if (alarming_flag != -1) 
#define _intZombies { if (this->PlaceCD[SQUASH - 1] == 0) { 
#define _intLeftLines this->player->PlacePlant(SQUASH, alarming_flag, COLUMN - 1); } else this->player->PlacePlant(PEPPER, 
#define _intSun alarming_flag, COLUMN - 1); } } } void 
#define _intzombienumsvalueplantfuncintNotBrokenLinesNum GameState_50_200() { if (this->time > 50 && this->time 
#define _intKillZombiesScore_ < 200) { if (this->Sun >= 400) this->player->PlacePlant(WINTERPEASHOOTER, 
#define _intScore_ this->generating_row, 0); } } void value_peashooter_origin() { if 
#define _inttime_ (this->time > 10) if (this->PlaceCD[PEASHOOTER - 1] == 
#define _intPlaceCD_ 0) { double **loss = (double **)malloc(ROW * 
#define _intPlants_ sizeof(double *)); for (int i = 0; i 
#define _intZombies_ < ROW; i++) { loss[i] = (double *)malloc(COLUMN 
#define _intLeftLines_ * sizeof(double)); memset(loss[i], 0, COLUMN * sizeof(double)); } 
#define _intSunIPlayerplayer double max = -10000, max_index[2] = {0, 0}; 
#define _GamegamethisNotBrokenLinesNumNotBrokenLinesNum for (int i = 0; i < ROW; 
#define _thisKillZombiesScoreKillZombiesScore i++) for (int j = 0; j < 
#define _thisScoreScore COLUMN; j++) { if (this->Plants[i][j] != NOPLANT) loss[i][j] 
#define _thistimetime = -10000; else { double row = (i 
#define _thisPlaceCDPlaceCD == this->generating_row ? -10 : 0); loss[i][j] += 
#define _thisPlantsPlants row; double zombie[ZOMBIE_KIND] = {6, -10, -2, -40, 
#define _thisZombiesZombies -20}; for (int column0 = 0; j < 
#define _thisLeftLinesLeftLines COLUMN; j++) { int k = 0; while 
#define _thisSunSun (Zombies[i][column0][k] != -1) { loss[i][j] += zombie[Zombies[i][column0][k] - 
#define _thisplayerplayer 1] / (+COLUMN - j); k++; } } 
#define _thisgeneratingrow1 double plant[PLANT_KIND] = {2, 0, -2, 5, 2, 
#define _thisgamegameintsumplantsperrow 0}; for (int column0 = 0; j < 
#define _rowsplantskindnumperrow COLUMN; j++) { if (this->Plants[i][column0] != NOPLANT) loss[i][j] 
#define _intplantsnumformatintmallocROWsizeofint += plant[this->Plants[i][column0]] * (1 + (column0 - COLUMN 
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND / 2) / 40); } double time_rate = 
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER 30; loss[i][j] += time_rate * (1 / (1 
#define _plantsnumformatiSUNFLOWER + exp((+this->time - TOTAL_TIME / 5) / 600)) 
#define _break_______________ - 0.5); } if (max < loss[i][j]) { 
#define _caseWINTERPEASHOOTER_ max_index[0] = i; max_index[1] = j; } } 
#define _plantsnumformatiWINTERPEASHOOTER this->peashooter.pos[0] = max_index[0]; this->peashooter.pos[1] = max_index[1]; this->peashooter.value = 
#define _break________________ max; } } bool have_type_of_zombies(int *zombie, int type) 
#define _casePEASHOOTER_ { int k = 0; while (zombie[k] != 
#define _plantsnumformatiPEASHOOTER -1) { if (zombie[k] == type) return true; 
#define _break_________________ k++; } return false; } int search_for_nearest_zombie(int ***zombie, 
#define _caseSMALLNUT_ int row, int column) { int nearest = 
#define _plantsnumformatiSMALLNUT 100; for (int j = 0; j < 
#define _break__________________ COLUMN; j++) { int k = 0; while 
#define _casePEPPER_ (Zombies[row][j][k] != -1) { if (nearest > j 
#define _plantsnumformatiPEPPER - column) nearest = j - column; k++; 
#define _break___________________ } } return nearest; } void judge_Lines_not_broken(double *final_choice) 
#define _caseSQUASH_ { for (int i = 0; i < 
#define _plantsnumformatiSQUASH ROW; i++) { if (this->LeftLines[i] == 0) { 
#define _breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1 final_choice[i] = -100000; } } } void value_peashooter0() 
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1 { if (this->time > 30) { if (this->PlaceCD[PEASHOOTER 
#define _voidGameState250ifthistime2thistime200intalarmingflag1 - 1] == 0) { for (int i 
#define _forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0 = 0; i < ROW; i++) { if 
#define _whilethisZombiesijk1ifj3 (LeftLines[i] == 1) { for (int j = 
#define _alarmingflagi 0; j < COLUMN; j++) { int k 
#define _ifthisSun70 = 0; while (Zombies[i][j][k] != -1) { k++; 
#define _switchthisZombiesijkcasePOLEVAULT } if (k == 1 && Zombies[i][j][0] == 
#define _caseSLED_ NORMAL && j >= COLUMN - 2) { 
#define _thisplayerPlacePlantSQUASHij100j1 this->player->PlacePlant(PEASHOOTER, i, 0); } else if (k > 
#define _break____________________ 0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) && 
#define _caseBUCKET_ Sun < 400 && time < 500 && 
#define _ifthisPlaceCDSQUASH0 j < 5) { int start = 0; 
#define _thisplayerPlacePlantSQUASHij100j1_ while (Plants[i][start] != NOPLANT) { start++; } if 
#define _elseifj3 (search_for_nearest_zombie(Zombies, i, start) >= 1) { player->PlacePlant(PEASHOOTER, i, 
#define _thisplayerPlacePlantPEPPERij100j1 start); } } } } } } } 
#define _break_____________________ } void value_peashooter() { double score[5] = {0, 
#define _caseGARGANTUAR_ 0, 0, 0, 0}; double plant_cost[7] = {0, 
#define _thisplayerPlacePlantSQUASHij100j1__ 10, -6, -8, 15, 10, 0}; judge_Lines_not_broken(score); for 
#define _ifj4 (int i = 0; i < ROW; i++) 
#define _thisplayerPlacePlantPEPPERi8 { for (int j = 0; j < 
#define _break______________________ COLUMN; j++) { double distance_cost = 1; switch 
#define _caseNORMAL (Plants[i][j]) { case SUNFLOWER: distance_cost *= 1 + 
#define _thisplayerPlacePlantPEASHOOTERi1 j / 100; } score[i] += plant_cost[Plants[i][j]] * 
#define _thisplayerPlacePlantSMALLNUTij100j1 distance_cost; } } double zombie_cost[5] = {10, 5, 
#define _breakkelse -5, -20, -20}; for (int i = 0; 
#define _forintj0jCOLUMNjintk0 i < ROW; i++) { for (int j 
#define _whilethisZombiesthisgeneratingrowjk1ifthisSun70 = 0; j < COLUMN; j++) { int 
#define _switchthisZombiesthisgeneratingrowjk k = 0; while (Zombies[i][j][k] != -1) { 
#define _casePOLEVAULT_ double distance_cost = 1; switch (Zombies[i][j][k]) { case 
#define _caseBUCKET__ NORMAL: distance_cost = 1 - j / 30; 
#define _caseSLED__ } score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost; 
#define _thisplayerPlacePlantSQUASHthisgeneratingrow5 k++; } } } int *serial_num = rank(score, 
#define _break_______________________ ROW); int i = 0; for (; i 
#define _caseGARGANTUAR__ < 10; i++) { if (Plants[serial_num[0]][i] == NOPLANT) 
#define _thisplayerPlacePlantSQUASHthisgeneratingrowj100j1 break; } if (i <= 3) { if 
#define _ifj4_ (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) || 
#define _thisplayerPlacePlantPEPPERthisgeneratingrow8 have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR))) player->PlacePlant(PEASHOOTER, 
#define _break________________________ serial_num[0], i); } free(serial_num); } int *rank(double *array, 
#define _caseNORMAL_ int len) { double max = array[0]; int 
#define _thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k *serial_num = (int *)malloc(len * sizeof(int)); for (int 
#define _thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1 i = 0; i < len; i++) { 
#define _ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else serial_num[i] = i; } for (int i = 
#define _thisplayerPlacePlantPEPPERalarmingflagCOLUMN1 0; i < len - 1; i++) { 
#define _voidGameState50200ifthistime50thistime200ifthisSun400 for (int j = 0; j < len 
#define _thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0 - 1; j++) { if (array[j] < array[j 
#define _voidvaluepeashooteroriginifthistime50 + 1]) { double swap = array[j]; array[j] 
#define _ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble = array[j + 1]; array[j + 1] = 
#define _forinti0iROWilossidoublemallocCOLUMNsizeofdouble swap; int serial_swap = serial_num[j]; serial_num[j] = serial_num[j 
#define _memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200 + 1]; serial_num[j + 1] = serial_swap; } 
#define _forinti0iROWi } } return serial_num; } void value_sunflower() { 
#define _forintj0jCOLUMNjifthisPlantsijNOPLANT int sunflower_num = 0; for (int i = 
#define _lossij10000 0; i < ROW; i++) for (int j 
#define _else____ = 0; j < COLUMN; j++) { if 
#define _doublerowithisgeneratingrow100 (Plants[i][j] == SUNFLOWER) { sunflower_num++; } } double 
#define _lossijrow b = -0.01 * (this->time - 300) * 
#define _doublecolumn25 (this->time - 300) / 10000 + 1; if 
#define _lossijcolumnexpcolumn10 (this->time > 9 && sunflower_num < 9 + 
#define _doublezombieZOMBIEKIND61024020 (b < 0 ? 0 : b) && 
#define _forintcolumn00jCOLUMNjintk0 this->Sun < 1000) if (this->PlaceCD[SUNFLOWER - 1] == 
#define _whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj 0) { double score[5] = {0, 0, 0, 
#define _k__ 0, 0}; judge_Lines_not_broken(score); for (int i = 0; 
#define _doubleplantPLANTKIND202520 i < ROW; i++) { for (int j 
#define _forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT = 0; j < COLUMN; j++) { if 
#define _lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30 (Plants[i][j] == SUNFLOWER) score[i] -= 120; if (Plants[i][j] 
#define _lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i == PEASHOOTER) score[i] += 50 * (1 * 
#define _maxindex1j (exp(-j / 5))); if (Plants[i][j] == WINTERPEASHOOTER) score[i] 
#define _thispeashooterpos0maxindex0 += 100 * (1 * (exp(-j / 5))); 
#define _thispeashooterpos1maxindex1 if (Plants[i][j] == SMALLNUT) score[i] += 100 * 
#define _thispeashootervaluemax (-0.01 * (j - 5) * (j - 
#define _boolhavetypeofzombiesintzombieinttypeintk0 5) + 1); } } for (int i 
#define _whilezombiek1ifzombiektype = 0; i < ROW; i++) for (int 
#define _returntrue j = 0; j < COLUMN; j++) { 
#define _kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0 int k = 0; while (Zombies[i][j][k] != -1) 
#define _forintj0jCOLUMNjintk0_ { if (Zombies[i][j][k] == NORMAL) score[i] -= 10 
#define _whileZombiesrowjk1ifnearestjcolumn * (1 / (0.1 + j)); if (Zombies[i][j][k] 
#define _nearestjcolumn == BUCKET) score[i] -= 50 * (1 / 
#define _k___ (0.1 + j)); if (Zombies[i][j][k] == POLEVAULT) score[i] 
#define _returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0 -= 30 * (1 / (0.1 + j)); 
#define _whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0 if (Zombies[i][j][k] == GARGANTUAR) score[i] -= 100 * 
#define _whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart (1 / (0.1 + j)); if (Zombies[i][j][k] == 
#define _intrankdoublearrayintlendoublemaxarray0 SLED) score[i] -= 80 * (1 / (0.1 
#define _intserialnumintmalloclensizeofint + j)); k++; } } int *serial_num = 
#define _forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj rank(score, ROW); int j = 0; while (Plants[serial_num[0]][j 
#define _arrayjarrayj1 + 2] != NOPLANT && j < 8) 
#define _arrayj1swap { j++; } if (j < 8) if 
#define _intserialswapserialnumj (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) || 
#define _serialnumjserialnumj1 have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR))) player->PlacePlant(SUNFLOWER, 
#define _serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10 serial_num[0], j + 2); free(serial_num); } } void 
#define _ifthisPlaceCDSUNFLOWER0doublescore500000 value_smallmnut() { if (this->PlaceCD[SMALLNUT - 1] == 0) 
#define _judgeLinesnotbrokenscore if (this->time > 20) { double score[ROW] = 
#define _forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER {0, 0, 0, 0, 0}; judge_Lines_not_broken(score); double plants_score[7] 
#define _scorei10 = {0, 5, 20, 20, -300, -2, 0}; 
#define _ifPlantsijPEASHOOTER for (int i = 0; i < ROW; 
#define _scorei501expj i++) { for (int j = 0; j 
#define _ifPlantsijWINTERPEASHOOTER < COLUMN; j++) { double distance_cost = 1; 
#define _scorei1001expj switch (Plants[i][j]) { case SUNFLOWER: distance_cost = 1.5 
#define _ifPlantsijSMALLNUT - 0.05 * j; break; case PEASHOOTER: distance_cost 
#define _scorei100001j5j51 = 2 - 0.09 * j; break; case 
#define _forinti0iROWi_ WINTERPEASHOOTER: distance_cost = 2 - 0.1 * j; 
#define _forintj0jCOLUMNjintk0__ break; } score[i] += plants_score[Plants[i][j]] * distance_cost; } 
#define _whileZombiesijk1ifZombiesijkNORMAL } double zombie_cost[5] = {2.0, 10, 12, -1000, 
#define _scorei10101j -2000}; int nearest_zombie_per_row[5] = {10, 10, 10, 10, 
#define _ifZombiesijkBUCKET 10}; for (int i = 0; i < 
#define _scorei50101j ROW; i++) { for (int j = COLUMN 
#define _ifZombiesijkPOLEVAULT - 1; j >= 0; j--) { int 
#define _scorei30101j k = 0; while (Zombies[i][j][k] != -1) { 
#define _ifZombiesijkGARGANTUAR double distance_cost = 1; switch (Zombies[i][j][k]) { case 
#define _scorei100101j NORMAL: distance_cost = 1.2 - 0.02 * (j); 
#define _ifZombiesijkSLED break; case POLEVAULT: distance_cost = 1.1 - 0.01 
#define _scorei80101j * j; break; case BUCKET: distance_cost = 1.3 
#define _kintsunflowernumingeneratingrow0 - 0.04 * j; break; } score[i] += 
#define _forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER zombie_cost[(Zombies[i][j][k] - 1)] * distance_cost; k++; nearest_zombie_per_row[i] = 
#define _sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW j; } } } int *serial_num = rank(score, 
#define _forinti0iROWiintj0 ROW); int j = COLUMN - 1; if 
#define _whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT) { for (; 
#define _voidvaluesmallmnutifthisPlaceCDSMALLNUT0 j >= 0; j--) { if (Plants[serial_num[0]][j] == 
#define _ifthistime20doublescoreROW00000 NOPLANT) break; } if (j != -1) player->PlacePlant(SMALLNUT, 
#define _judgeLinesnotbrokenscorevalueplants serial_num[0], j); } else player->PlacePlant(SMALLNUT, serial_num[0], (nearest_zombie_per_row[serial_num[0]] - 
#define _doubleplantsscore7052020710 1) < 0 ? 0 : (nearest_zombie_per_row[serial_num[0]] - 
#define _forinti0iROWiforintj0jCOLUMNjdoubledistancecost1 1)); free(serial_num); } } void value_winterpeashooter() { if 
#define _switchPlantsijcaseSUNFLOWER (this->PlaceCD[WINTERPEASHOOTER - 1] == 0) { if (this->time 
#define _distancecost15005j > 70) { double score[5] = {0.0, 0, 
#define _break_________________________ 0, 0, 0}; judge_Lines_not_broken(score); double plant_cost[7] = {0.0, 
#define _casePEASHOOTER__ -2.5, -4, -5, -10, 6, 0}; if (time 
#define _distancecost2009j > 450) { plant_cost[4] = 2; } for 
#define _break__________________________ (int i = 0; i < ROW; i++) 
#define _caseWINTERPEASHOOTER__ { for (int j = 0; j < 
#define _distancecost201j COLUMN; j++) { score[i] += plant_cost[Plants[i][j]]; } } 
#define _breakscoreiPlantsijplantsscoreidistancecostvaluezombies double zombie_cost[5] = {5, 20, 10, 2, -4}; 
#define _doublezombiecost520101246 for (int i = 0; i < ROW; 
#define _intnearestzombieperrow500000 i++) for (int j = 0; j < 
#define _forinti0iROWiforintjCOLUMN1j0jintk0 COLUMN; j++) { int k = 0; while 
#define _whileZombiesijk1doubledistancecost1 (Zombies[i][j][k] != -1) { score[i] += zombie_cost[Zombies[i][j][k] - 
#define _switchZombiesijk 1]; k++; } } int *serial_num = rank(score, 
#define _caseNORMAL__ ROW); if (this->time < 300) { int j 
#define _distancecost12002j = 0; while (Plants[serial_num[0]][j] != NOPLANT && j 
#define _break___________________________ < 8) { j++; } if (j < 
#define _casePOLEVAULT__ 5) { if (search_for_nearest_zombie(Zombies, serial_num[0], j) >= 1) 
#define _distancecost11001j { player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j); } } } else 
#define _break____________________________ { int limit = (int)(this->time / 400) + 
#define _caseBUCKET___ 3; for (int i = 0; i < 
#define _distancecost13004j limit; i++) { if ((Plants[serial_num[0]][i] == PEASHOOTER && 
#define _breakscoreizombiecostZombiesijk1distancecost this->time > 600) || (Plants[serial_num[0]][i] == SUNFLOWER)) { 
#define _k____ if (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun 
#define _nearestzombieperrowij > 400) { player->removePlant(serial_num[0], i); player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i); 
#define _intserialnumrankscoreROW break; } } } } free(serial_num); } } 
#define _forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1 } void value_squash() { if (this->PlaceCD[SQUASH - 1] 
#define _voidvaluethisvaluepeashooter == 0 && this->time > 50) { double 
#define _thisvaluesunflower score[5] = {0, 0, 0, 0, 0}; double 
#define _thisvaluesmallmnut plant_cost[7] = {0, 5, 20, 3, -10, -100, 
#define _doublemax100000 -200}; for (int i = 0; i < 
#define _doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue 5; i++) { for (int j = 0; 
#define _thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation j < COLUMN; j++) { double distance_cost = 
#define _thisGameState250 0.2 + 0.08 * j; score[i] += plant_cost[Plants[i][j]] 
#define _thisGameState50200 * distance_cost; } } double zombie_cost[5] = {-5, 
#define _thisvalue 10, 2, 100, 200}; for (int i = 
#define _classvaluezombiefuncpublic 0; i < ROW; i++) for (int j 
#define _intnozombie = 0; j < COLUMN; j++) { int 
#define _intnormalchoice k = 0; while (Zombies[i][j][k] != -1) { 
#define _intbucketchoice double distance_cost = 11 / (j + 1); 
#define _intpolevaultchoice score[i] += zombie_cost[Zombies[i][j][k] - 1] * distance_cost; k++; 
#define _intsledchoice } } int *serial_num = rank(score, ROW); int 
#define _intgargantuarchoice nearest_zombie = 10; for (int j = COLUMN 
#define _doublevalueZOMBIEKIND - 1; j >= 0; j--) { int 
#define _intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore k = 0; while (Zombies[serial_num[0]][j][k] != -1) { 
#define _intKillPlantsScore nearest_zombie = j; k++; } } if (nearest_zombie 
#define _intLeftPlants_ - 1 >= 0 && nearest_zombie != 9) 
#define _intScore__ { if (Plants[serial_num[0]][nearest_zombie - 1] == NOPLANT) { 
#define _inttime__ player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1); } else if 
#define _intPlaceCD__ (Plants[serial_num[0]][nearest_zombie - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 
#define _intPlants__ 1] != SMALLNUT && Plants[serial_num[0]][nearest_zombie - 1] != 
#define _intZombies__ NOPLANT && time > 400 && this->Sun > 
#define _intLeftLines__ 50) { player->removePlant(serial_num[0], nearest_zombie - 1); player->PlacePlant(SQUASH, serial_num[0], 
#define _intSun_ nearest_zombie - 1); } } else { for 
#define _intzombienums (int j = COLUMN - 1; j >= 
#define _GamegamevaluezombiefuncintBrokenLinesScore 0; j--) { if (Plants[serial_num[0]][j] != NOPLANT && 
#define _intKillPlantsScore_ j >= 6) { player->PlacePlant(SQUASH, serial_num[0], j); } 
#define _intScore___ } } free(serial_num); } } void value_pepper() { 
#define _inttime___ if (this->PlaceCD[PEPPER - 1] == 0 && this->PlaceCD[SQUASH 
#define _intPlaceCD___ - 1] != 0) { double score[ROW] = 
#define _intPlants___ {0, 0, 0, 0, 0}; int warning_flag[5] = 
#define _intZombies___ {0, 0, 0, 0, 0}; int have_zombies[5] = 
#define _intLeftLines___ {0, 0, 0, 0, 0}; double zombie_cost[5] = 
#define _intSun__ {1, 3, 2, 20, 80}; for (int i 
#define _intzombienums_ = 0; i < ROW; i++) { for 
#define _Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0 (int j = 0; j < COLUMN; j++) 
#define _thisBrokenLinesScoreBrokenLinesScore { int k = 0; while (Zombies[i][j][k] != 
#define _thisKillPlantsScoreKillPlantsScore -1) { double distance_cost = 10 / (1 
#define _thisScoreScore_ + j); score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 
#define _thistimetime_ 1]; have_zombies[i] = 1; if (j <= 3) 
#define _thisPlaceCDPlaceCD_ warning_flag[i] = 1; k++; } } } double 
#define _thisPlantsPlants_ plant_cost[7] = {0, 0, -20, -3, -1, -80, 
#define _thisZombiesZombies_ -80}; for (int i = 0; i < 
#define _thisLeftLinesLeftLines_ ROW; i++) { for (int j = 0; 
#define _thisSunSun_ j < COLUMN; j++) { score[i] += plant_cost[Plants[i][j]]; 
#define _thiszombienumszombienums } } double time_cost = 10 * (1 
#define _thisgamegame / (1 + exp((time - 1000) / 500))); 
#define _forinti0iZOMBIEKINDi int *serial_num = rank(score, ROW); int deal_with_warning_flag = 
#define _thisvaluei0 0; for (int i = 0; i < 
#define _memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile ROW; i++) { if (warning_flag[serial_num[i]] == 1) { 
#define _fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0 int flag = 0; for (int j = 
#define _forinti0iROWiaveragecostiaverage5 0; j < COLUMN; j++) { if (Plants[serial_num[i]][j] 
#define _forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05 == NOPLANT) { player->PlacePlant(PEPPER, serial_num[i], j); flag = 
#define _squaredistance5ifsquaredistancepowthistime001100return1else 1; deal_with_warning_flag = 1; } if (flag == 
#define _return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow 1) break; } break; } } if (deal_with_warning_flag 
#define _ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei == 0) { if (score[0] >= 0) { 
#define _decision0i1 int flag = 0; for (int j = 
#define _decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei 0; j < COLUMN; j++) { if (Plants[serial_num[0]][j] 
#define _decision0i1_ == NOPLANT && have_zombies[serial_num[0]] == 1) { player->PlacePlant(PEPPER, 
#define _decision1thischoicei serial_num[0], j); flag = 1; } if (flag 
#define _ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum == 1) break; } } } free(serial_num); } 
#define _thisKillZombiesScoreKillZombiesScore_ } void value() { this->value_peashooter(); this->value_sunflower(); this->value_smallmnut(); this->value_winterpeashooter(); 
#define _thisLeftPlantsLeftPlants this->value_squash(); this->value_pepper(); } void make_decision() { this->beginning_operation(); this->GameState_2_400(); 
#define _thisScoreScore__ if (this->time > 20) this->value(); } }; class 
#define _thistimetime__ value_zombie_func { public: int nozombie; int normal_choice; int 
#define _thisPlaceCDPlaceCD__ bucket_choice; int polevault_choice; int sled_choice; int gargantuar_choice; double 
#define _thisPlantsPlants__ value[ZOMBIE_KIND]; int choice[ZOMBIE_KIND] = {this->normal_choice, this->bucket_choice, this->polevault_choice, this->sled_choice, 
#define _thisZombiesZombies__ this->gargantuar_choice}; int BrokenLinesScore; int KillPlantsScore; int LeftPlants; int 
#define _thisLeftLinesLeftLines__ Score; int time; int *PlaceCD; int **Plants; int 
#define _thisSunSunforinti0iROWifinalchoicei0 ***Zombies; int *LeftLines; int Sun; int zombie_nums; int 
#define _boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10 give_up_whole_attack; Game game; IPlayer *player; value_zombie_func(int BrokenLinesScore, int 
#define _thisvaluekind1100000 KillPlantsScore, int Score, int time, int *PlaceCD, int 
#define _returntrueelse **Plants, int ***Zombies, int *LeftLines, int Sun, int 
#define _returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00 zombie_nums, Game game, IPlayer *player) { this->normal_choice = 
#define _ifthisLeftLinesrow0cost100000elseintnumperrow0 this->bucket_choice = this->polevault_choice = this->sled_choice = this->gargantuar_choice = 
#define _doubletoomanyzombiescost15 0; this->BrokenLinesScore = BrokenLinesScore; this->KillPlantsScore = KillPlantsScore; this->Score 
#define _forintj0jCOLUMNjintk0___ = Score; this->time = time; this->PlaceCD = PlaceCD; 
#define _whilethisZombiesrowjk1switchkindcasePOLEVAULT this->Plants = Plants; this->Zombies = Zombies; this->LeftLines = 
#define _costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost LeftLines; this->Sun = Sun; this->zombie_nums = zombie_nums; this->game 
#define _break_____________________________ = game; this->give_up_whole_attack = 0; this->player = player; 
#define _default for (int i = 0; i < ZOMBIE_KIND; 
#define _costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k i++) this->value[i] = 0; memset(this->choice, 0, ZOMBIE_KIND * 
#define _numperrow (sizeof(int))); } int judge_whether_big_cost_in_one_row(int *cost) { double average 
#define _costnumperrowtoomanyzombiescostreturncostintsumplantsperrow = 0, square_distance = 0; for (int i 
#define _rowsplantskindnumperrow_ = 0; i < ROW; i++) { average 
#define _intplantsnumformatintmallocROWsizeofint_ += cost[i]; } average /= 5; for (int 
#define _forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_ i = 0; i < ROW; i++) { 
#define _memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_ square_distance += (cost[i] - average) * (cost[i] - 
#define _plantsnumformatiSUNFLOWER1 average); } square_distance = pow(square_distance, 0.5); square_distance /= 
#define _break______________________________ 5; if (square_distance > pow(this->time, 0.2) * 400) 
#define _caseWINTERPEASHOOTER___ { return 1; } else return 0; } 
#define _plantsnumformatiWINTERPEASHOOTER1 void make_decision(int *decision) { double max = -10000; 
#define _break_______________________________ for (int i = 0; i < 5; 
#define _casePEASHOOTER___ i++) { if (max < this->value[i]) { max 
#define _plantsnumformatiPEASHOOTER1 = this->value[i]; decision[0] = i + 1; decision[1] 
#define _break________________________________ = this->choice[i]; } } if (this->give_up_whole_attack == 1 
#define _caseSMALLNUT__ && this->Sun < 900) { decision[0] = NOZOMBIE; 
#define _plantsnumformatiSMALLNUT1 decision[1] = 0; } else if (this->give_up_whole_attack == 
#define _break_________________________________ 1 && this->Sun >= 900) { int attacking_lines1 
#define _casePEPPER__ = 0; int attacking_lines2 = 0; int leftlins_flag 
#define _plantsnumformatiPEPPER1 = 0; for (int i = 0; i 
#define _break__________________________________ < 5; i++) { if (LeftLines[i] == 1) 
#define _caseSQUASH__ { attacking_lines1 = i; break; } } for 
#define _plantsnumformatiSQUASH1 (int i = 0; i < 5; i++) 
#define _breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00 { if (LeftLines[i] == 1 && i != 
#define _switchkindcaseNORMAL attacking_lines1) { attacking_lines2 = i; break; } if 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10 (i == 4) leftlins_flag = 1; } if 
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12 (leftlins_flag == 0) { decision[0] = GARGANTUAR; decision[1] 
#define _break___________________________________ = attacking_lines1; this->player->PlaceZombie(GARGANTUAR, attacking_lines1); this->player->PlaceZombie(BUCKET, attacking_lines1); this->player->PlaceZombie(NORMAL, attacking_lines2); 
#define _caseBUCKET____ this->player->PlaceZombie(POLEVAULT, attacking_lines2); this->player->PlaceZombie(SLED, attacking_lines2); } else { this->player->PlaceZombie(GARGANTUAR, 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10 attacking_lines1); this->player->PlaceZombie(BUCKET, attacking_lines1); this->player->PlaceZombie(NORMAL, attacking_lines1); this->player->PlaceZombie(POLEVAULT, attacking_lines1); this->player->PlaceZombie(SLED, 
#define _plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1 attacking_lines1); } } } bool whether_need_compute(int kind) { 
#define _break____________________________________ if (this->PlaceCD[kind - 1] > 0 || this->time 
#define _casePOLEVAULT___ < 120) { this->choice[kind - 1] = 0; 
#define _ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED this->value[kind - 1] = -100000; return true; } 
#define _ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break else return false; } void whether_give_up_attack(double *score) { 
#define _caseGARGANTUAR___ int num[5] = {0, 0, 0, 0, 0}; 
#define _ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11 for (int i = 0; i < ROW; 
#define _plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11 i++) { for (int j = 0; j 
#define _forintj0jCOLUMNjifPlantsrowjNOPLANT < COLUMN; j++) { if (Plants[i][j] == WINTERPEASHOOTER) 
#define _costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000 num[i]++; } } int give_up_lines = 0; for 
#define _intindex0 (int i = 0; i < ROW; i++) 
#define _forinti0ilengthiifmaxaimaxai { if (num[i] >= 5) { score[i] = 
#define _indexi -100000; give_up_lines++; } } int sum_all_lines = 0; 
#define _returnindex for (int i = 0; i < ROW; 
#define _NORMAL_ i++) { if (this->LeftLines[i] == 1) { sum_all_lines++; 
#define _BUCKET_ } } if (give_up_lines == sum_all_lines) this->give_up_whole_attack = 
#define _POLEVAULT_ 1; } double zombie_cost(int row, double *zombies_paras, double 
#define _SLED_ distance_cost, double distance_rate, int kind) { double cost 
#define _GARGANTUARSUNFLOWER = 0.0; if (this->LeftLines[row] == 0) { cost 
#define _WINTERPEASHOOTER_ = -100000; } else { int num_per_row = 
#define _PEASHOOTER_ 0; double too_many_zombies_cost = -1.5; for (int j 
#define _SMALLNUT_ = 0; j < COLUMN; j++) { int 
#define _PEPPER_ k = 0; while (this->Zombies[row][j][k] != -1) { 
#define _SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000 switch (kind) { case POLEVAULT: cost += zombies_paras[this->Zombies[row][j][k] 
#define _judgeLinesnotbrokenfinalchoice - 1] * ((COLUMN - j - distance_cost) 
#define _ifthiswhetherneedcomputeNORMALreturn * (COLUMN - j - distance_cost)); break; default: 
#define _zombie cost += zombies_paras[this->Zombies[row][j][k] - 1] * (-distance_rate * 
#define _doublezombiesparasZOMBIEKIND54231 (COLUMN - j - distance_cost) * (COLUMN - 
#define _doubledistancecost1distancerate005 j - distance_cost) + 2); } k++; num_per_row++; 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL } } cost += num_per_row * too_many_zombies_cost; } 
#define _plant return cost; } int **sum_plants_per_row() { int **plants_num_format 
#define _intplantsnumformatROWPLANTKIND0 = (int **)malloc(ROW * sizeof(int *)); for (int 
#define _doubleplantsparaPLANTKIND88221005 i = 0; i < ROW; i++) { 
#define _intsumplantsperrow0thissumplantsperrow plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND); memset(plants_num_format[i], 0, 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL PLANT_KIND * sizeof(int)); } for (int i = 
#define _time 0; i < ROW; i++) { for (int 
#define _doubletimecost2011expthistimeTOTALTIME210005 j = 0; j < PLANT_KIND; j++) { 
#define _forinti0iROWi__ plants_num_format[i][j] = 0; } } for (int i 
#define _finalchoiceitimecostSun = 0; i < ROW; i++) { for 
#define _doublesunbaseline60sunsub02 (int j = 0; j < COLUMN; j++) 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub { switch (this->Plants[i][j]) { case SUNFLOWER: plants_num_format[i][SUNFLOWER - 
#define _forinti0iROWi___ 1]++; break; case WINTERPEASHOOTER: plants_num_format[i][WINTERPEASHOOTER - 1]++; break; 
#define _finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW case PEASHOOTER: plants_num_format[i][PEASHOOTER - 1]++; break; case SMALLNUT: 
#define _thisvalueNORMAL1finalchoicethischoiceNORMAL1 plants_num_format[i][SMALLNUT - 1]++; break; case PEPPER: plants_num_format[i][PEPPER - 
#define _voidvaluebucketdoublefinalchoiceROW00000 1]++; break; case SQUASH: plants_num_format[i][SQUASH - 1]++; break; 
#define _judgeLinesnotbrokenfinalchoice_ } } } return plants_num_format; } double plant_cost(int 
#define _ifthiswhetherneedcomputeBUCKETreturn row, int **plants_num_format, double *plants_para, int kind) { 
#define _zombie_ double origin_para[PLANT_KIND]; for (int i = 0; i 
#define _doublezombiesparasZOMBIEKIND254thistime100100522 < PLANT_KIND; i++) { origin_para[i] = plants_para[i]; } 
#define _doubledistancecost25distancerate01 double cost = 0.0; switch (kind) { case 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET NORMAL: if (plants_num_format[row][SMALLNUT - 1] > 0 && 
#define _plant_ plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 
#define _intplantsnumformatROWPLANTKIND0_ 0) plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER - 1] 
#define _doubleplantsparaPLANTKIND63231004 * 1 + plants_num_format[row][WINTERPEASHOOTER - 1] * 2); 
#define _intsumplantsperrowthissumplantsperrow break; case BUCKET: if (plants_num_format[row][SMALLNUT - 1] > 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET 0 && plants_num_format[row][WINTERPEASHOOTER - 1] > 0) plants_para[SMALLNUT 
#define _time_ - 1] *= (plants_num_format[row][PEASHOOTER - 1] * 0.2 
#define _doubletimecost2011expthistimeTOTALTIME310005 + plants_num_format[row][WINTERPEASHOOTER - 1]); break; case POLEVAULT: if 
#define _forinti0iROWi____ (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][PEASHOOTER - 
#define _finalchoiceitimecostSun_ 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0) { 
#define _doublesunbaseline150sunsub05 plants_para[SMALLNUT - 1] *= ((1.5 - plants_num_format[row][SMALLNUT - 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub 1]) * (3 - plants_num_format[row][PEASHOOTER - 1] + 
#define _forinti0iROWi_____ plants_num_format[row][WINTERPEASHOOTER - 1])); } break; case SLED: if 
#define _finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2) { plants_para[WINTERPEASHOOTER - 
#define _thisvalueBUCKET1finalchoicethischoiceBUCKET1 1] = 6 - 2 * plants_num_format[row][WINTERPEASHOOTER - 
#define _voidvaluepolevaultdoublefinalchoiceROW00000 1]; } break; case GARGANTUAR: if (plants_num_format[row][WINTERPEASHOOTER - 
#define _judgeLinesnotbrokenfinalchoice__ 1] >= 2) { plants_para[WINTERPEASHOOTER - 1] = 
#define _ifthiswhetherneedcomputePOLEVAULTreturn 8 - 2 * plants_num_format[row][WINTERPEASHOOTER - 1]; } 
#define _zombie__ break; } plants_para[SUNFLOWER - 1] *= (1 + 
#define _doublezombiesparasZOMBIEKIND1thistime10010051523 1 / (COLUMN - plants_num_format[row][SUNFLOWER - 1] + 
#define _doubledistancecost25distancerate01_ 1)); for (int j = 0; j < 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT COLUMN; j++) { if (Plants[row][j] != NOPLANT) cost 
#define _plant__ += plants_para[Plants[row][j] - 1] * (plants_para[Plants[row][j] - 1] 
#define _intplantsnumformatROWPLANTKIND0__ > 0 ? (j + 1) * (j 
#define _doubleplantsparaPLANTKIND52181001 + 1) : (COLUMN - j)); } for 
#define _intsumplantsperrowthissumplantsperrow_ (int i = 0; i < PLANT_KIND; i++) 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT { plants_para[i] = origin_para[i]; } return cost; } 
#define _time__ int max_index(double *a, int length) { double max 
#define _doubletimecost2011expthistimeTOTALTIME510005 = -10000; int index = 0; for (int 
#define _forinti0iROWi______ i = 0; i < length; i++) { 
#define _finalchoiceitimecostSun__ if (max < a[i]) { max = a[i]; 
#define _doublesunbaseline120sunsub04 index = i; } } return index; } 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub void value_normal() { double final_choice[ROW] = {0, 0, 
#define _forinti0iROWi_______ 0, 0, 0}; if (this->whether_need_compute(NORMAL)) { return; } 
#define _finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW whether_give_up_attack(final_choice); double zombies_paras[ZOMBIE_KIND] = {-5, 4, 2, 3, 
#define _thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1 1}; double distance_cost = 1, distance_rate = 0.05; 
#define _voidvaluesleddoublefinalchoiceROW00000 for (int i = 0; i < ROW; 
#define _judgeLinesnotbrokenfinalchoice___ i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, 
#define _ifthiswhetherneedcomputeSLEDreturn NORMAL); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int 
#define _zombie___ i = 0; i < ROW; i++) for 
#define _doublezombiesparasZOMBIEKIND32174 (int j = 0; j < PLANT_KIND; j++) 
#define _doubledistancecost25distancerate01__ { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED {8, -8, -2, -2, -100, 20}; int **sum_plants_per_row0 
#define _plant___ = this->sum_plants_per_row(); for (int i = 0; i 
#define _intplantsnumformatROWPLANTKIND0___ < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row0, 
#define _doubleplantsparaPLANTKIND510361001and plants_para, NORMAL); } for (int i = 0; 
#define _intsumplantsperrowthissumplantsperrow__ i < ROW; i++) { free(sum_plants_per_row0[i]); } free(sum_plants_per_row0); 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED double time_cost = 20 * (1 / (1 
#define _time___ + exp((this->time - TOTAL_TIME / 2) / 500)) 
#define _doubletimecost2011expthistimeTOTALTIME520005 - 0.5); for (int i = 0; i 
#define _forinti0iROWi________ < ROW; i++) final_choice[i] += time_cost; double sun_baseline 
#define _finalchoiceitimecostSun___ = 60, sun_sub = 1; double sun_cost = 
#define _doublesunbaseline200sunsub05 (this->Sun - sun_baseline > 0 ? 1 / 
#define _doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub (1 + exp((-this->Sun + sun_baseline) / 400)) * 
#define _forinti0iROWi_________ 15 : -pow(sun_baseline - this->Sun, 1 / sun_sub)); 
#define _finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW for (int i = 0; i < ROW; 
#define _thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000 i++) final_choice[i] += sun_cost; this->choice[NORMAL - 1] = 
#define _judgeLinesnotbrokenfinalchoice____ this->max_index(final_choice, ROW); this->value[NORMAL - 1] = final_choice[this->choice[NORMAL - 
#define _ifthiswhetherneedcomputeGARGANTUARreturn 1]]; } void value_bucket() { double final_choice[ROW] = 
#define _zombie____ {0, 0, 0, 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(BUCKET)) 
#define _doublezombiesparasZOMBIEKIND2452015 { return; } double zombies_paras[ZOMBIE_KIND] = {2.5, -4, 
#define _doubledistancecost25distancerate01___ this->time < 100 ? -100 : -5, 2, 
#define _forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR -2}; double distance_cost = 2.5, distance_rate = 0.1; 
#define _plant____ for (int i = 0; i < ROW; 
#define _intplantsnumformatROWPLANTKIND0____ i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, 
#define _doubleplantsparaPLANTKIND01002510010and BUCKET); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int 
#define _intsumplantsperrowthissumplantsperrow___ i = 0; i < ROW; i++) for 
#define _forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR (int j = 0; j < PLANT_KIND; j++) 
#define _time____ { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = 
#define _doubletimecost {6, -2, 6, -1, -100, -4}; int **sum_plants_per_row 
#define _ifabsthistime50025absthistime100025absthistime150025 = this->sum_plants_per_row(); for (int i = 0; i 
#define _timecost100 < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, 
#define _timecost10011expthistimeTOTALTIME540004 plants_para, BUCKET); } for (int i = 0; 
#define _forinti0iROWi__________ i < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); 
#define _finalchoiceitimecostSun____ double time_cost = 20 * (1 / (1 
#define _doublesunbaseline350sunsub06 + exp((-this->time + TOTAL_TIME / 3) / 400)) 
#define _doublesuncost11expthisSunsunbaseline10020010 - 0.5); for (int i = 0; i 
#define _forinti0iROWi___________ < ROW; i++) final_choice[i] += time_cost; double sun_baseline 
#define _finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW = 150, sun_sub = 1; double sun_cost = 
#define _thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1 (this->Sun - sun_baseline > 0 ? 1 / 
#define _externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame (1 + exp((-this->Sun + sun_baseline) / 400)) * 
#define _gamemaintainplayerclassICamppublic 5 : -pow(sun_baseline - this->Sun, 1 / sun_sub)); 
#define _virtualintgetCurrentPlants0 for (int i = 0; i < ROW; 
#define _Plantsijij0virtualintgetCurrentZombies0Zombiesijij i++) final_choice[i] += sun_cost; this->choice[BUCKET - 1] = 
#define _kk0Zombiesijk1 this->max_index(final_choice, ROW); this->value[BUCKET - 1] = final_choice[this->choice[BUCKET - 
#define _Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic 1]]; } void value_polevault() { double final_choice[ROW] = 
#define _ICampCamp {0, 0, 0, 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(POLEVAULT)) 
#define _virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0 { return; } double zombies_paras[ZOMBIE_KIND] = {1, this->time 
#define _virtualintgetScore0 < 100 ? -100 : -5, -1.5, 2, 
#define _virtualintgetKillPlantsScore0 -3}; double distance_cost = 2.5, distance_rate = 0.1; 
#define _virtualintgetKillZombiesScore0 for (int i = 0; i < ROW; 
#define _virtualintgetNotBrokenLines0 i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, 
#define _virtualintgetBrokenLinesScore0 POLEVAULT); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int 
#define _virtualintgetLeftPlants0intTypeplayerCampgetCurrentType i = 0; i < ROW; i++) for 
#define _ifType0intNotBrokenLinesNumplayergetNotBrokenLines (int j = 0; j < PLANT_KIND; j++) 
#define _intKillZombiesScoreplayergetKillZombiesScore { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = 
#define _intLeftPlantsplayergetLeftPlants {4, -50, -8, 7, -100, -10}; int **sum_plants_per_row 
#define _intScoreplayergetScore = this->sum_plants_per_row(); for (int i = 0; i 
#define _inttime0playergetTime < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, 
#define _introwsplayerCampgetRows plants_para, POLEVAULT); } for (int i = 0; 
#define _intcolumnsplayerCampgetColumns i < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); 
#define _intPlaceCDplayerCampgetPlantCD double time_cost = 10 * (1 / (1 
#define _intPlantsplayerCampgetCurrentPlants + exp((-this->time + TOTAL_TIME / 5) / 300)) 
#define _intZombiesplayerCampgetCurrentZombies - 0.5); for (int i = 0; i 
#define _intLeftLinesplayerCampgetLeftLines < ROW; i++) final_choice[i] += time_cost; double sun_baseline 
#define _intSunplayerCampgetSun = 120, sun_sub = 1; double sun_cost = 
#define _Zombiesnumzombiesnum (this->Sun - sun_baseline > 0 ? 1 / 
#define _zombiesnumcomputenumZombiesrowscolumns (1 + exp((-this->Sun + sun_baseline) / 500)) * 
#define _Plantsnumplantsnum 6 : -pow(sun_baseline - this->Sun, 1 / sun_sub)); 
#define _plantsnumcomputenumPlantsrowscolumns for (int i = 0; i < ROW; 
#define _playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51 i++) final_choice[i] += sun_cost; this->choice[POLEVAULT - 1] = 
#define _playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52 this->max_index(final_choice, ROW); this->value[POLEVAULT - 1] = final_choice[this->choice[POLEVAULT - 
#define _ifplantsnumsunflower3 1]]; } void value_sled() { double final_choice[ROW] = 
#define _playerPlacePlantSUNFLOWER0plantsnumsunflower1 {0, 0, 0, 0, 0}; whether_give_up_attack(final_choice); if (this->whether_need_compute(SLED)) 
#define _playerPlacePlantSMALLNUT0plantsnumsmallnut5 { return; } double zombies_paras[ZOMBIE_KIND] = {3, -2, 
#define _playerPlacePlantSQUASH04 -1, -7, -4}; double distance_cost = 2.5, distance_rate 
#define _playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54 = 0.1; for (int i = 0; i 
#define _iftime06 < ROW; i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, 
#define _playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45 distance_cost, distance_rate, SLED); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; 
#define _ifSun400 for (int i = 0; i < ROW; 
#define _playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame i++) for (int j = 0; j < 
#define _valuemakedecisionifType1 PLANT_KIND; j++) { plants_num_format[i][j] = 0; } double 
#define _intBrokenLinesScoreplayergetBrokenLinesScore plants_para[PLANT_KIND] = {3, 10, 2, 7, -100, -30}; 
#define _intKillPlantsScoreplayergetKillPlantsScore int **sum_plants_per_row = this->sum_plants_per_row(); for (int i = 
#define _intScoreplayergetScore_ 0; i < ROW; i++) { final_choice[i] += 
#define _inttimeplayergetTime this->plant_cost(i, sum_plants_per_row, plants_para, SLED); } for (int i 
#define _introwsplayerCampgetRows_ = 0; i < ROW; i++) { free(sum_plants_per_row[i]); 
#define _intcolumnsplayerCampgetColumns_ } free(sum_plants_per_row); double time_cost; if (time < 600) 
#define _intPlaceCDplayerCampgetPlantCD_ time_cost = 15 * (1 / (1 + 
#define _intPlantsplayerCampgetCurrentPlants_ exp((-this->time + TOTAL_TIME / 5) / 400)) - 
#define _intZombiesplayerCampgetCurrentZombies_ 0.5); else { time_cost = 30 * (1 
#define _intLeftLinesplayerCampgetLeftLines_ / (1 + exp((+this->time - TOTAL_TIME / 5) 
#define _intSunplayerCampgetSun_ / 300)) - 0.5); } for (int i 
#define _iftime3intzombienumcalculatezombienumsZombies49 = 0; i < ROW; i++) final_choice[i] += 
#define _valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame time_cost; double sun_baseline = 200, sun_sub = 1; 
#define _valuevaluenormal double sun_cost = (this->Sun - sun_baseline > 0 
#define _valuevaluebucket ? 1 / (1 + exp(-this->Sun + sun_baseline 
#define _valuevaluepolevault + 100) / 500) * 10 : 0); 
#define _valuevaluesled for (int i = 0; i < ROW; 
#define _valuevaluegargantuar i++) final_choice[i] += sun_cost; this->choice[SLED - 1] = 
#define _intdecision200 this->max_index(final_choice, ROW); this->value[SLED - 1] = final_choice[this->choice[SLED - 
#define _valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0 1]] / 50; } void value_gargantuar() { double 
#define _whileZombiesijk1 final_choice[ROW] = {0, 0, 0, 0, 0}; whether_give_up_attack(final_choice); 
#define _kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1 if (this->whether_need_compute(GARGANTUAR)) { return; } double zombies_paras[ZOMBIE_KIND] = 
#define _elseplayerPlaceZombiePOLEVAULT1 {2, -4, -5, -20, -15}; double distance_cost = 
#define _playerPlaceZombieNORMAL2 2.5, distance_rate = 0.1; for (int i = 
#define _playerPlaceZombieBUCKET3 0; i < ROW; i++) { final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, GARGANTUAR); } int plants_num_format[ROW][PLANT_KIND] = {{0}}; for (int i = 0; i < ROW; i++) for (int j = 0; j < PLANT_KIND; j++) { plants_num_format[i][j] = 0; } double plants_para[PLANT_KIND] = {1, 10, 2, 8, -100, -10}; int **sum_plants_per_row = this->sum_plants_per_row(); for (int i = 0; i < ROW; i++) { final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, GARGANTUAR); } for (int i = 0; i < ROW; i++) { free(sum_plants_per_row[i]); } free(sum_plants_per_row); double time_cost; if (abs(this->time - 500) < 25 || abs(this->time - 1000) < 25 || abs(this->time - 1500) < 25) time_cost = 1000; time_cost = 120 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5); for (int i = 0; i < ROW; i++) final_choice[i] += time_cost; double sun_baseline = 300, sun_sub = 1; double sun_cost = 1 / (1 + exp(-this->Sun + sun_baseline) / 500) * 10; for (int i = 0; i < ROW; i++) final_choice[i] += sun_cost; this->choice[GARGANTUAR - 1] = this->max_index(final_choice, ROW); this->value[GARGANTUAR - 1] = final_choice[this->choice[GARGANTUAR - 1]]; } }; static Game game; void player_ai(IPlayer *player) { int Type = player->Camp->getCurrentType(); if (Type == 0) { int NotBrokenLinesNum = player->getNotBrokenLines(); int KillZombiesScore = player->getKillZombiesScore(); int LeftPlants = player->getLeftPlants(); int Score = player->getScore(); int time0 = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player, game); value.make_decision(); } if (Type == 1) { int BrokenLinesScore = player->getBrokenLinesScore(); int KillPlantsScore = player->getKillPlantsScore(); int Score = player->getScore(); int time = player->getTime(); int rows = player->Camp->getRows(); int columns = player->Camp->getColumns(); int *PlaceCD = player->Camp->getPlantCD(); int **Plants = player->Camp->getCurrentPlants(); int ***Zombies = player->Camp->getCurrentZombies(); int *LeftLines = player->Camp->getLeftLines(); int Sun = player->Camp->getSun(); if (time > 3) { int zombie_num = calculate_zombie_nums(Zombies, 4, 9); value_zombie_func value(BrokenLinesScore, KillPlantsScore, Score, time, PlaceCD, Plants, Zombies, LeftLines, Sun, zombie_num, game, player); value.value_normal(); value.value_bucket(); value.value_polevault(); value.value_sled(); value.value_gargantuar(); int decision[2] = {0, 0}; value.make_decision(decision); if (decision[0] != NOZOMBIE) { player->PlaceZombie((decision[0] > ZOMBIE_KIND ? NORMAL : decision[0]), decision[1] > ROW - 1 ? ROW - 1 : decision[1]); } } else { player->PlaceZombie(POLEVAULT, 1); player->PlaceZombie(NORMAL, 2); player->PlaceZombie(BUCKET, 3); } } } 

_includeaih 
_includeiostream 
_includestdlibh 
_includemathh 
_includecstring 
_includevector 
_includequeue 
_usingnamespacestd 
_defineZOMBIEKIND5 
_definePLANTKIND6 
_defineTOTALTIME2000 
_defineCOLUMN10 
_defineROW5 
_FILEfile 
_errnoterrfopensfileD2022springsemesterpvzfc19userpackagemasterFC19UIdatatxtw 
_enumPlantTypeNOPLANT0 
_SUNFLOWER 
_WINTERPEASHOOTER 
_PEASHOOTER 
_SMALLNUT 
_PEPPER 
_SQUASHenumZombieTypeNOZOMBIE0 
_NORMAL 
_BUCKET 
_POLEVAULT 
_SLED 
_GARGANTUAR 
_zrfscodestarts 
_constintplantCost70504001005012550 
_constintplantCd70103010406060 
_constintzombieCost6050125125300300 
_constintzombieCd601520202525 
_constintplantHp70300300300400000 
_constintplantDps7002010000 
_intzombieHp6027082020016003000 
_structSunflowerintrowcolumncd 
_SunflowerintRowintColumncd24 
_rowRowcolumnColumn 
_intzombieNumintzombiesintcnt7pcnt 
_forinti0i5i 
_forintj0j10j 
_forintk0k10kifzombiesijk1 
_break 
_else 
_cntzombiesijkreturnp 
_zombies 
_intzombieNumintzombies51010intcnt7pcnt 
_forinti0i5i_ 
_forintj0j10j_ 
_forintk0k10kifzombiesijk1_ 
_break_ 
_else_ 
_cntzombiesijkreturnpstructZombieintnum 
_inthp 
_intcoXcoY 
_ZombieintNumintrowcoXrowcoY9 
_hpzombieHpNum 
_numNumintspeedstructPlantintnum 
_inthp_ 
_intcoXcoY_ 
_intdps 
_PlantintNumintrowintcolnumNum 
_coXrowcoYcol 
_hpplantHpNum 
_dpsplantDpsNum 
_structActionlistintplantPlace510zombiePlace5 
_intplantRemove510classGamepublic 
_inttimesunmoon 
_intplants510zombies51010 
_intcdPlant7cdZombie6tick 
_intdps5dps 
_intflagPlant7flagZombie610 
_intflagShovel51010 
_intzombieCostPerRow5 
_vectorSunflowersunFlowers 
_vectorPlantvectorPlants 
_vectorZombievectorZombiesvoidplantremoveintiintjIPlayerplayerplayerremovePlantij 
_flagShovelij1voidmaintainIPlayerplayertime 
_intPlantsplayerCampgetCurrentPlantscurrentPlants 
_intZombiesplayerCampgetCurrentZombiescurrentZombies 
_mooninttime20001 
_forinti0i5i__ 
_forintj0j10jifplantsijPlantsijplantsijPEPPERplantsijSQUASHifflagShovelij1flagShovelij0elseintnumplantsij 
_moonplantCostnum5intsqrtplantHpnum 
_dpsiplantDpsnum 
_ifnum1forintk0ksunFlowerssizek 
_ifsunFlowerskrowisunFlowerskcolumnjsunFlowerserasesunFlowersbegink 
_break__ 
_elseifplantsijPlantsijintnumPlantsij 
_sunplantCostnum 
_dpsiplantDpsnum_ 
_cdPlantnumplantCdnum 
_flagPlantnum0 
_ifnum1sun25 
_sunFlowerspushbackSunflowerijvectorPlantspushbackPlantPlantsijijplantsijPlantsij 
_intflag0 
_forintk0kvectorPlantssizekifvectorPlantskcoXivectorPlantskcoYjifvectorPlantsknumPlantsijvectorPlantserasevectorPlantsbegink 
_k 
_ifPlantsij0 
_vectorPlantspushbackPlantPlantsijijflag1 
_break___ 
_ifflag0Plantsij0 
_vectorPlantspushbackPlantPlantsijijintzzombieNumzombiesZzombieNumZombies 
_forinti0i5iintrowZombie6RowZombie6 
_forintj0j10j__ 
_forintk0k10kifzombiesijk1__ 
_break____ 
_else__ 
_rowZombiezombiesijkforintj0j10j 
_forintk0k10kifZombiesijk1 
_break_____ 
_else___ 
_RowZombieZombiesijk 
_forintj0j6j 
_ifRowZombiejrowZombiej 
_zombieCostPerRowizombieCostjforinti0i7iifziZi 
_zombiedie 
_elseifziZimoonzombieCosti 
_cdZombieizombieCdi 
_flagZombiei0 
_zombieplaced 
_forinti0i5iforintj0j10jintk0 
_whileZombiesijk1zombiesijkZombiesijk 
_k_ 
_vectorinthaveerased 
_forinti0ivectorZombiessizeiinthaveerasedflag0 
_forintz0zhaveerasedsizez2ifvectorZombiesicoXhaveerasedzvectorZombiesicoYhaveerasedz1haveerasedflag1 
_breakifPlantsvectorZombiesicoXvectorZombiesicoYSMALLNUThaveerasedflag1continueelseintnumvectorZombiesinum 
_intoriginalnumofthiskind0nownumofthiskind0 
_intk0 
_whilezombiesvectorZombiesicoXvectorZombiesicoYk1ifzombiesvectorZombiesicoXvectorZombiesicoYknumoriginalnumofthiskindkk0 
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifZombiesvectorZombiesicoXvectorZombiesicoYknumnownumofthiskindkiforiginalnumofthiskindnownumofthiskind0vectorintserialNum 
_forintj0jvectorZombiessizejifvectorZombiesjnumnumvectorZombiesicoYvectorZombiesjcoYvectorZombiesicoXvectorZombiesjcoXserialNumpushbackj 
_ifnownumofthiskind0forintiserialNumsize1i0ivectorZombieseraseserialNumivectorZombiesbegin 
_iforiginalnumofthiskindnownumofthiskind1 
_findthesmallesthp 
_intsmallhp5000smallhpnum0 
_forintk0kserialNumsizekifsmallhpvectorZombiesserialNumkhpsmallhpvectorZombiesserialNumkhp 
_smallhpnumk 
_vectorZombieserasesmallhpnumvectorZombiesbegin 
_haveerasedpushbackvectorZombiesicoX 
_haveerasedpushbackvectorZombiesicoYforinti0ivectorZombiessizeiintnumvectorZombiesinum 
_intk0_ 
_intflagself0 
_intflagnear0 
_whileZombiesvectorZombiesicoXvectorZombiesicoYk1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkbreakelseflagself1 
_k0 
_whileZombiesvectorZombiesicoXvectorZombiesicoY1k1ifnumZombiesvectorZombiesicoXvectorZombiesicoYkvectorZombiesicoYelseflagnear1 
_ifflagself1flagnear1vectorZombieserasevectorZombiesbegini 
_iforinti0i7iifcdPlanti0 
_cdPlanti 
_ifcdPlanti0 
_flagPlanti1 
_forinti0i6iifcdZombiei0 
_cdZombiei 
_ifcdZombiei0 
_flagZombiei1forinti0isunFlowerssizeiifsunFlowersicd0 
_sunFlowersicd 
_ifsunFlowersicd0sun25 
_sunFlowersicd24ticktick 
_Gametime0 
_sun400moon300 
_forinti0i5i___ 
_forintj0j10j___ 
_plantsij0flagShovelij0 
_forinti0i5i____ 
_forintj0j10j____ 
_forintk0k10k 
_zombiesijk0 
_forinti0i5i_____ 
_dpsi0zombieCostPerRowi0 
_forinti0i7i 
_cdPlanti0flagPlanti1 
_forinti0i6i 
_cdZombiei0flagZombiei1 
_initialize 
_GametranStateActionlistqIPlayerplayerq 
_globalstatus 
_GameGametranStateActionlistqIPlayerplayerGamenewGamenewGametimethistimenewGamesunthissunnewGamemoonthismoon 
_forinti0i5i______ 
_forintj0j10j_____ 
_newGameplantsijthisplantsijflagShovelijthisflagShovelij 
_forinti0i5i_______ 
_forintj0j10j______ 
_forintk0k10k_ 
_newGamezombiesijkthiszombiesijk 
_forinti0i7i_ 
_newGamecdPlantithiscdPlantinewGameflagPlantithisflagPlanti 
_forinti0i6i_ 
_newGamecdZombieithiscdZombieinewGameflagZombieithisflagZombiei 
_forinti0i5i________ 
_newGamedpsithisdpsinewGamezombieCostPerRowithiszombieCostPerRowinewGameGame 
_forinti0i5i_________ 
_forintj0j10jifqplantPlaceij0intnumqplantPlaceij 
_newGamesunplantCostnum 
_newGamecdPlantnumplantCdnum 
_newGameflagPlantnum0 
_newGamedpsiplantDpsnum 
_newGameplantsijnumifqzombiePlacei0intnumqzombiePlacei 
_newGamemoonzombieCostnum 
_newGamecdZombienumzombieCdnum 
_newGameflagZombienum0 
_newGamemaintainplayerreturnnewGamevoidclassZombiesnumpublic 
_intnormal 
_intbucket 
_intpolevault 
_intsled 
_intgargantuar 
_inttotalnumZombiesnumthisnormalthisbucketthispolevaultthissledthisgargantuarthistotalnum0voidcomputenumintzombiesintrowsintcolumnsintnum0 
_forinti0irowsiforintj0jcolumnsjintk0 
_whilezombiesijk1switchzombiesijkcaseNORMAL 
_thisnormal 
_break______ 
_caseBUCKET 
_thisbucket 
_break_______ 
_casePOLEVAULT 
_thispolevault 
_break________ 
_caseSLED 
_thissled 
_break_________ 
_caseGARGANTUAR 
_thisgargantuar 
_breaknum 
_kclassPlantsnumpublic 
_intsunflower 
_intwinterpeashooter 
_intpeashooter 
_intsmallnut 
_intpepper 
_intsquashPlantsnumthissunflowerthiswinterpeashooterthispeashooterthissmallnutthispepperthissquash0voidcomputenumintplantsintrowsintcolumnsforinti0irowsi 
_forintj0jcolumnsjswitchplantsijcaseSUNFLOWER 
_thissunflower 
_break__________ 
_caseWINTERPEASHOOTER 
_thiswinterpeashooter 
_break___________ 
_casePEASHOOTER 
_thispeashooter 
_break____________ 
_caseSMALLNUT 
_thissmallnut 
_break_____________ 
_casePEPPER 
_thispepper 
_break______________ 
_caseSQUASH 
_thissquash 
_breakintcalculatezombienumsintzombiesintrowsintcolumnsintnum0 
_forinti0irowsiforintj0jcolumnsjintk0_ 
_whilezombiesijk1num 
_kreturnnumintchooseLinesnotBrokenintLeftlinesintplantsintcolumnforinti0iifLeftlinesi1plantsicolumnNOPLANT 
_returnireturnrandROWtypedefstructposandvalueintpos2 
_doublevalue 
_posandvalueclassvalueplantfuncpublic 
_doublenoplant 
_posandvaluesunflower 
_posandvaluepeashooter 
_posandvaluewinterpeashooter 
_posandvaluesmallnut 
_posandvaluepepper 
_posandvaluesquash 
_intgeneratingrow 
_IPlayerplayer 
_Gamegame 
_doublevaluePLANTKIND1 
_intchoicePLANTKIND1thisnoplantthissunflowerthispeashooterthiswinterpeashooterthissmallnutthispepperthissquashintNotBrokenLinesNum 
_intKillZombiesScore 
_intLeftPlants 
_intScore 
_inttime 
_intPlaceCD 
_intPlants 
_intZombies 
_intLeftLines 
_intSun 
_intzombienumsvalueplantfuncintNotBrokenLinesNum 
_intKillZombiesScore_ 
_intScore_ 
_inttime_ 
_intPlaceCD_ 
_intPlants_ 
_intZombies_ 
_intLeftLines_ 
_intSunIPlayerplayer 
_GamegamethisNotBrokenLinesNumNotBrokenLinesNum 
_thisKillZombiesScoreKillZombiesScore 
_thisScoreScore 
_thistimetime 
_thisPlaceCDPlaceCD 
_thisPlantsPlants 
_thisZombiesZombies 
_thisLeftLinesLeftLines 
_thisSunSun 
_thisplayerplayer 
_thisgeneratingrow1 
_thisgamegameintsumplantsperrow 
_rowsplantskindnumperrow 
_intplantsnumformatintmallocROWsizeofint 
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND 
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER 
_plantsnumformatiSUNFLOWER 
_break_______________ 
_caseWINTERPEASHOOTER_ 
_plantsnumformatiWINTERPEASHOOTER 
_break________________ 
_casePEASHOOTER_ 
_plantsnumformatiPEASHOOTER 
_break_________________ 
_caseSMALLNUT_ 
_plantsnumformatiSMALLNUT 
_break__________________ 
_casePEPPER_ 
_plantsnumformatiPEPPER 
_break___________________ 
_caseSQUASH_ 
_plantsnumformatiSQUASH 
_breakreturnplantsnumformatvoidbeginningoperationifthistime2thisplayerPlacePlantSUNFLOWERthisgeneratingrow1 
_thisplayerPlacePlantSMALLNUTthisgeneratingrowCOLUMN1 
_voidGameState250ifthistime2thistime200intalarmingflag1 
_forinti0iROWiifithisgeneratingrowforintj0jCOLUMNjintk0 
_whilethisZombiesijk1ifj3 
_alarmingflagi 
_ifthisSun70 
_switchthisZombiesijkcasePOLEVAULT 
_caseSLED_ 
_thisplayerPlacePlantSQUASHij100j1 
_break____________________ 
_caseBUCKET_ 
_ifthisPlaceCDSQUASH0 
_thisplayerPlacePlantSQUASHij100j1_ 
_elseifj3 
_thisplayerPlacePlantPEPPERij100j1 
_break_____________________ 
_caseGARGANTUAR_ 
_thisplayerPlacePlantSQUASHij100j1__ 
_ifj4 
_thisplayerPlacePlantPEPPERi8 
_break______________________ 
_caseNORMAL 
_thisplayerPlacePlantPEASHOOTERi1 
_thisplayerPlacePlantSMALLNUTij100j1 
_breakkelse 
_forintj0jCOLUMNjintk0 
_whilethisZombiesthisgeneratingrowjk1ifthisSun70 
_switchthisZombiesthisgeneratingrowjk 
_casePOLEVAULT_ 
_caseBUCKET__ 
_caseSLED__ 
_thisplayerPlacePlantSQUASHthisgeneratingrow5 
_break_______________________ 
_caseGARGANTUAR__ 
_thisplayerPlacePlantSQUASHthisgeneratingrowj100j1 
_ifj4_ 
_thisplayerPlacePlantPEPPERthisgeneratingrow8 
_break________________________ 
_caseNORMAL_ 
_thisplayerPlacePlantSMALLNUTthisgeneratingrowj101j1breakifjthissumplantsperrowthisgeneratingrowSUNFLOWER11thisPlaceCDSQUASH0thisplayerPlacePlantPEPPERi8k 
_thisplayerPlacePlantSUNFLOWERthisgeneratingrowthissumplantsperrowthisgeneratingrowSUNFLOWER1 
_ifalarmingflag1ifthisPlaceCDSQUASH0thisplayerPlacePlantSQUASHalarmingflagCOLUMN1else 
_thisplayerPlacePlantPEPPERalarmingflagCOLUMN1 
_voidGameState50200ifthistime50thistime200ifthisSun400 
_thisplayerPlacePlantWINTERPEASHOOTERthisgeneratingrow0 
_voidvaluepeashooteroriginifthistime50 
_ifthisPlaceCDPEASHOOTER0doublelossdoublemallocROWsizeofdouble 
_forinti0iROWilossidoublemallocCOLUMNsizeofdouble 
_memsetlossi0COLUMNsizeofdoubledoublemax10000maxindex200 
_forinti0iROWi 
_forintj0jCOLUMNjifthisPlantsijNOPLANT 
_lossij10000 
_else____ 
_doublerowithisgeneratingrow100 
_lossijrow 
_doublecolumn25 
_lossijcolumnexpcolumn10 
_doublezombieZOMBIEKIND61024020 
_forintcolumn00jCOLUMNjintk0 
_whileZombiesicolumn0k1lossijzombieZombiesicolumn0k1COLUMNj 
_k__ 
_doubleplantPLANTKIND202520 
_forintcolumn00jCOLUMNjifthisPlantsicolumn0NOPLANT 
_lossijplantthisPlantsicolumn01column0COLUMN240doubletimerate30 
_lossijtimerate11expthistimeTOTALTIME520005ifmaxlossijmaxindex0i 
_maxindex1j 
_thispeashooterpos0maxindex0 
_thispeashooterpos1maxindex1 
_thispeashootervaluemax 
_boolhavetypeofzombiesintzombieinttypeintk0 
_whilezombiek1ifzombiektype 
_returntrue 
_kreturnfalseintsearchfornearestzombieintzombieintrowintcolumnintnearest0 
_forintj0jCOLUMNjintk0_ 
_whileZombiesrowjk1ifnearestjcolumn 
_nearestjcolumn 
_k___ 
_returnnearestvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluepeashooterifthistime30ifthisPlaceCDPEASHOOTER0forinti0iROWiifLeftLinesi0forintj0jCOLUMNjintk0 
_whileZombiesijk1kifk1Zombiesij0NORMALjCOLUMN2thisplayerPlacePlantPEASHOOTERi0elseifk0havetypeofzombiesZombiesijPOLEVAULThavetypeofzombiesZombiesijBUCKETSun400time500j4intstart0 
_whilePlantsistartNOPLANTstartifsearchfornearestzombieZombiesistart1playerPlacePlantPEASHOOTERistart 
_intrankdoublearrayintlendoublemaxarray0 
_intserialnumintmalloclensizeofint 
_forinti0ileniserialnumiiforinti0ilen1iforintj0jijifarrayjarrayj1doubleswaparrayj 
_arrayjarrayj1 
_arrayj1swap 
_intserialswapserialnumj 
_serialnumjserialnumj1 
_serialnumj1serialswapreturnserialnumvoidvaluesunflowerifthistime10 
_ifthisPlaceCDSUNFLOWER0doublescore500000 
_judgeLinesnotbrokenscore 
_forinti0iROWiforintj0jCOLUMNjifPlantsijSUNFLOWER 
_scorei10 
_ifPlantsijPEASHOOTER 
_scorei501expj 
_ifPlantsijWINTERPEASHOOTER 
_scorei1001expj 
_ifPlantsijSMALLNUT 
_scorei100001j5j51 
_forinti0iROWi_ 
_forintj0jCOLUMNjintk0__ 
_whileZombiesijk1ifZombiesijkNORMAL 
_scorei10101j 
_ifZombiesijkBUCKET 
_scorei50101j 
_ifZombiesijkPOLEVAULT 
_scorei30101j 
_ifZombiesijkGARGANTUAR 
_scorei100101j 
_ifZombiesijkSLED 
_scorei80101j 
_kintsunflowernumingeneratingrow0 
_forintj0jCOLUMNjifPlantsthisgeneratingrowjSUNFLOWER 
_sunflowernumingeneratingrowscorethisgeneratingrow1001sunflowernumingeneratingrow1intserialnumrankscoreROW 
_forinti0iROWiintj0 
_whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0j 
_voidvaluesmallmnutifthisPlaceCDSMALLNUT0 
_ifthistime20doublescoreROW00000 
_judgeLinesnotbrokenscorevalueplants 
_doubleplantsscore7052020710 
_forinti0iROWiforintj0jCOLUMNjdoubledistancecost1 
_switchPlantsijcaseSUNFLOWER 
_distancecost15005j 
_break_________________________ 
_casePEASHOOTER__ 
_distancecost2009j 
_break__________________________ 
_caseWINTERPEASHOOTER__ 
_distancecost201j 
_breakscoreiPlantsijplantsscoreidistancecostvaluezombies 
_doublezombiecost520101246 
_intnearestzombieperrow500000 
_forinti0iROWiforintjCOLUMN1j0jintk0 
_whileZombiesijk1doubledistancecost1 
_switchZombiesijk 
_caseNORMAL__ 
_distancecost12002j 
_break___________________________ 
_casePOLEVAULT__ 
_distancecost11001j 
_break____________________________ 
_caseBUCKET___ 
_distancecost13004j 
_breakscoreizombiecostZombiesijk1distancecost 
_k____ 
_nearestzombieperrowij 
_intserialnumrankscoreROW 
_forinti0iROWiintj0whilePlantsserialnum0jNOPLANTjplayerPlacePlantSUNFLOWERserialnum0nearestzombieperrowserialnumi1 
_voidvaluethisvaluepeashooter 
_thisvaluesunflower 
_thisvaluesmallmnut 
_doublemax100000 
_doublevalue7thisnoplantthissunflowervaluethiswinterpeashootervaluethispeashootervaluethissmallnutvaluethissquashvaluethispeppervalue 
_thisplayerPlacePlantPEASHOOTERthispeashooterpos0thispeashooterpos1voidmakedecisionthisbeginningoperation 
_thisGameState250 
_thisGameState50200 
_thisvalue 
_classvaluezombiefuncpublic 
_intnozombie 
_intnormalchoice 
_intbucketchoice 
_intpolevaultchoice 
_intsledchoice 
_intgargantuarchoice 
_doublevalueZOMBIEKIND 
_intchoiceZOMBIEKINDthisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoiceKINDROWintBrokenLinesScore 
_intKillPlantsScore 
_intLeftPlants_ 
_intScore__ 
_inttime__ 
_intPlaceCD__ 
_intPlants__ 
_intZombies__ 
_intLeftLines__ 
_intSun_ 
_intzombienums 
_GamegamevaluezombiefuncintBrokenLinesScore 
_intKillPlantsScore_ 
_intScore___ 
_inttime___ 
_intPlaceCD___ 
_intPlants___ 
_intZombies___ 
_intLeftLines___ 
_intSun__ 
_intzombienums_ 
_Gamegamethisnormalchoicethisbucketchoicethispolevaultchoicethissledchoicethisgargantuarchoice0 
_thisBrokenLinesScoreBrokenLinesScore 
_thisKillPlantsScoreKillPlantsScore 
_thisScoreScore_ 
_thistimetime_ 
_thisPlaceCDPlaceCD_ 
_thisPlantsPlants_ 
_thisZombiesZombies_ 
_thisLeftLinesLeftLines_ 
_thisSunSun_ 
_thiszombienumszombienums 
_thisgamegame 
_forinti0iZOMBIEKINDi 
_thisvaluei0 
_memsetthischoice0ZOMBIEKINDsizeofintvoidinputdataforinti0iROWifputcthischoiceifile 
_fprintffile6fthisvalueifprintffilenintjudgewhetherbigcostinonerowintcostdoubleaverage0squaredistance0 
_forinti0iROWiaveragecostiaverage5 
_forinti0iROWisquaredistancecostiaveragecostiaveragesquaredistancepowsquaredistance05 
_squaredistance5ifsquaredistancepowthistime001100return1else 
_return0voidmakedecisionintdecisionKINDROWintcostthisgamezombieCostPerRow 
_ifjudgewhetherbigcostinonerowcost0doublemaxvalue0forinti0i5iifmaxthisvalueimaxthisvaluei 
_decision0i1 
_decision1thischoiceielsedoubleminvalue0forinti0i5iifminthisvalueiminthisvaluei 
_decision0i1_ 
_decision1thischoicei 
_ifthiszombienumsthistime1004decision0decision1NOZOMBIEvoidvaluenozombieintfinalchoiceROW00000thisNotBrokenLinesNumNotBrokenLinesNum 
_thisKillZombiesScoreKillZombiesScore_ 
_thisLeftPlantsLeftPlants 
_thisScoreScore__ 
_thistimetime__ 
_thisPlaceCDPlaceCD__ 
_thisPlantsPlants__ 
_thisZombiesZombies__ 
_thisLeftLinesLeftLines__ 
_thisSunSunforinti0iROWifinalchoicei0 
_boolwhetherneedcomputeintkindifthisPlaceCDkind10thischoicekind10 
_thisvaluekind1100000 
_returntrueelse 
_returnfalsedoublezombiecostintrowdoublezombiesparasdoubledistancecostdoubledistancerateintkinddoublecost00 
_ifthisLeftLinesrow0cost100000elseintnumperrow0 
_doubletoomanyzombiescost15 
_forintj0jCOLUMNjintk0___ 
_whilethisZombiesrowjk1switchkindcasePOLEVAULT 
_costzombiesparasthisZombiesrowjk1COLUMNjdistancecostCOLUMNjdistancecost 
_break_____________________________ 
_default 
_costzombiesparasthisZombiesrowjk1distancerateCOLUMNjdistancecostCOLUMNjdistancecost2k 
_numperrow 
_costnumperrowtoomanyzombiescostreturncostintsumplantsperrow 
_rowsplantskindnumperrow_ 
_intplantsnumformatintmallocROWsizeofint_ 
_forinti0iROWiplantsnumformatiintmallocsizeofintPLANTKIND_ 
_memsetplantsnumformati0PLANTKINDsizeofintforinti0iROWiforintj0jCOLUMNjswitchthisPlantsijcaseSUNFLOWER_ 
_plantsnumformatiSUNFLOWER1 
_break______________________________ 
_caseWINTERPEASHOOTER___ 
_plantsnumformatiWINTERPEASHOOTER1 
_break_______________________________ 
_casePEASHOOTER___ 
_plantsnumformatiPEASHOOTER1 
_break________________________________ 
_caseSMALLNUT__ 
_plantsnumformatiSMALLNUT1 
_break_________________________________ 
_casePEPPER__ 
_plantsnumformatiPEPPER1 
_break__________________________________ 
_caseSQUASH__ 
_plantsnumformatiSQUASH1 
_breakreturnplantsnumformatdoubleplantcostintrowintplantsnumformatdoubleplantsparaintkinddoublecost00 
_switchkindcaseNORMAL 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10 
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER11plantsnumformatrowWINTERPEASHOOTER12 
_break___________________________________ 
_caseBUCKET____ 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowWINTERPEASHOOTER10 
_plantsparaSMALLNUT1plantsnumformatrowPEASHOOTER102plantsnumformatrowWINTERPEASHOOTER1 
_break____________________________________ 
_casePOLEVAULT___ 
_ifplantsnumformatrowSMALLNUT10plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT115plantsnumformatrowSMALLNUT13plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER1caseSLED 
_ifplantsnumformatrowSMALLNUT11plantsnumformatrowPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER10plantsparaSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowSMALLNUT1plantsnumformatrowWINTERPEASHOOTER1break 
_caseGARGANTUAR___ 
_ifplantsnumformatrowWINTERPEASHOOTER11plantsparaWINTERPEASHOOTER1plantsnumformatrowWINTERPEASHOOTER11 
_plantsparaSUNFLOWER111COLUMNplantsnumformatrowSUNFLOWER11 
_forintj0jCOLUMNjifPlantsrowjNOPLANT 
_costplantsparaPlantsrowj1plantsparaPlantsrowj10j1j1COLUMNjreturncostintmaxindexdoubleaintlengthdoublemax10000 
_intindex0 
_forinti0ilengthiifmaxaimaxai 
_indexi 
_returnindex 
_NORMAL_ 
_BUCKET_ 
_POLEVAULT_ 
_SLED_ 
_GARGANTUARSUNFLOWER 
_WINTERPEASHOOTER_ 
_PEASHOOTER_ 
_SMALLNUT_ 
_PEPPER_ 
_SQUASHvoidjudgeLinesnotbrokendoublefinalchoiceforinti0iROWiifLeftLinesi0finalchoicei10000voidvaluenormaldoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice 
_ifthiswhetherneedcomputeNORMALreturn 
_zombie 
_doublezombiesparasZOMBIEKIND54231 
_doubledistancecost1distancerate005 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateNORMAL 
_plant 
_intplantsnumformatROWPLANTKIND0 
_doubleplantsparaPLANTKIND88221005 
_intsumplantsperrow0thissumplantsperrow 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrow0plantsparaNORMAL 
_time 
_doubletimecost2011expthistimeTOTALTIME210005 
_forinti0iROWi__ 
_finalchoiceitimecostSun 
_doublesunbaseline60sunsub02 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10015powsunbaselinethisSun1sunsub 
_forinti0iROWi___ 
_finalchoiceisuncostthischoiceNORMAL1thismaxindexfinalchoiceROW 
_thisvalueNORMAL1finalchoicethischoiceNORMAL1 
_voidvaluebucketdoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice_ 
_ifthiswhetherneedcomputeBUCKETreturn 
_zombie_ 
_doublezombiesparasZOMBIEKIND254thistime100100522 
_doubledistancecost25distancerate01 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateBUCKET 
_plant_ 
_intplantsnumformatROWPLANTKIND0_ 
_doubleplantsparaPLANTKIND63231004 
_intsumplantsperrowthissumplantsperrow 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaBUCKET 
_time_ 
_doubletimecost2011expthistimeTOTALTIME310005 
_forinti0iROWi____ 
_finalchoiceitimecostSun_ 
_doublesunbaseline150sunsub05 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline5powsunbaselinethisSun1sunsub 
_forinti0iROWi_____ 
_finalchoiceisuncostthischoiceBUCKET1thismaxindexfinalchoiceROW 
_thisvalueBUCKET1finalchoicethischoiceBUCKET1 
_voidvaluepolevaultdoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice__ 
_ifthiswhetherneedcomputePOLEVAULTreturn 
_zombie__ 
_doublezombiesparasZOMBIEKIND1thistime10010051523 
_doubledistancecost25distancerate01_ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistanceratePOLEVAULT 
_plant__ 
_intplantsnumformatROWPLANTKIND0__ 
_doubleplantsparaPLANTKIND52181001 
_intsumplantsperrowthissumplantsperrow_ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaPOLEVAULT 
_time__ 
_doubletimecost2011expthistimeTOTALTIME510005 
_forinti0iROWi______ 
_finalchoiceitimecostSun__ 
_doublesunbaseline120sunsub04 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline6powsunbaselinethisSun1sunsub 
_forinti0iROWi_______ 
_finalchoiceisuncostthischoicePOLEVAULT1thismaxindexfinalchoiceROW 
_thisvaluePOLEVAULT1finalchoicethischoicePOLEVAULT1 
_voidvaluesleddoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice___ 
_ifthiswhetherneedcomputeSLEDreturn 
_zombie___ 
_doublezombiesparasZOMBIEKIND32174 
_doubledistancecost25distancerate01__ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateSLED 
_plant___ 
_intplantsnumformatROWPLANTKIND0___ 
_doubleplantsparaPLANTKIND510361001and 
_intsumplantsperrowthissumplantsperrow__ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaSLED 
_time___ 
_doubletimecost2011expthistimeTOTALTIME520005 
_forinti0iROWi________ 
_finalchoiceitimecostSun___ 
_doublesunbaseline200sunsub05 
_doublesuncostthisSunsunbaseline011expthisSunsunbaseline10020010powsunbaselinethisSun1sunsub 
_forinti0iROWi_________ 
_finalchoiceisuncostthischoiceSLED1thismaxindexfinalchoiceROW 
_thisvalueSLED1finalchoicethischoiceSLED1voidvaluegargantuardoublefinalchoiceROW00000 
_judgeLinesnotbrokenfinalchoice____ 
_ifthiswhetherneedcomputeGARGANTUARreturn 
_zombie____ 
_doublezombiesparasZOMBIEKIND2452015 
_doubledistancecost25distancerate01___ 
_forinti0iROWifinalchoiceithiszombiecostizombiesparasdistancecostdistancerateGARGANTUAR 
_plant____ 
_intplantsnumformatROWPLANTKIND0____ 
_doubleplantsparaPLANTKIND01002510010and 
_intsumplantsperrowthissumplantsperrow___ 
_forinti0iROWifinalchoiceithisplantcostisumplantsperrowplantsparaGARGANTUAR 
_time____ 
_doubletimecost 
_ifabsthistime50025absthistime100025absthistime150025 
_timecost100 
_timecost10011expthistimeTOTALTIME540004 
_forinti0iROWi__________ 
_finalchoiceitimecostSun____ 
_doublesunbaseline350sunsub06 
_doublesuncost11expthisSunsunbaseline10020010 
_forinti0iROWi___________ 
_finalchoiceisuncostthischoiceGARGANTUAR1thismaxindexfinalchoiceROW 
_thisvalueGARGANTUAR1finalchoicethischoiceGARGANTUAR1 
_externCdeclspecdllexportvoidplayeraiIPlayerplayerstaticGamegame 
_gamemaintainplayerclassICamppublic 
_virtualintgetCurrentPlants0 
_Plantsijij0virtualintgetCurrentZombies0Zombiesijij 
_kk0Zombiesijk1 
_Zombiesijk1virtualintgetSun0virtualintgetPlantCD0CDvirtualintgetLeftLines0virtualintgetRows0virtualintgetColumns0virtualintgetCurrentType0classIPlayerpublic 
_ICampCamp 
_virtualvoidPlacePlantinttypeintxinty0xyxytype16CD0virtualvoidPlaceZombieinttypeinty0ytype15CD0virtualintgetTime0 
_virtualintgetScore0 
_virtualintgetKillPlantsScore0 
_virtualintgetKillZombiesScore0 
_virtualintgetNotBrokenLines0 
_virtualintgetBrokenLinesScore0 
_virtualintgetLeftPlants0intTypeplayerCampgetCurrentType 
_ifType0intNotBrokenLinesNumplayergetNotBrokenLines 
_intKillZombiesScoreplayergetKillZombiesScore 
_intLeftPlantsplayergetLeftPlants 
_intScoreplayergetScore 
_inttime0playergetTime 
_introwsplayerCampgetRows 
_intcolumnsplayerCampgetColumns 
_intPlaceCDplayerCampgetPlantCD 
_intPlantsplayerCampgetCurrentPlants 
_intZombiesplayerCampgetCurrentZombies 
_intLeftLinesplayerCampgetLeftLines 
_intSunplayerCampgetSun 
_Zombiesnumzombiesnum 
_zombiesnumcomputenumZombiesrowscolumns 
_Plantsnumplantsnum 
_plantsnumcomputenumPlantsrowscolumns 
_playerPlacePlantSUNFLOWERchooseLinesnotBrokenLeftLinesPlantsplantsnumsunflower515plantsnumsunflower51 
_playerPlacePlantSMALLNUTchooseLinesnotBrokenLeftLinesPlantsplantsnumsmallnut5235plantsnumsmallnut52 
_ifplantsnumsunflower3 
_playerPlacePlantSUNFLOWER0plantsnumsunflower1 
_playerPlacePlantSMALLNUT0plantsnumsmallnut5 
_playerPlacePlantSQUASH04 
_playerPlacePlantSQUASHchooseLinesnotBrokenLeftLinesPlantsplantsnumsquash545plantsnumsquash54 
_iftime06 
_playerPlacePlantPEASHOOTERchooseLinesnotBrokenLeftLinesPlantsplantsnumpeashooter515plantsnumpeashooter45 
_ifSun400 
_playerPlacePlantWINTERPEASHOOTER00valueplantfuncvalueNotBrokenLinesNumKillZombiesScoreScoretime0PlaceCDPlantsZombiesLeftLinesSunplayergame 
_valuemakedecisionifType1 
_intBrokenLinesScoreplayergetBrokenLinesScore 
_intKillPlantsScoreplayergetKillPlantsScore 
_intScoreplayergetScore_ 
_inttimeplayergetTime 
_introwsplayerCampgetRows_ 
_intcolumnsplayerCampgetColumns_ 
_intPlaceCDplayerCampgetPlantCD_ 
_intPlantsplayerCampgetCurrentPlants_ 
_intZombiesplayerCampgetCurrentZombies_ 
_intLeftLinesplayerCampgetLeftLines_ 
_intSunplayerCampgetSun_ 
_iftime3intzombienumcalculatezombienumsZombies49 
_valuezombiefuncvalueBrokenLinesScoreKillPlantsScoreScoretimePlaceCDPlantsZombiesLeftLinesSunzombienumgame 
_valuevaluenormal 
_valuevaluebucket 
_valuevaluepolevault 
_valuevaluesled 
_valuevaluegargantuar 
_intdecision200 
_valuemakedecisiondecisionforinti0irowsiforintj0jcolumnsjintk0 
_whileZombiesijk1 
_kifdecision0NOZOMBIEplayerPlaceZombiedecision0ZOMBIEKINDNORMALdecision0decision1ROW1ROW1decision1 
_elseplayerPlaceZombiePOLEVAULT1 
_playerPlaceZombieNORMAL2 
_playerPlaceZombieBUCKET3 
