
/**
 * @file 1.ai.cpp
 * @author Futrime (futrime@outlook.com)
 * @brief AI Edition One
 * @details This AI calls the legacy plant agent and model-based reflex zombie agent.
 * @version 1.0.0
 * @date 2022-04-27
 *
 * @copyright Copyright (c) 2022 Futrime
 *
 */

#include <iostream>


/*** Start of inlined file: Game.cpp ***/
// #define ZOMBIE_TRACKING

#ifndef __GAME_CPP__
#define __GAME_CPP__

#include <algorithm>
#include <bitset>
#include <cmath>
#include <iostream>
#include <string>
#include <vector>

#include "ai.h"


/*** Start of inlined file: Entity.cpp ***/
#ifndef __ENTITY_CPP__
#define __ENTITY_CPP__

#include <string>


/*** Start of inlined file: Utility.cpp ***/
#ifndef __UTILITY_CPP__
#define __UTILITY_CPP__

#include <bitset>
#include <iostream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

const struct
{
	int PLANT = 0;
	int ZOMBIE = 1;
} CAMP;

const struct
{
	int NOPLANT = 0;
	int SUNFLOWER = 1;
	int WINTERPEASHOOTER = 2;
	int PEASHOOTER = 3;
	int SMALLNUT = 4;
	int PEPPER = 5;
	int SQUASH = 6;
} PLANT;

const string PLANT_STRING[7] = {"NOPLANT", "SUNFLOWER", "WINTERPEASHOOTER", "PEASHOOTER", "SMALLNUT", "PEPPER", "SQUASH"};

const struct
{
	int NOZOMBIE = 0;
	int NORMAL = 1;
	int BUCKET = 2;
	int POLEVAULT = 3;
	int SLED = 4;
	int GARGANTUAR = 5;
} ZOMBIE;

const string ZOMBIE_STRING[6] = {"NOZOMBIE", "NORMAL", "BUCKET", "POLEVAULT", "SLED", "GARGANTUAR"};

const struct
{
	int SUNFLOWER = 300;
	int WINTERPEASHOOTER = 300;
	int PEASHOOTER = 300;
	int SMALLNUT = 4000;
	int PEPPER = 300;
	int SQUASH = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw string("(PLANT_HP::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_HP;

const struct
{
	int SUNFLOWER = 50;
	int WINTERPEASHOOTER = 400;
	int PEASHOOTER = 100;
	int SMALLNUT = 50;
	int PEPPER = 125;
	int SQUASH = 50;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw string("(PLANT_COST::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_COST;

const struct
{
	int WINTERPEASHOOTER = 60;
	int PEASHOOTER = 20;
	int PEPPER = 1800;
	int SQUASH = 1800;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1: // SUNFLOWER
			return 0;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4: // SMALLNUT
			return 0;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw string("(PLANT_ATK::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_ATK;

const struct
{
	int SUNFLOWER = 10;
	int WINTERPEASHOOTER = 30;
	int PEASHOOTER = 10;
	int SMALLNUT = 40;
	int PEPPER = 60;
	int SQUASH = 60;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->SUNFLOWER;
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		case 4:
			return this->SMALLNUT;
		case 5:
			return this->PEPPER;
		case 6:
			return this->SQUASH;
		}

		/* Check legality */
		if (type < 1 || type > 6)
		{
			throw string("(PLANT_CD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_CD;

const struct
{
	int WINTERPEASHOOTER = 3;
	int PEASHOOTER = 2;
	int operator[](int type) const
	{
		switch (type)
		{
		case 2:
			return this->WINTERPEASHOOTER;
		case 3:
			return this->PEASHOOTER;
		}

		/* Check legality */
		if (type != 2 && type != 3)
		{
			throw string("(PLANT_PERIOD::[]) Wrong plant type!");
		}
		return 0;
	}
} PLANT_PERIOD;

const struct
{
	int NORMAL = 270;
	int BUCKET = 550 + 270;
	int POLEVAULT = 200;
	int SLED = 1600;
	int GARGANTUAR = 3000;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw string("(ZOMBIE_HP::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_HP;

const struct
{
	int NORMAL = 50;
	int BUCKET = 125;
	int POLEVAULT = 125;
	int SLED = 300;
	int GARGANTUAR = 300;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw string("(ZOMBIE_COST::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_COST;

const struct
{
	int NORMAL = 75;
	int BUCKET = 75;
	int POLEVAULT = 75;
	int SLED = 999999;
	int GARGANTUAR = 999999;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw string("(ZOMBIE_ATK::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_ATK;

const struct
{
	int NORMAL = 15;
	int BUCKET = 20;
	int POLEVAULT = 20;
	int SLED = 25;
	int GARGANTUAR = 25;
	int operator[](int type) const
	{
		switch (type)
		{
		case 0: // NOPLANT
			return 0;
		case 1:
			return this->NORMAL;
		case 2:
			return this->BUCKET;
		case 3:
			return this->POLEVAULT;
		case 4:
			return this->SLED;
		case 5:
			return this->GARGANTUAR;
		}

		/* Check legality */
		if (type < 1 || type > 5)
		{
			throw string("(ZOMBIE_CD::[]) Wrong zombie type!");
		}
		return 0;
	}
} ZOMBIE_CD;

const struct
{
	double DEFAULT = 0.2;
	double POLEVAULT[2] = {0.4, 0.2222222222222222};
	double SLED[5] = {0.3333333333333333, 0.28125, 0.2291666666666667, 0.1770833333333333, 0.125};
} ZOMBIE_SPEED;

template <typename T>
class Position
{
public:
	T x, y;

	/**
	 * @brief Construct a new Position object
	 *
	 */
	Position()
	{
		this->x = -1;
		this->y = -1;
	}

	/**
	 * @brief Construct a new Position object
	 *
	 * @param x
	 * @param y
	 */
	Position(T x, T y) : x(x), y(y)
	{
	}
};

class Action
{
protected:
	bitset<7> plant_switch_;
	bitset<6> zombie_switch_;
	Position<int> plant_position_[7];
	Position<int> zombie_position_[6];

public:
	/**
	 * @brief Construct a new Action object
	 *
	 */
	Action()
	{
	}

	/**
	 * @brief Check if a slot is set in this action
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return true The slot is set
	 * @return false The slot is not set
	 */
	bool isSet(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw string("(Action::isSet) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw string("(Action::isSet) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw string("(Action::isSet) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_switch_[slot];
		}
		else if (camp == CAMP.ZOMBIE)
		{
			return this->zombie_switch_[slot];
		}

		return false; // to avoid compilation warning
	}

	/**
	 * @brief Get the target position of a slot
	 *
	 * @param camp The camp, either CAMP.PLANT or CAMP.ZOMBIE
	 * @param slot The slot, within [0, 6] for plant camp or [0, 5] for zombie camp
	 * @return Position<int> The target position
	 */
	Position<int> getPosition(int camp, int slot)
	{
		/* Check legality */
		if (camp < 0 || camp > 1)
		{
			throw string("(Action::getPosition) Invalid camp!");
		}
		if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
		{
			throw string("(Action::getPosition) Invalid slot!");
		}
		if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
		{
			throw string("(Action::getPosition) Invalid slot!");
		}

		if (camp == CAMP.PLANT)
		{
			return this->plant_position_[slot];
		}
		else if (camp == CAMP.ZOMBIE)
		{
			return this->zombie_position_[slot];
		}

		return Position<int>(); // to avoid compilation warning
	}

	/**
	 * @brief Place a plant
	 *
	 * @param type The type of the plant, should be PLANT.X
	 * @param x The x position to place, within [0, 4]
	 * @param y The y position to place, within [0, 9]
	 */
	void placePlant(int type, int x, int y)
	{
		/* Check legality */
		if (type < 0 || type > 6)
		{
			throw string("(Action::placePlant) Wrong plant type!");
		}
		if (x < 0 || x > 4 || y < 0 || y > 9)
		{
			throw string("(Action::placePlant) Wrong position!");
		}
		if (this->plant_switch_[type])
		{
			throw string("(Action::placePlant) Duplicated plant placement!");
		}

		this->plant_switch_[type] = true;
		this->plant_position_[type].x = x;
		this->plant_position_[type].y = y;
	}

	/**
	 * @brief Place a zombie
	 *
	 * @param type The type of the zombie, should be ZOMBIE.x
	 * @param x The x position to place, within [0, 4]
	 */
	void placeZombie(int type, int x)
	{
		/* Check legality */
		if (type < 0 || type > 5)
		{
			throw string("(Action::placeZombie) Wrong plant type!");
		}
		if (x < 0 || x > 4)
		{
			throw string("(Action::placeZombie) Wrong position!");
		}
		if (this->zombie_switch_[type])
		{
			throw string("(Action::placeZombie) Duplicated zombie placement!");
		}

		this->zombie_switch_.set(type, true);
		this->zombie_position_[type].x = x;
	}
};

#endif
/*** End of inlined file: Utility.cpp ***/

using namespace std;

/****************
 * Declarations
 ****************/

class Entity
{
protected:
	int spawn_time_;
	int type_;
	int hp_;
	Position<int> position_;

public:
	/**
	 * @brief Construct a new Entity object
	 *
	 * @param spawn_time The spawning time of the entity
	 * @param type The type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 * @param position The position of the entity
	 */
	Entity(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Get the spawning time of the entity
	 *
	 * @return int The spawning time
	 */
	int getSpawnTime();

	/**
	 * @brief Get the type of the entity, within [0, 6] for plants or [0, 5] for zombies
	 *
	 * @return int The type of the entity, fitting PLANT.X or ZOMBIE.X
	 */
	int getType();

	/**
	 * @brief Get the health of the entity
	 *
	 * @return int The health of the entity, >= 0
	 */
	int getHealth();

	/**
	 * @brief Reduce the health of the entity
	 *
	 * @param value The number of health to reduce
	 * @return int The health left
	 */
	int reduceHealth(int value);

	/**
	 * @brief Get the position of the entity
	 *
	 * @return Position<int> The position of the entity
	 */
	Position<int> getPosition();
};

class Plant : public Entity
{
protected:
	/* data */
public:
	/**
	 * @brief Construct a new Plant object
	 *
	 */
	Plant();

	/**
	 * @brief Construct a new Plant object
	 *
	 * @param spawn_time The spawing time of the plant
	 * @param type The type of the plant
	 * @param position The position of the plant
	 */
	Plant(int spawn_time, int type, Position<int> position);
};

class Zombie : public Entity
{
protected:
	Position<double> position_real_;
	int state_ = 0; // Polevault and Sled's state
	bool frozen_state_ = false;

public:
	/**
	 * @brief Construct a new Zombie object
	 *
	 */
	Zombie();

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<int> position);

	/**
	 * @brief Construct a new Zombie object
	 *
	 * @param spawn_time The spawning time of the zombie
	 * @param type The type of the zombie
	 * @param position The position of the zombie
	 */
	Zombie(int spawn_time, int type, Position<double> position);

	/**
	 * @brief Get the position of the zombie
	 *
	 * @return Position<int> The position of the zombie
	 */
	Position<int> getPosition();

	/**
	 * @brief Get the real position of the zombie
	 *
	 * @return Position<double> The real position of the zombie
	 */
	Position<double> getRealPosition();

	/**
	 * @brief Set the real position of the zombie
	 *
	 * @param position The real position of the zombie
	 */
	void setRealPosition(Position<double> position);

	/**
	 * @brief Get the state of the zombie
	 *
	 * @return int The state number
	 */
	int getState();

	/**
	 * @brief Set the state of the zombie
	 *
	 * @param state The state number
	 */
	void setState(int state);

	/**
	 * @brief Get if the zombie is frozen
	 *
	 * @return true The zombie is frozen
	 * @return false The zombie is not frozen
	 */
	bool getFrozenState();

	/**
	 * @brief Set if the zombie is frozen
	 *
	 * @param state true The zombie is frozen
	 * @param state false The zombie is not frozen
	 */
	void setFrozenState(bool state);
};

/****************
 * Definitions
 ****************/

Entity::Entity(int spawn_time, int type, Position<int> position)
	: spawn_time_(spawn_time), type_(type), position_(position)
{
}

int Entity::getSpawnTime()
{
	return this->spawn_time_;
}

int Entity::getType()
{
	return this->type_;
}

int Entity::getHealth()
{
	return this->hp_;
}

int Entity::reduceHealth(int value)
{
	this->hp_ -= value;
	return this->hp_;
}

Position<int> Entity::getPosition()
{
	return this->position_;
}

Plant::Plant() : Plant(0, PLANT.NOPLANT, Position<int>())
{
}

Plant::Plant(int spawn_time, int type, Position<int> position) : Entity(spawn_time, type, position)
{
}

Zombie::Zombie() : Zombie(0, ZOMBIE.NOZOMBIE, Position<double>())
{
}

Zombie::Zombie(int spawn_time, int type, Position<int> position)
	: Entity(spawn_time, type, position), position_real_(position.x, position.y)
{
}

Zombie::Zombie(int spawn_time, int type, Position<double> position)
	: Entity(spawn_time, type, Position<int>(static_cast<int>(position.x), static_cast<int>(position.y))), position_real_(position.x, position.y)
{
}

Position<int> Zombie::getPosition()
{
	return this->position_;
}

Position<double> Zombie::getRealPosition()
{
	return this->position_real_;
}

void Zombie::setRealPosition(Position<double> position)
{
	this->position_.x = static_cast<int>(floor(position.x + 0.0001));
	this->position_.y = static_cast<int>(floor(position.y + 0.0001));
	this->position_real_.x = position.x;
	this->position_real_.y = position.y;
}

int Zombie::getState()
{
	return this->state_;
}

void Zombie::setState(int state)
{
	this->state_ = state;
}

bool Zombie::getFrozenState()
{
	return this->frozen_state_;
}

void Zombie::setFrozenState(bool state)
{
	this->frozen_state_ = state;
}

#endif
/*** End of inlined file: Entity.cpp ***/


using namespace std;

/****************
 * Declarations
 ****************/

class GameState
{
protected:
	/* Global Information */
	IPlayer *player_;
	int time_ = 0;
	bitset<5> broken_lines_;

	/* Camp Information */
	int camp_;
	int other_camp_;
	vector<Plant> plant_;
	vector<Zombie> zombie_;
	int sun_plant_ = 400;
	int sun_zombie_ = 300;
	int cd_plant_[7] = {0};
	int cd_zombie_[6] = {0};
	int score_plant_ = 5000;
	int score_zombie_ = 0;

public:
	/**
	 * @brief Construct a new Game State object
	 *
	 * @param camp The current camp
	 */
	GameState(int camp);

	/**
	 * @brief Get the IPlayer handler
	 *
	 * @return IPlayer* The handler
	 */
	IPlayer *getPlayer();

	/**
	 * @brief Get the time
	 *
	 * @return int The time
	 */
	int getTime();

	/**
	 * @brief Get the broken lines
	 *
	 * @return bitset<5> True if broken
	 */
	bitset<5> getBrokenLines();

	/**
	 * @brief Get the current camp
	 *
	 * @return int The current camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getCamp();

	/**
	 * @brief Get the other camp
	 *
	 * @return int The other camp, either CAMP.PLANT or CAMP.ZOMBIE
	 */
	int getOtherCamp();

	/**
	 * @brief Get the plant at the position
	 *
	 * @param x The x position
	 * @param y The y position
	 * @return Plant The plant
	 */
	Plant getPlant(int x, int y);

	/**
	 * @brief Get plants fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The plant type, -1 for all (optional)
	 * @return vector<Plant>
	 */
	vector<Plant> getPlantList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Get zombies fitting the query
	 *
	 * @param x The x position, -1 for all (optional)
	 * @param y The y position, -1 for all (optional)
	 * @param type The zombie type, -1 for all (optional)
	 * @return vector<Zombie>
	 */
	vector<Zombie> getZombieList(int x = -1, int y = -1, int type = -1);

	/**
	 * @brief Get the sun count
	 *
	 * @param camp The camp
	 * @return int The sun count of the camp
	 */
	int getSun(int camp);

	/**
	 * @brief Get the left cooldown time of a slot
	 *
	 * @param camp The camp
	 * @param slot The slot
	 * @return int The left cooldown time
	 */
	int getCD(int camp, int slot);

	/**
	 * @brief Get the score
	 *
	 * @param camp The camp
	 * @return int The score of the camp
	 */
	int getScore(int camp);

	/**
	 * @brief Add to the score
	 *
	 * @param camp The camp
	 * @param score The score to add
	 */
	void increaseScore(int camp, int score);

	/**
	 * @brief Get the battlefront of a line
	 *
	 * @param x The line
	 * @return int The y position of the battlefront, 10 if no zombie on this row
	 */
	int getBattlefront(int x);

	/**
	 * @brief Update the state
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Infer the next state
	 *
	 */
	void infer();

	/**
	 * @brief Generate a predicted state after applying an action
	 *
	 * @param action The action to apply
	 * @return GameState* The predicted state
	 */
	GameState *generateSuccessor(Action action);

	/**
	 * @brief Print current time for debugging
	 *
	 */
	void printTime();
};

class Game
{
protected:
	IPlayer *player_;
	GameState *game_state_;

public:
	/**
	 * @brief Construct a new Game object
	 *
	 * @param player The IPlayer object
	 */
	Game(IPlayer *player);

	/**
	 * @brief Destroy the Game object
	 *
	 */
	~Game();

	/**
	 * @brief Get the current state
	 *
	 * @return GameState* The current state
	 */
	GameState *getGameState();

	/**
	 * @brief Update the game environment
	 *
	 * @param player The IPlayer object
	 */
	void update(IPlayer *player);

	/**
	 * @brief Apply an action
	 *
	 * @param action The action to apply
	 */
	void applyAction(Action action);
};

/****************
 * Definitions
 ****************/

GameState::GameState(int camp) : camp_(camp), other_camp_(1 - camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(GameState::GameState) Invalid camp!");
	}
}

IPlayer *GameState::getPlayer()
{
	return this->player_;
}

int GameState::getTime()
{
	return this->time_;
}

bitset<5> GameState::getBrokenLines()
{
	return this->broken_lines_;
}

int GameState::getCamp()
{
	return this->camp_;
}

int GameState::getOtherCamp()
{
	return this->other_camp_;
}

Plant GameState::getPlant(int x, int y)
{
	/* Check legality */
	if (x < 0 || x > 4 || y < 0 || y > 9)
	{
		throw string("(GameState::getPlant) Out of map!");
	}

	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x == iter->getPosition().x &&
			y == iter->getPosition().y)
		{
			return *iter;
		}
	}

	return Plant(); // if there exists no plant
}

vector<Plant> GameState::getPlantList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 9)
	{
		throw string("(GameState::getPlantList) Out of map!");
	}
	if (type < -1 || type > 6)
	{
		throw string("(GameState::getPlantList) Invalid type!");
	}

	vector<Plant> result;
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

vector<Zombie> GameState::getZombieList(int x, int y, int type)
{
	/* Check legality */
	if (x < -1 || x > 4 || y < -1 || y > 9)
	{
		throw string("(GameState::getZombieList) Out of map!");
	}
	if (type < -1 || type > 5)
	{
		throw string("(GameState::getZombieList) Invalid type!");
	}

	vector<Zombie> result;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (x != -1 && iter->getPosition().x != x)
		{
			continue;
		}
		if (y != -1 && iter->getPosition().y != y)
		{
			continue;
		}
		if (type != -1 && iter->getType() != type)
		{
			continue;
		}
		result.push_back(*iter);
	}
	return result;
}

int GameState::getSun(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(GameState::getCD) Invalid camp!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->sun_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->sun_zombie_;
	}

	return 0; // to avoid compilation warning
}

int GameState::getCD(int camp, int slot)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		throw string("(GameState::getCD) Invalid camp!");
	}
	if (camp == CAMP.PLANT && (slot < 0 || slot > 6))
	{
		throw string("(GameState::getCD) Invalid slot!");
	}
	if (camp == CAMP.ZOMBIE && (slot < 0 || slot > 5))
	{
		throw string("(GameState::getCD) Invalid slot!");
	}

	if (camp == CAMP.PLANT)
	{
		return this->cd_plant_[slot];
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->cd_zombie_[slot];
	}

	return 0; // to avoid compilation warning
}

int GameState::getScore(int camp)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		if (camp < 0 || camp > 1)
		{
			throw string("(GameState::getScore) Invalid camp!");
		}
	}

	if (camp == CAMP.PLANT)
	{
		return this->score_plant_;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		return this->score_zombie_;
	}

	return 0; // to avoid compilation warning
}

void GameState::increaseScore(int camp, int score)
{
	/* Check legality */
	if (camp < 0 || camp > 1)
	{
		if (camp < 0 || camp > 1)
		{
			throw string("(GameState::increaseScore) Invalid camp!");
		}
	}
	if (camp == CAMP.PLANT)
	{
		this->score_plant_ += score;
	}
	else if (camp == CAMP.ZOMBIE)
	{
		this->score_zombie_ += score;
	}
}

int GameState::getBattlefront(int x)
{
	/* Check legality */
	if (x < 0 || x > 4)
	{
		throw string("(GameState::getBattlefront) Out of map!");
	}

	int battle_front = 10;
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		if (iter->getPosition().x == x)
		{
			battle_front = min(battle_front, iter->getPosition().y);
		}
	}
	return battle_front;
}

void GameState::update(IPlayer *player)
{
	/* Update player */
	this->player_ = player;

	/* Update time */
	this->time_ = player->getTime();

	/* Update broken lines */
	for (int i = 0; i < 5; ++i)
	{
		if (player->Camp->getLeftLines()[i])
		{
			this->broken_lines_.reset(i);
		}
		else
		{
			this->broken_lines_.set(i);
		}
	}

#ifdef ZOMBIE_TRACKING
	/* Update frozen state */
	for (vector<Plant>::iterator iter = this->plant_.begin();
		 iter != this->plant_.end();
		 ++iter)
	{
		if (iter->getType() == PLANT.WINTERPEASHOOTER && (this->getTime() - iter->getSpawnTime()) % 3 == 1)
		{
			int y = this->getBattlefront(iter->getPosition().x);
			for (vector<Zombie>::iterator iter2 = this->zombie_.begin();
				 iter2 != this->zombie_.end();
				 ++iter2)
			{
				if (iter2->getPosition().y == y)
				{
					iter2->setFrozenState(true);
				}
			}
		}
	}

#endif

	vector<Plant> prev_plants = this->plant_;
	vector<Zombie> prev_zombies = this->zombie_;

	vector<int> raw_new_plants;
	vector<int> raw_new_zombies;
	vector<int> raw_killed_plants;
	vector<int> raw_killed_zombies;
	vector<int> raw_new_broken_lines;

	int **raw_plant_map = player->Camp->getCurrentPlants();
	int ***raw_zombie_map = player->Camp->getCurrentZombies();

	/* Update plant list */
	// Plants should be updated later than zombies' positions
	// due to polevaults' dependency
	for (int x = 0; x <= 4; ++x)
	{
		for (int y = 0; y < 10; ++y)
		{
			Plant plant;
			vector<Plant>::iterator iter = this->plant_.begin();
			for (; iter != this->plant_.end(); ++iter)
			{
				if (iter->getPosition().x == x &&
					iter->getPosition().y == y)
				{
					plant = *iter;
					break;
				}
			}

			if (this->broken_lines_[x] &&
				plant.getType() != PLANT.NOPLANT)
			{ // if the line is broken, remove all plants
				this->plant_.erase(iter);
				continue;
			}
			else if (raw_plant_map[x][y] == PLANT.NOPLANT &&
					 plant.getType() != PLANT.NOPLANT)
			{ // if there removes a plant or killed a plant
				this->plant_.erase(iter);
				if (raw_zombie_map[x][y][0] != -1)
				{
					raw_killed_plants.push_back(plant.getType());
				}
			}
			else if (raw_plant_map[x][y] != PLANT.NOPLANT &&
					 plant.getType() == PLANT.NOPLANT)
			{ // if there places a new plant
				this->plant_.push_back(
					Plant(this->getTime(),
						  raw_plant_map[x][y],
						  Position<int>(x, y)));
				raw_new_plants.push_back(raw_plant_map[x][y]);
			}
			else if (raw_plant_map[x][y] != PLANT.NOPLANT &&
					 plant.getType() != raw_plant_map[x][y])
			{ // if there replaces a plant
				this->plant_.erase(iter);
				this->plant_.push_back(
					Plant(this->getTime(),
						  raw_plant_map[x][y],
						  Position<int>(x, y)));
				raw_new_plants.push_back(raw_plant_map[x][y]);
			}
		}
	}

#ifdef ZOMBIE_TRACKING

	/* Update zombies' real position */
	for (vector<Zombie>::iterator iter = this->zombie_.begin();
		 iter != this->zombie_.end();
		 ++iter)
	{
		Position<double> pos = iter->getRealPosition();
		double prev_pos_y = pos.y;
		Position<int> pos_int = iter->getPosition();

		if (iter->getType() == ZOMBIE.POLEVAULT)
		{
			if (iter->getState() == 1)
			{ // if the polevault zombie has skipped a plant
				if (raw_plant_map[pos_int.x][pos_int.y] == PLANT.NOPLANT)
				{ // if there's no plant
					pos.y -= ZOMBIE_SPEED.POLEVAULT[1];
				}
			}
			else if (iter->getState() == 0)
			{ // if the polevault zombie has not skipped a plant
				if (this->getPlant(pos_int.x, pos_int.y).getType() == PLANT.NOPLANT)
				{ // if there is no plant to skip
					pos.y -= ZOMBIE_SPEED.POLEVAULT[0];
				}
				else
				{ // if there is a plant to skip
					pos.y -= 1;
					iter->setState(1);
				}
			}
		}
		else if (iter->getType() == ZOMBIE.SLED)
		{
			switch (iter->getPosition().y)
			{
			case 10:
				pos.y -= ZOMBIE_SPEED.SLED[0];
				break;

			case 9:
				pos.y -= ZOMBIE_SPEED.SLED[1];
				break;

			case 8:
				pos.y -= ZOMBIE_SPEED.SLED[2];
				break;

			case 7:
				pos.y -= ZOMBIE_SPEED.SLED[3];
				break;

			default:
				pos.y -= ZOMBIE_SPEED.SLED[4];
				break;
			}
		}
		else if (iter->getType() == ZOMBIE.GARGANTUAR)
		{
			pos.y -= ZOMBIE_SPEED.DEFAULT;
		}
		else
		{ // if the zombie is BUCKET or NORMAL
			if (raw_plant_map[pos_int.x][pos_int.y] == PLANT.NOPLANT)
			{ // if there's no plant
				pos.y -= ZOMBIE_SPEED.POLEVAULT[1];
			}
		}

		if (iter->getType() != ZOMBIE.POLEVAULT && iter->getFrozenState())
		{
			pos.y += (prev_pos_y - pos.y) * 0.5;
		}

		iter->setRealPosition(pos);
	}

	/* Update zombie list */
	for (int x = 0; x <= 4; ++x)
	{
		int z = 0;
		for (int y = 0; y <= 9; ++y)
		{
			z = 0;
			for (vector<Zombie>::iterator iter = this->zombie_.begin();
				 iter != this->zombie_.end();)
			{
				if (this->broken_lines_[x])
				{
					iter = this->zombie_.erase(iter);
					raw_new_broken_lines.push_back(x);
					continue;
				}
				if (iter->getPosition().x != x || iter->getPosition().y != y)
				{
					++iter;
					continue;
				}
				if (raw_zombie_map[x][y][z] == -1)
				{
					raw_killed_zombies.push_back(iter->getType());
					iter = this->zombie_.erase(iter);
					continue;
				}
				if (raw_zombie_map[x][y][z] != iter->getType())
				{
					raw_killed_zombies.push_back(iter->getType());
					iter = this->zombie_.erase(iter);
					continue;
				}
				++z;
				++iter;
			}
		}
		// For column 9 adding zombies
		while (raw_zombie_map[x][9][z] != -1)
		{
			this->zombie_.push_back(Zombie(this->getTime(), raw_zombie_map[x][9][z], Position<double>(x, 10)));
			raw_new_zombies.push_back(raw_zombie_map[x][9][z]);
			++z;
		}
	}

#endif

#ifndef ZOMBIE_TRACKING
	this->zombie_.clear();
	for (int x = 0; x <= 4; ++x)
	{
		for (int y = 0; y <= 9; ++y)
		{
			for (int z = 0; raw_zombie_map[x][y][z] != -1; ++z)
			{
				this->zombie_.push_back(Zombie(0, raw_zombie_map[x][y][z], Position<double>(x + 0.5, y + 0.5)));
			}
		}
	}
#endif

	/* Update sun, CD and score */
	if (this->camp_ == CAMP.PLANT)
	{
		this->sun_plant_ = player->Camp->getSun();

		for (int i = 0; i < 6; ++i)
		{
			this->cd_plant_[i + 1] = player->Camp->getPlantCD()[i];
		}

		this->score_plant_ = player->getScore() + 5000 + static_cast<int>(100 * this->plant_.size());

		/* Predict zombie's information */
		this->sun_zombie_ += this->time_ / 200 + 1;
		for (vector<int>::iterator iter = raw_new_zombies.begin();
			 iter != raw_new_zombies.end();
			 ++iter)
		{
			this->sun_zombie_ -= ZOMBIE_COST[*iter];
			this->cd_zombie_[*iter] = ZOMBIE_CD[*iter];
		}
		for (vector<int>::iterator iter = raw_killed_plants.begin();
			 iter != raw_killed_plants.end();
			 ++iter)
		{
			this->sun_zombie_ += static_cast<int>(PLANT_COST[*iter] / 5) + static_cast<int>(sqrt(PLANT_HP[*iter]));
			this->score_zombie_ += PLANT_COST[*iter];
		}

		// Remove duplicated elements
		sort(raw_new_broken_lines.begin(), raw_new_broken_lines.end());
		raw_new_broken_lines.erase(unique(raw_new_broken_lines.begin(), raw_new_broken_lines.end()), raw_new_broken_lines.end());

		this->score_zombie_ += static_cast<int>(raw_new_broken_lines.size()) * (3000 - this->time_);
	}
	else if (this->camp_ == CAMP.ZOMBIE)
	{
		this->sun_zombie_ = player->Camp->getSun();
		for (int i = 0; i < 5; ++i)
		{
			this->cd_zombie_[i + 1] = player->Camp->getPlantCD()[i];
		}
		this->score_zombie_ = player->getScore();

		/* Predict plant's information */
		for (vector<Plant>::iterator iter = this->plant_.begin();
			 iter != this->plant_.end();
			 ++iter)
		{
			if (iter->getType() == PLANT.SUNFLOWER && (this->time_ - iter->getSpawnTime()) % 24 == 1)
			{
				this->score_plant_ += 25;
			}
		}
		for (vector<int>::iterator iter = raw_new_plants.begin();
			 iter != raw_new_plants.end();
			 ++iter)
		{
			this->sun_plant_ -= PLANT_COST[*iter];
			this->cd_plant_[*iter] = PLANT_CD[*iter];
		}
		for (vector<int>::iterator iter = raw_killed_zombies.begin();
			 iter != raw_killed_zombies.end();
			 ++iter)
		{
			this->score_plant_ += ZOMBIE_COST[*iter];
		}

		// Remove duplicated elements
		sort(raw_new_broken_lines.begin(), raw_new_broken_lines.end());
		raw_new_broken_lines.erase(unique(raw_new_broken_lines.begin(), raw_new_broken_lines.end()), raw_new_broken_lines.end());

		this->score_plant_ -= static_cast<int>(raw_new_broken_lines.size()) * 1000;
	}
}

void GameState::infer()
{
}

GameState *GameState::GameState::generateSuccessor(Action action)
{
	GameState *next_game_state = new GameState(*this);
	return next_game_state;
}

Game::Game(IPlayer *player)
{
	this->player_ = player;
	this->game_state_ = new GameState(player->Camp->getCurrentType());
}

Game::~Game()
{
	delete this->game_state_;
}

GameState *Game::getGameState()
{
	return this->game_state_;
}

void Game::update(IPlayer *player)
{
	this->player_ = player;
	this->game_state_->update(player);
}

void Game::applyAction(Action action)
{
	int camp = this->game_state_->getCamp();
	if (camp == CAMP.PLANT)
	{
		/* Check legality */
		for (int slot = 1; slot <= 5; ++slot)
		{
			if (action.isSet(CAMP.ZOMBIE, slot))
			{
				throw string("(Game::applyAction) No access!");
			}
		}
		int sun_consumption = 0;
		for (int slot = 1; slot <= 6; ++slot)
		{
			if (action.isSet(CAMP.PLANT, slot))
			{
				sun_consumption += PLANT_COST[slot];
				if (this->game_state_->getBrokenLines()[action.getPosition(CAMP.PLANT, slot).x])
				{
					throw string("(Game::applyAction) Broken line!");
				}
				if (this->game_state_->getCD(CAMP.PLANT, slot) > 0)
				{
					throw string("(Game::applyAction) Unfinished cooldown!");
				}
			}
		}
		if (sun_consumption > this->game_state_->getSun(CAMP.PLANT))
		{
			throw string("(Game::applyAction) Insufficient sun!");
		}

		for (int slot = 1; slot <= 6; ++slot)
		{
			if (action.isSet(CAMP.PLANT, slot))
			{
				Position<int> position = action.getPosition(CAMP.PLANT, slot);

				/* Update zombie camp's scores if using SQUASH or PEPPER */
				if (slot == PLANT.SQUASH)
				{
					this->game_state_->increaseScore(CAMP.ZOMBIE, 50);
				}
				if (slot == PLANT.PEPPER)
				{
					this->game_state_->increaseScore(CAMP.ZOMBIE, 125);
				}

				this->player_->removePlant(position.x, position.y);
				this->player_->PlacePlant(slot, position.x, position.y);
			}
		}
	}
	else if (camp == CAMP.ZOMBIE)
	{
		/* Check legality */
		for (int slot = 1; slot <= 6; ++slot)
		{
			if (action.isSet(CAMP.PLANT, slot))
			{
				throw string("(Game::applyAction) No access!");
			}
		}

		int sun_consumption = 0;
		for (int slot = 1; slot <= 5; ++slot)
		{
			if (action.isSet(CAMP.ZOMBIE, slot))
			{
				sun_consumption += ZOMBIE_COST[slot];
				if (this->game_state_->getBrokenLines()[action.getPosition(CAMP.ZOMBIE, slot).x])
				{
					throw string("(Game::applyAction) Broken line!");
				}
				if (this->game_state_->getCD(CAMP.ZOMBIE, slot) > 0)
				{
					throw string("(Game::applyAction) Unfinished cooldown!");
				}
			}
		}
		if (sun_consumption > this->game_state_->getSun(CAMP.ZOMBIE))
		{
			throw string("(Game::applyAction) Insufficient sun!");
		}

		for (int slot = 1; slot <= 5; ++slot)
		{
			if (action.isSet(CAMP.ZOMBIE, slot))
			{
				this->player_->PlaceZombie(slot, action.getPosition(CAMP.ZOMBIE, slot).x);
			}
		}
	}
}

void GameState::printTime()
{
	cout << endl
		 << "**************** time="
		 << this->getTime()
		 << " ****************"
		 << endl;
}

#endif
/*** End of inlined file: Game.cpp ***/


/*** Start of inlined file: PlantLegacyAgent.cpp ***/

/*** Start of inlined file: LegacyAI.cpp ***/
#ifndef __LEGACY_AI_CPP__
#define __LEGACY_AI_CPP__

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>

#include "ai.h"


using namespace std;

namespace legacy_ai
{
	constexpr int ZOMBIE_KIND = 5;
	constexpr int PLANT_KIND = 6;
	constexpr int TOTAL_TIME = 2000;
	constexpr int COLUMN = 10;
	constexpr int ROW = 5;

	// FILE *file;
	// errno_t err = fopen_s(&file, "D:\\2022 spring_semester\\pvz\\fc19_userpackage-master\\FC19_UI\\data.txt", "w+");
	enum PlantType
	{
		NOPLANT = 0,
		SUNFLOWER,
		WINTERPEASHOOTER,
		PEASHOOTER,
		SMALLNUT,
		PEPPER,
		SQUASH
	};

	//僵 尸 种 类 4
	enum ZombieType
	{
		NOZOMBIE = 0,
		NORMAL,
		BUCKET,
		POLEVAULT,
		SLED,
		GARGANTUAR
	};

	// zrf 's code starts
	const int plantCost[7] = {0, 50, 400, 100, 50, 125, 50};
	const int plantCd[7] = {0, 10, 30, 10, 40, 60, 60};
	const int zombieCost[6] = {0, 50, 125, 125, 300, 300};
	const int zombieCd[6] = {0, 15, 20, 20, 25, 25};
	const int plantHp[7] = {0, 300, 300, 300, 4000, 0, 0};
	const int plantDps[7] = {0, 0, 20, 10, 0, 0, 0};
	int zombieHp[6] = {0, 270, 820, 200, 1600, 3000};
	struct Sunflower
	{
		int row, column, cd;
		Sunflower(int Row, int Column)
		{
			cd = 24;
			row = Row, column = Column;
		}
	}; //跟踪向日葵
	int *zombieNum(int ***zombies)
	{
		int cnt[7] = {}, *p = cnt;
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
				for (int k = 0; k < 10; k++)
				{
					if (zombies[i][j][k] = -1)
						break;
					else
						cnt[zombies[i][j][k]]++;
				}
		return p;
	} //将zombies分类计数
	int *zombieNum(int zombies[5][10][10])
	{
		int cnt[7] = {}, *p = cnt;
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
				for (int k = 0; k < 10; k++)
				{
					if (zombies[i][j][k] = -1)
						break;
					else
						cnt[zombies[i][j][k]]++;
				}
		return p;
	} //重载
	struct Zombie
	{
		int num;
		int hp;
		int coX, coY;
		Zombie(int Num, int row)
		{
			coX = row, coY = 9;
			hp = zombieHp[Num];
			num = Num;
		}
		// int speed;   ?
	};
	struct Plant
	{
		int num;
		int hp;
		int coX, coY;
		int dps;
		Plant(int Num, int row, int col)
		{
			num = Num;
			coX = row, coY = col;
			hp = plantHp[Num];
			dps = plantDps[Num];
		}
	};
	struct Actionlist
	{
		int plantPlace[5][10] = {}, zombiePlace[5] = {};
		int plantRemove[5][10] = {};
	};
	class Game
	{
	public:
		int time, sun, moon;
		int plants[5][10], zombies[5][10][10];
		int cdPlant[7], cdZombie[6];     //记录双方在当前tick下冷却
		int dps[5];                      //记录每行dps
		int flagPlant[7], flagZombie[6]; //记录冷却是否(1/0)完成
		int flagShovel[5][10];           //记录某个位置是否(1/0)进行铲除操作
		int zombieCostPerRow[5];
		vector<Sunflower> sunFlowers;
		vector<Plant> vectorPlants;
		vector<Zombie> vectorZombies;

		void plantremove(int i, int j, IPlayer *player)
		{
			player->removePlant(i, j);
			flagShovel[i][j] = 1;
		}
		void maintain(IPlayer *player)
		{
			time++;
			int **Plants = player->Camp->getCurrentPlants();    // currentPlants
			int ***Zombies = player->Camp->getCurrentZombies(); // currentZombies
			moon += int(time / 200.0) + 1;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
				{
					if (plants[i][j] > Plants[i][j] && plants[i][j] != PEPPER && plants[i][j] != SQUASH)
					{
						if (flagShovel[i][j] == 1)
						{
							flagShovel[i][j] = 0;
						}
						else
						{
							int num = plants[i][j];
							moon += plantCost[num] / 5 + int(sqrt(plantHp[num]));
							dps[i] -= plantDps[num];
							if (num == 1)
							{
								for (int k = 0; k < sunFlowers.size(); k++)
									if (sunFlowers[k].row == i && sunFlowers[k].column == j)
									{
										sunFlowers.erase(sunFlowers.begin() + k);
										break;
									}
							}
						}
					} //植物阵亡
					else if (plants[i][j] < Plants[i][j])
					{
						int num = Plants[i][j];
						sun -= plantCost[num];
						dps[i] += plantDps[num];
						cdPlant[num] = plantCd[num];
						flagPlant[num] = 0;
						if (num == 1)
						{
							sun += 25;
							sunFlowers.push_back(Sunflower(i, j));
						}
						vectorPlants.push_back(Plant(Plants[i][j], i, j));
					} //植物种植
					plants[i][j] = Plants[i][j];
					int flag = 0;
					for (int k = 0; k < vectorPlants.size(); k++)
					{
						if (vectorPlants[k].coX == i && vectorPlants[k].coY == j)
						{
							if (vectorPlants[k].num != Plants[i][j])
							{
								vectorPlants.erase(vectorPlants.begin() + k);
								k--;
								if (Plants[i][j] != 0)
									vectorPlants.push_back(Plant(Plants[i][j], i, j));
							}
							flag = 1;
							break;
						}
					}
					if (flag == 0 && Plants[i][j] != 0)
						vectorPlants.push_back(Plant(Plants[i][j], i, j));
				}
			int *z = zombieNum(zombies), *Z = zombieNum(Zombies);
			for (int i = 0; i < 5; i++)
			{
				int rowZombie[6] = {}, RowZombie[6] = {}; //前者为保存的状态，后者为当前状态
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
					{
						if (zombies[i][j][k] = -1)
							break;
						else
							rowZombie[zombies[i][j][k]]++;
					}
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
					{
						if (Zombies[i][j][k] = -1)
							break;
						else
							RowZombie[Zombies[i][j][k]]++;
						;
					}
				for (int j = 0; j < 6; j++)
					if (RowZombie[j] > rowZombie[j])
						zombieCostPerRow[i] += zombieCost[j];
			}
			for (int i = 0; i < 7; i++)
			{
				if (z[i] < Z[i])
				{

				} // zombie die
				else if (z[i] > Z[i])
				{
					moon -= zombieCost[i];
					cdZombie[i] = zombieCd[i];
					flagZombie[i] = 0;
				} // zombie placed
			}

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 10; j++)
				{
					int k = 0;
					while (Zombies[i][j][k] != -1)
					{
						zombies[i][j][k] = Zombies[i][j][k];
						k++;
					}
				}
			}

			vector<int> have_erased;
			for (int i = 0; i < vectorZombies.size(); i++)
			{
				int have_erased_flag = 0;
				for (int z = 0; z < have_erased.size(); z += 2)
				{
					if (vectorZombies[i].coX == have_erased[z] && vectorZombies[i].coY == have_erased[z + 1])
					{
						have_erased_flag = 1;
						break;
					}
				}

				if (Plants[vectorZombies[i].coX][vectorZombies[i].coY] != SMALLNUT || have_erased_flag == 1)
				{
					continue;
				}
				else
				{
					int num = vectorZombies[i].num;
					int original_num_of_this_kind = 0, now_num_of_this_kind = 0;
					int k = 0;
					while (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
					{
						if (zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num)
						{
							original_num_of_this_kind++;
						}
						k++;
					}
					k = 0;
					while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
					{
						if (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] == num)
						{
							now_num_of_this_kind++;
						}
						k++;
					}
					if (original_num_of_this_kind - now_num_of_this_kind > 0)
					{
						vector<int> serialNum;
						for (int j = 0; j < vectorZombies.size(); j++)
						{
							if (vectorZombies[j].num == num && vectorZombies[i].coY == vectorZombies[j].coY && vectorZombies[i].coX == vectorZombies[j].coX)
							{
								serialNum.push_back(j);
							}
						}
						if (now_num_of_this_kind == 0)
						{
							for (int i = serialNum.size() - 1; i >= 0; i--)
							{
								vectorZombies.erase(serialNum[i] + vectorZombies.begin());
							}
						}
						if (original_num_of_this_kind - now_num_of_this_kind == 1)
						{ // find the smallest hp
							int small_hp = 5000, small_hp_num = 0;
							for (int k = 0; k < serialNum.size(); k++)
							{
								if (small_hp > vectorZombies[serialNum[k]].hp)
								{
									small_hp = vectorZombies[serialNum[k]].hp;
									small_hp_num = k;
								}
							}
							vectorZombies.erase(small_hp_num + vectorZombies.begin());
						}

						have_erased.push_back(vectorZombies[i].coX);
						have_erased.push_back(vectorZombies[i].coY);
					}
				}
			}
			for (int i = 0; i < vectorZombies.size(); i++)
			{
				int num = vectorZombies[i].num;
				int k = 0;
				int flag_self = 0;
				int flag_near = 0;
				while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k] != -1)
				{
					if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k])
					{
						break;
					}
					else
					{
						flag_self = 1;
					}
				}
				k = 0;
				while (Zombies[vectorZombies[i].coX][vectorZombies[i].coY - 1][k] != -1)
				{
					if (num == Zombies[vectorZombies[i].coX][vectorZombies[i].coY][k])
					{
						vectorZombies[i].coY--;
					}
					else
					{
						flag_near = 1;
					}
				}
				if (flag_self == 1 && flag_near == 1)
				{
					vectorZombies.erase(vectorZombies.begin() + i);
					i--;
				}
			}

			for (int i = 0; i < 7; i++)
			{
				if (cdPlant[i] > 0)
					cdPlant[i]--;
				if (cdPlant[i] == 0)
					flagPlant[i] = 1;
			}

			for (int i = 0; i < 6; i++)
			{
				if (cdZombie[i] > 0)
					cdZombie[i]--;
				if (cdZombie[i] == 0)
					flagZombie[i] = 1;
			}
			for (int i = 0; i < sunFlowers.size(); i++)
			{
				if (sunFlowers[i].cd > 0)
					sunFlowers[i].cd--;
				if (sunFlowers[i].cd == 0)
				{
					sun += 25;
					sunFlowers[i].cd = 24;
				}
			}

		} //将上一tick的状态转移至当前tick
		Game()
		{
			time = 0;
			sun = 400, moon = 300;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					plants[i][j] = 0, flagShovel[i][j] = 0;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
						zombies[i][j][k] = 0;
			for (int i = 0; i < 5; i++)
				dps[i] = 0, zombieCostPerRow[i] = 0;
			for (int i = 0; i < 7; i++)
				cdPlant[i] = 0, flagPlant[i] = 1;
			for (int i = 0; i < 6; i++)
				cdZombie[i] = 0, flagZombie[i] = 1;
		}                                              // initialize
		Game tranState(Actionlist q, IPlayer *player); //推算一系列操作q后状态
	};                                                 // global status
	Game Game::tranState(Actionlist q, IPlayer *player)
	{
		Game newGame;
		{
			newGame.time = this->time, newGame.sun = this->sun, newGame.moon = this->moon;
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					newGame.plants[i][j] = this->plants[i][j], flagShovel[i][j] = this->flagShovel[i][j];
			for (int i = 0; i < 5; i++)
				for (int j = 0; j < 10; j++)
					for (int k = 0; k < 10; k++)
						newGame.zombies[i][j][k] = this->zombies[i][j][k];
			for (int i = 0; i < 7; i++)
				newGame.cdPlant[i] = this->cdPlant[i], newGame.flagPlant[i] = this->flagPlant[i];
			for (int i = 0; i < 6; i++)
				newGame.cdZombie[i] = this->cdZombie[i], newGame.flagZombie[i] = this->flagZombie[i];
			for (int i = 0; i < 5; i++)
				newGame.dps[i] = this->dps[i], newGame.zombieCostPerRow[i] = this->zombieCostPerRow[i];
		}
		// newGame=Game
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 10; j++)
			{
				if (q.plantPlace[i][j] > 0)
				{
					int num = q.plantPlace[i][j];
					newGame.sun -= plantCost[num];
					newGame.cdPlant[num] = plantCd[num];
					newGame.flagPlant[num] = 0;
					newGame.dps[i] += plantDps[num];
					newGame.plants[i][j] = num;
				}
				if (q.zombiePlace[i] > 0)
				{
					int num = q.zombiePlace[i];
					newGame.moon -= zombieCost[num];
					newGame.cdZombie[num] = zombieCd[num];
					newGame.flagZombie[num] = 0;
				}
			}
		newGame.maintain(player);
		//对操作进行运算
		return newGame;
	}
	// void

	class Zombies_num
	{
	public:
		int normal;
		int bucket;
		int polevault;
		int sled;
		int gargantuar;
		int total_num;

		Zombies_num()
		{
			this->normal = this->bucket = this->polevault = this->sled = this->gargantuar = this->total_num = 0;
		}
		void compute_num(int ***zombies, int rows, int columns)
		{
			int num = 0;
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					int k = 0;
					while (zombies[i][j][k] != -1)
					{
						switch (zombies[i][j][k])
						{
						case NORMAL:
							this->normal++;
							break;
						case BUCKET:
							this->bucket++;
							break;
						case POLEVAULT:
							this->polevault++;
							break;
						case SLED:
							this->sled++;
							break;
						case GARGANTUAR:
							this->gargantuar++;
							break;
						}
						num++;
						k++;
					}
				}
			}
		}
	};
	class Plants_num
	{
	public:
		int sunflower;
		int winterpeashooter;
		int peashooter;
		int smallnut;
		int pepper;
		int squash;

		Plants_num()
		{
			this->sunflower = this->winterpeashooter = this->peashooter = this->smallnut = this->pepper = this->squash = 0;
		}
		void compute_num(int **plants, int rows, int columns)
		{
			for (int i = 0; i < rows; i++)
				for (int j = 0; j < columns; j++)
				{
					switch (plants[i][j])
					{
					case SUNFLOWER:
						this->sunflower++;
						break;
					case WINTERPEASHOOTER:
						this->winterpeashooter++;
						break;
					case PEASHOOTER:
						this->peashooter++;
						break;
					case SMALLNUT:
						this->smallnut++;
						break;
					case PEPPER:
						this->pepper++;
						break;
					case SQUASH:
						this->squash++;
						break;
					}
				}
		}
	};

	int calculate_zombie_nums(int ***zombies, int rows, int columns)
	{
		int num = 0;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++)
			{
				int k = 0;
				while (zombies[i][j][k] != -1)
				{
					num++;
					k++;
				}
			}
		}
		return num;
	}
	int choose_Lines_not_Broken(int *Left_lines, int **plants, int column)
	{
		for (int i = 0;; i++)
		{
			if (Left_lines[i] == 1 && plants[i][column] == NOPLANT)
				return i;
		}
		return rand() % ROW;
	}
	typedef struct pos_and_value
	{
		int pos[2];
		double value;
	} pos_and_value;

	class value_plant_func
	{
	public:
		double noplant;
		pos_and_value sunflower;
		pos_and_value peashooter;
		pos_and_value winterpeashooter;
		pos_and_value smallnut;
		pos_and_value pepper;
		pos_and_value squash;
		int generating_row;
		IPlayer *player;
		Game game;
		// double value[PLANT_KIND + 1];
		// int choice[PLANT_KIND + 1] = {this->noplant, this->sunflower, this->peashooter, this->winterpeashooter, this->smallnut, this->pepper, this->squash};

		int NotBrokenLinesNum;
		int KillZombiesScore;
		int LeftPlants;
		int Score;
		int time;
		int *PlaceCD;
		int **Plants;
		int ***Zombies;
		int *LeftLines;
		int Sun;
		int zombie_nums;

		value_plant_func(int NotBrokenLinesNum,
						 int KillZombiesScore,
						 int Score,
						 int time,
						 int *PlaceCD,
						 int **Plants,
						 int ***Zombies,
						 int *LeftLines,
						 int Sun, IPlayer *player,
						 Game game)
		{
			this->NotBrokenLinesNum = NotBrokenLinesNum;
			this->KillZombiesScore = KillZombiesScore;
			this->Score = Score;
			this->time = time;
			this->PlaceCD = PlaceCD;
			this->Plants = Plants;
			this->Zombies = Zombies;
			this->LeftLines = LeftLines;
			this->Sun = Sun;
			this->player = player;
			this->generating_row = 1;
			this->game = game;
		}
		int **sum_plants_per_row()
		{ // [rows,plants_kind] = num_per_row
			int **plants_num_format = (int **)malloc(ROW * sizeof(int *));
			for (int i = 0; i < ROW; i++)
			{
				plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND);
				memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int));
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					switch (this->Plants[i][j])
					{
					case SUNFLOWER:
						plants_num_format[i][SUNFLOWER]++;
						break;
					case WINTERPEASHOOTER:
						plants_num_format[i][WINTERPEASHOOTER]++;
						break;
					case PEASHOOTER:
						plants_num_format[i][PEASHOOTER]++;
						break;
					case SMALLNUT:
						plants_num_format[i][SMALLNUT]++;
						break;
					case PEPPER:
						plants_num_format[i][PEPPER]++;
						break;
					case SQUASH:
						plants_num_format[i][SQUASH]++;
						break;
					}
				}
			}
			return plants_num_format;
		}
		void beginning_operation()
		{
			if (this->time == 3)
			{
				this->player->PlacePlant(SUNFLOWER, this->generating_row, 1);
				// this->player->PlacePlant(SMALLNUT, this->generating_row, COLUMN - 1);
			}
		}
		void GameState_2_400()
		{
			if (this->time > 2 && this->time < 150)
			{
				int alarming_flag = -1;
				for (int i = 0; i < ROW; i++)
				{
					if (i != this->generating_row)
					{
						if (time < 25)
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (this->Zombies[i][j][k] != -1)
								{
									if (j < 3)
										alarming_flag = i;
									if (this->Sun >= 70)
										switch (this->Zombies[i][j][k])
										{
										case POLEVAULT:
										case SLED:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										case BUCKET:
											if (this->PlaceCD[SQUASH] == 0)
												this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											else if (j <= 5)
												this->player->PlacePlant(PEPPER, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										case GARGANTUAR:
											this->player->PlacePlant(SQUASH, i, (j - 1 < 0 ? 0 : j - 1));
											if (j < 4)
												this->player->PlacePlant(PEPPER, i, 8);
											break;
										case NORMAL:
											this->player->PlacePlant(PEASHOOTER, i, 0);
											this->player->PlacePlant(SMALLNUT, i, (j - 1 < 0 ? 0 : j - 1));
											break;
										}
									k++;
								}
							}
					}
					else
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (this->Zombies[this->generating_row][j][k] != -1)
							{
								if (this->Sun >= 70)
									switch (this->Zombies[this->generating_row][j][k])
									{
									case POLEVAULT:
									case BUCKET:
									case SLED:
										this->player->PlacePlant(SQUASH, this->generating_row, 5);
										break;
									case GARGANTUAR:
										this->player->PlacePlant(SQUASH, this->generating_row, (j - 1 < 0 ? 0 : j - 1));
										if (j < 4)
											this->player->PlacePlant(PEPPER, this->generating_row, 8);
										break;
									case NORMAL:
										this->player->PlacePlant(SMALLNUT, this->generating_row, (j - 1 < 0 ? 1 : j - 1));
										break;
									}
								if (j < (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1 + 1 && this->PlaceCD[SQUASH - 1] != 0)
								{
									this->player->PlacePlant(PEPPER, i, 8);
								}
								k++;
							}
						}
				}
				int num = 0, pos = 0;
				for (int i = 0; i < COLUMN; i++)
				{
					if (Plants[this->generating_row][i] == SUNFLOWER)
					{
						num++;
					}
					if (Plants[this->generating_row][i] != NOPLANT)
					{
						pos = i;
					}
				}
				if (num < 5)
					this->player->PlacePlant(SUNFLOWER, this->generating_row, (this->sum_plants_per_row())[this->generating_row][SUNFLOWER] + 1);
				if (alarming_flag != -1)
				{
					if (this->PlaceCD[SQUASH - 1] == 0)
					{
						this->player->PlacePlant(SQUASH, alarming_flag, COLUMN - 1);
					}
					else
						this->player->PlacePlant(PEPPER, alarming_flag, COLUMN - 1);
				}
			}
		}

		void GameState_50_200()
		{
			if (this->time > 50 && this->time < 200)
			{
				if (this->Sun >= 400)
					this->player->PlacePlant(WINTERPEASHOOTER, this->generating_row, 0);
			}
		}
		void value_peashooter_origin()
		{
			if (this->time > 10)
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					double **loss = (double **)malloc(ROW * sizeof(double *));
					for (int i = 0; i < ROW; i++)
					{
						loss[i] = (double *)malloc(COLUMN * sizeof(double));
						memset(loss[i], 0, COLUMN * sizeof(double));
					}
					double max = -10000, max_index[2] = {0, 0};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							if (this->Plants[i][j] != NOPLANT)
								loss[i][j] = -10000;
							else
							{
								//对行的参数
								double row = (i == this->generating_row ? -10 : 0);
								loss[i][j] += row;

								//对列的参数
								// double column = (25);
								// loss[i][j] += column * exp(-column) - 10;

								//对僵尸参数
								double zombie[ZOMBIE_KIND] = {6, -10, -2, -40, -20};
								for (int column0 = 0; j < COLUMN; j++)
								{
									int k = 0;
									while (Zombies[i][column0][k] != -1)
									{
										loss[i][j] += zombie[Zombies[i][column0][k] - 1] / (+COLUMN - j);
										k++;
									}
								}

								//对植物参数
								double plant[PLANT_KIND] = {2, 0, -2, 5, 2, 0};
								for (int column0 = 0; j < COLUMN; j++)
								{
									if (this->Plants[i][column0] != NOPLANT)
										loss[i][j] += plant[this->Plants[i][column0]] * (1 + (column0 - COLUMN / 2) / 40);
								}

								//对时间的参数
								double time_rate = 30;
								loss[i][j] += time_rate * (1 / (1 + exp((+this->time - TOTAL_TIME / 5) / 600)) - 0.5);
							}
							if (max < loss[i][j])
							{
								max_index[0] = i;
								max_index[1] = j;
							}
						}
					this->peashooter.pos[0] = max_index[0];
					this->peashooter.pos[1] = max_index[1];
					this->peashooter.value = max;
				}
		}
		bool have_type_of_zombies(int *zombie, int type)
		{
			int k = 0;
			while (zombie[k] != -1)
			{
				if (zombie[k] == type)
					return true;
				k++;
			}
			return false;
		}
		int search_for_nearest_zombie(int ***zombie, int row, int column)
		{
			int nearest = 100;
			for (int j = 0; j < COLUMN; j++)
			{
				int k = 0;
				while (Zombies[row][j][k] != -1)
				{
					if (nearest > j - column)
						nearest = j - column;
					k++;
				}
			}
			return nearest;
		}
		void judge_Lines_not_broken(double *final_choice)
		{
			for (int i = 0; i < ROW; i++)
			{
				if (this->LeftLines[i] == 0)
				{
					final_choice[i] = -100000;
				}
			}
		}
		void value_peashooter0()
		{
			if (this->time > 30)
			{
				if (this->PlaceCD[PEASHOOTER - 1] == 0)
				{
					for (int i = 0; i < ROW; i++)
					{
						if (LeftLines[i] == 1)
						{
							for (int j = 0; j < COLUMN; j++)
							{
								int k = 0;
								while (Zombies[i][j][k] != -1)
								{
									k++;
								}
								if (k == 1 && Zombies[i][j][0] == NORMAL && j >= COLUMN - 2)
								{
									this->player->PlacePlant(PEASHOOTER, i, 0);
								}
								else if (k > 0 && (have_type_of_zombies(Zombies[i][j], POLEVAULT) || have_type_of_zombies(Zombies[i][j], BUCKET)) && Sun < 400 && time < 500 && j < 5)
								{
									int start = 0;
									while (Plants[i][start] != NOPLANT)
									{
										start++;
									}
									if (search_for_nearest_zombie(Zombies, i, start) >= 1)
									{
										player->PlacePlant(PEASHOOTER, i, start);
									}
								}
							}
						}
					}
				}
			}
		}
		void value_peashooter()
		{
			double score[5] = {0, 0, 0, 0, 0};
			double plant_cost[7] = {0, 10, -6, -8, 15, 10, 0};
			judge_Lines_not_broken(score);

			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					double distance_cost = 1;
					switch (Plants[i][j])
					{
					case SUNFLOWER:
						distance_cost *= 1 + j / 100;
					}
					score[i] += plant_cost[Plants[i][j]] * distance_cost;
				}
			}

			double zombie_cost[5] = {10, 5, -5, -20, -20};
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					int k = 0;
					while (Zombies[i][j][k] != -1)
					{
						double distance_cost = 1;
						switch (Zombies[i][j][k])
						{
						case NORMAL:
							distance_cost = 1 - j / 30;
						}
						score[i] += plant_cost[Zombies[i][j][k] - 1] * distance_cost;
						k++;
					}
				}
			}
			int *serial_num = rank(score, ROW);
			int i = 0;
			for (; i < 10; i++)
			{
				if (Plants[serial_num[0]][i] == NOPLANT)
					break;
			}
			if (i <= 3)
			{
				if (!(have_type_of_zombies(Zombies[serial_num[0]][i + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][i], SLED) ||
					  have_type_of_zombies(Zombies[serial_num[0]][i + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][i], GARGANTUAR)))
					player->PlacePlant(PEASHOOTER, serial_num[0], i);
			}
			free(serial_num);
		}
		int *rank(double *array, int len)
		{
			double max = array[0];
			int *serial_num = (int *)malloc(len * sizeof(int));
			for (int i = 0; i < len; i++)
			{
				serial_num[i] = i;
			}
			for (int i = 0; i < len - 1; i++)
			{
				for (int j = 0; j < len - 1; j++)
				{
					if (array[j] < array[j + 1])
					{
						double swap = array[j];
						array[j] = array[j + 1];
						array[j + 1] = swap;
						int serial_swap = serial_num[j];
						serial_num[j] = serial_num[j + 1];
						serial_num[j + 1] = serial_swap;
					}
				}
			}
			return serial_num;
		}
		void value_sunflower()
		{
			int sunflower_num = 0;
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == SUNFLOWER)
					{
						sunflower_num++;
					}
				}
			double b = -0.01 * (this->time - 300) * (this->time - 300) / 10000 + 1;
			if (this->time > 9 && sunflower_num < 9 + (b < 0 ? 0 : b) && this->Sun < 1000)
				if (this->PlaceCD[SUNFLOWER - 1] == 0)
				{
					double score[5] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[i][j] == SUNFLOWER)
								score[i] -= 120;
							if (Plants[i][j] == PEASHOOTER)
								score[i] += 50 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == WINTERPEASHOOTER)
								score[i] += 100 * (1 * (exp(-j / 5)));
							if (Plants[i][j] == SMALLNUT)
								score[i] += 100 * (-0.01 * (j - 5) * (j - 5) + 1);
						}
					}
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								if (Zombies[i][j][k] == NORMAL)
									score[i] -= 10 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == BUCKET)
									score[i] -= 50 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == POLEVAULT)
									score[i] -= 30 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == GARGANTUAR)
									score[i] -= 100 * (1 / (0.1 + j));
								if (Zombies[i][j][k] == SLED)
									score[i] -= 80 * (1 / (0.1 + j));
								k++;
							}
						}

					// int sunflower_num_in_generating_row = 0;
					// for (int j = 0; j < COLUMN; j++)
					// {
					//     if (Plants[this->generating_row][j] == SUNFLOWER)
					//         sunflower_num_in_generating_row++;
					// }
					// score[this->generating_row] += 100 * (1 / (sunflower_num_in_generating_row + 2));

					int *serial_num = rank(score, ROW);
					int j = 0;
					while (Plants[serial_num[0]][j + 2] != NOPLANT && j < 8)
					{
						j++;
					}
					if (j < 8)
						if (!(have_type_of_zombies(Zombies[serial_num[0]][j + 1], SLED) || have_type_of_zombies(Zombies[serial_num[0]][j], SLED) ||
							  have_type_of_zombies(Zombies[serial_num[0]][j + 1], GARGANTUAR) || have_type_of_zombies(Zombies[serial_num[0]][j], GARGANTUAR)))
							player->PlacePlant(SUNFLOWER, serial_num[0], j + 2);
					free(serial_num);
				}
		}
		void value_smallmnut()
		{
			if (this->PlaceCD[SMALLNUT - 1] == 0)
				if (this->time > 20)
				{
					double score[ROW] = {0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);

					// value plants
					double plants_score[7] = {0, 5, 20, 20, -300, -2, 0};
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							double distance_cost = 1;
							switch (Plants[i][j])
							{
							case SUNFLOWER:
								distance_cost = 1.5 - 0.05 * j;
								break;
							case PEASHOOTER:
								distance_cost = 2 - 0.09 * j;
								break;
							case WINTERPEASHOOTER:
								distance_cost = 2 - 0.1 * j;
								break;
							}
							score[i] += plants_score[Plants[i][j]] * distance_cost;
						}
					}

					// value zombies;
					double zombie_cost[5] = {2.0, 10, 12, -1000, -2000};
					int nearest_zombie_per_row[5] = {10, 10, 10, 10, 10};
					for (int i = 0; i < ROW; i++)
					{
						for (int j = COLUMN - 1; j >= 0; j--)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								double distance_cost = 1;
								switch (Zombies[i][j][k])
								{
								case NORMAL:
									distance_cost = 1.2 - 0.02 * (j);
									break;
								case POLEVAULT:
									distance_cost = 1.1 - 0.01 * j;
									break;
								case BUCKET:
									distance_cost = 1.3 - 0.04 * j;
									break;
								}
								score[i] += zombie_cost[(Zombies[i][j][k] - 1)] * distance_cost;
								k++;
								nearest_zombie_per_row[i] = j;
							}
						}
					}
					// for(int i=0;i< ROW; i++){
					//     score[i] += this->time/2;
					// }
					int *serial_num = rank(score, ROW);
					// for (int i = 0; i < ROW; i++)
					// {
					//     int j = 0;

					// if (Plants[serial_num[i]][nearest_zombie_per_row[serial_num[i]] - 1])
					int j = COLUMN - 1;
					if (Plants[serial_num[0]][nearest_zombie_per_row[serial_num[0]] - 1] != NOPLANT)
					{
						for (; j >= 4; j--)
						{
							if (Plants[serial_num[0]][j] == NOPLANT)
								break;
						}
						if (j != -1)
							player->PlacePlant(SMALLNUT, serial_num[0], min(j, 7));
					}
					else
					{
						int target_y = (nearest_zombie_per_row[serial_num[0]] - 1) < 0 ? 0 : (nearest_zombie_per_row[serial_num[0]] - 1);
						target_y = min(target_y, 7);
						player->PlacePlant(SMALLNUT, serial_num[0], target_y);
					}
					free(serial_num);
				}
		}
		void value_winterpeashooter()
		{
			if (this->PlaceCD[WINTERPEASHOOTER - 1] == 0)
			{
				if (this->time > 70)
				{
					double score[5] = {0.0, 0, 0, 0, 0};
					judge_Lines_not_broken(score);

					// value plant;
					double plant_cost[7] = {0.0, -2.5, -4, -5, -10, 6, 0};
					if (time > 450)
					{
						plant_cost[4] = 2;
					}
					for (int i = 0; i < ROW; i++)
					{
						for (int j = 0; j < COLUMN; j++)
						{
							score[i] += plant_cost[Plants[i][j]];
						}
					}

					double zombie_cost[5] = {5, 20, 10, 2, -4};
					for (int i = 0; i < ROW; i++)
						for (int j = 0; j < COLUMN; j++)
						{
							int k = 0;
							while (Zombies[i][j][k] != -1)
							{
								score[i] += zombie_cost[Zombies[i][j][k] - 1];
								k++;
							}
						}
					int *serial_num = rank(score, ROW);
					if (this->time < 300)
					{
						int j = 0;

						while (Plants[serial_num[0]][j] != NOPLANT && j < 8)
						{
							j++;
						}

						if (j < 5)
						{
							if (search_for_nearest_zombie(Zombies, serial_num[0], j) >= 1)
							{
								player->PlacePlant(WINTERPEASHOOTER, serial_num[0], j);
							}
						}
					}
					else
					{
						int limit = (int)(this->time / 400) + 3;
						for (int i = 0; i < limit; i++)
						{
							if ((Plants[serial_num[0]][i] == PEASHOOTER && this->time > 600) || (Plants[serial_num[0]][i] == SUNFLOWER))
							{
								if (search_for_nearest_zombie(Zombies, serial_num[0], i) >= 1 && this->Sun > 400)
								{
									player->removePlant(serial_num[0], i);
									player->PlacePlant(WINTERPEASHOOTER, serial_num[0], i);
									break;
								}
							}
						}
					}
					free(serial_num);
				}
			}
		}

		void value_squash()
		{
			if (this->PlaceCD[SQUASH - 1] == 0 && this->time > 50)
			{
				double score[5] = {0, 0, 0, 0, 0};

				double plant_cost[7] = {0, 5, 20, 3, -10, -100, -200};

				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						double distance_cost = 0.2 + 0.08 * j;
						score[i] += plant_cost[Plants[i][j]] * distance_cost;
					}
				}

				double zombie_cost[5] = {-5, 10, 2, 100, 200};
				for (int i = 0; i < ROW; i++)
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 11 / (j + 1);
							score[i] += zombie_cost[Zombies[i][j][k] - 1] * distance_cost;
							k++;
						}
					}
				int *serial_num = rank(score, ROW);

				int nearest_zombie = 10;
				for (int j = COLUMN - 1; j >= 0; j--)
				{
					int k = 0;
					while (Zombies[serial_num[0]][j][k] != -1)
					{
						nearest_zombie = j;
						k++;
					}
				}

				if (nearest_zombie - 1 >= 0 && nearest_zombie != 9)
				{
					if (Plants[serial_num[0]][nearest_zombie - 1] == NOPLANT)
					{
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
					else if (Plants[serial_num[0]][nearest_zombie - 1] != WINTERPEASHOOTER && Plants[serial_num[0]][nearest_zombie - 1] != SMALLNUT && Plants[serial_num[0]][nearest_zombie - 1] != NOPLANT && time > 400 && this->Sun > 50)
					{
						player->removePlant(serial_num[0], nearest_zombie - 1);
						player->PlacePlant(SQUASH, serial_num[0], nearest_zombie - 1);
					}
				}
				else
				{
					for (int j = COLUMN - 1; j >= 0; j--)
					{
						if (Plants[serial_num[0]][j] != NOPLANT && j >= 6)
						{
							player->PlacePlant(SQUASH, serial_num[0], j);
						}
					}
				}
				free(serial_num);
			}
		}
		void value_pepper()
		{
			if (this->PlaceCD[PEPPER - 1] == 0 && this->PlaceCD[SQUASH - 1] != 0)
			{
				double score[ROW] = {0, 0, 0, 0, 0};
				int warning_flag[5] = {0, 0, 0, 0, 0};
				int have_zombies[5] = {0, 0, 0, 0, 0};
				double zombie_cost[5] = {1, 3, 2, 20, 80};
				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						int k = 0;
						while (Zombies[i][j][k] != -1)
						{
							double distance_cost = 10 / (1 + j);
							score[i] += distance_cost * zombie_cost[Zombies[i][j][k] - 1];
							have_zombies[i] = 1;
							if (j <= 3)
								warning_flag[i] = 1;
							k++;
						}
					}
				}

				double plant_cost[7] = {0, 0, -20, -3, -1, -80, -80};

				for (int i = 0; i < ROW; i++)
				{
					for (int j = 0; j < COLUMN; j++)
					{
						score[i] += plant_cost[Plants[i][j]];
					}
				}

				double time_cost = 10 * (1 / (1 + exp((time - 1000) / 500)));

				int *serial_num = rank(score, ROW);
				int deal_with_warning_flag = 0;

				for (int i = 0; i < ROW; i++)
				{
					if (warning_flag[serial_num[i]] == 1)
					{ //加入detect wrong
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[i]][j] == NOPLANT)
							{
								player->PlacePlant(PEPPER, serial_num[i], j);
								flag = 1;
								deal_with_warning_flag = 1;
							}
							if (flag == 1)
								break;
						}
						break;
					}
				}
				if (deal_with_warning_flag == 0)
				{
					if (score[0] >= 0)
					{
						int flag = 0;
						for (int j = 0; j < COLUMN; j++)
						{
							if (Plants[serial_num[0]][j] == NOPLANT && have_zombies[serial_num[0]] == 1)
							{
								player->PlacePlant(PEPPER, serial_num[0], j);
								flag = 1;
							}
							if (flag == 1)
								break;
						}
					}
				}

				// for (int i = 0; i < ROW; i++)
				// {
				//     printf("%lf ", score[i]);
				// }
				// printf("\n");
				free(serial_num);
			}
		}
		void value()
		{ //加入time_cost;!!!!!
			this->value_peashooter();
			this->value_sunflower();
			this->value_smallmnut();
			this->value_winterpeashooter();
			this->value_squash();
			this->value_pepper();
			// double max = -100000;
			// double value[7] = {this->noplant, this->sunflower.value, this->winterpeashooter.value, this->peashooter.value, this->smallnut.value, this->squash.value, this->pepper.value};
			// this->player->PlacePlant(PEASHOOTER, this->peashooter.pos[0], this->peashooter.pos[1]);
		}
		void make_decision()
		{
			this->beginning_operation();
			this->GameState_2_400();
			// this->GameState_50_200();
			if (this->time > 20)
				this->value();
		}
	};
	class value_zombie_func //  应加入多次进攻未果 换线的操作
	{
	public:
		int nozombie;
		int normal_choice;
		int bucket_choice;
		int polevault_choice;
		int sled_choice;
		int gargantuar_choice;
		double value[ZOMBIE_KIND];
		int choice[ZOMBIE_KIND] = {this->normal_choice, this->bucket_choice, this->polevault_choice, this->sled_choice, this->gargantuar_choice}; // KIND->ROW

		int BrokenLinesScore;
		int KillPlantsScore;
		int LeftPlants;
		int Score;
		int time;
		int *PlaceCD;
		int **Plants;
		int ***Zombies;
		int *LeftLines;
		int Sun;
		int zombie_nums;
		int give_up_whole_attack;
		Game game;
		IPlayer *player;

		value_zombie_func(int BrokenLinesScore,
						  int KillPlantsScore,
						  int Score,
						  int time,
						  int *PlaceCD,
						  int **Plants,
						  int ***Zombies,
						  int *LeftLines,
						  int Sun,
						  int zombie_nums,
						  Game game,
						  IPlayer *player)
		{
			this->normal_choice = this->bucket_choice = this->polevault_choice = this->sled_choice = this->gargantuar_choice = 0;
			this->BrokenLinesScore = BrokenLinesScore;
			this->KillPlantsScore = KillPlantsScore;
			this->Score = Score;
			this->time = time;
			this->PlaceCD = PlaceCD;
			this->Plants = Plants;
			this->Zombies = Zombies;
			this->LeftLines = LeftLines;
			this->Sun = Sun;
			this->zombie_nums = zombie_nums;
			this->game = game;
			this->give_up_whole_attack = 0;
			this->player = player;
			for (int i = 0; i < ZOMBIE_KIND; i++)
				this->value[i] = 0;
			memset(this->choice, 0, ZOMBIE_KIND * (sizeof(int)));
		}
		// void input_data()
		// {
		//     for (int i = 0; i < ROW; i++)
		//     {
		//         fputc(this->choice[i], file);
		//         fprintf(file, " %.6f ", this->value[i]);
		//     }
		//     fprintf(file, "\n");
		// }
		int judge_whether_big_cost_in_one_row(int *cost)
		{
			double average = 0, square_distance = 0;
			for (int i = 0; i < ROW; i++)
			{
				average += cost[i];
			}
			average /= 5;
			for (int i = 0; i < ROW; i++)
			{
				square_distance += (cost[i] - average) * (cost[i] - average);
			}
			square_distance = pow(square_distance, 0.5);
			square_distance /= 5;

			if (square_distance > pow(this->time, 0.2) * 400)
			{
				return 1;
			}
			else
				return 0;
		}
		void make_decision(int *decision) //[ KIND , ROW ]
		{
			// int *cost = this->game.zombieCostPerRow;
			// if (judge_whether_big_cost_in_one_row(cost) == 0)
			// {
			double max = -10000;

			for (int i = 0; i < 5; i++)
			{
				if (max < this->value[i])
				{
					max = this->value[i];
					decision[0] = i + 1;
					decision[1] = this->choice[i];
				}
			}
			if (this->give_up_whole_attack == 1 && this->Sun < 900)
			{
				decision[0] = NOZOMBIE;
				decision[1] = 0;
			}
			else if (this->give_up_whole_attack == 1 && this->Sun >= 900 && this->time < 1350)
			{

				int attacking_lines1 = 0;
				int attacking_lines2 = 0;
				int leftlins_flag = 0;
				for (int i = 0; i < 5; i++)
				{
					if (LeftLines[i] == 1)
					{
						attacking_lines1 = i;

						break;
					}
				}
				for (int i = 0; i < 5; i++)
				{
					if (LeftLines[i] == 1 && i != attacking_lines1)
					{
						attacking_lines2 = i;
						break;
					}
					if (i == 4)
						leftlins_flag = 1;
				}
				if (leftlins_flag == 0)
				{
					decision[0] = GARGANTUAR;
					decision[1] = attacking_lines1;

					this->player->PlaceZombie(GARGANTUAR, attacking_lines1);
					this->player->PlaceZombie(BUCKET, attacking_lines1);
					this->player->PlaceZombie(NORMAL, attacking_lines2);
					this->player->PlaceZombie(POLEVAULT, attacking_lines2);
					this->player->PlaceZombie(SLED, attacking_lines2);
				}
				else
				{
					this->player->PlaceZombie(GARGANTUAR, attacking_lines1);
					this->player->PlaceZombie(BUCKET, attacking_lines1);
					this->player->PlaceZombie(NORMAL, attacking_lines1);
					this->player->PlaceZombie(POLEVAULT, attacking_lines1);
					this->player->PlaceZombie(SLED, attacking_lines1);
				}
			}
			// for (int i = 0; i <ROW;i++)
			// printf("%lf ",value[i]);
			// printf("\n");
			// }
			// else
			// {
			//     double min = value[0];

			//     for (int i = 0; i < 5; i++)
			//     {
			//         if (min > this->value[i])
			//         {
			//             min = this->value[i];
			//             decision[0] = i + 1;
			//             decision[1] = this->choice[i];
			//         }
			//     }
			//     if (this->zombie_nums > (this->time / 100 + 4))
			//     {
			//         decision[0] = decision[1] = NOZOMBIE;
			//     }
			// }
		}
		// void value_nozombie()
		// {
		//     int final_choice[ROW] = {0, 0, 0, 0, 0};
		//     /*
		//             this->NotBrokenLinesNum = NotBrokenLinesNum;
		//             this->KillZombiesScore = KillZombiesScore;
		//             this->LeftPlants = LeftPlants;
		//             this->Score = Score;
		//             this->time = time;
		//             this->PlaceCD = PlaceCD;
		//             this->Plants = Plants;
		//             this->Zombies = Zombies;
		//             this->LeftLines = LeftLines;
		//             this->Sun = Sun;
		//     */
		//     for (int i = 0; i < ROW; i++)
		//     {
		//         final_choice[i] += 0;
		//     }
		// }
		bool whether_need_compute(int kind)
		{ //需要为0 不需要为1
			if (this->PlaceCD[kind - 1] > 0 || this->time < 120)
			{
				this->choice[kind - 1] = 0;
				this->value[kind - 1] = -100000;
				return true;
			}
			else
				return false;
		}
		void whether_give_up_attack(double *score)
		{
			int num[5] = {0, 0, 0, 0, 0};

			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					if (Plants[i][j] == WINTERPEASHOOTER)
						num[i]++;
				}
			}
			int give_up_lines = 0;
			for (int i = 0; i < ROW; i++)
			{
				if (num[i] >= 4)
				{
					score[i] = -100000;
					give_up_lines++;
				}
			}
			int sum_all_lines = 0;
			for (int i = 0; i < ROW; i++)
			{
				if (this->LeftLines[i] == 1)
				{
					sum_all_lines++;
				}
			}
			if (give_up_lines == sum_all_lines)
				this->give_up_whole_attack = 1;
		}
		double zombie_cost(int row, double *zombies_paras, double distance_cost, double distance_rate, int kind)
		{
			double cost = 0.0;
			if (this->LeftLines[row] == 0)
			{
				cost = -100000;
			}
			else
			{
				int num_per_row = 0;
				double too_many_zombies_cost = -1.5;
				for (int j = 0; j < COLUMN; j++)
				{
					int k = 0;
					while (this->Zombies[row][j][k] != -1)
					{
						switch (kind)
						{
						case POLEVAULT:
							cost += zombies_paras[this->Zombies[row][j][k] - 1] * ((COLUMN - j - distance_cost) * (COLUMN - j - distance_cost));
							break;
						default:
							cost += zombies_paras[this->Zombies[row][j][k] - 1] * (-distance_rate * (COLUMN - j - distance_cost) * (COLUMN - j - distance_cost) + 2);
						}
						k++;
						num_per_row++;
					}
				}
				cost += num_per_row * too_many_zombies_cost;
			}
			return cost;
		}
		int **sum_plants_per_row()
		{ // [rows,plants_kind] = num_per_row
			int **plants_num_format = (int **)malloc(ROW * sizeof(int *));
			for (int i = 0; i < ROW; i++)
			{
				plants_num_format[i] = (int *)malloc(sizeof(int) * PLANT_KIND);
				memset(plants_num_format[i], 0, PLANT_KIND * sizeof(int));
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			}
			for (int i = 0; i < ROW; i++)
			{
				for (int j = 0; j < COLUMN; j++)
				{
					switch (this->Plants[i][j])
					{
					case SUNFLOWER:
						plants_num_format[i][SUNFLOWER - 1]++;
						break;
					case WINTERPEASHOOTER:
						plants_num_format[i][WINTERPEASHOOTER - 1]++;
						break;
					case PEASHOOTER:
						plants_num_format[i][PEASHOOTER - 1]++;
						break;
					case SMALLNUT:
						plants_num_format[i][SMALLNUT - 1]++;
						break;
					case PEPPER:
						plants_num_format[i][PEPPER - 1]++;
						break;
					case SQUASH:
						plants_num_format[i][SQUASH - 1]++;
						break;
					}
				}
			}
			return plants_num_format;
		}
		double plant_cost(int row, int **plants_num_format, double *plants_para, int kind)
		{
			double origin_para[PLANT_KIND];
			for (int i = 0; i < PLANT_KIND; i++)
			{
				origin_para[i] = plants_para[i];
			}
			double cost = 0.0;
			switch (kind)
			{
			case NORMAL:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
					plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER - 1] * 1 + plants_num_format[row][WINTERPEASHOOTER - 1] * 2);
				break;
			case BUCKET:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
					plants_para[SMALLNUT - 1] *= (plants_num_format[row][PEASHOOTER - 1] * 0.2 + plants_num_format[row][WINTERPEASHOOTER - 1]);
				break;
			case POLEVAULT:
				if (plants_num_format[row][SMALLNUT - 1] > 0 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
				{
					plants_para[SMALLNUT - 1] *= ((1.5 - plants_num_format[row][SMALLNUT - 1]) * (3 - plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1]));
				}
				break;
			case SLED:
				// if (plants_num_format[row][SMALLNUT - 1] > 1 && plants_num_format[row][PEASHOOTER - 1] + plants_num_format[row][WINTERPEASHOOTER - 1] > 0)
				// {
				//     plants_para[SMALLNUT - 1] *= (plants_num_format[row][SMALLNUT - 1] * plants_num_format[row][SMALLNUT - 1]) * (plants_num_format[row][WINTERPEASHOOTER - 1]);
				// }
				if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2)
				{
					plants_para[WINTERPEASHOOTER - 1] = 6 - 2 * plants_num_format[row][WINTERPEASHOOTER - 1];
				}
				break;
			case GARGANTUAR:
				if (plants_num_format[row][WINTERPEASHOOTER - 1] >= 2)
				{
					plants_para[WINTERPEASHOOTER - 1] = 8 - 2 * plants_num_format[row][WINTERPEASHOOTER - 1];
				}
				break;
			}
			plants_para[SUNFLOWER - 1] *= (1 + 1 / (COLUMN - plants_num_format[row][SUNFLOWER - 1] + 1));

			// for (int j = 0; j < PLANT_KIND; j++)
			//     printf(" %lf ", plants_para[j]);
			//     printf("\n");

			for (int j = 0; j < COLUMN; j++)
			{
				if (Plants[row][j] != NOPLANT)
					cost += plants_para[Plants[row][j] - 1] * (plants_para[Plants[row][j] - 1] > 0 ? (j + 1) * (j + 1) : (COLUMN - j));
			}
			for (int i = 0; i < PLANT_KIND; i++)
			{
				plants_para[i] = origin_para[i];
			}
			return cost;
		}
		int max_index(double *a, int length)
		{
			double max = -10000;
			int index = 0;
			for (int i = 0; i < length; i++)
			{
				if (max < a[i])
				{
					max = a[i];
					index = i;
				}
			}
			return index;
		}
		/*
				NORMAL,
				BUCKET,
				POLEVAULT,
				SLED,
				GARGANTUAR
		*/

		/*
			SUNFLOWER,
			WINTERPEASHOOTER,
			PEASHOOTER,
			SMALLNUT,
			PEPPER,
			SQUASH
		*/

		void value_normal()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			if (this->whether_need_compute(NORMAL))
			{
				return;
			}
			whether_give_up_attack(final_choice);
			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {-5, 4, 2, 3, 1};
			double distance_cost = 1, distance_rate = 0.05;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, NORMAL);
			}

			//遍历plant

			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {8, -8, -2, -2, -100, 20};
			int **sum_plants_per_row0 = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row0, plants_para, NORMAL);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row0[i]);
			}
			free(sum_plants_per_row0);
			//考虑time
			double time_cost = 20 * (1 / (1 + exp((this->time - TOTAL_TIME / 2) / 500)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 60, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 400)) * 15 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[NORMAL - 1] = this->max_index(final_choice, ROW);
			this->value[NORMAL - 1] = final_choice[this->choice[NORMAL - 1]];
		}

		void value_bucket()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(BUCKET))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {2.5, -4, this->time < 100 ? -100 : -5, 2, -2};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, BUCKET);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {6, -2, 6, -1, -100, -4};
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, BUCKET);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);

			//考虑time
			double time_cost = 20 * (1 / (1 + exp((-this->time + TOTAL_TIME / 3) / 400)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 150, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 400)) * 5 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[BUCKET - 1] = this->max_index(final_choice, ROW);
			this->value[BUCKET - 1] = final_choice[this->choice[BUCKET - 1]];
		}

		void value_polevault()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(POLEVAULT))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {1, this->time < 100 ? -100 : -5, -1.5, 2, -3};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, POLEVAULT);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {4, -50, -8, 7, -100, -10}; //偏好建国
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, POLEVAULT);
			}

			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);

			//考虑time
			double time_cost = 10 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 300)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 120, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp((-this->Sun + sun_baseline) / 500)) * 6 : -pow(sun_baseline - this->Sun, 1 / sun_sub));
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[POLEVAULT - 1] = this->max_index(final_choice, ROW);
			this->value[POLEVAULT - 1] = final_choice[this->choice[POLEVAULT - 1]];
		}

		void value_sled()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(SLED))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {3, -2, -1, -7, -4};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, SLED);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {3, 10, 2, 7, -100, -30}; //偏好建国 and 冰豌豆
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, SLED);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);
			double time_cost;
			//考虑time
			if (time < 600)
				time_cost = 15 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5);
			else
			{
				time_cost = 30 * (1 / (1 + exp((+this->time - TOTAL_TIME / 5) / 300)) - 0.5);
			}
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 200, sun_sub = 1;
			double sun_cost = (this->Sun - sun_baseline > 0 ? 1 / (1 + exp(-this->Sun + sun_baseline + 100) / 500) * 10 : 0);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			// for (int i = 0; i < ROW; i++)
			// {

			//     printf("%lf\t", final_choice[i]);
			// }
			this->choice[SLED - 1] = this->max_index(final_choice, ROW);
			this->value[SLED - 1] = final_choice[this->choice[SLED - 1]];
		}
		void value_gargantuar()
		{
			double final_choice[ROW] = {0, 0, 0, 0, 0};
			whether_give_up_attack(final_choice);
			if (this->whether_need_compute(GARGANTUAR))
			{
				return;
			}

			//遍历zombie
			double zombies_paras[ZOMBIE_KIND] = {2, -4, -5, -20, -15};
			double distance_cost = 2.5, distance_rate = 0.1;
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->zombie_cost(i, zombies_paras, distance_cost, distance_rate, GARGANTUAR);
			}

			//遍历plant
			int plants_num_format[ROW][PLANT_KIND] = {{0}};
			for (int i = 0; i < ROW; i++)
				for (int j = 0; j < PLANT_KIND; j++)
				{
					plants_num_format[i][j] = 0;
				}
			double plants_para[PLANT_KIND] = {1, 10, 2, 8, -100, -10}; //偏好建国 and 冰豌豆
			int **sum_plants_per_row = this->sum_plants_per_row();
			for (int i = 0; i < ROW; i++)
			{
				final_choice[i] += this->plant_cost(i, sum_plants_per_row, plants_para, GARGANTUAR);
			}
			for (int i = 0; i < ROW; i++)
			{
				free(sum_plants_per_row[i]);
			}
			free(sum_plants_per_row);
			//考虑time
			double time_cost;
			if (abs(this->time - 500) < 25 || abs(this->time - 1000) < 25 || abs(this->time - 1500) < 25)
				time_cost = 1000;
			time_cost = 120 * (1 / (1 + exp((-this->time + TOTAL_TIME / 5) / 400)) - 0.5);
			for (int i = 0; i < ROW; i++)
				final_choice[i] += time_cost;

			//考虑Sun
			double sun_baseline = 300, sun_sub = 1;
			double sun_cost = 1 / (1 + exp(-this->Sun + sun_baseline) / 500) * 10;
			for (int i = 0; i < ROW; i++)
				final_choice[i] += sun_cost;

			this->choice[GARGANTUAR - 1] = this->max_index(final_choice, ROW);
			this->value[GARGANTUAR - 1] = final_choice[this->choice[GARGANTUAR - 1]];
		}
	};
	static Game game;
	void player_ai(IPlayer *player)
	{
		// game.maintain(player);

		/*
		class ICamp
		{
		public:
			virtual int** getCurrentPlants() = 0;

			获 取 现 在 场 上 存 活 的 植 物 情 况。
			Plants [ i ] [ j ] 即 为 第 i 行 j 列 的 植 物 情 况， 0代 表 不 存 在

			virtual int*** getCurrentZombies() = 0;

			Zombies [ i ] [ j ] 即 为 第 i 行 j 列 格 子 中 的 所 有 僵 尸，
			如 果 该 格 子 中 有k（k>=0） 个 僵 尸， 则Zombies [ i ] [ j ] 的 长 度 为k+1，
			最 后 一 位Zombies [ i ] [ j ] [ k ] 为−1， 代 表 这 一 格 结 束

			virtual int getSun() = 0;

			获 取 己 方 阵 营 当 前 所 剩 的 阳 光 （月 光） 数

			virtual int* getPlantCD() = 0;

			获 取 植 物 或 僵 尸 种 植 冷 却 时 间， 植 物 方 调 用 时 仅 返 回 植 物 的 种 植CD， 僵 尸 方 同 理。
			植 物 方 返 回 的 数 组 依 次 是 太 阳 花， 冰 豌 豆 射 手， 豌 豆 射 手， 坚 果 墙， 火 爆 辣 椒， 倭 瓜；
			僵 尸 方 返 回 的 数 组 依 次 是 普 通 僵 尸， 铁 桶 僵 尸， 撑 杆 跳 僵 尸， 雪 橇 车 僵 尸， 伽 刚 特 尔。 数 组 下 标 从0开 始

			virtual int* getLeftLines() = 0

			获 取 植 物 方 各 行 是 否 被 攻 破， 长 度 为 行 数， 1为 该 行 未 被 攻 破， 0为 被 攻 破

			virtual int getRows() = 0;获 取 场 地 的 行 数

			virtual int getColumns() = 0;获 取 场 地 的 列 数

			virtual int getCurrentType() = 0;
		};
		class IPlayer
		{
		public:
			ICamp* Camp;
			virtual void PlacePlant(int type, int x, int y) = 0;  横着数为x 竖着数为y

			//参 数： 放 置 的 行 数x , 列 数y， 植 物 的 种 类type , 从1~6依 次 为 太 阳 花， 冰 豌 豆 射 手， 豌 豆 射 手， 坚 果
			墙， 火 爆 辣 椒， 倭 瓜 3 //作 用： 植 物 方 调 用 种 植 植 物。 僵 尸 方 调 用 无 效。 注 意 一 个 回 合 内 一 种 植 物 只 能 种 植 一 次，
			一 个 回 合 种 植 多 株 相 同 植 物 只 取 第 一 次。  当 要 种 植 植 物 的 种 植 CD 不 为 0 或 者 阳 光 不 足 或 者 待 种 植 的 位 置 已 经 存 在 植 物 则 种 植 无 效。

			virtual void PlaceZombie(int type, int y) = 0;

			放 置 的 列 数y， 僵 尸 的 种 类type , 从1~5依 次 为 普 通 僵 尸， 铁 桶 僵 尸， 撑 杆 跳 僵 尸， 雪 橇 车 僵 尸， 伽 刚 特 尔。
			作 用： 僵 尸 方 调 用 放 置 僵 尸。 植 物 方 调 用 无 效。 注 意 一 个 回 合 内 一 种 僵 尸 只 能 放 置 一 次，
			一 个 回 合 放 置 多 只 相 同 僵 尸 只 取 第 一 次。 当 要 放 置 的 僵 尸 放 置CD不 为0或 者 阳 光 不 足 则 放 置 无 效。

			virtual int getTime() = 0; 获 取 当 前 回 合 数
			virtual int getScore() = 0;获 取 己 方 分 数
			virtual int getKillPlantsScore() = 0;获 取 己 方 作 为 僵 尸 方 时 通 过 杀 死 植 物 得 到 的 分 数
			virtual int getKillZombiesScore() = 0;获 取 己 方 作 为 植 物 方 时 通 过 杀 死 僵 尸 得 到 的 分 数
			virtual int getNotBrokenLines() = 0;  返 回 己 方 作 为 植 物 方 时 未 被 攻 破 的 行 数
			virtual int getBrokenLinesScore() = 0;   返 回 己 方 作 为 僵 尸 方 时 通 过 攻 破 一 整 行 获 得 的 分 数
			virtual int getLeftPlants() = 0;;获 取 己 方 作 为 植 物 方 时 结 束 时 剩 余 的 植 物 个 数
		};*/
		int Type = player->Camp->getCurrentType();
		//植 物 种 类 2

		if (Type == 0)
		{ //植物方
			int NotBrokenLinesNum = player->getNotBrokenLines();
			int KillZombiesScore = player->getKillZombiesScore();
			int LeftPlants = player->getLeftPlants();
			int Score = player->getScore();
			int time0 = player->getTime();
			int rows = player->Camp->getRows();
			int columns = player->Camp->getColumns();
			int *PlaceCD = player->Camp->getPlantCD();
			int **Plants = player->Camp->getCurrentPlants();
			int ***Zombies = player->Camp->getCurrentZombies();
			int *LeftLines = player->Camp->getLeftLines();
			int Sun = player->Camp->getSun();
			// Zombies_num zombies_num;
			// zombies_num.compute_num(Zombies, rows, columns);
			// Plants_num plants_num;
			// plants_num.compute_num(Plants, rows, columns);
			// player->PlacePlant(SUNFLOWER, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.sunflower / 5 + 1)) % 5, plants_num.sunflower / 5 + 1);
			// player->PlacePlant(SMALLNUT, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.smallnut / 5 + 2)+3)%5, plants_num.smallnut / 5 + 2);
			// if (plants_num.sunflower < 3)
			//     player->PlacePlant(SUNFLOWER, 0, plants_num.sunflower + 1);
			// player->PlacePlant(SMALLNUT, 0, plants_num.smallnut + 5);
			// player->PlacePlant(SQUASH, 0, 4);
			// player->PlacePlant(SQUASH, (choose_Lines_not_Broken(LeftLines, Plants, plants_num.squash / 5 + 4) ) % 5, (plants_num.squash) / 5 + 4);
			// if (time0 > 6)
			//     player->PlacePlant(PEASHOOTER, (choose_Lines_not_Broken(LeftLines, Plants, (plants_num.peashooter) / 5)+1)%5, (plants_num.peashooter + 4) / 5);
			// if (Sun > 400)
			// player->PlacePlant(WINTERPEASHOOTER, 0, 0);

			value_plant_func value(NotBrokenLinesNum, KillZombiesScore, Score, time0, PlaceCD, Plants, Zombies, LeftLines, Sun, player, game);
			value.make_decision();
		}
		if (Type == 1)
		{
			//僵尸方
			int BrokenLinesScore = player->getBrokenLinesScore();
			int KillPlantsScore = player->getKillPlantsScore();
			int Score = player->getScore();
			int time = player->getTime();
			int rows = player->Camp->getRows();
			int columns = player->Camp->getColumns();
			int *PlaceCD = player->Camp->getPlantCD();
			int **Plants = player->Camp->getCurrentPlants();
			int ***Zombies = player->Camp->getCurrentZombies();
			int *LeftLines = player->Camp->getLeftLines();
			int Sun = player->Camp->getSun();
			if (time > 3)
			{
				int zombie_num = calculate_zombie_nums(Zombies, 4, 9);
				value_zombie_func value(BrokenLinesScore, KillPlantsScore, Score, time, PlaceCD, Plants, Zombies, LeftLines, Sun, zombie_num, game, player);
				value.value_normal();
				value.value_bucket();
				value.value_polevault();
				value.value_sled();
				value.value_gargantuar();
				int decision[2] = {0, 0};
				value.make_decision(decision);

				// for (int i = 0; i < rows; i++)
				// {
				//     for (int j = 0; j < columns; j++)
				//     {
				//         int k = 0;
				//         while (Zombies[i][j][k] != -1)
				//         {
				//             // . . .
				//             k++;
				//         }
				//     }
				// }
				if (decision[0] != NOZOMBIE)
				{
					player->PlaceZombie((decision[0] > ZOMBIE_KIND ? NORMAL : decision[0]), decision[1] > ROW - 1 ? ROW - 1 : decision[1]);
				}
			}
			else
			{
				player->PlaceZombie(POLEVAULT, 1);
				player->PlaceZombie(NORMAL, 2);
				player->PlaceZombie(BUCKET, 3);
			}
		}
	}

} // namespace legacy_ai

#endif
/*** End of inlined file: LegacyAI.cpp ***/

class PlantLegacyAgent
{
public:
	Action getAction(GameState *game_state)
	{
		Action action;
		legacy_ai::player_ai(game_state->getPlayer());
		return action;
	}
};

static PlantLegacyAgent agent_plant;
/*** End of inlined file: PlantLegacyAgent.cpp ***/


/*** Start of inlined file: ZombieReflexAgent.cpp ***/
#include <algorithm>
#include <bitset>
#include <random>
#include <cstdlib>
#include <vector>
#include <utility>

#include <iostream>


/*** Start of inlined file: Debug.cpp ***/
#ifndef __DEBUG_CPP__
#define __DEBUG_CPP__

#include <iostream>
#include <string>
#include <vector>
#include <utility>

using namespace std;

const struct
{
	/**
	 * @brief Print a vector
	 *
	 * @tparam T The type of vector elements
	 * @param v The vector
	 * @param ending The ending string
	 */
	template <typename T>
	void log(vector<T> v, string ending = string("\n")) const
	{
		cout << "[";
		for (typename vector<T>::iterator iter = v.begin(); iter != v.end(); ++iter)
		{
			this->log(*iter, string("\0"));
			if (iter != v.end() - 1)
			{
				cout << ", ";
			}
		}
		cout << "]" << ending;
	}

	/**
	 * @brief Print a 2D vector
	 *
	 * @tparam T The type of vector elements
	 * @param v The vector
	 * @param ending The ending string
	 * @param row_ending The ending string of each row
	 */
	template <typename T>
	void log(vector<vector<T>> v, string ending = string("\n"), string row_ending = string("\n")) const
	{
		cout << "[";
		for (typename vector<T>::iterator iter = v.begin(); iter != v.end(); ++iter)
		{
			this->log(*iter, string("\0"));
			if (iter != v.end() - 1)
			{
				cout << "," << row_ending;
			}
		}
		cout << "]" << ending;
	}

	/**
	 * @brief Print a C style array
	 *
	 * @tparam T The type of array elements
	 * @param v The array
	 * @param n The number of elements to print
	 * @param ending The ending string
	 */
	template <typename T>
	void log(T *v, size_t n, string ending = string("\n")) const
	{
		cout << "[";
		for (size_t i = 0; i < n; ++i)
		{
			this->log(v[i], string("\0"));
			if (i != n - 1)
			{
				cout << ", ";
			}
		}
		cout << "]" << ending;
	}

	/**
	 * @brief Print a C style 2D array
	 *
	 * @tparam T The type of array elements
	 * @param v The array
	 * @param m The number of rows to print
	 * @param n The number of elements in a row to print
	 * @param ending The ending string
	 * @param row_ending The ending string of each row
	 */
	template <typename T>
	void log(T **v, size_t m, size_t n, string ending = string("\n"), string row_ending = string("\n")) const
	{
		cout << "[";
		for (size_t i = 0; i < n; ++i)
		{
			this->log(v[i], string("\0"));
			if (i != n - 1)
			{
				cout << "," << row_ending;
			}
		}
		cout << "]" << ending;
	}

	/**
	 * @brief Print a pair
	 *
	 * @tparam T1 The type of v.first
	 * @tparam T2 The type of v.second
	 * @param v The pair
	 * @param ending The ending string
	 */
	template <typename T1, typename T2>
	void log(pair<T1, T2> v, string ending = string("\n")) const
	{
		cout << "(" << v.first << ", " << v.second << ")" << ending;
	}

	/**
	 * @brief Print a plant
	 *
	 * @param v The plant
	 * @param ending The ending string
	 */
	void log(Plant v, string ending = string("\n")) const
	{
		cout << "Plant(spawn_time=" << v.getSpawnTime() << ", type=";
		if (v.getType() == PLANT.NOPLANT)
		{
			cout << "NOPLANT";
		}
		else if (v.getType() == PLANT.SUNFLOWER)
		{
			cout << "SUNFLOWER";
		}
		else if (v.getType() == PLANT.WINTERPEASHOOTER)
		{
			cout << "WINTERPEASHOOTER";
		}
		else if (v.getType() == PLANT.PEASHOOTER)
		{
			cout << "PEASHOOTER";
		}
		else if (v.getType() == PLANT.SMALLNUT)
		{
			cout << "SMALLNUT";
		}
		else if (v.getType() == PLANT.PEPPER)
		{
			cout << "PEPPER";
		}
		else if (v.getType() == PLANT.SQUASH)
		{
			cout << "SQUASH";
		}
		cout << ", position=(" << v.getPosition().x << ", "
			 << v.getPosition().y << "))" << ending;
	}

	/**
	 * @brief Print a zombie
	 *
	 * @param v The zombie
	 * @param ending The ending string
	 */
	void log(Zombie v, string ending = string("\n")) const
	{
		cout << "Zombie(spawn_time=" << v.getSpawnTime() << ", type=";
		if (v.getType() == ZOMBIE.NOZOMBIE)
		{
			cout << "NOZOMBIE";
		}
		else if (v.getType() == ZOMBIE.NORMAL)
		{
			cout << "NORMAL";
		}
		else if (v.getType() == ZOMBIE.BUCKET)
		{
			cout << "BUCKET";
		}
		else if (v.getType() == ZOMBIE.POLEVAULT)
		{
			cout << "POLEVAULT";
		}
		else if (v.getType() == ZOMBIE.SLED)
		{
			cout << "SLED";
		}
		else if (v.getType() == ZOMBIE.GARGANTUAR)
		{
			cout << "GARGANTUAR";
		}
		cout << ", position=(" << v.getRealPosition().x << ", "
			 << v.getRealPosition().y << "))" << ending;
	}

	/**
	 * @brief Print a value
	 *
	 * @tparam T The type of the value
	 * @param v The value
	 * @param ending The ending string
	 */
	template <typename T>
	void log(T v, string ending = string("\n")) const
	{
		cout << v << ending;
	}

	/**
	 * @brief Print an error value
	 *
	 * @tparam T The type of the error value
	 * @param e The error value
	 */
	template <typename T>
	void error(T e) const
	{
		throw e;
	}
} console;

#endif
/*** End of inlined file: Debug.cpp ***/

using namespace std;

class ZombieReflexAgent
{
protected:
	/* Paramters */
	// Parameters for getDifficultyScore()
	const double SCORE_TABLE_PLANT[7][10] = { // [slot][y]
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, -2, -4, -6, -8, -10},
		{40, 40, 40, 40, 40, 35, 30, 25, 20, 15},
		{10, 10, 10, 10, 10, 9, 8, 7, 6, 5},
		{1, 1, 1, 1, 1, 1, 2, 3, 4, 5},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1800, 1800, 1800, 1800, 1800, 1800, 1800, 2400, 3000, 3600}};

	const double SCORE_TABLE_ZOMBIE[6] = {0, 5.4, 41, 5.7, 30 + 10, 60}; // [slot]

	// Parameters for onEarlyStage()
	const vector<int> EARLY_ZOMBIE_PRIORITY = {ZOMBIE.BUCKET, ZOMBIE.POLEVAULT, ZOMBIE.NORMAL};

	// Parameters for onWaveStage()
	const vector<int> WAVE_ZOMBIE_PRIORITY = {ZOMBIE.GARGANTUAR, ZOMBIE.SLED, ZOMBIE.BUCKET};
	const int WAVE_PLACEMENT_GAP = 7;

	/* Class-wide variables for storaging data */
	int stage = -1;      // the stage of the game for choosing different logics
	int prev_stage = -1; // the previous stage
	Action *action = new Action();

	/**
	 * @brief Get the difficulty score
	 *
	 * @param game_state The game state
	 * @param row The row to judge
	 * @return double The difficulty score
	 */
	double getDifficultyScore(GameState *game_state, int row)
	{
		double score = 0.0;
		vector<Plant> plant_list = game_state->getPlantList(row);
		for (vector<Plant>::iterator it = plant_list.begin();
			 it != plant_list.end();
			 ++it)
		{
			score += SCORE_TABLE_PLANT[it->getType()][it->getPosition().y];
		}
		vector<Zombie> zombie_list = game_state->getZombieList(row);
		for (vector<Zombie>::iterator it = zombie_list.begin();
			 it != zombie_list.end();
			 ++it)
		{
			score -= SCORE_TABLE_ZOMBIE[it->getType()];
		}
		return score;
	}

	/**
	 * @brief Get the weakest rows
	 *
	 * @param game_state The game state
	 * @return vector<pair<int, double>> A list of (row, difficulty_score)
	 */
	vector<pair<int, double>> getWeakestRows(GameState *game_state)
	{
		/* Get available rows and sort by difficulty score */
		vector<pair<int, double>> difficulty_score;
		for (int i = 0; i <= 4; ++i)
		{
			if (!game_state->getBrokenLines()[i])
			{
				difficulty_score.push_back(pair<int, double>(i, this->getDifficultyScore(game_state, i)));
			}
		}
		auto cmp = [](pair<int, double> a, pair<int, double> b)
		{ return a < b; };
		sort(difficulty_score.begin(), difficulty_score.end(), cmp);
		return difficulty_score;
	}

	/**
	 * @brief Judge if it's the early stage of the game
	 *
	 * @param game_state The game state
	 * @return true if it's the early stage of the game
	 * @return false if it's not the early stage of the game
	 */
	bool judgeEarlyStage(GameState *game_state)
	{
		if (game_state->getTime() < 60 && game_state->getTime() > 2)
		{
			return true;
		}
		return false;
	}

	/**
	 * @brief Logic for early stage
	 *
	 * @param game_state The game state
	 */
	void onEarlyStage(GameState *game_state)
	{
		/* Static variables and their initializers */
		vector<pair<int, double>> weakest_rows = this->getWeakestRows(game_state);

		for (vector<pair<int, double>>::iterator it = weakest_rows.begin();
			 it != weakest_rows.end();
			 ++it)
		{
			if (!game_state->getZombieList(it->first).empty())
			{ // if there is a zombie in a row, skip the row
				continue;
			}

			for (vector<int>::const_iterator it1 = EARLY_ZOMBIE_PRIORITY.begin();
				 it1 != EARLY_ZOMBIE_PRIORITY.end();
				 ++it1)
			{
				if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE_COST[*it1] &&
					game_state->getCD(CAMP.ZOMBIE, *it1) == 0)
				{
					this->action->placeZombie(*it1, it->first);
					return;
				}
			}
		}
	}

	/**
	 * @brief Judge if a wave is ready or finished
	 *
	 * @param game_state
	 * @return true The wave is ready or ongoing
	 * @return false The wave is not ready
	 */
	bool judgeWaveStage(GameState *game_state)
	{
		// If boost stage is around the corner, exit wave stage
		if ((game_state->getTime() % 500 > 400 &&
			 game_state->getSun(CAMP.ZOMBIE) < 1000) || // to earn enough sun for boost stage
			game_state->getTime() % 500 < 20)
		{
			return false;
		}

		static bool is_ongoing = false;
		if (!is_ongoing && game_state->getSun(CAMP.ZOMBIE) > min(max(game_state->getTime(), 600), 1500))
		{
			is_ongoing = true;
		}
		else if (is_ongoing && game_state->getSun(CAMP.ZOMBIE) < 100)
		{
			is_ongoing = false;
		}
		return is_ongoing;
	}

	/**
	 * @brief Logic for early stage
	 *
	 * @param game_state The game state
	 */
	void onWaveStage(GameState *game_state)
	{
		/* Static variables and their initializers */
		static vector<int> target_row;  // the rows to attack
		static bool is_ongoing = false; // is the wave ongoing?

		// Clear static variables when entering the stage
		if (game_state->getSun(CAMP.ZOMBIE) > 1000 && !is_ongoing)
		{
			is_ongoing = true;
			target_row.clear();
		}
		if (game_state->getSun(CAMP.ZOMBIE) < 100)
		{
			is_ongoing = false;
		}

		/* Get available rows and sort by difficulty score */
		vector<pair<int, double>> weakest_rows = this->getWeakestRows(game_state);

		/* Get target rows */
		// Select target rows when entering a new stage
		if (target_row.empty())
		{
			for (int i = 0; i < min(2, static_cast<int>(weakest_rows.size())); ++i)
			{
				target_row.push_back(weakest_rows[i].first);
			}
		}

		// Remove broken rows
		for (vector<int>::iterator it = target_row.begin(); it != target_row.end();)
		{
			if (game_state->getBrokenLines()[*it])
			{
				it = target_row.erase(it);
			}
			else
			{
				++it;
			}
		}

		if (game_state->getTime() % WAVE_PLACEMENT_GAP == 0)
		{
			int sun_sum = 0;
			for (vector<int>::iterator it = target_row.begin();
				 it != target_row.end();
				 ++it)
			{
				for (vector<int>::const_iterator it1 = WAVE_ZOMBIE_PRIORITY.begin();
					 it1 != WAVE_ZOMBIE_PRIORITY.end();
					 ++it1)
				{
					if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE_COST[*it1] + sun_sum &&
						game_state->getCD(CAMP.ZOMBIE, *it1) == 0 &&
						!this->action->isSet(CAMP.ZOMBIE, *it1))
					{
						this->action->placeZombie(*it1, *it);
						sun_sum += ZOMBIE_COST[*it1];
						break;
					}
				}
			}
		}
	}

	/**
	 * @brief Judge if it's boost time
	 *
	 * @param game_state The game state
	 * @return true If it's boost time
	 * @return false If it's not boost time
	 */
	bool judgeBoostStage(GameState *game_state)
	{
		if (game_state->getTime() % 500 >= 490 ||
			(game_state->getTime() > 500 && game_state->getTime() % 500 < 10))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * @brief Logic for boost stage
	 *
	 * @param game_state The game stage
	 */
	void onBoostStage(GameState *game_state)
	{
		/* Static variables and their initializers */

		const int time = game_state->getTime();
		const vector<pair<int, double>> weakest_rows = this->getWeakestRows(game_state);

		if (time == 499)
		{
			if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE.GARGANTUAR &&
				game_state->getCD(CAMP.ZOMBIE, ZOMBIE.GARGANTUAR) == 0)
			{
				this->action->placeZombie(ZOMBIE.GARGANTUAR, weakest_rows[0].first);
			}
		}
		else if (time == 501)
		{
			int row = 0;
			for (vector<pair<int, double>>::const_iterator it = weakest_rows.begin();
				 it != weakest_rows.end();
				 ++it)
			{
				if (game_state->getZombieList(it->first, -1, ZOMBIE.GARGANTUAR).empty())
				{
					row = it->first;
				}
			}

			if (game_state->getSun(CAMP.ZOMBIE) >= ZOMBIE.GARGANTUAR &&
				game_state->getCD(CAMP.ZOMBIE, ZOMBIE.GARGANTUAR) == 0)
			{
				this->action->placeZombie(ZOMBIE.GARGANTUAR, row);
			}
		}
	}

public:
	Action getAction(GameState *game_state)
	{
		delete this->action;
		this->action = new Action();

		/* Get the current stage */
		this->prev_stage = this->stage;
		if (this->stage == -1)
		{ // if the last stage has been cleared
			vector<int> available_stages;
			if (this->judgeEarlyStage(game_state))
			{
				available_stages.push_back(0);
			}
			if (this->judgeWaveStage(game_state))
			{
				available_stages.push_back(1);
			}
			if (this->judgeBoostStage(game_state))
			{
				available_stages.push_back(2);
			}

			if (!available_stages.empty())
			{
				this->stage = available_stages[0];
			}
		}
		else
		{ // judge if it's time to clear the stage
			this->stage = (this->stage == 0 && !this->judgeEarlyStage(game_state)) ? -1 : this->stage;
			this->stage = (this->stage == 1 && !this->judgeWaveStage(game_state)) ? -1 : this->stage;
			this->stage = (this->stage == 2 && !this->judgeBoostStage(game_state)) ? -1 : this->stage;
		}

		switch (this->stage)
		{
		case 0:
			this->onEarlyStage(game_state);
			break;
		case 1:
			this->onWaveStage(game_state);
			break;
		case 2:
			this->onBoostStage(game_state);
			break;
		default:
			break;
		}

		return *(this->action);
	}
};

static ZombieReflexAgent agent_zombie;
/*** End of inlined file: ZombieReflexAgent.cpp ***/

using namespace std;

void player_ai(IPlayer *player)
{
	static Game *game = new Game(player);

	/* Start a new game when the camp swapped */
	if (player->Camp->getCurrentType() != game->getGameState()->getCamp())
	{
		delete game;
		game = new Game(player);
	}

	game->update(player);

	try
	{
		Action action;
		if (game->getGameState()->getCamp() == CAMP.PLANT)
		{
			action = agent_plant.getAction(game->getGameState());
		}
		else if (game->getGameState()->getCamp() == CAMP.ZOMBIE)
		{
			action = agent_zombie.getAction(game->getGameState());
		}

		game->applyAction(action);
	}
	catch (string e)
	{
		game->getGameState()->printTime();
		cerr << "[ERROR]<CAMP " << ((game->getGameState()->getCamp() == CAMP.PLANT) ? "Plant" : "Zombie") << ", Tick " << game->getGameState()->getTime() << "> " << e << endl << endl;
	}
}
