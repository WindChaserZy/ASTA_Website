#include "ai.h"
#include<iostream>
#include<time.h>
//选手代码在下方填入
//通用变量
int step;
int** Plants;
int*** Zombies;
int* plantcd;

//植物所需变量
int sun;
bool notbait=true;
int squash[5][3] = { {-1,-1,-1},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1} };
int ali[] = { 1,1,1,1,1 };
void sq_list_flush();

//僵尸所需变量
bool zombie_placement_done = true;
int zomtype = 0, target_line = 0;
int rand_seed;

void place_sunflower(IPlayer* p);
void execute(IPlayer* p, int l);
void execute_squash(IPlayer* p);
void plant_ice(IPlayer* p, int l);
void player_ai(IPlayer* player) {
    //收集通用信息
    int _my_camp = player->Camp->getCurrentType();
    Plants = player->Camp->getCurrentPlants();
    Zombies = player->Camp->getCurrentZombies();
    step = player->getTime();

    if (_my_camp == 0)  //植物方策略
    {   //调试
        //std::cout << "step" << step << ": ";
        //system("pause");

        //获取数据
        sun = player->Camp->getSun();
        plantcd = player->Camp->getPlantCD();
        //放向日葵
        place_sunflower(player);
        //逐行操作
        //std::cout << "start execution. ";
        for (int i = 0; i < 5; i++) {
            execute(player,i);
        }
    }
    if (_my_camp == 1)  //僵尸方
    {
        int moon = player->Camp->getSun();
        int mooncost[] = { 0,50,125,125,300,300 };
        int* zomcd = player->Camp->getPlantCD();
        //std::cout << "step " << step << ": ";
        //std::cout << "moon: " << moon << ": ";
        if (zombie_placement_done)  //添加放置新僵尸的计划
        {
            if (step == 1)
                rand_seed = 5;
            srand(rand_seed);
            zomtype = rand() % 5 + 1;
            if (step <= 500 && zomtype == 5)
                zomtype = 1;
            if (step <= 500 && zomtype == 4)
                zomtype = 3;
            rand_seed += step;
            srand(rand_seed);
            target_line = rand() % 5;
            rand_seed += step;
            zombie_placement_done = false;
            //std::cout << "try to place zombie" << zomtype << " at line" << target_line << " ";
        }
        if (!zombie_placement_done && moon >= mooncost[zomtype] && !zomcd[zomtype - 1])
        {
            player->PlaceZombie(zomtype, target_line);
            //std::cout << moon << ">=" << mooncost[zomtype] << ", zombie placed\n";
            zombie_placement_done = true;
        }
        //else
        //    std::cout << "\n";
    }
}
void place_sunflower(IPlayer* p)
{
    int* cd = p->Camp->getPlantCD();
    int** plants = p->Camp->getCurrentPlants();
    
    for (int i = 0; i < 5; i++) {
        bool x = true;
        if (plants[i][1] != 1 && cd[0] == 0 && sun >= 150) {
            for (int j = 0; j < 4; j++) {
                int c = 0;
                while (Zombies[i][j][c] != -1) {
                    x = false;
                    c++;
                }
            }
            if(x)
            p->PlacePlant(1, i, 1);
            plantcd[0] = 10;
            sun -= 50;
        }
    }
}
int pp[] = { 0,0,10,1,0,0,0 };
void execute(IPlayer* p, int l)
{
    int firepower = 0;
    firepower += pp[Plants[l][0]];
    firepower += pp[Plants[l][2]];
    firepower += pp[Plants[l][3]];
    int zoms[10][2] = { {0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0} };
    int barrier = 0;
    if (Plants[l][4] == 4 || Plants[l][5] == 4)
        barrier = 4000;

    for (int i = 0; i < 10; i++){//记录全部僵尸
        int c = 0;
        while (Zombies[l][i][c] != -1){
            for (int j = 0; j < 10; j++) {
                if (zoms[j][0] == 0) {
                    zoms[j][0] = Zombies[l][i][c];
                    zoms[j][1] = i;
                    break;
                }
            }
            c++;
        }
    }
    //std::cout << "zombies documented\n";
    //system("pause");
    for (int i = 0; i < 10; i++) {
        if (zoms[i][0] && zoms[i][1] == 4) {//僵尸逼近
            if (sun > 125 && plantcd[4] == 0 && zoms[1][0]) {//有四个僵尸，辣椒
                p->PlacePlant(5, l, 0);
                plantcd[4] = 60;
                sun -= 125;
            }
            else if (firepower < 10 && zoms[i][0] >1 && zoms[i][0] <4) {

                if (sun >= 500 && plantcd[1] == 0 && plantcd[3] == 0) {//放坚果寒冰
                    p->PlacePlant(4, l, 4);
                    plantcd[3] = 40;
                    sun -= 50;
                    //std::cout << "icenut. ";
                    plant_ice(p, l);
                    plantcd[1] = 30;
                    sun -= 400;
                }
                else{
                    for (int j = 0; j < 5; j++) {
                        //std::cout << "squash line" << l << " bucket. ";
                        if (squash[j][0] < 0) {//添加窝瓜砸事件
                            squash[j][0] = l; squash[j][1] = 2; squash[j][2] = 5;
                            break;
                        }
                    }
                    sq_list_flush();
                }

            }
            else{
                for (int j = 0; j < 5; j++) {
                    //std::cout << "squash line" << l << " bucket. ";
                    if (squash[j][0] < 0) {//添加窝瓜砸事件
                        squash[j][0] = l; squash[j][1] = 2; squash[j][2] = 5;
                        break;
                    }
                }
                sq_list_flush();
            }
        }
        if (zoms[i][0] && zoms[i][1] == 0) {//危
            if (Plants[l][0] == 0) {//要寄了
                if (sun > 125 && plantcd[4] == 0&&zoms[1][0]) {//有俩僵尸且够条件
                    p->PlacePlant(5, l, 0);
                    plantcd[4] = 60;
                    sun -= 125;
                }
                else if (sun > 50 && plantcd[5] == 0) {//能放窝瓜
                    p->PlacePlant(6, l, 0);
                    plantcd[5] = 60;
                    sun -= 50;
                }
                if (sun > 125 && plantcd[4] == 0) {//没有俩僵尸但也没窝瓜
                    p->PlacePlant(5, l, 0);
                    plantcd[4] = 60;
                    sun -= 125;
                }
                else {//寄了
                    ali[l] = 0;
                }
            }
        }
        if (zoms[i][0] && zoms[i][1] >= 8){//如果最右两格中有僵尸
            //std::cout <<"zombie,line"<<l<<", ";
            //system("pause");
            if (zoms[i][0] == 1 && firepower == 0) {//如果是单个普通僵尸进入无防御行
                //std::cout << "singlezom. ";
                p->PlacePlant(3, l, 0);
                if (sun >= 100 && plantcd[2] == 0){
                    plantcd[2] = 10;
                    sun -= 100;//放置成功
                    //std::cout << "shooter. ";
                }
            }
            if (zoms[i][0] == 1 && i==1 && firepower==1) {//跟随的僵尸，且火力不够
                //std::cout << "fellowzom. ";
                if (!barrier) {//如果没坚果
                    if (sun > 50 && plantcd[3] == 0) {//放坚果
                        p->PlacePlant(4, l, 4);
                        plantcd[3] = 40;
                        sun -= 50;
                        //std::cout << "nut. ";
                    }
                    else //放不了坚果
                    {
                        //std::cout << "寄 ";
                    }
                }                    
            }
            if (zoms[i][0] == 1 && i >= 2 && firepower <= 1) {//火力完全不够
                //std::cout << "zomwave. ";
                if (sun >= 500 && plantcd[1] == 0) {//能放寒冰就直接一步到位
                    plant_ice(p, l);
                    plantcd[1] = 30;
                    sun -= 400;
                    //std::cout << "ice. ";
                }
                else if (sun >= 100 && plantcd[2] == 0) {//不行就放豌豆
                    p->PlacePlant(3, l, 2);
                    plantcd[2] = 10;
                    sun -= 100;
                    //std::cout << "nshoot. ";
                }
                
            }
            if (zoms[i][0] == 3 && firepower <= 1) {//撑杆进入无/弱防御行
                //std::cout << "dpole. ";
                if (sun >= 500 && plantcd[1]==0)
                {
                    p->PlacePlant(2, l, 0);//有寒冰就放
                }
                else if(sun >= 100 && plantcd[2] == 0){//放不了寒冰
                    if(plantcd[0]==0)
                        p->PlacePlant(1, l, 6); //垫向日葵
                    p->PlacePlant(3, l, 0); //放豌豆
                    if (sun >= 100 && plantcd[2] == 0) {
                        plantcd[2] = 10;
                        sun -= 100;         //放置成功
                        //std::cout << "shooter. ";
                    }
                }
                else {
                    for (int j = 0; j < 5; j++) {
                        //std::cout << "squash line" << l << " bucket. ";
                        if (squash[j][0] < 0) {//添加窝瓜砸撑杆事件
                            squash[j][0] = l; squash[j][1] = 2; squash[j][2] = 2;
                            break;
                        }
                    }
                }
            }
            if (zoms[i][0] == 2 && firepower < 10) {//铁桶进入无/弱防御行
                //std::cout << "bucket. ";
                if (sun >= 500 && plantcd[1] == 0) {//能放寒冰就放
                    plant_ice(p, l);
                    
                    //std::cout << "ice. ";
                }
                else {//拿窝瓜砸
                    for (int j = 0; j < 5; j++) {
                        //std::cout << "squash line"<<l<<" bucket. ";
                        if (squash[j][0] < 0) {//添加窝瓜砸铁桶事件
                            squash[j][0] = l; squash[j][1] = 2; squash[j][2] = 1;
                            break;
                        }
                    }
                    sq_list_flush();
                }                    
            }
            if (zoms[i][0] == 4 && firepower < 12){
                for (int j = 0; j < 5; j++) {
                    //std::cout << "squash line" << l << " boni. ";
                    if (squash[j][0] < 0) {//添加窝瓜砸冰车事件
                        squash[j][0] = l; squash[j][1] = 4; squash[j][2] = 2;
                        break;
                    }
                }
                sq_list_flush();
            }
            if (zoms[i][0] == 5) {//巨人
                for (int j = 0; j < 5; j++) {
                    //std::cout << "squash line" << l << " giant. ";
                    if (squash[j][0] < 0) {//添加窝瓜砸巨人事件
                        squash[j][0] = l; squash[j][1] = 5; squash[j][2] = 2;
                        break;
                    }
                }
                sq_list_flush();
                if (firepower < 10)
                {
                    //std::cout << "too weak.";
                    if (sun >= 500 && plantcd[1] == 0) {//能放寒冰就放
                        plant_ice(p, l);
                        
                    }
                }
                else if (firepower < 11 && sun>=200 && plantcd[2]==0)//打巨人最好加个豌豆
                {
                    p->PlacePlant(3, l, 2);
                    plantcd[2] = 10;
                    sun -= 100;
                }
            }
        }
    }
    execute_squash(p);
    //std::cout << "execute finished\n";
    //system("pause");
}
void plant_ice(IPlayer* p, int l)
{
    if (Plants[l][0] == 0)
        p->PlacePlant(2, l, 0);
    else if (Plants[l][2] == 0)
        p->PlacePlant(2, l, 2);
    else if (Plants[l][0] == 1)
    {
        p->removePlant(l, 0);
        p->PlacePlant(2, l, 0);
        Plants[l][0] = 2;
    }
    plantcd[1] = 30;
    sun -= 400;
}
void sq_list_flush()
{
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5;j++) {
            if (squash[i][0] == squash[j][0]) {
                if (squash[i][2] <= squash[j][2])
                    squash[i][0] = -1;
                else
                    squash[j][0] = -1;
            }
        }
    }
}
void execute_squash(IPlayer* p)
{
    //std::cout << "\nsquash time: ";
    //system("pause");

    if (plantcd[5] || sun < 50) {
        //std::cout << "can't. ";
        return;
    }
    int targetl=-1, targetzom=0,urgency=0,pos = 0;
    //std::cout << "targets:";
    for (int i = 0; i < 5; i++)
    {
        //std::cout << squash[i][0] << squash[i][1] << squash[i][2] << " ";
        if (squash[i][0] >= 0 && squash[i][2]>urgency) {
            targetl = squash[i][0];
            targetzom = squash[i][1];
            pos = i;
        }
    }
    if (targetl == -1) {
       // std::cout << "no target.\n";
        return;
    }
    //std::cout << "target finish searching\n";
    //system("pause");
    for (int i = 0; i < 10; i++) {
        int c = 0;
        while (Zombies[targetl][i][c] != -1) {
            if (Zombies[targetl][i][c] == targetzom) {
                p->PlacePlant(6, targetl, i);
                //std::cout << "\nsquashed zombie" << targetzom << " at line" << targetl << "," << i << "\n";
                squash[pos][0] = -1;
            }
            c++;
        }
    }
    //std::cout << "squash try finished\n";
    //system("pause");
}