#include "ai.h"
#include <iostream>


float zombiePH(int m_type,int steps) {
    float PH=0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270;
            break;
        case 2:PH = 820;
            break;
        case 3: PH = 200;
            break;
        case 4:PH = 1600;
            break;
        case 5:PH = 3000;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: PH = 0;
            break;
        case 1:PH = 270 * steps / 1000;
            break;
        case 2:PH = 820 * steps / 1000;
            break;
        case 3: PH = 500 * steps / 1000;
            break;
        case 4:PH = 1350 * steps / 1000;
            break;
        case 5:PH = 3000 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return PH;
   
}

float zombiespeed(int m_type, int steps) {
    float speed = 0;
    if (steps <= 1000) {
        switch (m_type)
        {
        case 0: speed = 0;
            break;
        case 1:speed = 0.2;
            break;
        case 2:speed = 0.4;
            break;
        case 3: speed = 0.222;
            break;
        case 4:speed = 0.333;
            break;
        case 5:speed = 0.2;
            break;
        default:
            break;
        }
    }
    else {
        switch (m_type)
        {
        case 0: speed = 0 * steps / 1000;
            break;
        case 1:speed = 0.2 * steps / 1000;
            break;
        case 2:speed = 0.4 * steps / 1000;
            break;
        case 3: speed = 0.222 * steps / 1000;
            break;
        case 4:speed = 0.333 * steps / 1000;
            break;
        case 5:speed = 0.2 * steps / 1000;
            break;
        default:
            break;
        }
    }
    return speed;
}

int PlantAttack(int m_type) {
    switch (m_type)
    {
    case 0:return 0;
        break;
    case 1:return 0;
        break;
    case 2:return 20;
        break;
    case 3:return 10;
        break;
    case 4:return 0;
        break;
    case 5:return 1800;
        break;
    case 6:return 1800;
        break;
    default:
        break;
    }
}


void player_ai(IPlayer* player)
{
    int Type = player->Camp->getCurrentType();//获取植物方还是僵尸方
    int** Plants = player->Camp->getCurrentPlants();//获取当前植物情况（向日葵1，冰豌豆2，豌豆射手3，坚果4，辣椒5，倭瓜6）
    int*** Zombies = player->Camp->getCurrentZombies();//获取当前僵尸情况（普通1，铁通2，撑杆跳3，路障4，伽刚特尔5）
    int rows = player->Camp->getRows();//返回有几行
    int columns = player->Camp->getColumns();//返回有几列
    int sun = player->Camp->getSun();//当前阳光数
    int time = player->getTime();//当前step
    int* LeftLines = player->Camp->getLeftLines();//各行是否攻破，1为未攻破
    int* PlantCD = player->Camp->getPlantCD();//获取当前CD
    

    if (Type == 0) {//当前为植物方


    }
    else {//当前为僵尸方
        int i = 0;
        while (LeftLines[i] == 0) {
            i++;
        }
        if (sun >= 300 && PlantCD[4] == 0) {
            player->PlaceZombie(5, i);
            sun -= 300;
        }
        if (sun >= 200 && PlantCD[3] == 0) {
            player->PlaceZombie(4, i);
            sun -= 200;
        }
        if (sun >= 75 && PlantCD[2] == 0) {
            player->PlaceZombie(3, i);
            sun -= 75;
        }
        if (sun >= 125 && PlantCD[1] == 0) {
            player->PlaceZombie(2, i);
            sun -= 125;
        }
        if (sun >= 50 && PlantCD[0] == 0) {
            player->PlaceZombie(1, i);
            sun -= 50;
        }
    }
}
