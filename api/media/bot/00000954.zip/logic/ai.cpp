#include "ai.h"
#include <iostream>

int help = 0;
int offend = 0;
bool had_xueqiao[5] = {0};
bool detect_guaorjiao[5] = { 0 };
int had_jiagang[5] = { 0 };

int selecteded[3];
void updateplants(int,int,int ,int& ,int *, int **);

void player_ai(IPlayer * player) {
    int Type = player->Camp->getCurrentType(); //获取植物方还僵尸方
    int BrokenLinesScore = player->getBrokenLinesScore();
    int NotBrokenLinesNum = player->getNotBrokenLines();
    int KillPlantsScore = player->getKillPlantsScore();
    int KillZombiesScore = player->getKillZombiesScore();
    int LeftPlants = player->getLeftPlants();
    int Score = player->getScore();
    int time = player->getTime();
    int rows = player->Camp->getRows();
    int columns = player->Camp->getColumns();
    int* PlantCD = player->Camp->getPlantCD();
    int** Plants = player->Camp->getCurrentPlants();
    int*** Zombies = player->Camp->getCurrentZombies();
    int* LeftLines = player->Camp->getLeftLines();
    int Sun = player->Camp->getSun();
    if (Type == 0) {
        //当前为植物方，采取若干策略
        // if(time==1)
        // {
        //     selecteded[0]=-1;
        //     selecteded[1]=-1;
        //     selecteded[2]=-1;
        // }
        // int gargantuar[10]={0};
        // int sled[10]={0};
        // int polevault[10]={0};
        // int bucket[10]={0};
        // int normal[10]={0};
        // int zombienum[5]={0};
        // int zombieplace[5]={0};
        // int dangerplace[5]={0};
        // for(int i=0;i<rows;i++)
        // {
        //     int k=0;
        //     gargantuar[i]=0;
        //     sled[i]=0;
        //     polevault[i]=0;
        //     bucket[i]=0;
        //     normal[i]=0;
        //     zombienum[i]=0;
        //     zombieplace[i]=10;
        //     dangerplace[i]=11;
        //     for(int j=0;j<columns;j++)
        //     {
        //         k=0;
        //         while(Zombies[i][j][k]!=-1)
        //         {
        //             switch(Zombies[i][j][k])
        //             {
        //                 case 1:normal[i]++;break;
        //                 case 2:bucket[i]++;break;
        //                 case 3:polevault[i]++;break;
        //                 case 4:{
        //                     sled[i]++;
        //                     if(dangerplace[i]==11)
        //                     {
        //                         dangerplace[i]=j;
        //                     }
        //                     break;
        //                 }
        //                 case 5:{
        //                     gargantuar[i]++;
        //                     if(dangerplace[i]==11)
        //                     {
        //                         dangerplace[i]=j;
        //                     }
        //                     break;
        //                 }
        //                 default:break;
        //             }
        //             k++;
        //             zombienum[i]++;
        //         }
        //         if(zombieplace[i]==10&&Zombies[i][j][0]!=-1)
        //         {
        //             zombieplace[i]=j;
        //         }
        //     }
        // }
        /*for(int i=0;i<3;i++)
        {
            if(selecteded[i]>=0&&selecteded[i]!=6)
            {
                if(LeftLines[selecteded[i]]==0)
                selecteded[i]=6;
            }
            if(selecteded[i]==-1)
            {
                int min=-1;
                int minnum=20;
                for(int j=0;j<rows;j++)
                {
                    if(zombienum[j]<minnum&&zombieplace[j]>=4)
                    {
                        minnum=zombienum[j];
                        min=j;
                    }
                }
                if(min!=-1)
                {
                    if(zombienum[min]!=0)
                    {
                        if(((Sun>=550&&PlantCD[1]==0)||(Sun>=250&&PlantCD[2]==0))&&PlantCD[0]==0&&PlantCD[3]==0)
                        {
                            int j=0;
                            for(;j<5&&j<zombieplace[min];j++)
                            {
                                if(Plants[min][j]==0)
                                {
                                    if(PlantCD[1]==0)
                                    {
                                        player->PlacePlant(2,min,j);
                                        updateplants(2,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                    else{
                                        player->PlacePlant(3,min,j);
                                        updateplants(3,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            for(;j<5&&j<zombieplace[min];j++)
                            {
                                if(Plants[min][j]==0)
                                {
                                    player->PlacePlant(1,min,j);
                                    updateplants(1,min,j,Sun,PlantCD,Plants);
                                    break;
                                }
                            }
                            if(zombieplace[min]<5)
                            {
                                for(int k=zombieplace[min];k>j;k--)
                                {
                                    if(Plants[min][k]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            else 
                            {
                                for(int j=5;j<zombieplace[min];j++)
                                {
                                    if(Plants[min][j]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            selecteded[i]=min;
                        }
                        else if(Sun>=150&&PlantCD[0]==0&&PlantCD[3]==0)
                        {
                            int j=1;
                            for(;j<5&&j<zombieplace[min];j++)
                            {
                                if(Plants[min][j]==0)
                                {
                                    player->PlacePlant(1,min,j);
                                    updateplants(1,min,j,Sun,PlantCD,Plants);
                                    break;
                                }
                            }
                            if(zombieplace[min]<5)
                            {
                                for(int k=zombieplace[min];k>j;k--)
                                {
                                    if(Plants[min][k]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            else 
                            {
                                for(int j=5;j<zombieplace[min];j++)
                                {
                                    if(Plants[min][j]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            selecteded[i]=min;
                        }
                    }
                    else {
                        if(Sun>=150&&PlantCD[0]==0&&PlantCD[3]==0)
                        {
                            int j=1;
                            for(;j<5&&j<zombieplace[min];j++)
                            {
                                if(Plants[min][j]==0)
                                {
                                    player->PlacePlant(1,min,j);
                                    updateplants(1,min,j,Sun,PlantCD,Plants);
                                    break;
                                }
                            }
                            if(zombieplace[min]<5)
                            {
                                for(int k=zombieplace[min];k>j;k--)
                                {
                                    if(Plants[min][k]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            else 
                            {
                                for(int j=5;j<zombieplace[min];j++)
                                {
                                    if(Plants[min][j]==0)
                                    {
                                        player->PlacePlant(4,min,j);
                                        updateplants(4,min,j,Sun,PlantCD,Plants);
                                        break;
                                    }
                                }
                            }
                            selecteded[i]=min;
                        }
                    }
                }
            }
            else*/ 
        //     if(selecteded[i]<6)
        //     {
        //         int cur_row=selecteded[i];
        //         if (cur_row > 4 || cur_row < 0) cur_row = 0;
        //         if(sled[cur_row]+gargantuar[cur_row]>0)
        //         {
        //             int dangerpoint=dangerplace[cur_row];
        //             if(PlantCD[5]==0&&Sun>=100&&Plants[cur_row][dangerpoint]==0)
        //             {
        //                 player->PlacePlant(6,cur_row,dangerpoint);
        //                 updateplants(6,cur_row,dangerpoint,Sun,PlantCD,Plants);
        //             }
        //             else if(PlantCD[4]==0&&Sun>=175&&(Plants[cur_row][dangerpoint]||(dangerpoint-1>=0&&Plants[cur_row][dangerpoint-1])))
        //             {
        //                 for(int i=columns-1;i>=0;i--)
        //                 {
        //                     if(Plants[cur_row][i]==0)
        //                     {
        //                         player->PlacePlant(5,cur_row,dangerpoint);
        //                         updateplants(5,cur_row,dangerpoint,Sun,PlantCD,Plants);
        //                         break;
        //                     }
        //                 }
        //             }
        //         }
        //         bool pea=0,sunflower=0,nut=0;
        //         for(int j=0;j<5;j++)
        //         {
        //             if(Plants[cur_row][j]==1)
        //             sunflower=1;
        //             else if(Plants[cur_row][j]==2||Plants[cur_row][j]==3)
        //             pea=1;
        //         }
        //         for(int j=5;j<columns;j++)
        //         {
        //             if(Plants[cur_row][j]==4)
        //             nut=1;
        //         }
        //         if(!pea)
        //         {
        //             for(int j=0;j<5;j++)
        //             {
        //                 if(Plants[cur_row][j]==0)
        //                 {
        //                     if(Sun>=450&&PlantCD[1]==0)
        //                     {
        //                         player->PlacePlant(2,cur_row,j);
        //                         updateplants(2,cur_row,j,Sun,PlantCD,Plants);
        //                         break;
        //                     }
        //                     else if(Sun>=150&&PlantCD[2]==0)
        //                     {
        //                         player->PlacePlant(3,cur_row,j);
        //                         updateplants(3,cur_row,j,Sun,PlantCD,Plants);
        //                         break;
        //                     }
        //                     else break;
        //                 }
        //             }
        //         }
        //         if(!sunflower)
        //         {
        //             for(int j=0;j<5;j++)
        //             {
        //                 if(Plants[cur_row][j]==0)
        //                 {
        //                     if(Sun>=50&&PlantCD[0]==0)
        //                     {
        //                         player->PlacePlant(1,cur_row,j);
        //                         updateplants(1,cur_row,j,Sun,PlantCD,Plants);
        //                         break;
        //                     }
        //                     else break;
        //                 }
        //             }
        //         }
        //         if(!nut)
        //         {
        //             for(int j=5;j<columns;j++)
        //             {
        //                 if(Plants[cur_row][j]==0)
        //                 {
        //                     if(Sun>=100&&PlantCD[3]==0)
        //                     {
        //                         player->PlacePlant(4,cur_row,j);
        //                         updateplants(4,cur_row,j,Sun,PlantCD,Plants);
        //                         break;
        //                     }
        //                     else break;
        //                 }
        //             }
        //         }
        //     }
        // }
        // int sfnum[3]={0,0,0},peanum[3]={0,0,0},nutnum[3]={0,0,0};
        // for(int i=0;i<3;i++)
        // {
        //     if(selecteded[i]!=-1&&selecteded[i]!=6)
        //     {
        //         int cur_row=selecteded[i];
        //         for(int j=0;j<5;j++)
        //         {
        //             if(Plants[cur_row][j]==1)
        //             {
        //                 sfnum[i]++;
        //             }
        //             else if(Plants[cur_row][j]==2||Plants[cur_row][j]==3)
        //             {
        //                 peanum[i]++;
        //             }
        //         }
        //         for(int j=5;j<columns;j++)
        //         {
        //             if(Plants[cur_row][j]==4)
        //             nutnum[i]++;
        //         }
        //     }
        // }
    }
    if (Type == 1) {
        // //当前为僵尸方,采取若干策略
        // // 扫描当前大致情况
        // int wandou[5] = {9999,9999,9999,9999,9999};
        // int hanbin[5]={9999,9999,9999,9999,9999};
        // int jianguo[5]={9999,9999,9999,9999,9999};
        // int wogua[5]={9999,9999,9999,9999,9999};
        // int xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        // double weighted_average_qianqi[5]={9999,9999,9999,9999,9999};
        // double weighted_average_zhongqi_xiangrikui[5] = { 9999,9999,9999,9999,9999 };
        // double weighted_average_zhongqi[5] = { 9999,9999,9999,9999,9999 };
        // bool need_attack[5]={1,1,1,1,1};
        // for(int i = 0; i<rows; ++i){
        //     if(LeftLines[i] == 0 || Zombies[i][0][0] != -1){
        //         need_attack[i] = false;
        //     }
        // }
        // for (int i = 0; i < rows; ++i) {
        //     if (!need_attack[i]) continue;
        //     wandou[i] = 0;
        //     hanbin[i] = 0;
        //     jianguo[i] = 0;
        //     wogua[i] = 0;
        //     xiangrikui[i] = 0;
        // }
        // for(int i = 0; i < rows; ++i){
        //     if(!need_attack[i]) continue;
        //     for(int j = 0; j<columns; ++j){
        //         if(Plants[i][j]==2) hanbin[i]++;
        //         if(Plants[i][j]==3) wandou[i]++;
        //         if(Plants[i][j]==4) jianguo[i]++;
        //         if(Plants[i][j]==6) wogua[i]++;
        //         if (Plants[i][j] == 1) xiangrikui[i]++;
        //     }
        // }
        // int min_wandou = 999, min_wandou_i=-1;
        // int min_hanbin = 999, min_hanbin_i=-1;
        // int min_jianguo = 999, min_jianguo_i=-1;
        // int max_xiangrikui = 0, max_xiangrikui_i = -1;
        // double min_weighted_average_qianqi = 999; 
        // int min_weighted_average_qianqi_i = -1;
        // double min_weighted_average_zhongqi_xiangrikui = 999;
        // int min_weighted_average_zhongqi_xiangrikui_i = -1;
        // double min_weighted_average_zhongqi = 999;
        // int min_weighted_average_zhongqi_i = -1;
        // for(int i = 0; i<rows; ++i){
        //     if(!need_attack[i])  continue;
        //     if(wandou[i]<min_wandou){
        //         min_wandou = wandou[i];
        //         min_wandou_i = i;
        //     }
        //     if (hanbin[i] < min_hanbin) {
        //         min_hanbin = hanbin[i];
        //         min_hanbin_i = i;
        //     }
        //     if (jianguo[i] < min_jianguo) {
        //         min_jianguo = jianguo[i];
        //         min_jianguo_i = i;
        //     }
        //     // warning：当前估值函数，以及后续采用的阈值为大致估计，需结合实战回访重新制定
        //     weighted_average_qianqi[i] = 1.0 * wogua[i] + 0.6 * hanbin[i] + 0.3 * jianguo[i] + 0.1 * wandou[i];
        //     if (weighted_average_qianqi[i] < min_weighted_average_qianqi) {
        //         min_weighted_average_qianqi = weighted_average_qianqi[i];
        //         min_weighted_average_qianqi_i = i;
        //     }
        //     weighted_average_zhongqi_xiangrikui[i] = 0.5 * wogua[i] + 0.5 * hanbin[i] + 0.3 * jianguo[i] + 0.7 * xiangrikui[i];
        //     if (weighted_average_zhongqi_xiangrikui[i] < min_weighted_average_zhongqi_xiangrikui) {
        //         min_weighted_average_zhongqi_xiangrikui = weighted_average_zhongqi_xiangrikui[i];
        //         min_weighted_average_zhongqi_xiangrikui_i = i;
        //     }
        //     weighted_average_zhongqi[i] = 0.5 * wogua[i] + 0.7 * hanbin[i] + 0.3 * jianguo[i] ;
        //     if (weighted_average_zhongqi[i] < min_weighted_average_zhongqi) {
        //         min_weighted_average_zhongqi = weighted_average_zhongqi[i];
        //         min_weighted_average_zhongqi_i = i;
        //     }
        //     if (xiangrikui[i] >= max_xiangrikui) {
        //         max_xiangrikui = xiangrikui[i];
        //         max_xiangrikui_i = i;
        //     }
        // }

        // // 检查当前僵尸状况
        // int zombies[5] = { 0,0,0,0,0 };
        // int tietong[5] = { 0,0,0,0,0 };
        // int chenggan[5] = { 0,0,0,0,0 };
        // int xueqiao[5] = { 0,0,0,0,0 };
        // int jiagang[5] = { 0,0,0,0,0 };
        // double all_zombies[5] = { 0,0,0,0,0 };
        // for (int i = 0; i < rows; ++i) {
        //     if (!need_attack[i]) continue;
        //     for (int j = 0; j < columns; ++j) {
        //         for (int k = 0; Zombies[i][j][k] != -1; ++k) {
        //             if (Zombies[i][j][k] == 1) zombies[i]++;
        //             if (Zombies[i][j][k] == 2) tietong[i]++;
        //             if (Zombies[i][j][k] == 3) chenggan[i]++;
        //             if (Zombies[i][j][k] == 4) xueqiao[i]++;
        //             if (Zombies[i][j][k] == 5) jiagang[i]++;
        //         }
        //     }
        //     all_zombies[i] = 0.1*zombies[i] + 0.3*tietong[i] + 0.2*chenggan[i] + 0.5*xueqiao[i] + 0.9*jiagang[i];
        // }
        
        // // 前期策略（单线程版本，warning：需升级至双线程版本）
        // int target = min_weighted_average_qianqi_i;
        // if (target == -1) return;
        // if (time <= 200 && target != -1 && weighted_average_qianqi[target] <1) {  
        //     if (zombies[target] == 0) {  // 放置普通僵尸
        //         if (PlantCD[1] == 0 && Sun >= 200)player->PlaceZombie(1, target);
        //     }
        //     if (tietong[target] == 0 && Zombies[target][0][0] == -1) {
        //         if (weighted_average_qianqi[target] > 0.3) { // 视情况放置铁桶僵尸，warning：单线程模式下大概率无法触发此条件
        //             if (PlantCD[1] == 0 && Sun >= 200)player->PlaceZombie(2, target);
        //         }
        //     }
        //     else if (Zombies[target][columns - 1][0] == -1) { // 根据场上情况补充僵尸，以攻击力植物为导向
        //         if (weighted_average_qianqi[target] > 0.1 && weighted_average_qianqi[target]<=0.5) {
        //             if ((tietong[target] + zombies[target]) <= wandou[target]+1 || (tietong[target] + zombies[target]) <= (hanbin[target] + 2)) {
        //                 if (PlantCD[0] == 0 && Sun >= 50)player->PlaceZombie(1, target);
        //             }
        //         }
        //     }
        // }
        // // 中期策略（当前版本下，中间存在500-600回合的空档期，用以积累阳光，
        // // warning：植物方若以僵尸为导向布置植物，会出现同步空档；若以发展为导向，则会致使植物方在此阶段获得较好发展，后期攻击难度增大
        
        // if (target == -1) return;
        // if ((time > 200 && time <= 500) || (time >600 && time <= 800) || weighted_average_qianqi[target] >= 1) {
        //     target = min_weighted_average_zhongqi_i;
        //     if (Sun <= 500 && (time-offend)>10) { // 阳光较小的情况下用普通僵尸/铁桶僵尸尝试攻击，warning：攻击间隔和攻击逻辑有争议，可能无法有效积蓄阳光，且大概率率为无效攻击
        //         if (weighted_average_zhongqi[target]<0.6 && (time - offend) >= 75 && ((tietong[target] + zombies[target]) <= wandou[target] || (tietong[target] + zombies[target]) <= (hanbin[target] + 2))) {
        //             player->PlaceZombie(1, target);
        //             offend = time;
        //         }
        //     }
        //     // 尝试用伽刚特尔+铁桶的模式进行攻击，warning：存在被火爆辣椒+倭瓜解围的风险
        //     if (help != 0) {
        //         if (jiagang[help] == 0 && Zombies[help][0][0] == -1) {
        //             player->PlaceZombie(2, help);
        //             help = 0;
        //         }
        //     }
        //     if (Sun >= 500) {
        //         if ((target - 1) >= 0 && need_attack[target]) {
        //             // 在旁路放置铁桶吸引植物方注意，消耗植物方阳光，warning：此操作未必能起到设计效果，存在浪费月光的可能
        //             if(weighted_average_zhongqi[target-1] <= 0.5) player->PlaceZombie(2, target - 1);
        //             if (Zombies[target - 1][0][0] == -1) {
        //                 if (PlantCD[4] == 0) {
        //                     if((jiagang[target] == 0)||(jiagang[target]>0 && weighted_average_zhongqi[target]>0.7))player->PlaceZombie(5, target);
        //                     help = target;
        //                 }
        //             }
        //         }
        //         else {
        //             if (weighted_average_zhongqi[target + 1] <= 0.5)player->PlaceZombie(2, target + 1);
        //             if (Zombies[target + 1][0][0] == -1) {
        //                 if (PlantCD[4] == 0) {
        //                     if ((jiagang[target] == 0) || (jiagang[target] > 0 && weighted_average_zhongqi[target] > 0.7))player->PlaceZombie(5, target);
        //                     help = target;
        //                 }
        //             }
        //         }

        //     }
        // }
        // // 中后期 （向日葵为导向的攻击模式）
        // target = max_xiangrikui_i;
        // if (target == -1) return;
        // if (time > 800 &&  time <= 1200) {
        //     for (int j = 0; j < columns; ++j) {
        //         if (Plants[target][j] == 5 || Plants[target][j] == 6) {
        //             detect_guaorjiao[target] == true;
        //             break;
        //         }
        //     }
        //     if (Sun > 500 && (time - offend) > 10) {
        //         if (weighted_average_zhongqi[target] <= 0.8 ) {  // 低攻击难度下的，采用普僵/铁桶的攻击模式
        //             player->PlaceZombie(2, target);
        //             if (weighted_average_zhongqi[target] >= 0.6) {
        //                 player->PlaceZombie(1, target);
        //             }
        //             offend = time;
        //         }
        //         else if((time-offend) > 10) {  
        //             // 高攻击难度下的，采用雪橇+伽刚的攻击模式，采用雪橇的目的是骗取火爆辣椒/倭瓜，
        //             // warning：雪橇血量小于倭瓜/火爆辣椒，该操作疑似无法有效辅助伽刚攻击，采用双伽刚可能为更好策略
        //             if (!had_xueqiao[target]) {
        //                 player->PlaceZombie(4, target);
        //                 had_xueqiao[target] = true;
        //             }
        //             int location_jiagang = -1; // 获取当前伽刚位置
        //             int location_xueqiao = -1;
        //             for (int j = 0; j < columns; ++j) {
        //                 for (int k = 0; Zombies[target][j][k] != -1; ++k) {
        //                     if (location_jiagang==-1 && Zombies[target][j][k] == 5) {
        //                         location_jiagang = j;
        //                     }
        //                     if (location_xueqiao == -1 && Zombies[target][j][k] == 4) {
        //                         location_xueqiao = j;
        //                     }
        //                 }
        //                 if (location_jiagang != -1 && location_xueqiao != -1) break;
        //             }
        //             if ((xueqiao[target] == 0 && had_xueqiao[target]) || (detect_guaorjiao[target] == true && Zombies[target][0][0] == -1 && had_jiagang[target] <= 2)) {
        //                 player->PlaceZombie(5, target);
        //                 had_jiagang[target] ++;
        //             }
        //         }
        //     }
        // }
        // // 后期

    }
}
void updateplants(int type,int x,int y,int& a,int *b,int **c)
{
    switch(type)
    {
        case 0:c[x][y]=0;break;
        case 1:a-=50;b[0]=10;c[x][y]=1;break;
        case 2:a-=400;b[1]=30;c[x][y]=2;break;
        case 3:a-=100;b[2]=10;c[x][y]=3;break;
        case 4:a-=50;b[3]=40;c[x][y]=4;break;
        case 5:a-=125;b[4]=60;c[x][y]=5;break;
        case 6:a-=50;b[5]-=60;c[x][y]=6;break;
        default:break;
    }
}