#include"ai.h"
#include <iostream> 
#include <stdlib.h>
int zb[6] = { 0,270,820,200,1600,3000 };
int chooseplant[6] = { 1,1,2,1,3,4};
int begin[4] = { 1,4,1,3 };
int choosezombie[12] = { 1,2,3,2,5,4,5,5,4,5,5,2};
int placex = -1;
int placey = -1;
int forceat = -1;
int protect[5];
int need[5];

int zombiePH(int m_type) {
	switch (m_type)
	{
	case 0: return 0;
		break;
	case 1:return 270;
		break;
	case 2:return 1370;
		break;
	case 3: return 500;
		break;
	case 4:return 1350;
		break;
	case 5:return 3000;
		break;
	default:
		break;
	}
}

int PlantAttack(int m_type) {
	switch (m_type)
	{
	case 0:return 0;
		break;
	case 1:return 0;
		break;
	case 2:return 26;
		break;
	case 3:return 20;
		break;
	case 4:return 0;
		break;
	case 5:return 1800;
		break;
	case 6:return 1800;
		break;
	default:
		break;
	}
}

int pdetr(IPlayer* player, int row)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	for (int j = 0;j < 10;j++)
	{
		int k = 0;
		while (Zombies[row][j][k] != -1)
			k++;
		ans += k;
	}
	return ans;
}
int pdetsp(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		ans += zb[Zombies[row][col][k]];
		k++;
	}
	return ans;
}

int search1(IPlayer* player)
{
	int decide_row = 0;
	int rowzombie = pdetr(player, 0);
	for (int i = 1;i <= 4;i++)
	{
		if (pdetr(player, i) < rowzombie)
		{
			rowzombie = pdetr(player, i);
			decide_row = i;
		}
	}
	return decide_row;
}

void procheck(IPlayer* player, int row)
{
	int** Plants = player->Camp->getCurrentPlants();
	for (int i = 0;i <= 9;i++)
	{
		if (Plants[row][i] == 4)
		{
			protect[row] = 1;
			return;
		}	
	}
	protect[row] = 0;
	return;
}
int search4(IPlayer* player)
{
	for (int i = 0;i < 5;i++)
		if (protect[i] == 0 && need[i] != 0)return i;
	return -1;
}
int iss(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 4)return 1;
		k++;
	}
	return 0;
}
int isj(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 5)return 1;
		k++;
	}
	return 0;
}

void checkneed(IPlayer* player)
{
	int** Plants = player->Camp->getCurrentPlants();
	
	for (int i = 0;i < 5;i++)
	{
		need[i] = 0;
		for (int j = 0;j < 10;j++)
			need[i] += Plants[i][j];
	}
	return;
}
void player_ai(IPlayer* player)
{
	// int Type = player->Camp->getCurrentType();
	// int time = player->getTime();
	// int Sun = player->Camp->getSun();
	// int** Plants = player->Camp->getCurrentPlants();
	// int* LeftLines = player-> Camp -> getLeftLines();

	// checkneed(player);

	// for (int i = 0;i < 5;i++)
	// {
	// 	if (LeftLines[i] == 1)forceat = i;
	// }
	// if (Type == 0)
	// {
	// 	if (placex != -1 && placey != -1)
	// 	{
	// 		player->PlacePlant(2, placex, placey);
	// 		placex = -1;
	// 		placey = -1;
	// 	}
	// 	srand(time);
	// 	//当 前 为 植 物方 
	// 	for (int i = 0;i < 5;i++)
	// 	{			
	// 		for (int j = 0;j < 10;j++)
	// 		{
	// 			if ((pdetr(player, i) >= 3||(pdetsp(player, i, j) >= 300 && j <=4))&&(time>200))
	// 				player->PlacePlant(5, i, 9);
	// 			if (pdetsp(player, i, j) >= 1000||(pdetsp(player, i, j) >= 100&&j<=5))
	// 			{
	// 					player->PlacePlant(6, i, j-1);
	// 			}
	// 		}
	// 	}

	// 	int thechosen;
	// 	if(time<=200)
	// 		thechosen = begin[rand() % 4];
	// 	else
	// 		thechosen = chooseplant[rand() % 6];

	// 	if (thechosen == 1&&time<=500)
	// 		player->PlacePlant(1, search1(player), rand()%2+1);
	// 	if (thechosen == 1 && time > 500)
	// 		player->PlacePlant(1, rand() % 5, 4);
	// 	if (thechosen == 2&&Sun>500)
	// 	{
	// 		if (placex==-1&&placey==-1)
	// 		{
	// 			placex = rand() % 5;
	// 			if (time <= 1000)
	// 				placey = rand() % 4;
	// 			else
	// 				placey = rand() % 5;
	// 			if(Plants[placex][placey]!=2&&(Plants[placex][placey] != 4))
	// 			player->removePlant(placex, placey);
	// 			if((Plants[placex][placey] == 4)&&time>700)
	// 			player->removePlant(placex, placey);
	// 		}
	// 	}
	// 	if (thechosen == 3)
	// 	{
	// 		if (time <= 500)
	// 			player->PlacePlant(3, rand() % 5, 0);
	// 		else
	// 			player->PlacePlant(3, rand() % 5, rand() % 5);
	// 	}
			
	// 	if (thechosen == 4)
	// 	{
	// 		for (int i = 0;i < 5;i++)
	// 			procheck(player,i);
	// 		if (search4(player) != -1)
	// 			player->PlacePlant(4, search4(player), 5);
	// 		else
	// 			player->PlacePlant(4, rand() % 5, rand() % 2 + 6);
	// 	}
	// 	//player->PlacePlant(3, rand() % 5, rand() % 4);

	// }
	// if (Type == 1)
	// {
	// 	srand(time);
	// 	if(time<=250)
	// 	player->PlaceZombie(choosezombie[rand() % 5], rand() % 5);
	// 	if(time<=500)
	// 	player->PlaceZombie(choosezombie[rand() % 4+3], rand() % 5);
	// 	else
	// 	{
	// 		player->PlaceZombie(choosezombie[rand() % 7+5], forceat);
	// 	}
	// }
	// return;
}