#include"ai.h"
#include <iostream> 
#include <stdlib.h>
extern"C" _declspec (dllexport)
int zb[5] = { 270,820,200,1600,3000 };
int chooseplant[4] = { 1,3,4 };
int choosezombie[2] = { 2,5 };


int zombiePH(int m_type) {
	switch (m_type)
	{
	case 0: return 0;
		break;
	case 1:return 270;
		break;
	case 2:return 1370;
		break;
	case 3: return 500;
		break;
	case 4:return 1350;
		break;
	case 5:return 3000;
		break;
	default:
		break;
	}
}

int PlantAttack(int m_type) {
	switch (m_type)
	{
	case 0:return 0;
		break;
	case 1:return 0;
		break;
	case 2:return 26;
		break;
	case 3:return 20;
		break;
	case 4:return 0;
		break;
	case 5:return 1800;
		break;
	case 6:return 1800;
		break;
	default:
		break;
	}
}

int pdetr(IPlayer* player, int row)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	for (int j = 0;j < 9;j++)
	{
		int k = 0;
		while (Zombies[row][j][k] != -1)
			k++;
		ans += k;
	}
	return ans;
}
int pdetsp(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		k++;
		ans += zb[Zombies[row][col][k]];
	}
	return ans;
}
int iss(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 3)return 1;
		k++;
	}
	return 0;
}
int isj(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 4)return 1;
		k++;
	}
	return 0;
}
/*void zdet(IPlayer* player)
{

}*/
void player_ai(IPlayer* player)
{
	int Type = player->Camp->getCurrentType();
	int time = player->getTime();
	if (Type == 0)
	{
		srand(time);
		//当 前 为 植 物方 
			/*for (int i = 0;i<5;i++)
				for (int j = 0;j < 8;j++)
				{
					if (pdetsp(player, i, j) >= 1600)
					{
						if (iss(player,i,j) == 1)
						{

						}

					}
				}*/
		int thechosen = chooseplant[rand() % 3];
		if (thechosen == 1)
			player->PlacePlant(1, rand() % 5, rand() % 2 + 2);
		if (thechosen == 3)
			player->PlacePlant(3, rand() % 5, rand() % 2);
		if (thechosen == 4)
			player->PlacePlant(4, rand() % 5, rand() % 2 + 4);

	}
	if (Type == 1)
	{
		srand(time);
		player->PlaceZombie(choosezombie[rand() % 2], rand() % 5);

		//当 前 为 僵 尸方 
	}
}