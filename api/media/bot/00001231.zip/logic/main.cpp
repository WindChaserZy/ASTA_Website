#include "ai.h"
#include "Interface.h"
#include "../json/json.h"
#include <iostream>

int main(){
    ios::sync_with_stdio(false);
    string dataString;
    cin >> dataString;
    Json::Reader reader;
    Json::Value dataJson;
    reader.parse(dataString.data(), dataJson);
    
    ICamp camp(dataJson["Camp"]);
    IPlayer player(dataJson["Player"], &camp);
    player_ai(&player);

    Json::FastWriter write;
    cout << write.write(player.action);
    return 0;
}