#include "ai.h"
#include<iostream>

bool beginPlace[5] = { false,false,false,false,false };
int totalFlowerNum = 0;
int totalPeaNum = 0;
int totalNutNum = 0;
int totalPumpkinNum = 0;

int nutRow = -1;
int pumpkinRow = -1;

int rowBegin[5] = { 0 };

bool isPea = false;
bool isNut = false;
bool isPumpkin = false;
bool isFlower = false;

bool sameRow = false;

int place1[5] = { 0 };

int currentTime1 = 0;

int status = 0;

void player_ai(IPlayer* player)
{
    int rows = player->Camp->getRows();//获取当前行数
    int columns = player->Camp->getColumns();//获取当前列数
    int* leftLines = player->Camp->getLeftLines();
    int leftRows = 0;
    for (int i = 0; i < rows; i++)
    {
        if (leftLines[i] != 0)
        {
            leftRows += 1;
        }
    }
#pragma region GameStatus
    int plantNum = 0;
    bool isPlant = false;//判断场上是否有植物存在
    bool isZombie = false;//判断场上是否有僵尸存在
    bool isfull = false;//判断当前扫描地图格上是否都存在植物
    int producerow = 1;//判断生产行是第几行
    int count = 0;//控制producerow不变的量
    int sb = 0;
#pragma endregion

#pragma region Interface
    //int* PlantCD = player->Camp->getPlantCD();//获取当前植物CD
    int time = player->getTime();//获得当前回合数
    int type = player->Camp->getCurrentType();//获得当前玩家类型

#pragma endregion

    int** plants = player->Camp->getCurrentPlants();//当前植物情况二维数组
    int*** zombies = player->Camp->getCurrentZombies();//当前僵尸情况三维数组

    //以下声明了很多个一维数组，用以计算某一行每种植物或僵尸数量，进而寻求对某一行的最优解
    int rowPlantNum[5] = { 0 };//植物总数
    int rowZombieNum[5] = { 0 };//僵尸总数

    int rowPeaNum[5] = { 0 };//豌豆射手总数

    int rowIceNum[5] = { 0 };//冰豌豆射手行数
    int columnIceNum[10] = { 0 };//冰豌豆射手列数

    int rowPumpkinNum[5] = { 0 };//倭瓜行数
    int columnPumpkinNum[10] = { 0 };//倭瓜列数

    int rowNutNum[5] = { 0 };//坚果总数

    int rowFlowerNum[5] = { 0 };//向日葵行数
    int columnFlowerNum[10] = { 0 };//向日葵列数

    int totalFlowerNum = 0;//向日葵总数

    //遍历植物二维数组计算每行植物数组对应的数量
    //先行后列遍历
    for (int i = 0; i < rows; i++)
    {

        for (int j = 0; j < columns; j++)
        {
            if (plants[i][j] != 0)
            {
                rowPlantNum[i] += 1;
                plantNum++;
            }
            if (plants[i][j] == 1)//向日葵
            {
                rowFlowerNum[i] += 1;
                totalFlowerNum++;
            }
            if (plants[i][j] == 2)//冰豌豆
            {
                rowIceNum[i] += 1;
                
            }
            if (plants[i][j] == 3)//豌豆
            {
                rowPeaNum[i] += 1;
                totalPeaNum += 1;
            }
            if (plants[i][j] == 6)//火爆辣椒
            {
                rowPumpkinNum[i] += 1;
                totalPumpkinNum += 1;
            }
            if (plants[i][j] == 4)//坚果
            {
                rowNutNum[i] += 1;
                totalNutNum += 1;
            }
        }
    }
    //先列后行遍历
    for (int i = 0; i < columns; i++)
    {
        for (int j = 0; j < rows; j++)
        {
            if (plants[j][i] == 1)//向日葵
            {
                columnFlowerNum[i] += 1;
            }
            if (plants[j][i] == 2)//冰豌豆
            {
                columnIceNum[i] += 1;

            }
            if (plants[j][i] == 6)//倭瓜
            {
                columnPumpkinNum[i] += 1;
            }
        }
    }

    for (int i = 0; i < rows; i++)//   遍历僵尸,得到各行的僵尸总数
    {
        for (int j = 0; j < columns; j++)
        {
            int k = 0;
            while (zombies[i][j][k] != -1)
            {
                rowZombieNum[i]++;
                k++;
            }
        }
    }

    //植物方操作
    if (type == 0)
    {
        int Sun = player->Camp->getSun();
        bool sunSupply = Sun > 600;
        int* PlantCD = player->Camp->getPlantCD();

        for (int i = 0; i <= 5; i++) 
        {
            PlantCD = player->Camp->getPlantCD();
        }

        for (int i = 0; i < rows; i++)
        {
            if (time >= 70)
            {
                if (rowZombieNum[i] == 0)
                {
                    if (columnPumpkinNum[7] < leftRows)
                    {
                        if (plants[i][7] != 6)
                        {
                            player->removePlant(i, 7);
                            player->PlacePlant(6, i, 7);
                        }
                    }
                    else if (columnPumpkinNum[8] < leftRows)
                    {
                        if (plants[i][8] != 6)
                        {
                            player->removePlant(i, 8);
                            player->PlacePlant(6, i, 8);
                        }
                    }
                    else if (columnPumpkinNum[9] < leftRows)
                    {
                        if (plants[i][9] != 6)
                        {
                            player->removePlant(i, 9);
                            player->PlacePlant(6, i, 9);
                        }
                    }
                }
            }
            /*
            if (sunSupply>600&&sunSupply<1000)
            {
                if (rowZombieNum[i] == 1)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];  //向日葵1，冰豆2，豌豆3，坚果墙4，辣椒5，倭瓜6
                            break;                      //  普僵1，铁桶2，撑杆3，冰车4，伽刚5
                        }
                    }
                    if (zomPosition <= 4)        //僵尸较近时，用倭瓜
                    {
                        if (PlantCD[6] == 0)
                        {
                            player->PlacePlant(6, i, zomPosition - 1);
                            player->PlacePlant(6, i, zomPosition);
                            player->PlacePlant(6, i, zomPosition - 2);
                        }
                        else
                        {
                            player->PlacePlant(5, i, 0);
                            player->PlacePlant(5, i, 1);
                            player->PlacePlant(5, i, 2);
                        }
                    }
                    else if (zomType == 1)       //普通僵尸，用坚果墙，开始攒阳光
                    {
                        player->PlacePlant(4, i, zomPosition - 1);
                        for (int j = 0; j < zomPosition - 1; j++)
                        {
                            player->PlacePlant(1, i, j);
                        }
                    }
                    else if (zomType == 3)        //撑杆跳：用坚果墙或者向日葵垫一下,后面放冰豆
                    {
                        if (PlantCD[3] == 0)
                        {
                            player->PlacePlant(4, i, 7);
                            player->PlacePlant(2, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(1, i, 7);
                            player->PlacePlant(2, i, 0);
                        }
                    }
                    //!sunSupply判断有问题.
                    else if (zomType == 2 || zomType == 4)  //雪车出现或铁桶出现（且阳光不充足），用倭瓜  
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                    }
                    else if (zomType == 5)
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 1);
                        player->PlacePlant(5, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 3);
                    }
                }

                else if (rowZombieNum[i] > 1)
                {
                    bool isCarOrGiant = false;    //是否有雪车和伽刚特尔
                    int* zomPosition = new int[rowZombieNum[i]];
                    int* zomType = new int[rowZombieNum[i]];
                    int a = 0;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        int k = 0;
                        while (zombies[i][j][k] != -1)
                        {
                            zomPosition[a] = k;
                            zomType[a] = zombies[i][j][k];
                            a++;
                            k++;
                        }             //得到这一行的僵尸位置及其种类
                    }

                    for (int j = 0; j < rowZombieNum[i]; j++)
                    {
                        if (zomType[j] == 4 || zomType[j] == 5)
                        {
                            isCarOrGiant = true;
                            break;
                        }
                    }
                    if (isCarOrGiant || rowZombieNum[i] > 2)
                    {
                        player->PlacePlant(5, i, 1);
                        player->PlacePlant(5, i, 2);
                        player->PlacePlant(5, i, 3);
                        player->PlacePlant(5, i, 4);
                        player->PlacePlant(5, i, 5);
                        player->PlacePlant(5, i, 6);
                        player->PlacePlant(5, i, 7);
                    }

                    else if (plants[i][0] == 3 || plants[i][0] == 2 || plants[i][1] == 3 || plants[i][0] == 2)
                    {
                        if (sunSupply)
                        {
                            player->PlacePlant(2, i, 0);
                            player->PlacePlant(2, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(3, i, 0);
                            player->PlacePlant(3, i, 0);
                        }
                    }
                    delete[]zomPosition;
                    delete[]zomType;
                }
                
                for (int j = 0; j <= 5; j++)
                {
                    if (plants[i][j] == 0) {
                        player->PlacePlant(2, i, j);
                        isfull = false;
                        if (!sunSupply)
                            break;
                    }
                    else isfull = true;
                    if (j == 5)
                    {
                        if (isfull)
                        {
                            for (int j = 0; j <= 5; j++)
                            {
                                if (plants[i][j] == 3 && *(player->Camp->getPlantCD() + 2) == 0)
                                {
                                    player->removePlant(i, j);
                                    player->PlacePlant(2, i, j);
                                    if (!sunSupply)
                                        break;
                                }
                            }
                        }
                    }
                }
            }*/

            if(Sun<=800)
            {
                //养经济
                if(time>=8)
                {
                    if (columnFlowerNum[1] < leftRows)
                    {
                        if (plants[i][1] != 1)
                        {
                            player->removePlant(i, 1);
                            player->PlacePlant(1, i, 1);
                        }
                    }
                    else if (columnFlowerNum[5] < leftRows)
                    {
                        if (plants[i][5] != 1)
                        {
                            player->removePlant(i, 5);
                            player->PlacePlant(1, i, 5);
                        }
                    }
                    else if (columnFlowerNum[6] < leftRows)
                    {
                        if (plants[i][6] != 1)
                        {
                            player->removePlant(i, 6);
                            player->PlacePlant(1, i, 6);
                        }
                    }
                }

                if (rowZombieNum[i] == 1)
                {
                    int zomPosition = -1;
                    int zomType = -1;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        if (zombies[i][j][0] != -1)
                        {
                            zomPosition = j;
                            zomType = zombies[i][j][0];  //向日葵1，冰豆2，豌豆3，坚果墙4，辣椒5，倭瓜6
                            break;                      //  普僵1，铁桶2，撑杆3，冰车4，伽刚5
                        }
                    }                   //得到这一个僵尸的种类和位置   
                    if (zomPosition <= 4)        //僵尸较近时，用倭瓜
                    {
                        if (PlantCD[6] == 0)
                        {
                            player->PlacePlant(6, i, 2);
                            //player->PlacePlant(6, i, zomPosition - 1);
                            //player->PlacePlant(6, i, zomPosition);
                            //player->PlacePlant(6, i, zomPosition - 2);
                        }
                        else
                        {
                            //player->PlacePlant(5, i, 0);
                            //player->PlacePlant(5, i, 1);
                            player->PlacePlant(5, i, 2);
                        }
                    }
                    //数值有更改。
                    else if (zomType == 3)      //撑杆跳：用坚果墙或者向日葵垫一下,后面放豌豆
                    {
                        if (PlantCD[1] == 0) 
                        {
                            player->PlacePlant(1, i, 6);
                            player->PlacePlant(3, i, 0);
                            //player->PlacePlant(3, i, 1);
                        }
                        else
                        {
                            player->PlacePlant(4, i, 6);
                            player->PlacePlant(3, i, 0);
                            //player->PlacePlant(3, i, 1);
                        }
                    }

                    else if (zomType == 1)   //普通僵尸，用坚果墙，开始攒阳光
                    {
                        player->PlacePlant(4, i, zomPosition - 1);
                        player->PlacePlant(3, i, 0);
                        //count += 1;//修改为+=1；
                        /*if (count == 1)
                        {
                            producerow = i;
                        }*/
                        //应该加入防御手段。
                        /*for (int j = 1; j < zomPosition - 1; j++)
                        {
                            player->PlacePlant(1, i, j);
                        }*/
                    }

                    else if (zomType == 2 || zomType == 4)  //雪车出现或铁桶出现（且阳光不充足），用倭瓜
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        //player->PlacePlant(6, i, zomPosition);
                        //player->PlacePlant(6, i, zomPosition - 2);
                    }
                    //该分支阳光必然不充足
                    /*
                    else if (zomType == 2 && sunSupply)  //铁桶出现，且阳光充足，用冰豆
                    {
                        player->PlacePlant(2, i, 0);
                        player->PlacePlant(2, i, 1);
                    }*/

                    else if (zomType == 5)   //伽刚特尔，用倭瓜和炸弹
                    {
                        player->PlacePlant(6, i, zomPosition - 1);
                        player->PlacePlant(6, i, zomPosition);
                        player->PlacePlant(6, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 1);
                        player->PlacePlant(5, i, zomPosition - 2);
                        player->PlacePlant(5, i, zomPosition - 3);
                    }
                }
                
                else if (rowZombieNum[i] > 1)
                {
                    bool isCarOrGiant = false;    //是否有雪车和伽刚特尔
                    int* zomPosition = new int[rowZombieNum[i]];
                    int* zomType = new int[rowZombieNum[i]];
                    int a = 0;
                    for (int j = columns - 1; j >= 0; j--)
                    {
                        int k = 0;
                        while (zombies[i][j][k] != -1)
                        {
                            zomPosition[a] = j;
                            zomType[a] = zombies[i][j][k];
                            a++;
                            k++;
                        }             //得到这一行的僵尸位置及其种类
                    }
                    for (int x = 0; x < a; x++)
                    {
                        if (zomPosition[x] <= 4)        //僵尸较近时，用倭瓜
                        {
                            if (PlantCD[6] == 0)
                            {
                                player->PlacePlant(6, i, 2);
                            }
                            else
                            {
                                player->PlacePlant(5, i, 2);
                            }
                        }
                    }

                    for (int j = 0; j < rowZombieNum[i]; j++)
                    {
                        if (zomType[j] == 4 || zomType[j] == 5)
                        {
                            isCarOrGiant = true;
                            break;
                        }
                    }  //判断本行有无雪车和伽刚
                    if (isCarOrGiant || rowZombieNum[i] > 2)
                    {
                        player->PlacePlant(5, i, 1);
                        player->PlacePlant(5, i, 2);
                        player->PlacePlant(5, i, 3);
                        player->PlacePlant(5, i, 4);
                        player->PlacePlant(5, i, 5);
                        player->PlacePlant(5, i, 6);
                        player->PlacePlant(5, i, 7);
                    }
                    //若有雪车或者伽刚，或者僵尸数大于2，放辣椒

                    else if (plants[i][0] == 3 || plants[i][0] == 2 || plants[i][1] == 3 || plants[i][0] == 2)
                    {
                        if (sunSupply)
                        {
                            player->PlacePlant(2, i, 0);
                            //player->PlacePlant(2, i, 0);
                        }
                        else
                        {
                            player->PlacePlant(3, i, 0);
                            player->PlacePlant(3, i, 0);
                        }
                    }
                    delete[]zomPosition;
                    delete[]zomType;
                }
                /*player->PlacePlant(1, producerow, 0);
                player->PlacePlant(1, producerow, 1);
                player->PlacePlant(1, producerow, 2);
                player->PlacePlant(1, producerow, 3);
                player->PlacePlant(1, producerow, 4);
                player->PlacePlant(1, producerow, 5);
                player->PlacePlant(1, producerow, 6);
                player->PlacePlant(1, producerow, 7);
                player->PlacePlant(1, producerow, 8);
                player->PlacePlant(1, producerow, 9);*/

                /*if (Sun < 800)
                {
                    player->PlacePlant(1, producerow, 0);
                    player->PlacePlant(1, producerow, 1);
                    player->PlacePlant(1, producerow, 2);
                    player->PlacePlant(1, producerow, 3);
                    player->PlacePlant(1, producerow, 4);
                    player->PlacePlant(1, producerow, 5);
                    player->PlacePlant(1, producerow, 6);
                    player->PlacePlant(1, producerow, 7);
                    player->PlacePlant(1, producerow, 8);
                    player->PlacePlant(1, producerow, 9);
                }*/
                //要修改
            }
            //阳光数多于1000,开始变更阵型,逐个铲掉生产行的向日葵,然后放上冰豆,再在6或7列补上向日葵
            else if (Sun > 800)
            {
                if(leftLines[i]!=0)
                {
                    if (columnIceNum[0] < leftRows)
                    {
                        if (plants[i][0] != 2 && PlantCD[2] == 0)
                        {
                            player->removePlant(i, 0);
                            player->PlacePlant(2, i, 0);
                        }
                    }
                    else if (columnIceNum[2] < leftRows)
                    {
						if (plants[i][2] != 2 && PlantCD[2] == 0)
                        {
                            player->removePlant(i, 2);
                            player->PlacePlant(2, i, 2);
                        }
                    }
                    else if (columnIceNum[3] < leftRows && PlantCD[2] == 0)
                    {
                        if (plants[i][3] != 2)
                        {
                            player->removePlant(i, 3);
                            player->PlacePlant(2, i, 3);
                        }
                    }
                    else if (columnIceNum[4] < leftRows && PlantCD[2] == 0)
                    {
                        if (plants[i][4] != 2)
                        {
                            player->removePlant(i, 4);
                            player->PlacePlant(2, i, 4);
                        }
                    }
                }

                /*if (PlantCD[1] == 0 && totalFlowerNum >= 6 && plants[i][sb] == 1)
                {
                    player->removePlant(producerow, sb);
                    totalFlowerNum--;

                    player->PlacePlant(1, i, 7);
                    player->PlacePlant(1, i, 6);
                    sb++;
                }
                for (int i = 0; i < rows; i++)
                {
                    if (plants[i][0] != 2)
                    {
                        player->PlacePlant(2, i, 0);
                    }
                }*/
            }
        }
    }

    //僵尸方操作
    if (type == 1)
    {   
        int sun = player->Camp->getSun();
        int* zombieCD = player->Camp->getPlantCD();
        int p = 0;
        //int* leftLines = player->Camp->getLeftLines();
        //std::cout << currentTime1;
        for (int i = 0; i < rows; i++)
        {
            int j = 4 - i;
            if (sun > 850)
            {
                if (j == 4)
                {
                    beginPlace[j] = true;
                }
                if (j == 3 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 2 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 1 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
                if (j == 0 && leftLines[1] == 0 && leftLines[2] == 0 && leftLines[3] == 0 && leftLines[4] == 0)
                {
                    beginPlace[j] = true;
                }
            }
        }
        if (time == 5)
        {
            if (totalFlowerNum != 0)
            {
                isFlower = true;
            }
            if (totalNutNum != 0)
            {
                isNut = true;
            }
            if (totalPumpkinNum != 0)
            {
                isPumpkin = true;
            }
            if (totalPeaNum != 0)
            {
                isPea = true;
            }
        }

        //开局摆放
        else if (time == 6)
        {
            //没有摆放特征植物
            if (!isNut && !isPea && !isPumpkin)
            {
                //摆放了向日葵
                if (isFlower)
                {
                    for (int i = 0; i < rows; i++)
                    {
                        if (rowFlowerNum[i] != 0)
                        {
                            player->PlaceZombie(2, i);
                            if (i - 1 == -1 || i + 1 == 5)
                            {
                                player->PlaceZombie(1, 1);
                                player->PlaceZombie(3, 2);
                            }
                            else
                            {
                                player->PlaceZombie(1, i - 1);
                                player->PlaceZombie(3, i + 1);
                            }
                        }
                    }
                }
                //未摆放向日葵
                else
                {
                    player->PlaceZombie(1, 3);
                    player->PlaceZombie(2, 2);
                    player->PlaceZombie(3, 1);                
                }
            }
            //摆放了特征植物
            else
            {
                if (isPea && !isNut && !isPumpkin)//仅有豌豆射手的情况
                {
                    for (int i = 0; i < rows; i++)
                    {
                        if (rowPeaNum[i] != 0)
                        {
                            player->PlaceZombie(2, i);
                            if (i - 1 == -1 || i + 1 == 5)
                            {
                                player->PlaceZombie(1, 1);
                                player->PlaceZombie(3, 2);
                            }
                            else
                            {
                                player->PlaceZombie(1, i - 1);
                                player->PlaceZombie(3, i + 1);
                            }
                        }
                    }
                }

                else if (isNut || isPumpkin)//仅有坚果或仅有倭瓜或仅有坚果和倭瓜
                {
					for (int i = 0; i < rows; i++)
					{
						if (rowNutNum[i] == 0 && rowPumpkinNum[i] == 0)
						{
                            if (rowPeaNum != 0)
                            {
                                player->PlaceZombie(2, i);
                                rowBegin[i] += 1;
                            }
                            else
                            {
                                if (zombieCD[1] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(1, i);
                                    rowBegin[i] += 1;
                                }
                                else if (zombieCD[2] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(2, i);
                                    rowBegin[i] += 1;
                                }
                                else if (zombieCD[3] != 0 && rowBegin[i] == 0)
                                {
                                    player->PlaceZombie(3, i);
                                    rowBegin[i] += 1;
                                }
                            }
						}
					}
                }
            }
        }

        else if (time > 6)
        {    
            for(int i = 0;i<rows;i++)
            {
                if (rowPeaNum[i] == 0 && rowNutNum[i] == 0 && rowPumpkinNum[i] == 0&&rowIceNum[i]==0)
                {
                    player->PlaceZombie(1, i);
                }
            }
			for (int i = 0; i < 5; i++)
			{
				int j = 4 - i;
				if (beginPlace[j] && rowIceNum[j] <= 1)
				{
					if (rowZombieNum[j] <= 1)
					{
						player->PlaceZombie(5, j);
					}
				}
				else if (beginPlace[j] && rowIceNum[j] > 1)
				{
					if (rowZombieNum[j] <= 2)
					{
						player->PlaceZombie(5, j);
					}
				}
			}
        }
    }
}
