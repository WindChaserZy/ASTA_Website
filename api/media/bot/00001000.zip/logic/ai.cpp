/*
 * @功能模块与目的: 
 * @版本: 
 * @开发者: 高嘉伟(gaojw20@mails.tsinghua.edu.cn)
 * @Date: 2022-04-01 00:33:12
 * @版权信息: 
 * @最后修改者: 高嘉伟(gaojw20@mails.tsinghua.edu.cn)
 * @LastEditTime: 2022-04-24 01:20:21
 * @修改日志: 
 * @备注: 
 */
#include "ai.h"
//选手代码在下方填入
void player_ai(IPlayer* player) {
    int Type = (player->Camp->getCurrentType());

    if (Type == 0) {//plants
        player->PlacePlant(2,1,2);
        return;
    }

    if(Type == 1){
        player->PlaceZombie(2,1);
        return;
    }
}