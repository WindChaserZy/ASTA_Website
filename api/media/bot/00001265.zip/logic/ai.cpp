#include"ai.h"
#include <iostream> 
#include <stdlib.h>
int zb[6] = { 0,270,820,200,1600,3000 };
int chooseplant[6] = { 1,1,2,1,3,4 };
int placebox[4] = { 0,0,3,4 };
int placex = -1;
int placey = -1;
int forceat1 = -1;
int forceat2 = -1;
int protect[5];
int need[5];
int plantpower[5];
int plantdefence[5];
int plantvalue[5];
int zombiePH(int m_type) {
	switch (m_type)
	{
	case 0: return 0;
		break;
	case 1:return 270;
		break;
	case 2:return 1370;
		break;
	case 3: return 500;
		break;
	case 4:return 1350;
		break;
	case 5:return 3000;
		break;
	default:
		break;
	}
}

int PlantAttack(int m_type) {
	switch (m_type)
	{
	case 0:return 0;
		break;
	case 1:return 0;
		break;
	case 2:return 26;
		break;
	case 3:return 20;
		break;
	case 4:return 0;
		break;
	case 5:return 1800;
		break;
	case 6:return 1800;
		break;
	default:
		break;
	}
}

int pdetr(IPlayer* player, int row)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	for (int j = 0;j < 10;j++)
	{
		int k = 0;
		while (Zombies[row][j][k] != -1)
			k++;
		ans += k;
	}
	return ans;
}
int pdetsp(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int ans = 0;
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		ans += zb[Zombies[row][col][k]];
		k++;
	}
	return ans;
}

int search1(IPlayer* player)
{
	int decide_row = 0;
	int rowzombie = pdetr(player, 0);
	for (int i = 1;i <= 4;i++)
	{
		if (pdetr(player, i) < rowzombie)
		{
			rowzombie = pdetr(player, i);
			decide_row = i;
		}
	}
	return decide_row;
}
int search1p(IPlayer* player)//返回土豆的行
{
	int** Plants = player->Camp->getCurrentPlants();
	for (int i = 0;i <= 4;i++)
	{
		for (int j = 0;j <= 9;j++)
			if (Plants[i][j] == 4)
			{
				return i;
			}
	}
	return -1;
}
int search1pp(IPlayer* player, int roww)//返回土豆的列
{
	int** Plants = player->Camp->getCurrentPlants();
	for (int j = 0;j <= 9;j++)
		if (Plants[roww][j] == 4)
		{
			return j;
		}
	return -1;
}
void procheck(IPlayer* player, int row)
{
	int** Plants = player->Camp->getCurrentPlants();
	for (int i = 0;i <= 9;i++)
	{
		if (Plants[row][i] == 4)
		{
			protect[row] = 1;
			return;
		}
	}
	protect[row] = 0;
	return;
}
int search4(IPlayer* player)
{
	for (int i = 0;i < 5;i++)
		if (protect[i] == 0 && need[i] != 0)return i;
	return -1;
}
int iss(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 4)return 1;
		k++;
	}
	return 0;
}
int isj(IPlayer* player, int row, int col)
{
	int*** Zombies = player->Camp->getCurrentZombies();
	int k = 0;
	while (Zombies[row][col][k] != -1)
	{
		if (Zombies[row][col][k] == 5)return 1;
		k++;
	}
	return 0;
}

void checkneed(IPlayer* player)
{
	int** Plants = player->Camp->getCurrentPlants();

	for (int i = 0;i < 5;i++)
	{
		need[i] = 0;
		for (int j = 0;j < 10;j++)
			need[i] += Plants[i][j];
	}
	return;
}
void checkpower(IPlayer* player)
{
	int** Plants = player->Camp->getCurrentPlants();
	for (int i = 0;i < 5;i++)
	{
		for (int j = 0;j <= 9;j++)
		{
			if (Plants[i][j] == 2)plantpower[i] += 60;
			if (Plants[i][j] == 3)plantpower[i] += 20;
			if (Plants[i][j] == 4)plantdefence[i] += 1;
			if (Plants[i][j] == 1)plantvalue[i] += 5;
			if (Plants[i][j] == 6)plantpower[i] += 10;
		}
		plantpower[i] = plantpower[i] * plantdefence[i] - plantvalue[i];
	}
}
int findweak()
{
	int po = plantpower[0];
	int ta = 0;
	for (int i = 1;i <= 4;i++)
	{
		if (po > plantpower[i])
		{
			po = plantpower[i];
			ta = i;
		}
	}
	return ta;
}
void player_ai(IPlayer* player)
{
	int Type = player->Camp->getCurrentType();
	int time = player->getTime();
	int Sun = player->Camp->getSun();
	int** Plants = player->Camp->getCurrentPlants();
	int* LeftLines = player->Camp->getLeftLines();
	int* PlantCD = player->Camp->getPlantCD();
	int*** Zombie = player->Camp->getCurrentZombies();
	checkneed(player);

	if (Type == 0)
	{
		srand(time);
		//当 前 为 植 物方 
		for (int i = 0;i < 5;i++)
		{
			for (int j = 0;j < 10;j++)
			{
				if (pdetr(player, i) >= 2&&time<=499)
					player->PlacePlant(5, i, 9);
				if (j <= 5 && (pdetsp(player, i, j) >= 200))
				{
					player->PlacePlant(5, i, 9);
				}
				//if(time>=400&& (pdetsp(player, i, j) >= 300 && j <= 6))
				//	player->PlacePlant(5, i, 9);
				if (pdetsp(player, i, j) >= 1000 || (pdetsp(player, i, j) > plantpower[i] * 10 && j <= 7) || (Zombie[i][j][0] == 3&& plantpower[i]<=20))
				{
					player->PlacePlant(6, i, j - 1);
				}
				if (pdetsp(player, i, j) <= 1500 && pdetsp(player, i, j) >= 100)
				{
					player->PlacePlant(4, i, j - 1);
				}
			}
		}
		player->PlacePlant(1, rand() % 5, 1);
		player->PlacePlant(1, rand() % 5, 2);
		if (time > 300)
			player->PlacePlant(1, rand() % 5, 5);
		if (Sun > 500 && PlantCD[1] == 0)
		{
			placex = rand() % 5;
			if (time <= 800)
				placey = placebox[rand() % 4];
			else
				placey = 2 + rand() % 3;
			//if (placey == 1)placey = 2;
			if (Plants[placex][placey] != 2)
			{
				player->removePlant(placex, placey);
				player->PlacePlant(2, placex, placey);
			}
		}
		
		for (int i = 0;i <= 4;i++)
			if (time >= 500)
			{
				player->PlacePlant(6, i, 6);
			}
	/*	for (int i = 0;i <= 4;i++)
			if (time >= 500)
			{
				player->PlacePlant(6, i, 8);
			}*/
	}
	if (Type == 1)
	{
		if (time == 1)return;
		for (int i = 0;i <= 4;i++)
		{
			plantdefence[i] = 1;
			plantpower[i] = 0;
			plantvalue[i] = 0;
		}
		checkpower(player);
		for (int i = 0;i <= 4;i++)
		{
			if (LeftLines[i] == 0)
				plantpower[i] = 10000;
		}
		int tar = findweak();
		if (time == 482)player->PlaceZombie(2, tar);
		if (time == 493)
		{
			player->PlaceZombie(4, tar);
		}
		if (time >= 200 && time <= 497)return;
		if (time == 498)player->PlaceZombie(5, tar);
		if (time > 498 && time <= 503)return;
		if (time == 504)
		{
			player->PlaceZombie(4, tar);
			player->PlaceZombie(5, tar);
		}


		if (time == 965)player->PlaceZombie(5, tar);
		if (time == 972)player->PlaceZombie(4, tar);
		if (time >= 800 && time <= 997)return;
		if (time == 998)
		{
			player->PlaceZombie(4, tar);
			player->PlaceZombie(5, tar);

		}
		if (time > 998 && time <= 1003)return;
		if (time >= 1004 && time <= 1080)
		{
			player->PlaceZombie(3, tar);
			player->PlaceZombie(4, tar);
			player->PlaceZombie(5, tar);
			player->PlaceZombie(2, tar);
		}
		if (time == 1467)player->PlaceZombie(5, tar);
		if (time == 1472)player->PlaceZombie(4, tar);
		if (time >= 1081 && time <= 1497)return;
		if (time >= 1498 && time <= 1525)
		{
			player->PlaceZombie(2, tar);
			player->PlaceZombie(4, tar);
			player->PlaceZombie(5, tar);
		}
		if (time >= 1526 && time <= 1550)
		{
			player->PlaceZombie(3, tar);
			player->PlaceZombie(4, tar);
			player->PlaceZombie(5, tar);
		}

		if (time > 1550 && time < 1750)return;
		if (time >= 1751 && Sun >= 500)
		{
			player->PlaceZombie(2, tar);
			player->PlaceZombie(5, tar);
			player->PlaceZombie(4, tar);
			player->PlaceZombie(3, tar);
		}


		if (plantpower[tar] <= 0 && plantdefence[tar]>1)
		{
			player->PlaceZombie(3, tar);
			return;
		}
		if (plantpower[tar] <= 0 && plantdefence[tar]==1)
		{
			player->PlaceZombie(1, tar);
			return;
		}
		if (plantpower[tar] <= 60 && plantdefence[tar] == 1)
		{
			if(time<=100)
			player->PlaceZombie(2, tar);
			else
			player->PlaceZombie(5, tar);
			return;
		}

	}
	return;
}